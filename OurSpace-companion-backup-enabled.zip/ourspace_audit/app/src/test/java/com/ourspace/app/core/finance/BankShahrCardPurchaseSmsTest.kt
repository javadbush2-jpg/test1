package com.ourspace.app.core.finance

import com.ourspace.app.core.time.PersianDateFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BankShahrCardPurchaseSmsTest {
    private val sampleSms = """خريد با کارت

برداشت از:4001002593265

مبلغ:152,000,000ريال

موجودي:467,924 ريال

1405/07/13 09:04:09"""

    @Test
    fun bankShahrCardPurchaseExtractsAccountExpenseAndTimestamp() {
        val template = UserSmsTemplate(
            name = "شهر · خرید با کارت",
            mustContain = "خريد با کارت,برداشت از:,مبلغ:",
            amountPattern = "برداشت از:{account}\nمبلغ:{amount}ريال\nموجودي:{balance} ريال\n{date} {time}",
            kind = "EXPENSE",
            amountIsRial = true
        )
        val result = SmsTemplateStore.testTemplate(template, sampleSms)

        assertTrue(result.matched)
        assertEquals(15_200_000L, result.amount ?: -1L)
        assertEquals("EXPENSE", result.kind)
        assertEquals("4001002593265", result.extras["حساب"])
        assertEquals("467٬924", result.extras["مانده"])
        assertEquals("1405/07/13", result.extras["تاریخ"])
        assertEquals("09:04:09", result.extras["ساعت"])
        assertEquals(
            PersianDateFormatter.toEpochMillis(1405, 7, 13, 9, 4) + 9_000L,
            result.transactionDateMillis
        )
    }
}
