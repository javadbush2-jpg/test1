package com.ourspace.app.core.finance

import com.ourspace.app.core.time.PersianDateFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BankShahrGroupDepositSmsTest {
    private val sampleSms = """واريز گروهي

واريز به :7001025513733

مبلغ:566,992,973ريال

موجودي:566,992,973 ريال

1405/08/4 09:58:11"""

    @Test
    fun bankShahrGroupDepositExtractsAccountAmountBalanceAndTimestamp() {
        val template = UserSmsTemplate(
            name = "شهر · واریز گروهی",
            mustContain = "واريز گروهي,مبلغ:",
            amountPattern = "واريز به :{account}\nمبلغ:{amount}ريال\nموجودي:{balance} ريال\n{date} {time}",
            kind = "INCOME",
            amountIsRial = true
        )
        val result = SmsTemplateStore.testTemplate(template, sampleSms)

        assertTrue(result.matched)
        assertEquals(56_699_297L, result.amount ?: -1L)
        assertEquals("INCOME", result.kind)
        assertEquals("7001025513733", result.extras["حساب"])
        assertEquals("566٬992٬973", result.extras["مانده"])
        assertEquals("1405/08/4", result.extras["تاریخ"])
        assertEquals("09:58:11", result.extras["ساعت"])
        assertEquals(
            PersianDateFormatter.toEpochMillis(1405, 8, 4, 9, 58) + 11_000L,
            result.transactionDateMillis
        )
    }
}
