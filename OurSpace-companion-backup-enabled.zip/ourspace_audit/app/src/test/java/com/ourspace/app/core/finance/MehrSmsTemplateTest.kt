package com.ourspace.app.core.finance

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MehrSmsTemplateTest {
    private val senderCode = "300102513345478001"
    private val depositSms = """$senderCode

49,500,000+

1405/7/30-11:51

مانده:294,046,569"""

    @Test
    fun depositTemplateExtractsSignedAmountNotSenderDateOrBalance() {
        val result = SmsTemplateStore.testTemplate(
            template(kind = "INCOME", pattern = "{amount}+"),
            depositSms,
            senderCode
        )

        assertTrue(result.matched)
        assertEquals(4_950_000L, result.amount ?: -1L)
        assertEquals("INCOME", result.kind)
    }

    @Test
    fun withdrawalTemplateDoesNotReadDateDayAsTheAmount() {
        val withdrawalSms = depositSms.replace("49,500,000+", "49,500,000-")
        val result = SmsTemplateStore.testTemplate(
            template(kind = "EXPENSE", pattern = "{amount}-"),
            withdrawalSms,
            senderCode
        )

        assertTrue(result.matched)
        assertEquals(4_950_000L, result.amount ?: -1L)
        assertEquals("EXPENSE", result.kind)
    }

    @Test
    fun actualMehrWithdrawalSampleExtracts701100Toman() {
        val withdrawalSms = """$senderCode

7,011,000-

1405/8/8-9:19

مانده:236,974,569"""
        val result = SmsTemplateStore.testTemplate(
            template(kind = "EXPENSE", pattern = "{amount}-"),
            withdrawalSms,
            senderCode
        )
        val parsed = BankSmsParser.parseSignedLineStyle(withdrawalSms, senderCode)

        assertTrue(result.matched)
        assertEquals(701_100L, result.amount ?: -1L)
        assertEquals("EXPENSE", result.kind)
        assertEquals(701_100L, parsed?.amount ?: -1L)
        assertEquals("EXPENSE", parsed?.kind)
    }

    @Test
    fun builtInMehrParserRecognizesThePlusSignAsIncome() {
        val parsed = BankSmsParser.parseSignedLineStyle(depositSms, senderCode)

        assertEquals(4_950_000L, parsed?.amount ?: -1L)
        assertEquals("INCOME", parsed?.kind)
    }

    private fun template(kind: String, pattern: String) = UserSmsTemplate(
        name = "بانک مهر",
        senderContains = senderCode,
        mustContain = "مانده",
        amountPattern = pattern,
        kind = kind,
        amountIsRial = true
    )
}
