package com.ourspace.app.core.finance

import com.ourspace.app.core.time.PersianDateFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BankShahrFeeSmsTest {
    private val sampleSms = """کارمزد

برداشت از:7001025513733

مبلغ:375,000ريال

موجودي:566,617,973 ريال

1405/08/7 08:19:21"""

    @Test
    fun bankShahrFeeWithdrawalExtractsAmountBalanceAndTimestampWithSeconds() {
        val template = UserSmsTemplate(
            name = "شهر · کارمزد برداشت ریالی",
            mustContain = "مبلغ:,موجود",
            amountPattern = "مبلغ:{amount}ريال\nموجودي:{balance} ريال\n{date} {time}",
            kind = "EXPENSE",
            amountIsRial = true
        )
        val result = SmsTemplateStore.testTemplate(template, sampleSms)

        assertTrue(result.matched)
        assertEquals(37_500L, result.amount ?: -1L)
        assertEquals("EXPENSE", result.kind)
        assertEquals("566٬617٬973", result.extras["مانده"])
        assertEquals("1405/08/7", result.extras["تاریخ"])
        assertEquals("08:19:21", result.extras["ساعت"])
        assertEquals(
            PersianDateFormatter.toEpochMillis(1405, 8, 7, 8, 19) + 21_000L,
            result.transactionDateMillis
        )
    }
}
