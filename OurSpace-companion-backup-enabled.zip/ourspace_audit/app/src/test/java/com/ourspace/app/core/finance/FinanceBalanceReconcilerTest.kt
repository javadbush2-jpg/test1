package com.ourspace.app.core.finance

import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.database.FinancialAccountEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FinanceBalanceReconcilerTest {
    @Test
    fun reportsDifferenceAndAdjustsOnlyThatAccountsOpeningBalance() {
        val first = account("first", 1_000L)
        val second = account("second", 500L)
        val existing = listOf(
            transaction("prior-income", "first", "INCOME", 300L, 10L),
            transaction("later-expense", "first", "EXPENSE", 200L, 30L)
        )
        val imports = listOf(
            SmsFinanceImport(
                accountId = "first",
                kind = "EXPENSE",
                amount = 100L,
                category = "خرید",
                note = "sms",
                occurredAt = 20L,
                reportedBalanceToman = 1_250L
            ),
            SmsFinanceImport(
                accountId = "second",
                kind = "INCOME",
                amount = 80L,
                category = "واریز",
                note = "sms",
                occurredAt = 20L,
                reportedBalanceToman = 580L
            )
        )

        val result = FinanceBalanceReconciler.reconcile(listOf(first, second), existing, imports)

        val mismatch = result.checks.single { it.accountId == "first" }
        assertEquals(1_300L, mismatch.localBalanceBefore)
        assertEquals(1_350L, mismatch.bankImpliedPreviousBalance)
        assertEquals(1_200L, mismatch.expectedBalanceAfter)
        assertEquals(50L, mismatch.difference)
        assertEquals(0L, result.checks.single { it.accountId == "second" }.difference)
        assertTrue(result.hasDiscrepancies)
        assertEquals(1_050L, result.adjustments.single { it.accountId == "first" }.correctedOpeningBalance)
        assertEquals(500L, result.adjustments.single { it.accountId == "second" }.correctedOpeningBalance)
    }

    @Test
    fun tracksTransfersAgainstEachAccountsOwnBalance() {
        val source = account("source", 1_000L)
        val target = account("target", 200L)
        val transfer = transaction("transfer", "source", "TRANSFER", 250L, 10L, "target")
        val imports = listOf(
            SmsFinanceImport("source", "EXPENSE", 250L, "جابجایی", "sms", 20L, 500L),
            SmsFinanceImport("target", "INCOME", 250L, "جابجایی", "sms", 20L, 700L)
        )

        val result = FinanceBalanceReconciler.reconcile(listOf(source, target), listOf(transfer), imports)

        assertFalse(result.hasDiscrepancies)
        assertTrue(result.checks.all { it.difference == 0L })
        assertTrue(result.adjustments.all { it.difference == 0L })
    }

    private fun account(id: String, opening: Long) = FinancialAccountEntity(
        id = id,
        name = id,
        openingBalance = opening,
        createdAt = 1L,
        updatedAt = 1L
    )

    private fun transaction(
        id: String,
        accountId: String,
        kind: String,
        amount: Long,
        occurredAt: Long,
        targetAccountId: String? = null
    ) = FinanceTransactionEntity(
        id = id,
        accountId = accountId,
        targetAccountId = targetAccountId,
        kind = kind,
        amount = amount,
        category = "test",
        payerDeviceId = "device",
        occurredAt = occurredAt,
        createdAt = occurredAt,
        updatedAt = occurredAt
    )
}
