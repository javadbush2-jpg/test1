package com.ourspace.app.core.finance

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialAssetCalculatorTest {
    @Test
    fun calculatesGoldAndDollarValueInTomanFromPersianInputs() {
        val inputs = FinancialAssetInputs(
            goldGrams = "۲٫۵",
            goldRateTomanPerGram = "۷٬۲۰۰٬۰۰۰",
            dollars = "100",
            dollarRateToman = "65,000"
        )

        val values = FinancialAssetCalculator.calculate(inputs)

        assertEquals(18_000_000L, values.goldValueToman)
        assertEquals(6_500_000L, values.dollarValueToman)
        assertEquals(24_500_000L, values.totalToman)
        assertEquals(25_500_000L, FinancialAssetCalculator.totalWealthToman(1_000_000L, inputs))
    }

    @Test
    fun calculatesFullHalfAndQuarterCoinValuesAndIncludesThemInPortfolioTotal() {
        val values = FinancialAssetCalculator.calculate(
            FinancialAssetInputs(
                fullCoins = "2",
                fullCoinRateToman = "۵۰٬۰۰۰٬۰۰۰",
                halfCoins = "۱",
                halfCoinRateToman = "۲۵۰۰۰۰۰۰",
                quarterCoins = "۲",
                quarterCoinRateToman = "۱۲۵۰۰۰۰۰"
            )
        )

        assertEquals(100_000_000L, values.fullCoinValueToman)
        assertEquals(25_000_000L, values.halfCoinValueToman)
        assertEquals(25_000_000L, values.quarterCoinValueToman)
        assertEquals(150_000_000L, values.totalToman)
    }

    @Test
    fun rejectsNegativeOrNonNumericInputAndRoundsFractionalToman() {
        assertFalse(FinancialAssetCalculator.isValidNumber("-2"))
        assertFalse(FinancialAssetCalculator.isValidNumber("دو"))
        assertTrue(FinancialAssetCalculator.isValidNumber(""))
        assertEquals(1L, FinancialAssetCalculator.valueToman("0.5", "1"))
    }
}
