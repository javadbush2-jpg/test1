package com.ourspace.app.core.finance

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BankSmsReviewGateTest {
    @Test
    fun genericShoppingMessageWithoutBankEvidenceIsExcluded() {
        val body = "پیشنهاد خرید ویژه؛ مبلغ 125,000 تومان"
        val parsed = BankSmsParser.parse(body)

        assertNotNull(parsed)
        assertFalse(BankSmsParser.isReviewWorthy(parsed!!, body, ""))
    }

    @Test
    fun nearMatchWithTransactionAmountAndBalanceIsKeptForReview() {
        val body = "برداشت از حساب، مبلغ 125,000ريال؛ موجودي:500,000 ريال"
        val parsed = BankSmsParser.parse(body)

        assertNotNull(parsed)
        assertTrue(BankSmsParser.isReviewWorthy(parsed!!, body, ""))
    }

    @Test
    fun exactUserTemplateMatchDoesNotNeedGenericHeuristics() {
        val parsed = parsed(templateId = "user:mehr-withdrawal", confidence = 0.96f)

        assertTrue(BankSmsParser.isReviewWorthy(parsed, "مبلغ 125,000", ""))
    }

    private fun parsed(templateId: String, confidence: Float) =
        BankSmsParser.ParsedSmsTransaction(
            amount = 12_500L,
            kind = "EXPENSE",
            category = "سایر",
            note = "",
            confidence = confidence,
            templateId = templateId
        )
}
