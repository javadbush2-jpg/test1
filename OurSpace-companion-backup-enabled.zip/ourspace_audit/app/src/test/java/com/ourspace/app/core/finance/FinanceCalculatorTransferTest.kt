package com.ourspace.app.core.finance

import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.time.PersianDateFormatter
import org.junit.Assert.assertEquals
import org.junit.Test

class FinanceCalculatorTransferTest {
    @Test
    fun transferMovesMoneyBetweenOwnAccountsWithoutChangingTotalWealth() {
        val source = FinancialAccountEntity(
            id = "source",
            name = "حساب اول",
            openingBalance = 1_000_000L,
            createdAt = 1L,
            updatedAt = 1L
        )
        val target = FinancialAccountEntity(
            id = "target",
            name = "حساب دوم",
            openingBalance = 500_000L,
            createdAt = 1L,
            updatedAt = 1L
        )
        val now = System.currentTimeMillis()
        val transfer = FinanceTransactionEntity(
            id = "transfer",
            accountId = source.id,
            targetAccountId = target.id,
            kind = "TRANSFER",
            amount = 200_000L,
            category = "جابجایی",
            payerDeviceId = "device",
            occurredAt = now,
            createdAt = now,
            updatedAt = now
        )

        assertEquals(800_000L, FinanceCalculator.accountBalance(source, listOf(transfer)))
        assertEquals(700_000L, FinanceCalculator.accountBalance(target, listOf(transfer)))
        assertEquals(1_500_000L, FinanceCalculator.totalBalance(listOf(source, target), listOf(transfer)))
        assertEquals(
            FinanceCalculator.PeriodTotals(0L, 0L),
            FinanceCalculator.periodTotals(listOf(transfer), PersianDateFormatter.jalaliMonthKey(now))
        )
    }
}
