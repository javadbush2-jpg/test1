package com.ourspace.app.core.finance

import com.ourspace.app.core.database.FinancialAccountEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FinancialAccountMatcherTest {
    private fun account(
        id: String,
        cardNumber: String = "",
        accountNumber: String = "",
        isArchived: Boolean = false,
        isDeleted: Boolean = false
    ) = FinancialAccountEntity(
        id = id,
        name = id,
        cardNumber = cardNumber,
        accountNumber = accountNumber,
        isArchived = isArchived,
        isDeleted = isDeleted,
        createdAt = 1L,
        updatedAt = 1L
    )

    @Test
    fun matchesFullCardNumberEvenWhenSmsUsesPersianDigits() {
        val accounts = listOf(
            account("first", cardNumber = "6037990012345678"),
            account("second", cardNumber = "6274123412349876")
        )

        assertEquals("first", FinancialAccountMatcher.matchId(accounts, "کارت ۶۰۳۷۹۹۰۰۱۲۳۴۵۶۷۸ برداشت شد"))
    }

    @Test
    fun matchesMaskedCardSuffixNearCardLabel() {
        val accounts = listOf(
            account("household", cardNumber = "6037990012345678"),
            account("savings", accountNumber = "123456789001")
        )

        assertEquals("household", FinancialAccountMatcher.matchId(accounts, "برداشت از کارت: **** **** **** 5678"))
        assertEquals("savings", FinancialAccountMatcher.matchId(accounts, "واریز به حساب شماره 9001"))
    }

    @Test
    fun doesNotGuessWhenOnlyAmbiguousDigitsArePresent() {
        val accounts = listOf(
            account("first", cardNumber = "6037990012345678"),
            account("second", cardNumber = "6274123412345678")
        )

        assertNull(FinancialAccountMatcher.matchId(accounts, "خرید انجام شد؛ شماره کارت 5678"))
    }

    @Test
    fun ignoresArchivedOrDeletedAccounts() {
        val accounts = listOf(account("old", cardNumber = "6037990012345678", isArchived = true))

        assertNull(FinancialAccountMatcher.matchId(accounts, "کارت 6037990012345678"))
    }
}
