package com.ourspace.app.core.sync

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class IncrementalSyncRetryIdTest {
    @Test
    fun transportIdIsStableWithinAttemptButRotatesForRetry() {
        val firstAttempt = listOf("financeAccounts:a:101:attempt-1", "sharedDebts:b:202:attempt-1")
        val firstId = IncrementalSyncCodec.stableTransportMessageId(firstAttempt)

        assertEquals(
            firstId,
            IncrementalSyncCodec.stableTransportMessageId(firstAttempt.reversed())
        )
        assertNotEquals(
            firstId,
            IncrementalSyncCodec.stableTransportMessageId(
                listOf("financeAccounts:a:101:attempt-2", "sharedDebts:b:202:attempt-2")
            )
        )
    }
}
