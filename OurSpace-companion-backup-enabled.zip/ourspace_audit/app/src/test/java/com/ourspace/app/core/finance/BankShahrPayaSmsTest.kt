package com.ourspace.app.core.finance

import com.ourspace.app.core.time.PersianDateFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BankShahrPayaSmsTest {
    private val sampleSms = """انتقال وجه پايا

واريز به:4001002593265

مبلغ:134,179,000ريال

موجودي:134,646,924ريال

1405/08/6 18:56:39"""

    @Test
    fun bankShahrPayaTransferExtractsIncomeBalanceAndTimestampWithSeconds() {
        val template = UserSmsTemplate(
            name = "شهر · واریز پایا",
            mustContain = "واريز به:,مبلغ:",
            amountPattern = "واريز به:{account}\nمبلغ:{amount}ريال\nموجودي:{balance}ريال\n{date} {time}",
            kind = "INCOME",
            amountIsRial = true
        )
        val result = SmsTemplateStore.testTemplate(template, sampleSms)

        assertTrue(result.matched)
        assertEquals(13_417_900L, result.amount ?: -1L)
        assertEquals("INCOME", result.kind)
        assertEquals("4001002593265", result.extras["حساب"])
        assertEquals("134٬646٬924", result.extras["مانده"])
        assertEquals("1405/08/6", result.extras["تاریخ"])
        assertEquals("18:56:39", result.extras["ساعت"])
        assertEquals(
            PersianDateFormatter.toEpochMillis(1405, 8, 6, 18, 56) + 39_000L,
            result.transactionDateMillis
        )
    }
}
