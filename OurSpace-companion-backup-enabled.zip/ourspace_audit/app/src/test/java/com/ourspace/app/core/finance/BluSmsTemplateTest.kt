package com.ourspace.app.core.finance

import com.ourspace.app.core.time.PersianDateFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BluSmsTemplateTest {
    private val sampleSms = """واریز پول

پریسا عزیز، 7,000,000ریال به حساب شما نشست.

موجودی: 1,070,650,159 ریال

۹:۱۹

۱۴۰۵.۰۸.۰۸"""

    @Test
    fun bluDepositExtractsTomanAmountBalanceAndJalaliTimestamp() {
        val template = UserSmsTemplate(
            name = "بلو · واریز ریالی",
            mustContain = "موجودی",
            amountPattern = "{amount}ریال به حساب شما نشست.\nموجودی: {balance} ریال\n{time}\n{date}",
            kind = "INCOME",
            amountIsRial = true
        )
        val result = SmsTemplateStore.testTemplate(template, sampleSms)

        assertTrue(result.matched)
        assertEquals(700_000L, result.amount ?: -1L)
        assertEquals("INCOME", result.kind)
        assertEquals("1٬070٬650٬159", result.extras["مانده"])
        assertEquals("9:19", result.extras["ساعت"])
        assertEquals("1405.08.08", result.extras["تاریخ"])
        assertEquals(
            PersianDateFormatter.toEpochMillis(1405, 8, 8, 9, 19),
            result.transactionDateMillis
        )
    }

    @Test
    fun bluWithdrawalExtractsTomanAmountBalanceAndJalaliTimestamp() {
        val withdrawalSms = """برداشت پول

پریسا عزیز، 7,010,000ریال از حساب شما پرید.

موجودی: 1,063,650,159 ریال

۱۵:۴۹

۱۴۰۵.۰۸.۰۷"""
        val template = UserSmsTemplate(
            name = "بلو · برداشت ریالی",
            mustContain = "موجودی",
            amountPattern = "{amount}ریال از حساب شما پرید.\nموجودی: {balance} ریال\n{time}\n{date}",
            kind = "EXPENSE",
            amountIsRial = true
        )
        val result = SmsTemplateStore.testTemplate(template, withdrawalSms)

        assertTrue(result.matched)
        assertEquals(701_000L, result.amount ?: -1L)
        assertEquals("EXPENSE", result.kind)
        assertEquals("1٬063٬650٬159", result.extras["مانده"])
        assertEquals("15:49", result.extras["ساعت"])
        assertEquals("1405.08.07", result.extras["تاریخ"])
        assertEquals(
            PersianDateFormatter.toEpochMillis(1405, 8, 7, 15, 49),
            result.transactionDateMillis
        )
    }
}
