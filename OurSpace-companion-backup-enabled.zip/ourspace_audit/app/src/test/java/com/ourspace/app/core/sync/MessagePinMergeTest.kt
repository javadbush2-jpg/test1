package com.ourspace.app.core.sync

import com.ourspace.app.core.database.MessageEntity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MessagePinMergeTest {
    @Test
    fun newerUnpinWinsOverOlderPinEvenWhenOtherMessageFieldsAreNewer() {
        val pinned = message(isPinned = true, pinnedUpdatedAt = 200L, updatedAt = 300L)
        val unpinned = message(isPinned = false, pinnedUpdatedAt = 250L, updatedAt = 900L)

        assertFalse(mergeMessageState(pinned, unpinned).isPinned)
        assertFalse(mergeMessageState(unpinned, pinned).isPinned)
    }

    @Test
    fun equalTimestampConflictResolvesIdenticallyOnBothDevices() {
        val pinned = message(isPinned = true, pinnedUpdatedAt = 500L, updatedAt = 500L)
        val unpinned = message(isPinned = false, pinnedUpdatedAt = 500L, updatedAt = 500L)

        assertTrue(mergeMessageState(pinned, unpinned).isPinned)
        assertTrue(mergeMessageState(unpinned, pinned).isPinned)
    }

    private fun message(
        isPinned: Boolean,
        pinnedUpdatedAt: Long,
        updatedAt: Long
    ) = MessageEntity(
        id = "message-1",
        senderDeviceId = "device-1",
        text = "پیام آزمایشی",
        isPinned = isPinned,
        pinnedUpdatedAt = pinnedUpdatedAt,
        createdAt = 100L,
        updatedAt = updatedAt
    )
}
