package com.ourspace.app.core.finance

import android.content.Context
import android.content.SharedPreferences
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.database.SyncChangeEntity
import com.ourspace.app.core.server.HostServerService
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * دسته‌بندی‌های هزینه/خرید و درآمد.
 * فهرست محلی در SharedPreferences نگه‌داری می‌شود و تغییر هر دسته به‌عنوان یک رکورد
 * مستقل در outbox قرار می‌گیرد تا افزودن یا حذف هم‌زمان دو دستهٔ متفاوت، همدیگر را حذف نکند.
 */
object CategoryPreferences {
    private const val PREFS = "ourspace_categories"
    private const val KEY_EXPENSE = "expense_categories"
    private const val KEY_INCOME = "income_categories"
    private const val KEY_SYNC_RECORDS = "finance_category_sync_records"
    private const val KEY_EXPENSE_SEEDED = "expense_sync_seeded"
    private const val KEY_INCOME_SEEDED = "income_sync_seeded"
    private const val KIND_EXPENSE = "expense"
    private const val KIND_INCOME = "income"
    private const val OTHER = "سایر"

    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** پیش‌فرض یکسان برای هزینه و خرید */
    val DEFAULT_EXPENSE = listOf(
        "خوراک", "میوه و سبزیجات", "گوشت و پروتئین", "لبنیات", "نان و غلات",
        "تنقلات", "نوشیدنی", "خانه", "لوازم خانه", "شوینده", "بهداشت", "آرایشی",
        "دارو و سلامت", "رفت‌وآمد", "تفریح", "پوشاک", "کودک", "حیوان خانگی",
        "لوازم‌التحریر", "دیجیتال", "هدیه", "سفر", OTHER
    )

    val DEFAULT_INCOME = listOf("حقوق", "پاداش", "فروش", "هدیه", OTHER)

    fun expenseCategories(context: Context): List<String> {
        ensureLegacyChangesSeeded(context, KIND_EXPENSE)
        return load(context, KEY_EXPENSE, DEFAULT_EXPENSE)
    }

    /** همان لیست هزینه — برای خرید */
    fun shoppingCategories(context: Context): List<String> = expenseCategories(context)

    fun incomeCategories(context: Context): List<String> {
        ensureLegacyChangesSeeded(context, KIND_INCOME)
        return load(context, KEY_INCOME, DEFAULT_INCOME)
    }

    /** با تغییرات دریافتی از گوشی دیگر نیز Compose را تازه می‌کند. */
    @OptIn(ExperimentalCoroutinesApi::class)
    fun observeChanges(context: Context): Flow<Int> = callbackFlow {
        val prefs = preferences(context)
        var revision = 0
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == KEY_EXPENSE || key == KEY_INCOME) trySend(++revision)
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(revision)
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }.conflate()

    fun addExpenseCategory(context: Context, name: String): Boolean =
        addCategory(context, KIND_EXPENSE, name)

    fun removeExpenseCategory(context: Context, name: String): Boolean =
        removeCategory(context, KIND_EXPENSE, name)

    fun addIncomeCategory(context: Context, name: String): Boolean =
        addCategory(context, KIND_INCOME, name)

    fun removeIncomeCategory(context: Context, name: String): Boolean =
        removeCategory(context, KIND_INCOME, name)

    fun resetExpenseToDefault(context: Context) = saveAndSync(context, KIND_EXPENSE, DEFAULT_EXPENSE)

    fun resetIncomeToDefault(context: Context) = saveAndSync(context, KIND_INCOME, DEFAULT_INCOME)

    /** Used by incremental sync and full snapshots. */
    fun exportSyncRecord(context: Context, entityId: String): JSONObject? {
        seedKindForEntity(context, entityId)
        val records = readRecords(preferences(context))
        val record = records.optJSONObject(entityId) ?: return null
        return JSONObject(record.toString())
    }

    fun exportAllSyncRecords(context: Context): List<JSONObject> {
        // Seed custom categories/deletions that existed before this sync format was introduced.
        expenseCategories(context)
        incomeCategories(context)
        val records = readRecords(preferences(context))
        return records.keys().asSequence()
            .mapNotNull { key -> records.optJSONObject(key)?.let { JSONObject(it.toString()) } }
            .sortedBy { it.optString("id") }
            .toList()
    }

    fun syncRecordUpdatedAt(context: Context?, entityId: String): Long? {
        context ?: return null
        seedKindForEntity(context, entityId)
        return readRecords(preferences(context)).optJSONObject(entityId)?.optLong("updatedAt")
    }

    /**
     * Applies a record already accepted by the sync conflict resolver. Does not enqueue it again.
     */
    fun applySyncedRecord(context: Context?, json: JSONObject) {
        context ?: return
        val kind = json.optString("kind")
        if (kind != KIND_EXPENSE && kind != KIND_INCOME) return
        val name = json.optString("name").trim().take(40)
        if (name.isBlank() || (name == OTHER && json.optBoolean("deleted"))) return
        val entityId = categoryId(kind, name)
        if (json.optString("id") != entityId) return
        val updatedAt = json.optLong("updatedAt", -1L)
        if (updatedAt < 0L) return

        // Preserve any custom list stored by an older version before applying remote records.
        ensureLegacyChangesSeeded(context, kind)
        val prefs = preferences(context)
        val records = readRecords(prefs)
        records.put(entityId, JSONObject()
            .put("id", entityId)
            .put("kind", kind)
            .put("name", name)
            .put("deleted", json.optBoolean("deleted"))
            .put("sortOrder", json.optInt("sortOrder", 0).coerceAtLeast(0))
            .put("updatedAt", updatedAt))
        prefs.edit().putString(KEY_SYNC_RECORDS, records.toString()).apply()
        rebuildVisibleCategories(prefs, kind, records)
    }

    private fun addCategory(context: Context, kind: String, name: String): Boolean {
        val clean = name.trim().take(40)
        if (clean.isEmpty()) return false
        val key = listKey(kind)
        val defaults = defaults(kind)
        val current = load(context, key, defaults).toMutableList()
        if (current.any { it.equals(clean, ignoreCase = true) }) return false
        current.removeAll { it == OTHER }
        current.add(clean)
        current.add(OTHER)
        saveAndSync(context, kind, current)
        return true
    }

    private fun removeCategory(context: Context, kind: String, name: String): Boolean {
        if (name == OTHER) return false
        val key = listKey(kind)
        val current = load(context, key, defaults(kind)).toMutableList()
        val removed = current.removeAll { it == name }
        if (!removed) return false
        if (OTHER !in current) current.add(OTHER)
        saveAndSync(context, kind, current)
        return true
    }

    private fun saveAndSync(context: Context, kind: String, requestedItems: List<String>) {
        val prefs = preferences(context)
        val key = listKey(kind)
        val defaults = defaults(kind)
        val oldItems = load(context, key, defaults)
        val newItems = normalizeList(requestedItems, defaults)
        prefs.edit().putString(key, newItems.joinToString("\u001F")).apply()

        val oldByName = oldItems.associateBy { normalizedName(it) }
        val newByName = newItems.associateBy { normalizedName(it) }
        val changed = mutableListOf<JSONObject>()
        (oldByName.keys - newByName.keys).forEach { normalized ->
            val oldName = oldByName.getValue(normalized)
            if (oldName != OTHER) {
                changed += putLocalRecord(
                    prefs, kind, oldName, deleted = true,
                    sortOrder = customOrder(oldItems, defaults, oldName)
                )
            }
        }
        (newByName.keys - oldByName.keys).forEach { normalized ->
            val newName = newByName.getValue(normalized)
            if (newName != OTHER) {
                changed += putLocalRecord(
                    prefs, kind, newName, deleted = false,
                    sortOrder = customOrder(newItems, defaults, newName)
                )
            }
        }
        markSeeded(prefs, kind)
        enqueueChanges(context, changed)
    }

    /**
     * One-time compatibility bridge: custom categories and removed defaults stored by older
     * app versions are converted to sync records without changing their visible names/order.
     */
    private fun ensureLegacyChangesSeeded(context: Context, kind: String) {
        val prefs = preferences(context)
        if (prefs.getBoolean(seedKey(kind), false)) return
        synchronized(this) {
            if (prefs.getBoolean(seedKey(kind), false)) return
            val defaults = defaults(kind)
            val items = load(context, listKey(kind), defaults)
            val changed = mutableListOf<JSONObject>()
            val itemNames = items.map(::normalizedName).toSet()
            defaults.filter { it != OTHER && normalizedName(it) !in itemNames }.forEachIndexed { index, name ->
                changed += putLocalRecord(prefs, kind, name, deleted = true, sortOrder = index)
            }
            val customItems = items.filter { item -> defaults.none { it.equals(item, ignoreCase = true) } }
            customItems.forEachIndexed { index, name ->
                changed += putLocalRecord(prefs, kind, name, deleted = false, sortOrder = index)
            }
            markSeeded(prefs, kind)
            enqueueChanges(context, changed)
        }
    }

    private fun putLocalRecord(
        prefs: SharedPreferences,
        kind: String,
        name: String,
        deleted: Boolean,
        sortOrder: Int
    ): JSONObject {
        val entityId = categoryId(kind, name)
        val records = readRecords(prefs)
        val previousUpdatedAt = records.optJSONObject(entityId)?.optLong("updatedAt") ?: 0L
        val updatedAt = maxOf(System.currentTimeMillis(), previousUpdatedAt + 1L)
        val record = JSONObject()
            .put("id", entityId)
            .put("kind", kind)
            .put("name", name)
            .put("deleted", deleted)
            .put("sortOrder", sortOrder.coerceAtLeast(0))
            .put("updatedAt", updatedAt)
        records.put(entityId, record)
        prefs.edit().putString(KEY_SYNC_RECORDS, records.toString()).apply()
        return JSONObject(record.toString())
    }

    private fun enqueueChanges(context: Context, records: List<JSONObject>) {
        if (records.isEmpty()) return
        val appContext = context.applicationContext
        syncScope.launch {
            runCatching {
                val changeDao = OurSpaceDatabase.getInstance(appContext).syncChangeDao()
                records.forEach { record ->
                    val updatedAt = record.getLong("updatedAt")
                    val entityId = record.getString("id")
                    changeDao.upsert(SyncChangeEntity(
                        changeId = "financeCategories:$updatedAt:${UUID.randomUUID()}",
                        entityType = "financeCategories",
                        entityId = entityId,
                        changedAt = updatedAt,
                        priority = 700,
                        createdAt = updatedAt
                    ))
                }
                runCatching { HostServerService.requestImmediateSync(appContext) }
            }
        }
    }

    private fun rebuildVisibleCategories(prefs: SharedPreferences, kind: String, records: JSONObject) {
        val defaults = defaults(kind)
        val kindRecords = records.keys().asSequence()
            .mapNotNull { records.optJSONObject(it) }
            .filter { it.optString("kind") == kind }
            .toList()
        val deleted = kindRecords.filter { it.optBoolean("deleted") }
            .map { normalizedName(it.optString("name")) }.toSet()
        val activeDefaults = defaults.filter { normalizedName(it) !in deleted }
        val activeCustom = kindRecords
            .filter { !it.optBoolean("deleted") }
            .filter { item -> defaults.none { it.equals(item.optString("name"), ignoreCase = true) } }
            .sortedWith(compareBy<JSONObject> { it.optInt("sortOrder", 0) }
                .thenBy { normalizedName(it.optString("name")) })
            .map { it.optString("name") }
        val result = normalizeList(activeDefaults + activeCustom, defaults)
        prefs.edit().putString(listKey(kind), result.joinToString("\u001F")).apply()
    }

    private fun normalizeList(items: List<String>, defaults: List<String>): List<String> {
        val result = mutableListOf<String>()
        items.map { it.trim().take(40) }
            .filter { it.isNotBlank() }
            .forEach { item ->
                if (result.none { it.equals(item, ignoreCase = true) }) result += item
            }
        result.removeAll { it == OTHER }
        if (items.any { it == OTHER } || result.isNotEmpty()) result += OTHER
        return result.ifEmpty { defaults }
    }

    private fun customOrder(items: List<String>, defaults: List<String>, name: String): Int =
        items.filter { item -> defaults.none { it.equals(item, ignoreCase = true) } }
            .indexOfFirst { it.equals(name, ignoreCase = true) }
            .coerceAtLeast(0)

    private fun load(context: Context, key: String, defaults: List<String>): List<String> =
        loadRaw(preferences(context), key, defaults)

    private fun loadRaw(prefs: SharedPreferences, key: String, defaults: List<String>): List<String> {
        val raw = prefs.getString(key, null)
        if (raw.isNullOrBlank()) return defaults
        val parsed = raw.split('\u001F')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
        return if (parsed.isEmpty()) defaults else parsed
    }

    private fun readRecords(prefs: SharedPreferences): JSONObject =
        runCatching { JSONObject(prefs.getString(KEY_SYNC_RECORDS, "{}") ?: "{}") }
            .getOrDefault(JSONObject())

    private fun markSeeded(prefs: SharedPreferences, kind: String) {
        prefs.edit().putBoolean(seedKey(kind), true).apply()
    }

    private fun seedKindForEntity(context: Context, entityId: String) {
        when {
            entityId.startsWith("$KIND_EXPENSE|") -> ensureLegacyChangesSeeded(context, KIND_EXPENSE)
            entityId.startsWith("$KIND_INCOME|") -> ensureLegacyChangesSeeded(context, KIND_INCOME)
        }
    }

    private fun listKey(kind: String) = if (kind == KIND_EXPENSE) KEY_EXPENSE else KEY_INCOME
    private fun seedKey(kind: String) = if (kind == KIND_EXPENSE) KEY_EXPENSE_SEEDED else KEY_INCOME_SEEDED
    private fun defaults(kind: String) = if (kind == KIND_EXPENSE) DEFAULT_EXPENSE else DEFAULT_INCOME
    private fun normalizedName(name: String) = name.trim().lowercase(Locale.ROOT)
    private fun categoryId(kind: String, name: String) = "$kind|${normalizedName(name)}"

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

}
