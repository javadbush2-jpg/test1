package com.ourspace.app.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TaskEntity::class,
        EventEntity::class,
        ShoppingItemEntity::class,
        MessageEntity::class,
        FinancialAccountEntity::class,
        FinanceTransactionEntity::class,
        FinanceBudgetEntity::class,
        SharedDebtEntity::class,
        RecurringTransactionEntity::class,
        MemoryEntity::class,
        MoodCheckInEntity::class,
        SpecialDateEntity::class,
        CoupleProfileEntity::class,
        CycleLogEntity::class,
        CycleSettingsEntity::class,
        LocationShareEntity::class,
        HeartPulseEntity::class,
        SharedPlaceEntity::class,
        HabitEntity::class,
        WatchlistItemEntity::class,
        BookItemEntity::class,
        FoodItemEntity::class,
        AttachmentEntity::class,
        TelegramStickerPackEntity::class,
        TelegramStickerEntity::class,
        SyncChangeEntity::class,
        SyncAcknowledgementEntity::class,
        SyncVersionEntity::class,
        SyncRuntimeControlEntity::class,
        SyncSessionStateEntity::class
    ],
    version = 31,
    exportSchema = true
)
abstract class OurSpaceDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun eventDao(): EventDao
    abstract fun shoppingDao(): ShoppingDao
    abstract fun messageDao(): MessageDao
    abstract fun financialAccountDao(): FinancialAccountDao
    abstract fun financeTransactionDao(): FinanceTransactionDao
    abstract fun financeBudgetDao(): FinanceBudgetDao
    abstract fun sharedDebtDao(): SharedDebtDao
    abstract fun recurringTransactionDao(): RecurringTransactionDao
    abstract fun memoryDao(): MemoryDao
    abstract fun moodCheckInDao(): MoodCheckInDao
    abstract fun specialDateDao(): SpecialDateDao
    abstract fun coupleProfileDao(): CoupleProfileDao
    abstract fun cycleLogDao(): CycleLogDao
    abstract fun cycleSettingsDao(): CycleSettingsDao
    abstract fun locationShareDao(): LocationShareDao
    abstract fun heartPulseDao(): HeartPulseDao
    abstract fun sharedPlaceDao(): SharedPlaceDao
    abstract fun habitDao(): HabitDao
    abstract fun watchlistDao(): WatchlistDao
    abstract fun bookDao(): BookDao
    abstract fun foodDao(): FoodDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun telegramStickerPackDao(): TelegramStickerPackDao
    abstract fun telegramStickerDao(): TelegramStickerDao
    abstract fun syncChangeDao(): SyncChangeDao
    abstract fun syncAcknowledgementDao(): SyncAcknowledgementDao
    abstract fun syncVersionDao(): SyncVersionDao
    abstract fun syncRuntimeControlDao(): SyncRuntimeControlDao
    abstract fun syncSessionStateDao(): SyncSessionStateDao

    companion object {

        val MIGRATION_17_18 = object : Migration(17, 18) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `tasks` ADD COLUMN `durationMinutes` INTEGER NOT NULL DEFAULT 60")
            }
        }

        

        val MIGRATION_20_21 = object : Migration(20, 21) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `telegram_sticker_packs` (
                        `name` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `isAnimated` INTEGER NOT NULL DEFAULT 0,
                        `stickerCount` INTEGER NOT NULL DEFAULT 0,
                        `importedAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`name`)
                    )
                """.trimIndent())
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_telegram_sticker_packs_importedAt` ON `telegram_sticker_packs` (`importedAt`)")
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `telegram_stickers` (
                        `id` TEXT NOT NULL,
                        `packName` TEXT NOT NULL,
                        `fileUniqueId` TEXT NOT NULL,
                        `emoji` TEXT NOT NULL,
                        `isAnimated` INTEGER NOT NULL DEFAULT 0,
                        `mimeType` TEXT NOT NULL,
                        `fileName` TEXT NOT NULL,
                        `sizeBytes` INTEGER NOT NULL,
                        `content` BLOB NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_telegram_stickers_packName` ON `telegram_stickers` (`packName`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_telegram_stickers_fileUniqueId` ON `telegram_stickers` (`fileUniqueId`)")
            }
        }

        /** Enable cross-device sticker sync and seed the packs already stored on upgraded phones. */
        val MIGRATION_21_22 = object : Migration(21, 22) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `telegram_sticker_packs` ADD COLUMN `isDeleted` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE `telegram_stickers` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("UPDATE `telegram_stickers` SET `updatedAt` = `createdAt` WHERE `updatedAt` = 0")

                // Older installations have no outbox rows for stickers. Seed both metadata and
                // binary rows so existing libraries are sent without requiring a re-import.
                seedTelegramStickerChanges(database)
                installSyncTriggers(database)
            }
        }



        val MIGRATION_29_30 = object : Migration(29, 30) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `financial_accounts` ADD COLUMN `cardNumber` TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE `financial_accounts` ADD COLUMN `accountNumber` TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_30_31 = object : Migration(30, 31) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Match the chat's keyset pagination and latest-message ordering with one index.
                // The old createdAt-only index is a prefix of this index and is redundant.
                database.execSQL("DROP INDEX IF EXISTS `index_messages_createdAt`")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_messages_createdAt_id` ON `messages` (`createdAt`, `id`)")
            }
        }

        val MIGRATION_28_29 = object : Migration(28, 29) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `messages` ADD COLUMN `isPinned` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE `messages` ADD COLUMN `pinnedUpdatedAt` INTEGER")
            }
        }

        val MIGRATION_27_28 = object : Migration(27, 28) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE `finance_transactions` ADD COLUMN `source` TEXT NOT NULL DEFAULT 'MANUAL'"
                )
                // پیامک‌های قبلی که با پیشوند یادداشت مشخص شده‌اند
                database.execSQL(
                    "UPDATE `finance_transactions` SET `source` = 'SMS' WHERE `note` LIKE 'از پیامک%'"
                )
            }
        }

        val MIGRATION_26_27 = object : Migration(26, 27) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `food_items` (
                        `id` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `isFavorite` INTEGER NOT NULL DEFAULT 0,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_food_items_updatedAt` ON `food_items` (`updatedAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_food_items_name` ON `food_items` (`name`)")
            }
        }

        val MIGRATION_25_26 = object : Migration(25, 26) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `watchlist_items` ADD COLUMN `rating` INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_24_25 = object : Migration(24, 25) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `book_items` (
                        `id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `author` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `status` TEXT NOT NULL,
                        `totalPages` INTEGER NOT NULL DEFAULT 0,
                        `readPages` INTEGER NOT NULL DEFAULT 0,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_book_items_updatedAt` ON `book_items` (`updatedAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_book_items_status` ON `book_items` (`status`)")
            }
        }

        val MIGRATION_23_24 = object : Migration(23, 24) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `watchlist_items` ADD COLUMN `totalEpisodes` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE `watchlist_items` ADD COLUMN `watchedEpisodes` INTEGER NOT NULL DEFAULT 0")
            }
        }

        /** Richer habit schedule: weekly frequency, selected days, per-day target, priority. */
        val MIGRATION_22_23 = object : Migration(22, 23) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `frequency` TEXT NOT NULL DEFAULT 'DAILY'")
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `timesPerWeek` INTEGER NOT NULL DEFAULT 7")
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `timesPerDay` INTEGER NOT NULL DEFAULT 1")
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `weekDays` TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `priority` TEXT NOT NULL DEFAULT 'NORMAL'")
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `completionsToday` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `completionsThisWeek` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE `habits` ADD COLUMN `weekKey` TEXT NOT NULL DEFAULT ''")
                // Preserve existing "done today" as one completion for upgraded rows.
                database.execSQL(
                    """
                    UPDATE `habits`
                    SET `completionsToday` = 1
                    WHERE `lastCompletedDayKey` IS NOT NULL AND `lastCompletedDayKey` != ''
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_19_20 = object : Migration(19, 20) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `messages` ADD COLUMN `deliveredAt` INTEGER")
            }
        }

        val MIGRATION_18_19 = object : Migration(18, 19) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `messages` ADD COLUMN `reaction2` TEXT")
                database.execSQL("ALTER TABLE `messages` ADD COLUMN `reaction2ByDeviceId` TEXT")
                database.execSQL("ALTER TABLE `messages` ADD COLUMN `reaction2UpdatedAt` INTEGER")
            }
        }

        val MIGRATION_16_17 = object : Migration(16, 17) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Older installations may already contain photos but have no durable outbox
                // row for them. Seed attachments and their parents so old photos can replicate.
                database.execSQL("""
                    INSERT OR IGNORE INTO `sync_changes` (
                        `changeId`, `entityType`, `entityId`, `changedAt`, `state`, `attempts`,
                        `nextAttemptAt`, `lastAttemptAt`, `lastMessageId`, `priority`, `createdAt`
                    )
                    SELECT 'attachments:' || a.`id` || ':' || a.`updatedAt` || ':alpha17-backfill',
                           'attachments', a.`id`, a.`updatedAt`, 'PENDING', 0, 0, NULL, NULL, 800, a.`updatedAt`
                    FROM `attachments` a
                """.trimIndent())
                database.execSQL("""
                    INSERT OR IGNORE INTO `sync_changes` (
                        `changeId`, `entityType`, `entityId`, `changedAt`, `state`, `attempts`,
                        `nextAttemptAt`, `lastAttemptAt`, `lastMessageId`, `priority`, `createdAt`
                    )
                    SELECT 'messages:' || m.`id` || ':' || m.`updatedAt` || ':alpha17-parent',
                           'messages', m.`id`, m.`updatedAt`, 'PENDING', 0, 0, NULL, NULL, 900, m.`updatedAt`
                    FROM `messages` m
                    WHERE m.`id` IN (SELECT `messageId` FROM `attachments` WHERE `messageId` IS NOT NULL)
                """.trimIndent())
                database.execSQL("""
                    INSERT OR IGNORE INTO `sync_changes` (
                        `changeId`, `entityType`, `entityId`, `changedAt`, `state`, `attempts`,
                        `nextAttemptAt`, `lastAttemptAt`, `lastMessageId`, `priority`, `createdAt`
                    )
                    SELECT 'memories:' || m.`id` || ':' || m.`updatedAt` || ':alpha17-parent',
                           'memories', m.`id`, m.`updatedAt`, 'PENDING', 0, 0, NULL, NULL, 500, m.`updatedAt`
                    FROM `memories` m
                    WHERE m.`id` IN (SELECT `memoryId` FROM `attachments` WHERE `memoryId` IS NOT NULL)
                """.trimIndent())
                installSyncTriggers(database)
            }
        }

        val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `habits` (
                        `id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `note` TEXT NOT NULL DEFAULT '',
                        `kind` TEXT NOT NULL DEFAULT 'HABIT',
                        `scheduleNote` TEXT NOT NULL DEFAULT '',
                        `lastCompletedDayKey` TEXT NOT NULL DEFAULT '',
                        `isDeleted` INTEGER NOT NULL DEFAULT 0,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_habits_updatedAt` ON `habits` (`updatedAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_habits_kind` ON `habits` (`kind`)")
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `watchlist_items` (
                        `id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `note` TEXT NOT NULL DEFAULT '',
                        `mediaType` TEXT NOT NULL DEFAULT 'MOVIE',
                        `status` TEXT NOT NULL DEFAULT 'WANT',
                        `isDeleted` INTEGER NOT NULL DEFAULT 0,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_watchlist_items_updatedAt` ON `watchlist_items` (`updatedAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_watchlist_items_status` ON `watchlist_items` (`status`)")
                // Reinstall triggers so new tables are tracked.
                installSyncTriggers(database)
            }
        }

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `messages` (
                        `id` TEXT NOT NULL,
                        `senderDeviceId` TEXT NOT NULL,
                        `text` TEXT NOT NULL,
                        `replyToId` TEXT,
                        `reaction` TEXT,
                        `reactionByDeviceId` TEXT,
                        `readAt` INTEGER,
                        `editedAt` INTEGER,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_messages_createdAt` ON `messages` (`createdAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_messages_updatedAt` ON `messages` (`updatedAt`)")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `financial_accounts` (
                        `id` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `type` TEXT NOT NULL,
                        `openingBalance` INTEGER NOT NULL,
                        `colorSeed` INTEGER NOT NULL,
                        `isArchived` INTEGER NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_financial_accounts_updatedAt` ON `financial_accounts` (`updatedAt`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `finance_transactions` (
                        `id` TEXT NOT NULL,
                        `accountId` TEXT NOT NULL,
                        `kind` TEXT NOT NULL,
                        `amount` INTEGER NOT NULL,
                        `category` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `payerDeviceId` TEXT NOT NULL,
                        `occurredAt` INTEGER NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_finance_transactions_accountId` ON `finance_transactions` (`accountId`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_finance_transactions_occurredAt` ON `finance_transactions` (`occurredAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_finance_transactions_updatedAt` ON `finance_transactions` (`updatedAt`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `finance_budgets` (
                        `id` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `periodKey` TEXT NOT NULL,
                        `monthlyLimit` INTEGER NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_finance_budgets_periodKey` ON `finance_budgets` (`periodKey`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_finance_budgets_updatedAt` ON `finance_budgets` (`updatedAt`)")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `finance_transactions` ADD COLUMN `targetAccountId` TEXT")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_finance_transactions_targetAccountId` ON `finance_transactions` (`targetAccountId`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `memories` (
                        `id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `mood` TEXT NOT NULL,
                        `createdByDeviceId` TEXT NOT NULL,
                        `occurredAt` INTEGER NOT NULL,
                        `isFavorite` INTEGER NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_memories_occurredAt` ON `memories` (`occurredAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_memories_updatedAt` ON `memories` (`updatedAt`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `mood_checkins` (
                        `id` TEXT NOT NULL,
                        `deviceId` TEXT NOT NULL,
                        `dayKey` TEXT NOT NULL,
                        `mood` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_mood_checkins_dayKey` ON `mood_checkins` (`dayKey`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_mood_checkins_updatedAt` ON `mood_checkins` (`updatedAt`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `special_dates` (
                        `id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `occurredAt` INTEGER NOT NULL,
                        `repeatYearly` INTEGER NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_special_dates_occurredAt` ON `special_dates` (`occurredAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_special_dates_updatedAt` ON `special_dates` (`updatedAt`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `couple_profile` (
                        `id` TEXT NOT NULL,
                        `firstPersonName` TEXT NOT NULL,
                        `secondPersonName` TEXT NOT NULL,
                        `relationshipStartedAt` INTEGER,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `messages` ADD COLUMN `reactionUpdatedAt` INTEGER")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `sync_changes` (
                        `changeId` TEXT NOT NULL,
                        `entityType` TEXT NOT NULL,
                        `entityId` TEXT NOT NULL,
                        `changedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`changeId`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_changes_changedAt` ON `sync_changes` (`changedAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_changes_entityType_entityId` ON `sync_changes` (`entityType`, `entityId`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `sync_acknowledgements` (
                        `changeId` TEXT NOT NULL,
                        `receivedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`changeId`)
                    )
                    """.trimIndent()
                )
                installSyncTriggers(database, includeAttachments = false, includeFinanceCapabilities = false)
                seedExistingChanges(database, includeAttachments = false, includeFinanceCapabilities = false)
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `attachments` (
                        `id` TEXT NOT NULL,
                        `messageId` TEXT,
                        `memoryId` TEXT,
                        `fileName` TEXT NOT NULL,
                        `mimeType` TEXT NOT NULL,
                        `sizeBytes` INTEGER NOT NULL,
                        `sha256` TEXT NOT NULL,
                        `content` BLOB NOT NULL,
                        `createdByDeviceId` TEXT NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_attachments_messageId` ON `attachments` (`messageId`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_attachments_memoryId` ON `attachments` (`memoryId`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_attachments_updatedAt` ON `attachments` (`updatedAt`)")
                installSyncTriggers(database, includeFinanceCapabilities = false)
            }
        }

        



        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `heart_pulses` ADD COLUMN `acknowledgedAt` INTEGER")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `shared_places` (
                        `id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `latitude` REAL NOT NULL,
                        `longitude` REAL NOT NULL,
                        `category` TEXT NOT NULL,
                        `createdByDeviceId` TEXT NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_shared_places_updatedAt` ON `shared_places` (`updatedAt`)")
                installSyncTriggers(database)
                seedExistingChanges(database)
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `heart_pulses` (
                        `id` TEXT NOT NULL,
                        `senderDeviceId` TEXT NOT NULL,
                        `consumedAt` INTEGER,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_heart_pulses_createdAt` ON `heart_pulses` (`createdAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_heart_pulses_updatedAt` ON `heart_pulses` (`updatedAt`)")
                installSyncTriggers(database)
                seedExistingChanges(database)
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `location_shares` (
                        `id` TEXT NOT NULL,
                        `latitude` REAL NOT NULL,
                        `longitude` REAL NOT NULL,
                        `accuracyMeters` REAL NOT NULL,
                        `isSharing` INTEGER NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_location_shares_updatedAt` ON `location_shares` (`updatedAt`)")
                installSyncTriggers(database)
                seedExistingChanges(database)
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cycle_logs` (
                        `id` TEXT NOT NULL,
                        `startAt` INTEGER NOT NULL,
                        `endAt` INTEGER,
                        `flowLevel` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `recordedByDeviceId` TEXT NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_cycle_logs_startAt` ON `cycle_logs` (`startAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_cycle_logs_updatedAt` ON `cycle_logs` (`updatedAt`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cycle_settings` (
                        `id` TEXT NOT NULL,
                        `averageCycleDays` INTEGER NOT NULL,
                        `averagePeriodDays` INTEGER NOT NULL,
                        `trackingEnabled` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                installSyncTriggers(database)
                seedExistingChanges(database)
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `shared_debts` (
                        `id` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `amount` INTEGER NOT NULL,
                        `creditorDeviceId` TEXT NOT NULL,
                        `debtorDeviceId` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `dueAt` INTEGER,
                        `settledAt` INTEGER,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_shared_debts_creditorDeviceId` ON `shared_debts` (`creditorDeviceId`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_shared_debts_debtorDeviceId` ON `shared_debts` (`debtorDeviceId`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_shared_debts_dueAt` ON `shared_debts` (`dueAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_shared_debts_updatedAt` ON `shared_debts` (`updatedAt`)")
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `recurring_transactions` (
                        `id` TEXT NOT NULL,
                        `accountId` TEXT NOT NULL,
                        `targetAccountId` TEXT,
                        `kind` TEXT NOT NULL,
                        `amount` INTEGER NOT NULL,
                        `category` TEXT NOT NULL,
                        `note` TEXT NOT NULL,
                        `interval` TEXT NOT NULL,
                        `anchorJalaliDay` INTEGER NOT NULL,
                        `nextRunAt` INTEGER NOT NULL,
                        `lastGeneratedAt` INTEGER,
                        `createdByDeviceId` TEXT NOT NULL,
                        `isActive` INTEGER NOT NULL,
                        `isDeleted` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_recurring_transactions_accountId` ON `recurring_transactions` (`accountId`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_recurring_transactions_nextRunAt` ON `recurring_transactions` (`nextRunAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_recurring_transactions_createdByDeviceId` ON `recurring_transactions` (`createdByDeviceId`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_recurring_transactions_updatedAt` ON `recurring_transactions` (`updatedAt`)")
                installSyncTriggers(database)
            }
        }

        @Volatile private var instance: OurSpaceDatabase? = null

        fun getInstance(context: Context): OurSpaceDatabase = instance ?: synchronized(this) {
            instance ?: buildDatabase(context.applicationContext).also { instance = it }
        }

        private val syncedTables = listOf(
            "tasks" to "tasks",
            "events" to "events",
            "shopping_items" to "shopping",
            "messages" to "messages",
            "financial_accounts" to "financialAccounts",
            "finance_transactions" to "financeTransactions",
            "finance_budgets" to "financeBudgets",
            "shared_debts" to "sharedDebts",
            "recurring_transactions" to "recurringTransactions",
            "memories" to "memories",
            "mood_checkins" to "moodCheckIns",
            "special_dates" to "specialDates",
            "couple_profile" to "coupleProfile",
            "cycle_logs" to "cycleLogs",
            "cycle_settings" to "cycleSettings",
            "location_shares" to "locationShares",
            "heart_pulses" to "heartPulses",
            "shared_places" to "sharedPlaces",
            "habits" to "habits",
            "watchlist_items" to "watchlistItems",
            "book_items" to "bookItems",
            "attachments" to "attachments"
        )

        private fun installSyncTriggers(
            database: SupportSQLiteDatabase,
            includeAttachments: Boolean = true,
            includeFinanceCapabilities: Boolean = true
        ) {
            database.execSQL("CREATE TABLE IF NOT EXISTS `sync_runtime_control` (`id` INTEGER NOT NULL, `suppressOutbox` INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(`id`))")
            database.execSQL("INSERT OR IGNORE INTO `sync_runtime_control` (`id`,`suppressOutbox`) VALUES (1,0)")
            syncedTables
                .filter { includeAttachments || it.first != "attachments" }
                .filter {
                    includeFinanceCapabilities || it.first !in setOf("shared_debts", "recurring_transactions")
                }
                .forEach { (table, type) ->
                listOf("INSERT" to "insert", "UPDATE" to "update").forEach { (operation, suffix) ->
                    database.execSQL(
                        """
                        CREATE TRIGGER IF NOT EXISTS `sync_track_v2_${table}_$suffix`
                        AFTER $operation ON `$table`
                        WHEN COALESCE((SELECT `suppressOutbox` FROM `sync_runtime_control` WHERE `id` = 1), 0) = 0
                        BEGIN
                            INSERT OR REPLACE INTO `sync_changes` (
                                `changeId`, `entityType`, `entityId`, `changedAt`,
                                `state`, `attempts`, `nextAttemptAt`, `lastAttemptAt`, `lastMessageId`,
                                `priority`, `createdAt`
                            )
                            VALUES (
                                '$type:' || NEW.`id` || ':' || NEW.`updatedAt` || ':' || lower(hex(randomblob(8))),
                                '$type',
                                NEW.`id`,
                                NEW.`updatedAt`,
                                'PENDING',
                                0,
                                0,
                                NULL,
                                NULL,
                                CASE '$type'
                                    WHEN 'heartPulses' THEN 1000
                                    WHEN 'messages' THEN 900
                                    WHEN 'attachments' THEN 800
                                    WHEN 'tasks' THEN 700
                                    ELSE 500
                                END,
                                NEW.`updatedAt`
                            );
                        END
                        """.trimIndent()
                    )
                }
            }
            installTelegramStickerSyncTriggers(database)
        }

        /**
         * Sticker-pack primary keys are named `name`, while sticker rows use `id`; keep their
         * triggers separate from the generic table list so older migrations can run before these
         * tables exist.
         */
        private fun installTelegramStickerSyncTriggers(database: SupportSQLiteDatabase) {
            val stickerTables = listOf(
                Triple("telegram_sticker_packs", "telegramStickerPacks", "name"),
                Triple("telegram_stickers", "telegramStickers", "id")
            )
            for ((table, type, idColumn) in stickerTables) {
                if (!tableExists(database, table)) continue
                listOf("INSERT" to "insert", "UPDATE" to "update").forEach { (operation, suffix) ->
                    database.execSQL(
                        """
                        CREATE TRIGGER IF NOT EXISTS `sync_track_v2_${table}_$suffix`
                        AFTER $operation ON `$table`
                        WHEN COALESCE((SELECT `suppressOutbox` FROM `sync_runtime_control` WHERE `id` = 1), 0) = 0
                        BEGIN
                            INSERT OR REPLACE INTO `sync_changes` (
                                `changeId`, `entityType`, `entityId`, `changedAt`,
                                `state`, `attempts`, `nextAttemptAt`, `lastAttemptAt`, `lastMessageId`,
                                `priority`, `createdAt`
                            )
                            VALUES (
                                '$type:' || NEW.`$idColumn` || ':' || NEW.`updatedAt` || ':' || lower(hex(randomblob(8))),
                                '$type',
                                NEW.`$idColumn`,
                                NEW.`updatedAt`,
                                'PENDING',
                                0,
                                0,
                                NULL,
                                NULL,
                                500,
                                NEW.`updatedAt`
                            );
                        END
                        """.trimIndent()
                    )
                }
            }
        }

        private fun tableExists(database: SupportSQLiteDatabase, table: String): Boolean =
            database.query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = '$table'")
                .use { it.moveToFirst() }

        /** Backfill imported rows on the first sync-capable database version. */
        private fun seedTelegramStickerChanges(database: SupportSQLiteDatabase) {
            database.execSQL("""
                INSERT OR IGNORE INTO `sync_changes` (
                    `changeId`, `entityType`, `entityId`, `changedAt`, `state`, `attempts`,
                    `nextAttemptAt`, `lastAttemptAt`, `lastMessageId`, `priority`, `createdAt`
                )
                SELECT 'telegramStickerPacks:' || `name` || ':' || `updatedAt` || ':alpha157-backfill',
                       'telegramStickerPacks', `name`, `updatedAt`, 'PENDING', 0, 0, NULL, NULL, 500, `updatedAt`
                FROM `telegram_sticker_packs`
            """.trimIndent())
            database.execSQL("""
                INSERT OR IGNORE INTO `sync_changes` (
                    `changeId`, `entityType`, `entityId`, `changedAt`, `state`, `attempts`,
                    `nextAttemptAt`, `lastAttemptAt`, `lastMessageId`, `priority`, `createdAt`
                )
                SELECT 'telegramStickers:' || s.`id` || ':' || s.`updatedAt` || ':alpha157-backfill',
                       'telegramStickers', s.`id`, s.`updatedAt`, 'PENDING', 0, 0, NULL, NULL, 500, s.`updatedAt`
                FROM `telegram_stickers` s
                INNER JOIN `telegram_sticker_packs` p ON p.`name` = s.`packName`
                WHERE p.`isDeleted` = 0
            """.trimIndent())
        }

        private fun seedExistingChanges(
            database: SupportSQLiteDatabase,
            includeAttachments: Boolean = true,
            includeFinanceCapabilities: Boolean = true
        ) {
            syncedTables
                .filter { includeAttachments || it.first != "attachments" }
                .filter {
                    includeFinanceCapabilities || it.first !in setOf("shared_debts", "recurring_transactions")
                }
                .forEach { (table, type) ->
                database.execSQL(
                    """
                    INSERT OR IGNORE INTO `sync_changes` (
                        `changeId`, `entityType`, `entityId`, `changedAt`,
                        `state`, `attempts`, `nextAttemptAt`, `priority`, `createdAt`
                    )
                    SELECT
                        '$type:' || `id` || ':' || `updatedAt`,
                        '$type',
                        `id`,
                        `updatedAt`,
                        'PENDING',
                        0,
                        0,
                        500,
                        `updatedAt`
                    FROM `$table`
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `state` TEXT NOT NULL DEFAULT 'PENDING'")
                database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `attempts` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `nextAttemptAt` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `lastAttemptAt` INTEGER")
                database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `lastMessageId` TEXT")
                database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `priority` INTEGER NOT NULL DEFAULT 100")
                database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                database.execSQL("UPDATE `sync_changes` SET `createdAt` = `changedAt` WHERE `createdAt` = 0")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_changes_nextAttemptAt` ON `sync_changes` (`nextAttemptAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_changes_state_priority_changedAt` ON `sync_changes` (`state`, `priority`, `changedAt`)")
                syncedTables.forEach { (table, _) ->
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_${table}_insert`")
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_${table}_update`")
                }
                database.execSQL("CREATE TABLE IF NOT EXISTS `sync_versions` (`entityType` TEXT NOT NULL, `entityId` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL, `originDeviceId` TEXT NOT NULL, `changeId` TEXT NOT NULL, `appliedAt` INTEGER NOT NULL, PRIMARY KEY(`entityType`, `entityId`))")
                database.execSQL("CREATE TABLE IF NOT EXISTS `sync_session_state` (`id` INTEGER NOT NULL, `state` TEXT NOT NULL, `lastConnectedAt` INTEGER NOT NULL, `lastSyncAt` INTEGER NOT NULL, `lastErrorAt` INTEGER NOT NULL, `lastError` TEXT, `consecutiveFailures` INTEGER NOT NULL, PRIMARY KEY(`id`))")
                database.execSQL("INSERT OR IGNORE INTO `sync_session_state` (`id`,`state`,`lastConnectedAt`,`lastSyncAt`,`lastErrorAt`,`lastError`,`consecutiveFailures`) VALUES (1,'DISCONNECTED',0,0,0,NULL,0)")
                installSyncTriggers(database)
                seedExistingChanges(database)
            }
        }


        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Ensure durable outbox columns exist with safe defaults (idempotent for partial upgrades).
                runCatching {
                    database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `state` TEXT NOT NULL DEFAULT 'PENDING'")
                }
                runCatching {
                    database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `attempts` INTEGER NOT NULL DEFAULT 0")
                }
                runCatching {
                    database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `nextAttemptAt` INTEGER NOT NULL DEFAULT 0")
                }
                runCatching {
                    database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `lastAttemptAt` INTEGER")
                }
                runCatching {
                    database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `lastMessageId` TEXT")
                }
                runCatching {
                    database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `priority` INTEGER NOT NULL DEFAULT 100")
                }
                runCatching {
                    database.execSQL("ALTER TABLE `sync_changes` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                }
                database.execSQL("UPDATE `sync_changes` SET `state` = 'PENDING' WHERE `state` IS NULL OR trim(`state`) = ''")
                database.execSQL("UPDATE `sync_changes` SET `attempts` = 0 WHERE `attempts` IS NULL")
                database.execSQL("UPDATE `sync_changes` SET `nextAttemptAt` = 0 WHERE `nextAttemptAt` IS NULL")
                database.execSQL("UPDATE `sync_changes` SET `priority` = 100 WHERE `priority` IS NULL")
                database.execSQL("UPDATE `sync_changes` SET `createdAt` = `changedAt` WHERE `createdAt` IS NULL OR `createdAt` = 0")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_changes_nextAttemptAt` ON `sync_changes` (`nextAttemptAt`)")
                database.execSQL("CREATE INDEX IF NOT EXISTS `index_sync_changes_state_priority_changedAt` ON `sync_changes` (`state`, `priority`, `changedAt`)")
                syncedTables.forEach { (table, _) ->
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_${table}_insert`")
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_${table}_update`")
                }
                installSyncTriggers(database)
            }
        }


        val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE `shopping_items` ADD COLUMN `isRecurring` INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_14_15 = object : Migration(14, 15) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `sync_runtime_control` (`id` INTEGER NOT NULL, `suppressOutbox` INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(`id`))")
                database.execSQL("INSERT OR IGNORE INTO `sync_runtime_control` (`id`,`suppressOutbox`) VALUES (1,0)")
                syncedTables.forEach { (table, _) ->
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_${table}_insert`")
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_${table}_update`")
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_v2_${table}_insert`")
                    database.execSQL("DROP TRIGGER IF EXISTS `sync_track_v2_${table}_update`")
                }
                installSyncTriggers(database)
            }
        }

        private fun buildDatabase(context: Context): OurSpaceDatabase {
            // Plain SQLite (no SQLCipher): message/sync path was already plain JSON on the wire;
            // local AES on every Room read/write was the main crypto cost and added latency.
            // New file name so an old encrypted DB is not opened with the wrong codec.
            return Room.databaseBuilder(
                context,
                OurSpaceDatabase::class.java,
                "ourspace.db"
            )
                .addMigrations(
                    MIGRATION_1_2,
                    MIGRATION_2_3,
                    MIGRATION_3_4,
                    MIGRATION_4_5,
                    MIGRATION_5_6,
                    MIGRATION_6_7,
                    MIGRATION_7_8,
                    MIGRATION_8_9,
                    MIGRATION_9_10,
                    MIGRATION_10_11,
                    MIGRATION_11_12,
                    MIGRATION_12_13,
                    MIGRATION_13_14,
                    MIGRATION_14_15,
                    MIGRATION_15_16,
                    MIGRATION_16_17,
                    MIGRATION_17_18,
                    MIGRATION_18_19,
                    MIGRATION_19_20,
                    MIGRATION_20_21,
                    MIGRATION_21_22,
                    MIGRATION_22_23,
                    MIGRATION_23_24,
                    MIGRATION_24_25,
                    MIGRATION_25_26,
                    MIGRATION_26_27,
                    MIGRATION_27_28,
                    MIGRATION_28_29,
                    MIGRATION_29_30,
                    MIGRATION_30_31
                )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onOpen(db: SupportSQLiteDatabase) {
                        installSyncTriggers(db)
                    }
                })
                .build()
        }
    }
}
