package com.ourspace.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
/**
 * Living ambient background — soft drifting color orbs drawn with Canvas.
 * Replaces the static mesh with a gentle animated atmosphere.
 */
fun AmbientBackground(
    modifier: Modifier = Modifier,
    /** فقط برای صفحات بدون لیست اسکرول (اسپلش) انیمیشن روشن شود. */
    animateMesh: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier.fillMaxSize()) {
        // پیش‌فرض ثابت: اسکرول نرم در تمام بخش‌ها
        LivingAmbientMesh(Modifier.fillMaxSize(), animate = animateMesh)
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) {
            content()
        }
    }
}

@Composable
fun MotionCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    cornerRadius: Int = 24,
    content: @Composable BoxScope.() -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    // فقط scale — انیمیشن shadowElevation روی ده‌ها کارت در لیست خیلی گران است.
    val scale by animateFloatAsState(
        targetValue = if (pressed) .97f else 1f,
        animationSpec = spring(dampingRatio = .75f, stiffness = 600f),
        label = "press-scale"
    )
    val shape = remember(cornerRadius) { RoundedCornerShape(cornerRadius.dp) }
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                // سایه ثابت سبک؛ بدون interpolate در هر فریم اسکرول
                shadowElevation = if (pressed) 1f else 3f
                this.shape = shape
                clip = true
            }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        content = content
    )
}

@Composable
fun FloatingMotion(
    modifier: Modifier = Modifier,
    /** برای کارت‌های داخل لیست اسکرول false بگذارید تا لگ نباشد. */
    enabled: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    if (!enabled) {
        Box(modifier, content = content)
        return
    }
    val transition = rememberInfiniteTransition(label = "floating")
    val translation by transition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(tween(4_800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "floating-y"
    )
    // rotation حذف شد — ترکیب translation+rotation در لیست‌های بلند هزینه دارد
    Box(
        modifier.graphicsLayer { translationY = translation },
        content = content
    )
}

/** Soft elevated surface used across home, pairing and feature cards. */
@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    elevation: Dp = 0.dp,
    cornerRadius: Dp = 20.dp,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

/** Gradient header block for heroes and section intros. Alpha114: richer depth + softer orbs. */
@Composable
fun GradientHero(
    modifier: Modifier = Modifier,
    colors: List<Color>? = null,
    cornerRadius: Dp = 32.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val resolvedColors = colors ?: if (dark) {
        listOf(
            MaterialTheme.colorScheme.primaryContainer,
            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.95f)
        )
    } else {
        listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.88f),
            MaterialTheme.colorScheme.tertiary
        )
    }
    val c0 = resolvedColors.getOrNull(0) ?: MaterialTheme.colorScheme.primary
    val c1 = resolvedColors.getOrNull(1) ?: MaterialTheme.colorScheme.tertiary
    val c2 = resolvedColors.getOrNull(2) ?: c1
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colorStops = arrayOf(
                        0.0f to c0,
                        0.45f to c0.copy(alpha = 0.94f),
                        0.75f to c1.copy(alpha = 0.90f),
                        1.0f to c2.copy(alpha = 0.85f)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(1100f, 780f)
                )
            )
    ) {
        // Decorative soft orbs inside hero — more organic depth
        Canvas(Modifier.matchParentSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.04f), Color.Transparent)
                ),
                radius = size.minDimension * 0.58f,
                center = Offset(size.width * 0.90f, size.height * 0.12f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.12f), Color.Transparent)
                ),
                radius = size.minDimension * 0.38f,
                center = Offset(size.width * 0.08f, size.height * 0.88f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.07f), Color.Transparent)
                ),
                radius = size.minDimension * 0.28f,
                center = Offset(size.width * 0.55f, size.height * 0.55f)
            )
        }
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp, vertical = 26.dp),
            content = content
        )
    }
}

/** Subtle glass-like panel for secondary info. Alpha114: softer border + better opacity. */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 26.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val border = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.28f)
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(cornerRadius))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.90f))
            .border(0.7.dp, border, RoundedCornerShape(cornerRadius))
            .padding(18.dp),
        content = content
    )
}

/** Staggered fade+slide entrance for list items. */
@Composable
fun AppearItem(
    index: Int,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var visible by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        visible = 1f
    }
    val progress by animateFloatAsState(
        targetValue = visible,
        animationSpec = tween(
            durationMillis = 420,
            delayMillis = (index * 48).coerceAtMost(360),
            easing = FastOutSlowInEasing
        ),
        label = "appear-$index"
    )
    Box(
        modifier.graphicsLayer {
            alpha = progress
            translationY = (1f - progress) * 18f
            scaleX = 0.96f + 0.04f * progress
            scaleY = 0.96f + 0.04f * progress
        }
    ) {
        content()
    }
}

/** Pulsing ring — useful for live / paired status. */
@Composable
fun PulseRing(
    color: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "pulse-ring")
    val scale by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(tween(1_600), RepeatMode.Restart),
        label = "pulse-scale"
    )
    val alpha by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1_600), RepeatMode.Restart),
        label = "pulse-alpha"
    )
    Canvas(modifier) {
        drawCircle(color = color.copy(alpha = alpha), radius = size.minDimension / 2f * scale)
        drawCircle(color = color, radius = size.minDimension / 2f * 0.42f)
    }
}

/** Animated heart icon scale for toolbar. */
@Composable
fun BeatingHeartModifier(): Modifier {
    val transition = rememberInfiniteTransition(label = "beat")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beat-scale"
    )
    return Modifier.scale(scale)
}
