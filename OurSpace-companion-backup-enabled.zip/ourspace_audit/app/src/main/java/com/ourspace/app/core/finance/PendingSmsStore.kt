package com.ourspace.app.core.finance

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * یک تراکنش بانکی که از پیامک ورودی استخراج شده و هنوز دسته‌بندی نهایی کاربر را ندارد.
 * تا وقتی کاربر دسته‌بندی را انتخاب نکند، هیچ ردیفی در دفتر مالی ثبت نمی‌شود.
 */
data class PendingSmsTransaction(
    val id: String,
    /** کلید پایدار برای جلوگیری از ثبت تکراری یک پیامک (هش محتوا) */
    val smsKey: String,
    val address: String,
    val body: String,
    val dateMillis: Long,
    val amount: Long,
    /** EXPENSE | INCOME */
    val kind: String,
    val suggestedCategory: String,
    val note: String,
    val bankLabel: String,
    val templateId: String,
    val createdAt: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("smsKey", smsKey)
        .put("address", address)
        .put("body", body)
        .put("dateMillis", dateMillis)
        .put("amount", amount)
        .put("kind", kind)
        .put("suggestedCategory", suggestedCategory)
        .put("note", note)
        .put("bankLabel", bankLabel)
        .put("templateId", templateId)
        .put("createdAt", createdAt)

    companion object {
        fun fromJson(o: JSONObject): PendingSmsTransaction = PendingSmsTransaction(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString().replace("-", "") },
            smsKey = o.optString("smsKey"),
            address = o.optString("address"),
            body = o.optString("body"),
            dateMillis = o.optLong("dateMillis"),
            amount = o.optLong("amount"),
            kind = o.optString("kind", "EXPENSE"),
            suggestedCategory = o.optString("suggestedCategory", "سایر"),
            note = o.optString("note"),
            bankLabel = o.optString("bankLabel"),
            templateId = o.optString("templateId", "generic"),
            createdAt = o.optLong("createdAt")
        )
    }
}

/**
 * صف تراکنش‌های پیامکی در انتظار دسته‌بندی — روی حافظهٔ محلی (SharedPreferences) و
 * قابل مشاهده به‌صورت StateFlow برای رابط کاربری.
 */
object PendingSmsStore {
    private const val PREFS = "ourspace_pending_sms"
    private const val KEY = "pending_json"
    private const val MAX_ITEMS = 50

    private val _items = MutableStateFlow<List<PendingSmsTransaction>>(emptyList())
    val items: StateFlow<List<PendingSmsTransaction>> = _items.asStateFlow()
    private var initialized = false

    /** اولین فراخوانی، صف را از حافظه بارگذاری می‌کند. */
    fun observe(context: Context): StateFlow<List<PendingSmsTransaction>> {
        ensureLoaded(context.applicationContext)
        return items
    }

    fun current(context: Context): List<PendingSmsTransaction> {
        ensureLoaded(context.applicationContext)
        return _items.value
    }

    fun containsKey(context: Context, smsKey: String): Boolean {
        ensureLoaded(context.applicationContext)
        return _items.value.any { it.smsKey == smsKey }
    }

    /**
     * تراکنش جدید را اضافه می‌کند. اگر همین پیامک قبلاً در صف باشد، نادیده گرفته می‌شود.
     * @return true اگر مورد جدیدی اضافه شد.
     */
    fun add(context: Context, item: PendingSmsTransaction): Boolean {
        ensureLoaded(context.applicationContext)
        if (!item.isReviewWorthy()) return false
        if (item.smsKey.isBlank() || _items.value.any { it.smsKey == item.smsKey }) return false
        val next = (_items.value + item)
            .sortedByDescending { it.dateMillis }
            .take(MAX_ITEMS)
        _items.value = next
        persist(context.applicationContext, next)
        return true
    }

    fun remove(context: Context, id: String) {
        ensureLoaded(context.applicationContext)
        val next = _items.value.filterNot { it.id == id }
        if (next.size == _items.value.size) return
        _items.value = next
        persist(context.applicationContext, next)
    }

    fun clear(context: Context) {
        ensureLoaded(context.applicationContext)
        if (_items.value.isEmpty()) return
        _items.value = emptyList()
        persist(context.applicationContext, emptyList())
    }

    @Synchronized
    private fun ensureLoaded(context: Context) {
        if (initialized) return
        initialized = true
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null)
            .orEmpty()
        if (raw.isBlank()) return
        val loaded = runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    add(PendingSmsTransaction.fromJson(arr.getJSONObject(i)))
                }
            }.sortedByDescending { it.dateMillis }
        }.getOrDefault(emptyList())
        val reviewable = loaded.filter { it.isReviewWorthy() }.take(MAX_ITEMS)
        _items.value = reviewable
        if (reviewable != loaded) persist(context, reviewable)
    }

    private fun PendingSmsTransaction.isReviewWorthy(): Boolean {
        val generic = templateId.isBlank() || templateId == "generic" || templateId.startsWith("generic_bank_")
        val parsed = BankSmsParser.ParsedSmsTransaction(
            amount = amount,
            kind = kind,
            category = suggestedCategory,
            note = note,
            confidence = if (generic) 0.55f else 0.96f,
            templateId = templateId
        )
        return BankSmsParser.isReviewWorthy(parsed, body, address)
    }

    private fun persist(context: Context, list: List<PendingSmsTransaction>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }
}

/**
 * پل ارتباطی اعلان → رابط کاربری: وقتی روی اعلان تراکنش پیامکی لمس شد، شناسهٔ مورد
 * از MainActivity اینجا قرار می‌گیرد و صفحهٔ مالی آن را مصرف و دیالوگ دسته‌بندی را باز می‌کند.
 */
object SmsPendingBus {
    private val _openRequest = MutableStateFlow<String?>(null)
    val openRequest: StateFlow<String?> = _openRequest.asStateFlow()

    fun request(pendingId: String) {
        _openRequest.value = pendingId
    }

    fun consume() {
        _openRequest.value = null
    }
}
