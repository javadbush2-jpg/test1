package com.ourspace.app.core.ai

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * مرز ایزولاسیون موتور بومی هوش مصنوعی.
 *
 * چرا پروسهٔ جدا؟ کتابخانهٔ llama.cpp/ggml در بعضی شرایط (کمبود حافظه، معماری مدل
 * ناسازگار، assert داخلی) مستقیم abort()/SIGSEGV می‌زند؛ این سیگنال‌ها با try/catch
 * یا runCatching قابل مهار نیستند و کل پروسهٔ اپ را می‌کشند. با اجرای موتور در
 * سرویس پروسهٔ «:llm»، مرگ بومی فقط همان پروسه را می‌کشد و پروسهٔ رابط کاربری
 * سالم می‌ماند؛ کلاینت مرگ سرویس را تشخیص می‌دهد و موتور را برای این مدل غیرفعال
 * کرده و پاسخ قانون‌محمد را جایگزین می‌کند.
 *
 * ارتباط با Messenger (بدون نیاز به AIDL) و کاملاً درون‌برنامه‌ای (exported=false).
 */

// ---- پروتکل پیام‌ها (بین کلاینت پروسهٔ اصلی و سرویس پروسهٔ :llm) ----
internal const val MSG_PING = 1
internal const val MSG_LOAD = 2
internal const val MSG_COMPLETE = 3
internal const val MSG_UNLOAD = 4
internal const val MSG_CANCEL = 5

internal const val KEY_PATH = "path"
internal const val KEY_PROMPT = "prompt"
internal const val KEY_TEXT = "text"
internal const val KEY_ERROR = "error"
internal const val KEY_AVAILABLE = "available"

/** نتیجهٔ کاوش موتور بومی؛ [kind] صفر یعنی موتور در دسترس نیست و [error] دلیل فارسی است. */
data class ProbeResult(
    val kind: Int,
    val available: Boolean,
    val error: String? = null
) {
    val isHealthy: Boolean get() = available && kind >= 1
}

/**
 * سرویس میزبان موتور بومی؛ در پروسهٔ جداگانه اجرا می‌شود (android:process=":llm").
 * همهٔ فراخوانی‌های بومی روی یک HandlerThread سریال می‌شوند.
 */
class LlmIsolationService : Service() {

    private lateinit var workerThread: HandlerThread
    private lateinit var worker: Handler
    private val inbound: Messenger by lazy { Messenger(worker) }

    override fun onCreate() {
        super.onCreate()
        HostLlmRuntime.attachContext(applicationContext)
        workerThread = HandlerThread("ourspace-llm-isolated").apply { start() }
        worker = object : Handler(workerThread.looper) {
            override fun handleMessage(msg: Message) {
                // پیام‌های یک‌طرفه (بدون replyTo) فقط قبل از بررسی پاسخ‌دهنده مدیریت شوند.
                if (msg.what == MSG_UNLOAD) {
                    runCatching { HostLlmRuntime.directUnload() }
                    return
                }
                if (msg.what == MSG_CANCEL) {
                    runCatching { HostLlmRuntime.directCancel() }
                    return
                }
                val replyTo = msg.replyTo ?: return

                val reply = Message.obtain().apply {
                    what = msg.what
                    arg1 = msg.arg1 // همان شناسهٔ ترتیبی درخواست
                    arg2 = 0
                }
                try {
                    when (msg.what) {
                        MSG_PING -> {
                            // نوع بک‌اند + دلیل دقیق در دسترس‌نبودن کتابخانه برای عیب‌یابی.
                            val kind = HostLlmRuntime.directBackendKind()
                            reply.arg2 = kind
                            if (kind < 1) {
                                val detail = HostLlmRuntime.directLastError()
                                    ?: "کتابخانهٔ بومی در پروسهٔ ایزوله بارگذاری نشد."
                                val report = HostLlmRuntime.environmentReport(applicationContext)
                                reply.data = Bundle().apply {
                                    putBoolean(KEY_AVAILABLE, false)
                                    putString(KEY_ERROR, "$detail · $report")
                                }
                            }
                        }
                        MSG_LOAD -> {
                            val path = msg.data?.getString(KEY_PATH).orEmpty()
                            val ok = HostLlmRuntime.directEnsureModelLoaded(path, applicationContext)
                            reply.arg2 = if (ok) 0 else -1
                            // همیشه kind و (در صورت شکست) دلیل را برگردان تا کلاینت کش کاوش را هم‌زمان به‌روز کند.
                            val kind = HostLlmRuntime.directBackendKind()
                            val err = if (!ok) HostLlmRuntime.directLastError() else null
                            reply.data = Bundle().apply {
                                putBoolean(KEY_AVAILABLE, ok)
                                putInt("kind", kind)
                                if (!err.isNullOrBlank()) putString(KEY_ERROR, err)
                            }
                        }
                        MSG_COMPLETE -> {
                            val prompt = msg.data?.getString(KEY_PROMPT).orEmpty()
                            val text = HostLlmRuntime.directCompleteText(prompt, msg.arg2)
                            val kind = HostLlmRuntime.directBackendKind()
                            if (text.isNullOrBlank()) {
                                reply.arg2 = 1
                                reply.data = Bundle().apply { putInt("kind", kind) }
                            } else {
                                reply.arg2 = 0
                                reply.data = Bundle().apply {
                                    putString(KEY_TEXT, text)
                                    putInt("kind", kind)
                                }
                            }
                        }
                        else -> return
                    }
                } catch (t: Throwable) {
                    // حتی اگر لایهٔ بومی به‌جای abort یک استثنا بیرون بیندازد، پاسخ خطا برمی‌گردد.
                    Log.w(TAG, "isolated service handler failure: ${t.message}")
                    reply.arg2 = -1
                    reply.data = Bundle().apply {
                        putString(KEY_ERROR, t.message ?: "native failure")
                    }
                }
                runCatching { replyTo.send(reply) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder = inbound.binder

    override fun onDestroy() {
        runCatching { workerThread.quitSafely() }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "LlmIsolationService"
    }
}

/**
 * کلاینت پروسهٔ اصلی: اتصال به سرویس ایزوله، فراخوانی همگامِ امن، تشخیص مرگ
 * پروسهٔ بومی و گیت ضدِ کرش‌لوپ (تا وقتی مدل عوض نشده دیگر سراغ بومی نمی‌رود).
 *
 * کاوش اتصال چندبار تلاش می‌کند و با هر پینگ سالم، گیت کهنهٔ ناشی از تست‌های
 * قبلی به‌صورت خودکار باز می‌شود تا نصب APK جدید هیچ‌وقت در وضعیت «none» گیر نکند.
 */
object LlmServiceClient {

    private const val TAG = "LlmServiceClient"
    private const val PREFS = "ourspace_llm_gate"
    private const val KEY_GATE_DISABLED = "disabled"
    private const val KEY_GATE_REASON = "reason"

    private const val BIND_TIMEOUT_MS = 8_000L
    private const val PING_TIMEOUT_MS = 8_000L
    const val LOAD_TIMEOUT_MS = 60_000L
    const val COMPLETE_TIMEOUT_MS = 50_000L

    private const val CRASH_REASON =
        "موتور بومی هوش مصنوعی هنگام کار با این مدل متوقف شد؛ برای جلوگیری از بسته‌شدن برنامه، " +
            "فعلاً پاسخ قانون‌محمد جایگزین می‌شود. مدل سبک‌تری را امتحان کنید یا مدل دیگری انتخاب کنید."

    private val seq = AtomicInteger(1)
    private val pending = ConcurrentHashMap<Int, CompletableDeferred<Message>>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val probeMutex = Mutex()

    @Volatile
    private var appCtx: Context? = null

    @Volatile
    private var remote: Messenger? = null

    @Volatile
    private var connecting = false

    @Volatile
    private var connectedDeferred: CompletableDeferred<Unit> = CompletableDeferred()

    // آخرین نتیجهٔ کاوش؛ null یعنی هنوز کاوشی تمام نشده.
    @Volatile
    private var cachedProbe: ProbeResult? = null

    @Volatile
    private var warmUpStarted = false

    /** پس از هر کاوش موفق/ناموفق برای به‌روزرسانی وضعیت مدل فراخوانی می‌شود. */
    @Volatile
    private var probeCompletedListener: ((ProbeResult) -> Unit)? = null

    /** مسیر مدل آمادهٔ کاربر برای پیش‌بارگذاری پس از وصل‌شدن سرویس. */
    @Volatile
    private var preloadPathProvider: (() -> String?)? = null

    fun setPreloadPathProvider(provider: (() -> String?)?) {
        preloadPathProvider = provider
    }

    fun setProbeCompletedListener(listener: ((ProbeResult) -> Unit)?) {
        probeCompletedListener = listener
    }

    private val inbound = Messenger(object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            pending.remove(msg.arg1)?.complete(msg)
        }
    })

    private val deathRecipient = IBinder.DeathRecipient { handleRemoteDeath("binderDied") }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            connecting = false
            if (service == null) {
                connectedDeferred = CompletableDeferred()
                return
            }
            remote = Messenger(service)
            runCatching { service.linkToDeath(deathRecipient, 0) }
            connectedDeferred.complete(Unit)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            // قطع موقت؛ درخواست‌های در جریان با شکست مواجه شوند و فراخوانی بعدی دوباره وصل شود.
            remote = null
            connectedDeferred = CompletableDeferred()
            failAllPending()
        }
    }

    fun init(context: Context) {
        if (appCtx == null) appCtx = context.applicationContext
    }

    // ---- گیت ضدِ کرش‌لوپ: بعد از مرگ پروسهٔ بومی تا تغییر مدل غیرفعال می‌ماند ----
    fun isGateDisabled(context: Context? = appCtx): Boolean {
        val ctx = context ?: return false
        return runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_GATE_DISABLED, false)
        }.getOrDefault(false)
    }

    fun gateReason(context: Context? = appCtx): String? {
        val ctx = context ?: return null
        return runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_GATE_REASON, null)
        }.getOrNull()
    }

    fun resetGate(context: Context? = appCtx) {
        clearGatePrefs(context)
        cachedProbe = null
        reprobe()
    }

    private fun clearGatePrefs(context: Context? = appCtx) {
        val ctx = context ?: return
        runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().clear().apply()
        }
    }

    /** ارسال پیام بدون انتظار پاسخ (UNLOAD/CANCEL)؛ هیچ درخواست معلق‌ی ثبت نمی‌شود. */
    fun sendOneWay(what: Int) {
        val ctx = appCtx ?: return
        if (isGateDisabled(ctx)) return
        scope.launch {
            if (!connectBlocking()) return@launch
            runCatching {
                remote?.send(Message.obtain().apply { this.what = what })
            }
        }
    }

    private fun disableGate(reason: String) {
        val ctx = appCtx ?: return
        runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_GATE_DISABLED, true)
                .putString(KEY_GATE_REASON, reason)
                .apply()
        }
        cachedProbe = ProbeResult(0, false, reason)
        notifyProbeCompleted()
    }

    // ---- کش بدون انسداد برای فراخوان‌های رشتهٔ اصلی ----
    fun currentProbe(): ProbeResult? = cachedProbe

    fun isNativeAvailableCached(): Boolean {
        val probe = cachedProbe
        if (probe != null) return probe.isHealthy && !isGateDisabled()
        // کاوش هنوز تمام نشده؛ خوش‌بینانه true تا وضعیت مدل مثبت کاذبِ «none» ندهد.
        scheduleWarmUp()
        return !isGateDisabled()
    }

    fun backendKindCached(): Int {
        val probe = cachedProbe
        if (probe != null) return if (isGateDisabled()) 0 else probe.kind
        scheduleWarmUp()
        // خوش‌بینانه ۲؛ اگر بیلد واقعاً پل باشد، نتیجهٔ کاوش خیلی سریع کش را اصلاح می‌کند.
        return if (isGateDisabled()) 0 else 2
    }

    /** آخرین خطای قابل‌نمایش به کاربر (کاوش یا گیت). */
    fun probeError(): String? = cachedProbe?.error ?: gateReason()

    /**
     * پس از بارگذاری موفق مدل (MSG_LOAD)، کش کاوش را هم‌راستا با واقعیت سرویس می‌کند
     * تا UI دیگر روی وضعیت کهنهٔ «کتابخانه بارگذاری نشد» گیر نکند.
     */
    fun markNativeHealthy(kind: Int) {
        if (kind < 1) return
        if (isGateDisabled()) clearGatePrefs()
        val previous = cachedProbe
        cachedProbe = ProbeResult(kind, true, null)
        if (previous == null || !previous.isHealthy || previous.kind != kind) {
            notifyProbeCompleted()
        }
    }

    fun scheduleWarmUp() {
        if (warmUpStarted) return
        warmUpStarted = true
        scope.launch {
            runCatching { probeNow() }
        }
    }

    /** کاوش اجباری تازه (دکمهٔ «بررسی» تنظیمات یا بازنشانی گیت). */
    fun reprobe() {
        warmUpStarted = true
        scope.launch {
            runCatching { probeNow(force = true) }
        }
    }

    /**
     * تا سه بار با فاصلهٔ زمانی تلاش می‌کند به سرویس ایزوله وصل شود و پینگ بگیرد.
     * پینگ همیشه از گیت عبور می‌کند؛ پاسخ سالم یعنی موتور واقعاً سالم است و گیت
     * کهنهٔ ناشی از مرگ‌های قبلی خودکار پاک می‌شود.
     */
    suspend fun probeNow(force: Boolean = false): ProbeResult = probeMutex.withLock {
        if (!force) {
            cachedProbe?.takeIf { it.isHealthy }?.let { return@withLock it }
        }
        val backoffs = longArrayOf(0L, 1_500L, 3_500L)
        var last: ProbeResult = ProbeResult(0, false, "کاوش موتور بومی انجام نشد.")
        for (attempt in backoffs.indices) {
            if (attempt > 0) {
                unbindQuietly()
                delay(backoffs[attempt])
            }
            val result = runCatching { attemptProbe() }
                .getOrElse { ProbeResult(0, false, it.message ?: "خطای ناشناخته در اتصال موتور.") }
            last = result
            cachedProbe = result
            if (result.isHealthy) {
                // شفای خودکار: سرویس سالم پاسخ داد؛ گیت کهنه دیگر اعتباری ندارد.
                if (isGateDisabled()) clearGatePrefs()
                notifyProbeCompleted()
                if (result.kind == 2) preloadModel()
                return@withLock result
            }
            notifyProbeCompleted()
        }
        last
    }

    private suspend fun attemptProbe(): ProbeResult {
        if (!connectBlocking()) {
            return ProbeResult(0, false, "سرویس ایزولهٔ موتور هوش مصنوعی متصل نشد.")
        }
        val id = seq.getAndIncrement()
        val deferred = CompletableDeferred<Message>()
        pending[id] = deferred
        val msg = Message.obtain().apply {
            what = MSG_PING
            arg1 = id
            replyTo = inbound
        }
        val target = remote ?: return ProbeResult(0, false, "اتصال موتور برقرار نیست.")
        val sent = runCatching { target.send(msg) }.isSuccess
        if (!sent) {
            pending.remove(id)
            return ProbeResult(0, false, "ارسال درخواست به سرویس موتور ناموفق بود.")
        }
        val reply = withTimeoutOrNull(PING_TIMEOUT_MS) { deferred.await() }
        if (reply == null) {
            pending.remove(id)
            return ProbeResult(0, false, "سرویس موتور در زمان مقرر پاسخ نداد.")
        }
        val kind = reply.arg2
        return if (kind >= 1) {
            ProbeResult(kind, true, null)
        } else {
            ProbeResult(
                0,
                false,
                reply.data?.getString(KEY_ERROR) ?: "کتابخانهٔ بومی هوش مصنوعی بارگذاری نشد."
            )
        }
    }

    private fun notifyProbeCompleted() {
        val listener = probeCompletedListener ?: return
        val snapshot = cachedProbe ?: return
        // روی رشتهٔ IO؛ مرگ بایندر از ترد اصلی می‌آید و refresh شامل خواندن فایل است.
        scope.launch { runCatching { listener(snapshot) } }
    }

    /**
     * بارگذاری مدل در پس‌زمینه، بلافاصله بعد از اتصال سرویس؛ اولین پیام کاربر دیگر
     * معطل تجزیهٔ فایل چندگیگابایتی GGUF نمی‌شود.
     */
    private fun preloadModel() {
        val ctx = appCtx ?: return
        if (isGateDisabled(ctx)) return
        val path = runCatching { preloadPathProvider?.invoke() }.getOrNull()
        if (path.isNullOrBlank()) return
        scope.launch {
            runCatching {
                val reply = requestBlocking(
                    what = MSG_LOAD,
                    data = Bundle().apply { putString(KEY_PATH, path) },
                    timeoutMs = LOAD_TIMEOUT_MS
                )
                if (reply != null && reply.arg2 == 0) {
                    val kind = reply.data?.getInt("kind", 0)?.takeIf { it >= 1 } ?: 2
                    markNativeHealthy(kind)
                    Log.i(TAG, "model preloaded ahead of first chat: $path")
                } else {
                    Log.w(TAG, "model preload did not complete; will retry on first chat")
                }
            }
        }
    }

    @Synchronized
    private fun connectBlocking(): Boolean {
        val ctx = appCtx ?: return false
        remote?.let { return true }
        if (!connecting) {
            connecting = true
            connectedDeferred = CompletableDeferred()
            val intent = Intent(ctx, LlmIsolationService::class.java).apply {
                setPackage(ctx.packageName)
            }
            val bound = runCatching {
                ctx.bindService(intent, connection, Context.BIND_AUTO_CREATE)
            }.getOrDefault(false)
            if (!bound) {
                connecting = false
                return false
            }
        }
        val ok = runBlocking {
            withTimeoutOrNull(BIND_TIMEOUT_MS) { connectedDeferred.await() }
        } != null
        if (!ok) connecting = remote == null
        return ok && remote != null
    }

    private fun unbindQuietly() {
        remote = null
        connecting = false
        connectedDeferred = CompletableDeferred()
        runCatching { appCtx?.unbindService(connection) }
    }

    /**
     * فراخوانی همگام از رشته‌های پس‌زمینه؛ هرگز روی رشتهٔ اصلی صدا زده نشود
     * (همهٔ فراخوان‌های فعلی از Dispatchers.IO/Default یا رشتهٔ پولر هستند).
     */
    fun requestBlocking(
        what: Int,
        data: Bundle? = null,
        arg2: Int = 0,
        timeoutMs: Long
    ): Message? {
        val ctx = appCtx ?: return null
        if (what != MSG_PING && isGateDisabled(ctx)) return null
        if (!connectBlocking()) return null

        val id = seq.getAndIncrement()
        val msg = Message.obtain().apply {
            this.what = what
            this.arg1 = id
            this.arg2 = arg2
            if (data != null) setData(data)
            replyTo = inbound
        }
        val deferred = CompletableDeferred<Message>()
        pending[id] = deferred

        val target = remote ?: run {
            pending.remove(id)
            return null
        }
        val sent = runCatching { target.send(msg) }.isSuccess
        if (!sent) {
            pending.remove(id)
            return null
        }

        val reply = runBlocking {
            withTimeoutOrNull(timeoutMs) { deferred.await() }
        }
        if (reply == null) {
            pending.remove(id)
            if (what == MSG_COMPLETE) {
                // تولید بومی طولانی شده؛ توقف حلقهٔ توکن را درخواست کن تا CPU هدر نرود.
                runCatching {
                    val cancel = Message.obtain().apply { this.what = MSG_CANCEL }
                    remote?.send(cancel)
                }
            }
            Log.w(TAG, "request $what timed out after ${timeoutMs}ms")
        }
        return reply
    }

    private fun failAllPending() {
        val entries = pending.entries.toList()
        pending.clear()
        entries.forEach { (_, deferred) ->
            runCatching { deferred.complete(Message.obtain().apply { arg2 = -1 }) }
        }
    }

    private fun handleRemoteDeath(cause: String) {
        Log.e(TAG, "isolated LLM process died ($cause) — engaging safety gate")
        unbindQuietly()
        failAllPending()
        disableGate(CRASH_REASON)
    }
}
