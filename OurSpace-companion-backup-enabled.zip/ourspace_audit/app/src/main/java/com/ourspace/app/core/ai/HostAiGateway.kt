package com.ourspace.app.core.ai

import android.content.Context
import android.util.Log
import org.json.JSONObject

/**
 * Host entry for AI completion (phase 1 rules + phase 2b native GGUF bridge).
 *
 * This is the process-crash boundary: any failure of the native runtime
 * (UnsatisfiedLinkError, OOM, unsupported GGUF architecture, timeout) is
 * contained here and degrades to the deterministic rule-based engine so the
 * AI chat keeps answering instead of the app closing.
 */
object HostAiGateway {
    private const val TAG = "HostAiGateway"

    @Volatile
    private var store: AiModelStore? = null

    fun init(context: Context) {
        // اول کلاینت سرویس ایزوله آماده و گرم شود؛ refresh زیر ممکن است در همین رشته
        // مقادیر کش‌شدهٔ نوع بک‌اند را بخواند و نباید با appCtx مقداردهی‌نشده اجرا شود.
        LlmServiceClient.init(context.applicationContext)
        if (store == null) {
            synchronized(this) {
                if (store == null) {
                    store = AiModelStore(context.applicationContext).also { it.refresh() }
                }
            }
        }
        // مدل آماده پس از اتصال سرویس در پس‌زمینه بارگذاری شود تا اولین پیام سریع باشد.
        LlmServiceClient.setPreloadPathProvider {
            val st = store?.state?.value
            st?.localPath?.takeIf {
                st.status == AiModelStatus.READY || st.status == AiModelStatus.RUNTIME_MISSING
            }
        }
        // با هر کاوش موفق/ناموفق، وضعیت مدل در UI هم به‌روز شود تا برچسب «none» گیر نکند.
        LlmServiceClient.setProbeCompletedListener { store?.refresh() }
        LlmServiceClient.scheduleWarmUp()
    }

    fun modelStore(context: Context): AiModelStore {
        init(context)
        return store!!
    }

    fun complete(context: Context, request: JSONObject): LocalAiEngine.Result =
        runCatching { completeUnsafe(context, request) }
            .getOrElse { throwable ->
                Log.w(TAG, "native AI path failed, using rules fallback: ${throwable.message}")
                LocalAiEngine.complete(request).copy(engine = "rules-v1 (fallback)")
            }

    private fun completeUnsafe(context: Context, request: JSONObject): LocalAiEngine.Result {
        init(context)
        val st = store!!.state.value
        val path = st.localPath
        val modelReady = !path.isNullOrBlank() &&
            (st.status == AiModelStatus.READY || st.status == AiModelStatus.RUNTIME_MISSING)

        // همیشه مسیر بومی را امتحان کن اگر فایل مدل هست.
        // ممکن است کش kind کهنه باشد (۱ به‌جای ۲)؛ completeNative خودش مدل را لود و kind واقعی را مشخص می‌کند.
        if (modelReady) {
            val native = HostLlmRuntime.completeNative(request, path!!, context)
            if (native != null) {
                // فقط پاسخ واقعی llama.cpp را بپذیر؛ پل بومی (backend 1) جملهٔ ثابت است نه مدل.
                val kind = HostLlmRuntime.backendKind()
                if (kind == 2 || native.engine == "local-llama") {
                    return native
                }
                Log.i(TAG, "native bridge responded but llama.cpp not linked (kind=$kind); using rules")
            }
        }

        val base = LocalAiEngine.complete(request)
        val kind = HostLlmRuntime.backendKind()
        val engine = when {
            kind == 2 && modelReady -> "قوانین (استنتاج بومی این بار پاسخ نداد)"
            kind == 1 -> "قوانین (llama.cpp در این بیلد لینک نشده)"
            modelReady -> "قوانین (مدل لود نشد)"
            else -> "قوانین"
        }
        return base.copy(engine = engine)
    }
}
