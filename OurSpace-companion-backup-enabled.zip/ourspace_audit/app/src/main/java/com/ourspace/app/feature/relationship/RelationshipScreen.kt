package com.ourspace.app.feature.relationship

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.material3.Surface
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Slideshow
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import com.ourspace.app.ui.design.OSConfirmDialog
import com.ourspace.app.ui.design.OSFormDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.produceState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.ourspace.app.BuildConfig
import com.ourspace.app.core.database.AttachmentEntity
import com.ourspace.app.core.database.CoupleProfileEntity
import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import com.ourspace.app.core.database.MemoryEntity
import com.ourspace.app.core.database.WatchlistItemEntity
import com.ourspace.app.core.database.BookItemEntity
import com.ourspace.app.core.database.FoodItemEntity
import com.ourspace.app.core.database.MoodCheckInEntity
import com.ourspace.app.core.database.SpecialDateEntity
import com.ourspace.app.core.cycle.CycleInsights
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.AppViewModel
import com.ourspace.app.ui.components.FloatingMotion
import com.ourspace.app.ui.components.MotionCard
import com.ourspace.app.ui.components.PersianDatePickerDialog
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode
import java.util.concurrent.TimeUnit
import java.util.Calendar
import java.time.Instant
import java.time.ZoneId
import java.time.temporal.ChronoUnit

private data class MoodOption(val code: String, val emoji: String, val label: String)

private val moods = listOf(
    MoodOption("GREAT", "😍", "عالی"),
    MoodOption("HAPPY", "😊", "خوشحال"),
    MoodOption("LOVED", "🥰", "عاشقانه"),
    MoodOption("CALM", "😌", "آرام"),
    MoodOption("EXCITED", "🤩", "هیجان‌زده"),
    MoodOption("GRATEFUL", "🙏", "قدردان"),
    MoodOption("TIRED", "😴", "خسته"),
    MoodOption("STRESSED", "😣", "پراسترس"),
    MoodOption("SAD", "😔", "دلگیر"),
    MoodOption("ANGRY", "😠", "عصبانی"),
    MoodOption("ANXIOUS", "😟", "نگران"),
    MoodOption("SICK", "🤒", "ناخوش")
)

@Composable
fun RelationshipScreen(
    focusItemId: String? = null,
    focusCategory: String? = null,
    focusTab: Int? = null,
    isImeVisible: Boolean = false,
    onFocusConsumed: () -> Unit = {},
    role: DeviceRole,
    ownDeviceId: String,
    profile: CoupleProfileEntity?,
    memories: List<MemoryEntity>,
    attachments: List<AttachmentEntity>,
    attachmentAction: AppViewModel.AttachmentActionState,
    moodCheckIns: List<MoodCheckInEntity>,
    specialDates: List<SpecialDateEntity>,
    cycleLogs: List<CycleLogEntity>,
    cycleSettings: CycleSettingsEntity?,
    watchlistItems: List<WatchlistItemEntity> = emptyList(),
    palette: AppPalette,
    themeMode: AppThemeMode,
    dynamicColor: Boolean = true,
    onAddWatchlistItem: (String, String, String, Int, Int) -> Unit = { _, _, _, _, _ -> },
    onUpdateWatchlistItem: (WatchlistItemEntity, String, String, String, String, Int, Int, Int) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onAdjustWatchlistWatchedEpisodes: (WatchlistItemEntity, Int) -> Unit = { _, _ -> },
    onCycleWatchlistStatus: (WatchlistItemEntity) -> Unit = {},
    onDeleteWatchlistItem: (WatchlistItemEntity) -> Unit = {},
    bookItems: List<BookItemEntity> = emptyList(),
    foodItems: List<FoodItemEntity> = emptyList(),
    onAddBookItem: (String, String, String, Int) -> Unit = { _, _, _, _ -> },
    onUpdateBookItem: (BookItemEntity, String, String, String, String, Int, Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onAdjustBookReadPages: (BookItemEntity, Int) -> Unit = { _, _ -> },
    onCycleBookStatus: (BookItemEntity) -> Unit = {},
    onDeleteBookItem: (BookItemEntity) -> Unit = {},
    onAddFoodItem: (String, String) -> Unit = { _, _ -> },
    onToggleFoodFavorite: (FoodItemEntity) -> Unit = {},
    onDeleteFoodItem: (FoodItemEntity) -> Unit = {},
    onAddMemory: (String, String, String, Long) -> Unit,
    onUpdateMemory: (MemoryEntity, String, String, String, Long) -> Unit = { _, _, _, _, _ -> },
    onAddMemoryAttachment: (String, String, Int) -> Unit,
    onRotateMemoryAttachment: (String, Int) -> Unit = { _, _ -> },
    onSaveAttachment: (String, String) -> Unit,
    onLoadAttachment: suspend (String) -> AttachmentEntity? = { null },
    onDeleteAttachment: (AttachmentEntity) -> Unit,
    onToggleMemoryFavorite: (MemoryEntity) -> Unit,
    onDeleteMemory: (MemoryEntity) -> Unit,
    onShareMemoryToChat: (MemoryEntity) -> Unit = {},
    onSetMood: (String, String) -> Unit,
    onAddSpecialDate: (String, String, Long, Boolean) -> Unit,
    onUpdateSpecialDate: (SpecialDateEntity, String, String, Long, Boolean) -> Unit,
    onDeleteSpecialDate: (SpecialDateEntity) -> Unit,
    onStartPeriod: (Long, String, String) -> Unit,
    onEndPeriod: (CycleLogEntity, Long) -> Unit,
    onDeleteCycleLog: (CycleLogEntity) -> Unit,
    onUpdateCycleSettings: (Int, Int, Boolean) -> Unit,
    onSaveProfile: (String, String, Long?) -> Unit,
    onSetPalette: (AppPalette) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit,
    onSetDynamicColor: (Boolean) -> Unit = {},
    onReset: () -> Unit
) {
    val haptics = LocalHapticFeedback.current
    var clockNow by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            clockNow = System.currentTimeMillis()
        }
    }
    val today = remember(clockNow) { PersianDateFormatter.jalaliDayKey(clockNow) }
    val todayMoods = moodCheckIns.filter { it.dayKey == today && !it.isDeleted }
    val ownMood = todayMoods.firstOrNull { it.deviceId == ownDeviceId }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showMemoryDialog by remember { mutableStateOf(false) }
    var showMemorySlideshow by remember { mutableStateOf(false) }
    var fullscreenGalleryImage by remember { mutableStateOf<AttachmentEntity?>(null) }
    var editingMemory by remember { mutableStateOf<MemoryEntity?>(null) }
    var showDateDialog by remember { mutableStateOf(false) }
    var editingSpecialDate by remember { mutableStateOf<SpecialDateEntity?>(null) }
    var selectedRelationshipTab by remember { mutableIntStateOf(0) }
    var highlightId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(focusItemId, focusTab, focusCategory) {
        when {
            focusTab != null -> selectedRelationshipTab = focusTab
            focusCategory == "watchlist" -> selectedRelationshipTab = 1
            focusCategory == "book" -> selectedRelationshipTab = 2
            focusCategory == "food" -> selectedRelationshipTab = 3
            focusCategory in setOf("memory", "special") -> selectedRelationshipTab = 0
        }
        if (!focusItemId.isNullOrBlank()) {
            highlightId = focusItemId
            onFocusConsumed()
            kotlinx.coroutines.delay(4000)
            if (highlightId == focusItemId) highlightId = null
        } else if (focusTab != null || !focusCategory.isNullOrBlank()) {
            onFocusConsumed()
        }
    }
    var selectedOccasionSubTab by remember { mutableIntStateOf(0) } // 0 occasions, 1 shared memories
    var showCycleSettings by remember { mutableStateOf(false) }
    var showStartPeriodDialog by remember { mutableStateOf(false) }
    // cycle settings dialog rendered below
    var imageTargetMemoryId by remember { mutableStateOf<String?>(null) }
    var pendingRotateUri by remember { mutableStateOf<String?>(null) }
    var pendingRotateMemoryId by remember { mutableStateOf<String?>(null) }
    var pendingRotationDegrees by remember { mutableIntStateOf(0) }
    var galleryMemoryId by remember { mutableStateOf<String?>(null) }
    var galleryImageIndex by remember { mutableIntStateOf(0) }
    var memoryFilter by remember { mutableIntStateOf(0) } // 0 all, 1 favorites, 2 anniversary album
    var memoryYear by remember { mutableStateOf<Int?>(null) } // Jalali year
    var memoryMonth by remember { mutableStateOf<Int?>(null) } // Jalali month 1..12
    val currentJalali = remember(clockNow) { PersianDateFormatter.jalaliDate(clockNow) }
    var calendarYear by remember { mutableIntStateOf(currentJalali.year) }
    var calendarMonth by remember { mutableIntStateOf(currentJalali.month) }
    var selectedCalendarDayKey by remember { mutableStateOf<String?>(null) }
    val memoryYears = remember(memories) {
        memories.map { PersianDateFormatter.jalaliDate(it.occurredAt).year }
            .distinct().sortedDescending()
    }
    val filteredMemories = remember(memories, memoryFilter, memoryYear, memoryMonth, specialDates, selectedCalendarDayKey) {
        val base = memories.filter { m ->
            val j = PersianDateFormatter.jalaliDate(m.occurredAt)
            val dayKey = "${j.year}-${j.month.toString().padStart(2, '0')}-${j.day.toString().padStart(2, '0')}"
            (selectedCalendarDayKey == null || dayKey == selectedCalendarDayKey) &&
                (memoryFilter != 1 || m.isFavorite) &&
                (memoryYear == null || j.year == memoryYear) &&
                (memoryMonth == null || j.month == memoryMonth)
        }
        if (memoryFilter != 2) base
        else {
            // Anniversary album: memories near yearly special dates (same month, ±3 days).
            val anniversaryMonths = specialDates.filter { !it.isDeleted && it.repeatYearly }
            if (anniversaryMonths.isEmpty()) base.filter { it.isFavorite }
            else base.filter { m ->
                val jm = PersianDateFormatter.jalaliDate(m.occurredAt)
                anniversaryMonths.any { sd ->
                    val sj = PersianDateFormatter.jalaliDate(sd.occurredAt)
                    jm.month == sj.month && kotlin.math.abs(jm.day - sj.day) <= 3
                } || m.isFavorite
            }
        }
    }
    val timelineGroups = remember(filteredMemories) {
        filteredMemories
            .sortedByDescending { it.occurredAt }
            .groupBy {
                val j = PersianDateFormatter.jalaliDate(it.occurredAt)
                j.year to j.month
            }
            .toList()
            .sortedByDescending { (key, _) -> key.first * 100 + key.second }
    }
    var pendingExport by remember { mutableStateOf<AttachmentEntity?>(null) }
    var pendingDelete by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    val memoryAttachments = remember(attachments) {
        attachments.asSequence()
            .filter { it.mimeType.startsWith("image/") && !it.isDeleted }
            .mapNotNull { attachment -> attachment.memoryId?.let { it to attachment } }
            .groupBy(keySelector = { it.first }, valueTransform = { it.second })
            .mapValues { (_, images) -> images.sortedBy { it.createdAt } }
    }
    val memoryImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val memoryId = imageTargetMemoryId
        imageTargetMemoryId = null
        if (uri != null && memoryId != null) {
            pendingRotateMemoryId = memoryId
            pendingRotateUri = uri.toString()
            pendingRotationDegrees = 0
        }
    }
    val memoryImageSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/*")
    ) { uri ->
        val attachment = pendingExport
        if (uri != null && attachment != null) onSaveAttachment(attachment.id, uri.toString())
        pendingExport = null
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(selectedRelationshipTab, isImeVisible) {
                // تب‌های این صفحه در بدنه با سوایپ عوض می‌شوند؛ حرکت عمودی و کیبورد دخالت نمی‌کنند.
                if (!isImeVisible) {
                    val swipeThresholdPx = 64.dp.toPx()
                    var horizontalDrag = 0f
                    detectHorizontalDragGestures(
                        onHorizontalDrag = { change, dragAmount ->
                            horizontalDrag += dragAmount
                            change.consume()
                        },
                        onDragEnd = {
                            val drag = horizontalDrag
                            horizontalDrag = 0f
                            val nextTab = when {
                                drag <= -swipeThresholdPx -> (selectedRelationshipTab - 1).coerceAtLeast(0)
                                drag >= swipeThresholdPx -> (selectedRelationshipTab + 1).coerceAtMost(4)
                                else -> selectedRelationshipTab
                            }
                            selectedRelationshipTab = nextTab
                        },
                        onDragCancel = { horizontalDrag = 0f }
                    )
                }
            }
    ) {
        // Tab bars use high zIndex so LazyColumn cannot steal clicks.
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .zIndex(10f)
                .background(MaterialTheme.colorScheme.background.copy(alpha = 0.94f))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedRelationshipTab == 0,
                onClick = { selectedRelationshipTab = 0 },
                label = { Text("ما") }
            )
            FilterChip(
                selected = selectedRelationshipTab == 1,
                onClick = { selectedRelationshipTab = 1 },
                label = { Text("مناسبت‌ها و خاطرات") }
            )
            FilterChip(
                selected = selectedRelationshipTab == 2,
                onClick = { selectedRelationshipTab = 2 },
                label = { Text("فیلم و سریال") }
            )
            FilterChip(
                selected = selectedRelationshipTab == 3,
                onClick = { selectedRelationshipTab = 3 },
                label = { Text("کتاب‌ها") }
            )
            FilterChip(
                selected = selectedRelationshipTab == 4,
                onClick = { selectedRelationshipTab = 4 },
                label = { Text("غذاها") }
            )
        }
        if (selectedRelationshipTab == 1) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .zIndex(10f)
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.94f))
                    .padding(start = 16.dp, end = 16.dp, top = 58.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedOccasionSubTab == 0,
                    onClick = { selectedOccasionSubTab = 0 },
                    label = { Text("مناسبت‌ها (${PersianDateFormatter.toPersianDigits(specialDates.count { !it.isDeleted })})") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = selectedOccasionSubTab == 1,
                    onClick = { selectedOccasionSubTab = 1 },
                    label = { Text("خاطرات مشترک (${PersianDateFormatter.toPersianDigits(memories.size)})") },
                    modifier = Modifier.weight(1f)
                )
            }
            if (selectedOccasionSubTab == 0) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(top = 106.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        RelationshipStats(
                            memories = memories.size,
                            favorites = memories.count { it.isFavorite },
                            dates = specialDates.size
                        )
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("مناسبت‌های ما", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                Text("تولدها، سالگردها و روزهای مهم شما", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(onClick = { editingSpecialDate = null; showDateDialog = true }) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("مناسبت جدید")
                            }
                        }
                    }
                    if (specialDates.none { !it.isDeleted }) {
                        item {
                            EmptyRelationshipCard(
                                icon = "✦",
                                title = "اولین مناسبت را ثبت کنید",
                                body = "تولد، سالگرد یا هر روز مهم دیگری.",
                                onClick = { editingSpecialDate = null; showDateDialog = true }
                            )
                        }
                    } else {
                        items(
                            specialDates.filterNot { it.isDeleted }.sortedBy { date ->
                                if (date.repeatYearly) nextSpecialDateOccurrence(date, clockNow)
                                else date.occurredAt.takeIf { it >= clockNow } ?: Long.MAX_VALUE
                            },
                            key = { "special-date-${it.id}" }
                        ) { date ->
                            SpecialDateCard(
                                date = date,
                                now = clockNow,
                                modifier = Modifier.fillMaxWidth(),
                                onEdit = { editingSpecialDate = date; showDateDialog = true },
                                onDelete = { pendingDelete = ("مناسبت «${date.title}»" to { onDeleteSpecialDate(date) }) }
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(top = 106.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        RelationshipStats(
                            memories = memories.size,
                            favorites = memories.count { it.isFavorite },
                            dates = specialDates.size
                        )
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("خاطرات مشترک", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                Text("لحظه‌ها و عکس‌های ثبت‌شده شما", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(onClick = { editingMemory = null; showMemoryDialog = true }) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("خاطره جدید")
                            }
                        }
                    }
                    item {
                        MemoryMonthCalendar(
                            year = calendarYear,
                            month = calendarMonth,
                            memories = memories,
                            selectedDayKey = selectedCalendarDayKey,
                            onPreviousMonth = {
                                if (calendarMonth == 1) { calendarMonth = 12; calendarYear-- } else calendarMonth--
                            },
                            onNextMonth = {
                                if (calendarMonth == 12) { calendarMonth = 1; calendarYear++ } else calendarMonth++
                            },
                            onSelectDay = { day ->
                                val key = "$calendarYear-${calendarMonth.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}"
                                selectedCalendarDayKey = if (selectedCalendarDayKey == key) null else key
                                memoryYear = null
                                memoryMonth = null
                                memoryFilter = 0
                            }
                        )
                    }
                    if (selectedCalendarDayKey != null) {
                        item {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("خاطرات روز انتخاب‌شده", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                TextButton(onClick = { selectedCalendarDayKey = null }) { Text("نمایش همه") }
                            }
                        }
                    }
                    val attachmentStatus = attachmentAction.error ?: attachmentAction.message
                    val showAttachmentStatus = attachmentAction.isLoading || attachmentAction.error != null ||
                        attachmentAction.message?.contains("تصویر") == true
                    if (attachmentStatus != null && showAttachmentStatus) {
                        item {
                            Text(
                                attachmentStatus,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (attachmentAction.error != null) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                            )
                        }
                    }
            item {
                Text(
                    "تایم‌لاین و آلبوم",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Text(
                    "بر اساس سال و ماه شمسی فیلتر کنید یا آلبوم سالگرد را ببینید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistChip(
                        onClick = { memoryFilter = 0 },
                        label = { Text(if (memoryFilter == 0) "✓ همه" else "همه") }
                    )
                    AssistChip(
                        onClick = { memoryFilter = 1 },
                        label = { Text(if (memoryFilter == 1) "✓ محبوب‌ها" else "محبوب‌ها") }
                    )
                    AssistChip(
                        onClick = { memoryFilter = 2 },
                        label = { Text(if (memoryFilter == 2) "✓ آلبوم سالگرد" else "آلبوم سالگرد") }
                    )
                }
            }
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistChip(
                        onClick = { memoryYear = null },
                        label = { Text(if (memoryYear == null) "✓ همه سال‌ها" else "همه سال‌ها", maxLines = 1) }
                    )
                    memoryYears.take(8).forEach { y ->
                        AssistChip(
                            onClick = { memoryYear = if (memoryYear == y) null else y },
                            label = {
                                Text(
                                    if (memoryYear == y) "✓ ${PersianDateFormatter.toPersianDigits(y)}"
                                    else PersianDateFormatter.toPersianDigits(y),
                                    maxLines = 1
                                )
                            }
                        )
                    }
                }
            }
            item {
                // Horizontal scroll so 12 Jalali months never overlap or merge labels.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistChip(
                        onClick = { memoryMonth = null },
                        label = { Text(if (memoryMonth == null) "✓ همه" else "همه", maxLines = 1) }
                    )
                    (1..12).forEach { m ->
                        val name = PersianDateFormatter.jalaliMonthName(m)
                        AssistChip(
                            onClick = { memoryMonth = if (memoryMonth == m) null else m },
                            label = {
                                Text(
                                    if (memoryMonth == m) "✓ $name" else name,
                                    maxLines = 1
                                )
                            }
                        )
                    }
                }
            }
            if (filteredMemories.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { showMemorySlideshow = true },
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
                        )
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Outlined.Slideshow,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text("اسلایدشو خاطرات", fontWeight = FontWeight.Black)
                                Text(
                                    "${PersianDateFormatter.toPersianDigits(filteredMemories.size)} خاطره · ورق بزنید و مرور کنید",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text("▶", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
            if (filteredMemories.isEmpty()) {
                item {
                    EmptyRelationshipCard(
                        icon = "♡",
                        title = if (selectedCalendarDayKey != null) "برای این روز خاطره‌ای ثبت نشده" else "داستان شما از اینجا شروع می‌شود",
                        body = if (selectedCalendarDayKey != null) "می‌توانید برای روز انتخاب‌شده خاطره جدیدی ثبت کنید یا همه خاطرات را ببینید." else "یک لحظه کوچک و دوست‌داشتنی را ثبت کنید.",
                        onClick = { editingMemory = null; showMemoryDialog = true }
                    )
                }
            } else {
                for ((ym, groupMemories) in timelineGroups) {
                    val (jy, jm) = ym
                    item(key = "hdr-$jy-$jm") {
                        Text(
                            "${PersianDateFormatter.jalaliMonthName(jm)} ${PersianDateFormatter.toPersianDigits(jy)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                        Text(
                            "${PersianDateFormatter.toPersianDigits(groupMemories.size)} خاطره",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(groupMemories, key = { it.id }) { memory ->
                    MemoryCard(
                        memory = memory,
                        images = memoryAttachments[memory.id].orEmpty(),
                        onLoadAttachment = onLoadAttachment,
                        isAddingImage = attachmentAction.isLoading,
                        onOpenGallery = { imageIndex ->
                            galleryMemoryId = memory.id
                            galleryImageIndex = imageIndex
                        },
                        onAddImage = {
                            imageTargetMemoryId = memory.id
                            memoryImagePicker.launch("image/*")
                        },
                        onEdit = { editingMemory = memory; showMemoryDialog = true },
                        onFavorite = { onToggleMemoryFavorite(memory) },
                        onDelete = { pendingDelete = ("خاطره «${memory.title}»" to { onDeleteMemory(memory) }) },
                        onShare = { onShareMemoryToChat(memory) }
                    )
                    }
                }
            }
                }
                FloatingActionButton(
                    onClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        editingMemory = null
                        showMemoryDialog = true
                    },
                    modifier = Modifier.align(Alignment.BottomStart).padding(20.dp),
                    containerColor = MaterialTheme.colorScheme.primary
                ) { Icon(Icons.Default.Add, "ثبت خاطره", tint = MaterialTheme.colorScheme.onPrimary) }
            }
        } else if (selectedRelationshipTab == 2) {
            WatchlistTabContent(
                watchlistItems = watchlistItems,
                onAddWatchlistItem = onAddWatchlistItem,
                onUpdateWatchlistItem = onUpdateWatchlistItem,
                onAdjustWatchlistWatchedEpisodes = onAdjustWatchlistWatchedEpisodes,
                onCycleWatchlistStatus = onCycleWatchlistStatus,
                onDeleteRequest = { item ->
                    pendingDelete = ("«${item.title}» از فهرست باهم ببینیم" to { onDeleteWatchlistItem(item) })
                }
            )
        } else if (selectedRelationshipTab == 3) {
            BooksTabContent(
                bookItems = bookItems,
                onAddBookItem = onAddBookItem,
                onUpdateBookItem = onUpdateBookItem,
                onAdjustBookReadPages = onAdjustBookReadPages,
                onCycleBookStatus = onCycleBookStatus,
                onDeleteRequest = { item ->
                    pendingDelete = ("«${item.title}» از فهرست کتاب‌ها" to { onDeleteBookItem(item) })
                }
            )
                } else if (selectedRelationshipTab == 4) {
            FoodsTabContent(
                foodItems = foodItems,
                onAddFoodItem = onAddFoodItem,
                onToggleFavorite = onToggleFoodFavorite,
                onDeleteRequest = { item ->
                    pendingDelete = ("«${item.name}» از فهرست غذاها" to { onDeleteFoodItem(item) })
                }
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 62.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    CoupleHero(profile = profile, onEdit = { showProfileDialog = true })
                }
                item {
                    MoodCard(
                        ownMood = ownMood,
                        partnerMood = todayMoods.firstOrNull { it.deviceId != ownDeviceId },
                        onMoodSelected = { mood, note ->
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            onSetMood(mood.code, note)
                        }
                    )
                }
                item {
                    CycleTrackerCard(
                        logs = cycleLogs,
                        settings = cycleSettings,
                        onStartPeriod = {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            showStartPeriodDialog = true
                        },
                        onEndOpenPeriod = { log ->
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            onEndPeriod(log, System.currentTimeMillis())
                        },
                        onDeleteLog = { log -> pendingDelete = ("ثبت چرخه قاعدگی ${PersianDateFormatter.formatDate(log.startAt)}" to { onDeleteCycleLog(log) }) },
                        now = clockNow,
                        onOpenSettings = { showCycleSettings = true }
                    )
                }
            }
        }
    }

    if (showMemorySlideshow && filteredMemories.isNotEmpty()) {
        MemorySlideshowOverlay(
            memories = filteredMemories,
            attachmentsByMemory = memoryAttachments,
            onLoadAttachment = onLoadAttachment,
            onDismiss = { showMemorySlideshow = false },
            onOpenImage = { att -> fullscreenGalleryImage = att }
        )
    }

    fullscreenGalleryImage?.let { att ->
        FullscreenImageViewer(
            attachment = att,
            onLoadAttachment = onLoadAttachment,
            onDismiss = { fullscreenGalleryImage = null }
        )
    }

    galleryMemoryId?.let { memoryId ->
        val images = memoryAttachments[memoryId].orEmpty()
        if (images.isNotEmpty()) {
            val safeIndex = galleryImageIndex.coerceIn(images.indices)
            val selectedImage = images[safeIndex]
            MemoryGalleryDialog(
                images = images,
                onLoadAttachment = onLoadAttachment,
                initialPosition = safeIndex,
                onPositionChange = { galleryImageIndex = it },
                isBusy = attachmentAction.isLoading,
                onRotateLeft = { onRotateMemoryAttachment(selectedImage.id, -90) },
                onRotateRight = { onRotateMemoryAttachment(selectedImage.id, 90) },
                onSave = {
                    pendingExport = selectedImage
                    memoryImageSaver.launch(selectedImage.fileName.replace('/', '_').replace('\\', '_'))
                },
                onDelete = {
                    onDeleteAttachment(selectedImage)
                    galleryImageIndex = safeIndex.coerceAtMost((images.size - 2).coerceAtLeast(0))
                    if (images.size == 1) galleryMemoryId = null
                },
                onDismiss = { galleryMemoryId = null }
            )
        }
    }

    pendingRotateUri?.let { uriValue ->
        MemoryImageRotateDialog(
            uriValue = uriValue,
            rotationDegrees = pendingRotationDegrees,
            isBusy = attachmentAction.isLoading,
            onRotateLeft = { pendingRotationDegrees = (pendingRotationDegrees - 90 + 360) % 360 },
            onRotateRight = { pendingRotationDegrees = (pendingRotationDegrees + 90) % 360 },
            onConfirm = {
                val memoryId = pendingRotateMemoryId
                val degrees = pendingRotationDegrees
                pendingRotateUri = null
                pendingRotateMemoryId = null
                pendingRotationDegrees = 0
                if (memoryId != null) onAddMemoryAttachment(memoryId, uriValue, degrees)
            },
            onDismiss = {
                pendingRotateUri = null
                pendingRotateMemoryId = null
                pendingRotationDegrees = 0
            }
        )
    }

    pendingDelete?.let { request ->
        OSConfirmDialog(
            title = "تأیید حذف",
            message = "آیا مطمئن هستید ${request.first} حذف شود؟ این عمل ممکن است در دستگاه‌های همگام‌شده نیز منعکس شود.",
            confirmLabel = "حذف",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "🗑️",
            onConfirm = {
                val action = request.second
                pendingDelete = null
                action()
            },
            onDismiss = { pendingDelete = null }
        )
    }
    if (showProfileDialog) {
        ProfileDialog(
            profile = profile,
            onDismiss = { showProfileDialog = false },
            onSave = { first, second, startedAt ->
                onSaveProfile(first, second, startedAt)
                showProfileDialog = false
            }
        )
    }
    if (showMemoryDialog) {
        MemoryDialog(
            memory = editingMemory,
            onDismiss = { showMemoryDialog = false; editingMemory = null },
            onSave = { title, note, mood, occurredAt ->
                val existing = editingMemory
                if (existing == null) onAddMemory(title, note, mood, occurredAt)
                else onUpdateMemory(existing, title, note, mood, occurredAt)
                showMemoryDialog = false
                editingMemory = null
            }
        )
    }
    if (showDateDialog) {
        SpecialDateDialog(
            date = editingSpecialDate,
            onDismiss = { showDateDialog = false; editingSpecialDate = null },
            onSave = { title, note, occurredAt, repeat ->
                val existing = editingSpecialDate
                if (existing == null) onAddSpecialDate(title, note, occurredAt, repeat)
                else onUpdateSpecialDate(existing, title, note, occurredAt, repeat)
                showDateDialog = false
                editingSpecialDate = null
            }
        )
    }
    if (showCycleSettings) {
        CycleSettingsDialog(
            settings = cycleSettings,
            onDismiss = { showCycleSettings = false },
            onSave = { cycleDays, periodDays, enabled ->
                onUpdateCycleSettings(cycleDays, periodDays, enabled)
                showCycleSettings = false
            }
        )
    }
    if (showStartPeriodDialog) {
        StartPeriodDialog(
            onDismiss = { showStartPeriodDialog = false },
            onConfirm = { startAt, flow, note ->
                onStartPeriod(startAt, flow, note)
                showStartPeriodDialog = false
            }
        )
    }
}


@Composable
private fun BooksTabContent(
    bookItems: List<BookItemEntity>,
    onAddBookItem: (String, String, String, Int) -> Unit,
    onUpdateBookItem: (BookItemEntity, String, String, String, String, Int, Int) -> Unit,
    onAdjustBookReadPages: (BookItemEntity, Int) -> Unit,
    onCycleBookStatus: (BookItemEntity) -> Unit,
    onDeleteRequest: (BookItemEntity) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<BookItemEntity?>(null) }
    var filter by remember { mutableStateOf("ALL") }

    fun statusLabel(status: String) = when (status) {
        "READING" -> "در حال خواندن"
        "DONE" -> "خواندیم"
        else -> "می‌خواهیم بخوانیم"
    }

    val active = remember(bookItems) { bookItems.filter { !it.isDeleted } }
    val reading = remember(active) { active.filter { it.status == "READING" } }
    val want = remember(active) { active.filter { it.status == "WANT" || (it.status != "READING" && it.status != "DONE") } }
    val done = remember(active) { active.filter { it.status == "DONE" } }

    val filteredSections = remember(active, filter, reading, want, done) {
        buildList {
            fun addSection(key: String, title: String, emoji: String, items: List<BookItemEntity>) {
                if (items.isEmpty()) return
                add(Triple(key, "$emoji $title", items))
            }
            when (filter) {
                "READING" -> addSection("READING", "در حال خواندن", "📖", reading)
                "WANT" -> addSection("WANT", "می‌خواهیم بخوانیم", "📝", want)
                "DONE" -> addSection("DONE", "خواندیم", "✅", done)
                else -> {
                    addSection("READING", "در حال خواندن", "📖", reading)
                    addSection("WANT", "می‌خواهیم بخوانیم", "📝", want)
                    addSection("DONE", "خواندیم", "✅", done)
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 62.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("کتاب‌های ما", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(
                        "لیست کتاب‌هایی که باهم می‌خوانیم",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = { showAddDialog = true }) { Text("افزودن") }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WatchlistStatChip(
                    label = "در حال",
                    count = reading.size,
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    onClick = { filter = if (filter == "READING") "ALL" else "READING" },
                    selected = filter == "READING",
                    modifier = Modifier.weight(1f)
                )
                WatchlistStatChip(
                    label = "لیست",
                    count = want.size,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    onClick = { filter = if (filter == "WANT") "ALL" else "WANT" },
                    selected = filter == "WANT",
                    modifier = Modifier.weight(1f)
                )
                WatchlistStatChip(
                    label = "خواندیم",
                    count = done.size,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    onClick = { filter = if (filter == "DONE") "ALL" else "DONE" },
                    selected = filter == "DONE",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to "همه",
                    "READING" to "در حال خواندن",
                    "WANT" to "می‌خواهیم بخوانیم",
                    "DONE" to "خواندیم"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = filter == key,
                        onClick = { filter = key },
                        label = { Text(label) }
                    )
                }
            }
        }

        if (active.isEmpty()) {
            item {
                EmptyRelationshipCard(
                    icon = "📚",
                    title = "هنوز کتابی نیست",
                    body = "کتابی را برای خواندن دونفره اضافه کنید.",
                    onClick = { showAddDialog = true }
                )
            }
        } else if (filteredSections.isEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
                ) {
                    Text(
                        "در این دسته موردی نیست",
                        modifier = Modifier.padding(20.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            filteredSections.forEach { (sectionKey, sectionTitle, sectionItems) ->
                item(key = "book-section-$sectionKey-$filter") {
                    WatchlistSectionHeader(title = sectionTitle, count = sectionItems.size)
                }
                items(sectionItems, key = { "book-$sectionKey-${it.id}" }) { item ->
                    BookItemCard(
                        item = item,
                        statusLabel = statusLabel(item.status),
                        onEdit = { editingItem = item },
                        onCycleStatus = { onCycleBookStatus(item) },
                        onDelete = { onDeleteRequest(item) },
                        onAdjustPages = { delta -> onAdjustBookReadPages(item, delta) }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var author by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        var totalPages by remember { mutableStateOf("") }
        OSFormDialog(
            title = "کتاب جدید",
            emoji = "📚",
            onDismiss = { showAddDialog = false },
            onConfirm = {
                if (title.isNotBlank()) {
                    val total = totalPages.filter { it.isDigit() }.toIntOrNull() ?: 0
                    onAddBookItem(title.trim(), author.trim(), note.trim(), total)
                    showAddDialog = false
                }
            },
            confirmLabel = "ثبت",
            confirmEnabled = title.isNotBlank()
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان کتاب") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = author,
                onValueChange = { author = it },
                label = { Text("نویسنده (اختیاری)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("یادداشت") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = totalPages,
                onValueChange = { totalPages = it.filter { ch -> ch.isDigit() }.take(6) },
                label = { Text("تعداد صفحات (اختیاری)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    editingItem?.let { item ->
        var title by remember(item.id) { mutableStateOf(item.title) }
        var author by remember(item.id) { mutableStateOf(item.author) }
        var note by remember(item.id) { mutableStateOf(item.note) }
        var status by remember(item.id) { mutableStateOf(item.status) }
        var totalPages by remember(item.id) {
            mutableStateOf(if (item.totalPages > 0) item.totalPages.toString() else "")
        }
        var readPages by remember(item.id) {
            mutableStateOf(item.readPages.coerceAtLeast(0).toString())
        }
        OSFormDialog(
            title = "ویرایش کتاب",
            emoji = "📚",
            onDismiss = { editingItem = null },
            onConfirm = {
                if (title.isNotBlank()) {
                    val total = totalPages.filter { it.isDigit() }.toIntOrNull() ?: 0
                    val read = readPages.filter { it.isDigit() }.toIntOrNull() ?: 0
                    onUpdateBookItem(item, title.trim(), author.trim(), note.trim(), status, total, read)
                    editingItem = null
                }
            },
            confirmLabel = "ذخیره",
            confirmEnabled = title.isNotBlank()
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = author,
                onValueChange = { author = it },
                label = { Text("نویسنده") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("یادداشت") },
                modifier = Modifier.fillMaxWidth()
            )
            Text("وضعیت", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "WANT" to "می‌خواهیم بخوانیم",
                    "READING" to "در حال خواندن",
                    "DONE" to "خواندیم"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = status == key,
                        onClick = { status = key },
                        label = { Text(label) }
                    )
                }
            }
            OutlinedTextField(
                value = totalPages,
                onValueChange = { totalPages = it.filter { ch -> ch.isDigit() }.take(6) },
                label = { Text("تعداد کل صفحات") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = readPages,
                onValueChange = { readPages = it.filter { ch -> ch.isDigit() }.take(6) },
                label = { Text("صفحات خوانده‌شده") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun BookItemCard(
    item: BookItemEntity,
    statusLabel: String,
    onEdit: () -> Unit,
    onCycleStatus: () -> Unit,
    onDelete: () -> Unit,
    onAdjustPages: (Int) -> Unit
) {
    val accent = when (item.status) {
        "READING" -> MaterialTheme.colorScheme.tertiary
        "DONE" -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
        ) {
            Box(
                Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(accent)
            )
            Column(
                Modifier
                    .weight(1f)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "📚 " + item.title,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            buildString {
                                append(statusLabel)
                                if (item.author.isNotBlank()) append(" · ${item.author}")
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = accent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Outlined.Edit, contentDescription = "ویرایش")
                    }
                }
                if (item.note.isNotBlank()) {
                    Text(
                        item.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                val total = item.totalPages
                val read = item.readPages.coerceAtLeast(0)
                val progress = if (total > 0) (read.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                Text(
                    if (total > 0)
                        "صفحه ${PersianDateFormatter.toPersianDigits(read)} از ${PersianDateFormatter.toPersianDigits(total)}"
                    else
                        "صفحه خوانده‌شده: ${PersianDateFormatter.toPersianDigits(read)}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                if (total > 0) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(999.dp)),
                        color = accent
                    )
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { onAdjustPages(-10) },
                        enabled = read > 0
                    ) { Text("−۱۰") }
                    OutlinedButton(
                        onClick = { onAdjustPages(-1) },
                        enabled = read > 0
                    ) { Text("−۱") }
                    OutlinedButton(
                        onClick = { onAdjustPages(+1) },
                        enabled = total <= 0 || read < total
                    ) { Text("+۱") }
                    OutlinedButton(
                        onClick = { onAdjustPages(+10) },
                        enabled = total <= 0 || read < total
                    ) { Text("+۱۰") }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TextButton(onClick = onCycleStatus) { Text("وضعیت") }
                    TextButton(onClick = onEdit) { Text("ویرایش") }
                    TextButton(onClick = onDelete) { Text("حذف") }
                }
            }
        }
    }
}


@Composable
private fun FoodsTabContent(
    foodItems: List<FoodItemEntity>,
    onAddFoodItem: (String, String) -> Unit,
    onToggleFavorite: (FoodItemEntity) -> Unit,
    onDeleteRequest: (FoodItemEntity) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val active = remember(foodItems) { foodItems.filter { !it.isDeleted } }
    val filtered = remember(active, query) {
        val q = query.trim()
        if (q.isEmpty()) active
        else active.filter {
            it.name.contains(q, ignoreCase = true) || it.note.contains(q, ignoreCase = true)
        }
    }
    val favorites = remember(filtered) { filtered.count { it.isFavorite } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 56.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("غذاهای ایرانی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(
                        "${PersianDateFormatter.toPersianDigits(active.size)} مورد · ${PersianDateFormatter.toPersianDigits(favorites)} مورد علاقه",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                FilledTonalButton(onClick = { showAdd = true }) {
                    Text("افزودن")
                }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(60) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("جستجو در غذاها") },
                placeholder = { Text("مثلاً قورمه، کباب…") }
            )
        }
        if (filtered.isEmpty()) {
            item {
                Text(
                    if (query.isBlank()) "هنوز غذایی ثبت نشده" else "نتیجه‌ای پیدا نشد",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }
        } else {
            items(filtered, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (item.isFavorite)
                            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
                        else
                            MaterialTheme.colorScheme.surfaceContainerLow
                    )
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { onToggleFavorite(item) }) {
                            Icon(
                                imageVector = if (item.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "علاقه‌مندی",
                                tint = if (item.isFavorite) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
                            if (item.note.isNotBlank()) {
                                Text(
                                    item.note,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        TextButton(onClick = { onDeleteRequest(item) }) {
                            Text("حذف")
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        OSFormDialog(
            title = "غذای جدید",
            emoji = "🍲",
            onDismiss = { showAdd = false },
            onConfirm = {
                if (name.isNotBlank()) {
                    onAddFoodItem(name.trim(), note.trim())
                    showAdd = false
                }
            },
            confirmLabel = "ثبت",
            confirmEnabled = name.isNotBlank()
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(120) },
                label = { Text("نام غذا") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = note,
                onValueChange = { note = it.take(500) },
                label = { Text("یادداشت (اختیاری)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun WatchlistTabContent(
    watchlistItems: List<WatchlistItemEntity>,
    onAddWatchlistItem: (String, String, String, Int, Int) -> Unit,
    onUpdateWatchlistItem: (WatchlistItemEntity, String, String, String, String, Int, Int, Int) -> Unit,
    onAdjustWatchlistWatchedEpisodes: (WatchlistItemEntity, Int) -> Unit,
    onCycleWatchlistStatus: (WatchlistItemEntity) -> Unit,
    onDeleteRequest: (WatchlistItemEntity) -> Unit
) {
    var showWatchDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<WatchlistItemEntity?>(null) }
    // ALL | WATCHING | WANT | DONE | MOVIE | SERIES
    var filter by remember { mutableStateOf("ALL") }

    fun statusLabel(status: String) = when (status) {
        "WATCHING" -> "در حال تماشا"
        "DONE" -> "دیدیم"
        else -> "می‌خواهیم ببینیم"
    }

    val active = remember(watchlistItems) { watchlistItems.filter { !it.isDeleted } }
    val watching = remember(active) { active.filter { it.status == "WATCHING" } }
    val want = remember(active) { active.filter { it.status == "WANT" || (it.status != "WATCHING" && it.status != "DONE") } }
    val done = remember(active) { active.filter { it.status == "DONE" } }

    val filteredSections = remember(active, filter, watching, want, done) {
        val sections = buildList {
            fun addSection(key: String, title: String, emoji: String, items: List<WatchlistItemEntity>) {
                if (items.isEmpty()) return
                add(Triple(key, "$emoji $title", items))
            }
            when (filter) {
                "WATCHING" -> addSection("WATCHING", "در حال تماشا", "▶️", watching)
                "WANT" -> addSection("WANT", "می‌خواهیم ببینیم", "📝", want)
                "DONE" -> addSection("DONE", "دیدیم", "✅", done)
                "MOVIE" -> {
                    val movies = active.filter { it.mediaType != "SERIES" }
                    addSection("MOVIE", "فیلم‌ها", "🎬", movies)
                }
                "SERIES" -> {
                    val series = active.filter { it.mediaType == "SERIES" }
                    addSection("SERIES", "سریال‌ها", "📺", series)
                }
                else -> {
                    // پیش‌فرض: گروه‌بندی بر اساس وضعیت
                    addSection("WATCHING", "در حال تماشا", "▶️", watching)
                    addSection("WANT", "می‌خواهیم ببینیم", "📝", want)
                    addSection("DONE", "دیدیم", "✅", done)
                }
            }
        }
        sections
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 62.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("فیلم و سریال ما", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(
                        "بر اساس وضعیت دسته‌بندی شده",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = { showWatchDialog = true }) { Text("افزودن") }
            }
        }

        item {
            // آمار خلاصه
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WatchlistStatChip(
                    label = "در حال",
                    count = watching.size,
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    onClick = { filter = if (filter == "WATCHING") "ALL" else "WATCHING" },
                    selected = filter == "WATCHING",
                    modifier = Modifier.weight(1f)
                )
                WatchlistStatChip(
                    label = "لیست",
                    count = want.size,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    onClick = { filter = if (filter == "WANT") "ALL" else "WANT" },
                    selected = filter == "WANT",
                    modifier = Modifier.weight(1f)
                )
                WatchlistStatChip(
                    label = "دیدیم",
                    count = done.size,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    onClick = { filter = if (filter == "DONE") "ALL" else "DONE" },
                    selected = filter == "DONE",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to "همه",
                    "WATCHING" to "در حال تماشا",
                    "WANT" to "می‌خواهیم ببینیم",
                    "DONE" to "دیدیم",
                    "SERIES" to "فقط سریال",
                    "MOVIE" to "فقط فیلم"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = filter == key,
                        onClick = { filter = key },
                        label = { Text(label) }
                    )
                }
            }
        }

        if (active.isEmpty()) {
            item {
                EmptyRelationshipCard(
                    icon = "🎬",
                    title = "هنوز موردی نیست",
                    body = "فیلم یا سریالی را برای تماشای دونفره اضافه کنید.",
                    onClick = { showWatchDialog = true }
                )
            }
        } else if (filteredSections.isEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
                ) {
                    Text(
                        "در این دسته موردی نیست",
                        modifier = Modifier.padding(20.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            filteredSections.forEach { (sectionKey, sectionTitle, sectionItems) ->
                item(key = "section-head-$sectionKey-$filter") {
                    WatchlistSectionHeader(
                        title = sectionTitle,
                        count = sectionItems.size
                    )
                }
                items(sectionItems, key = { "watchlist-${sectionKey}-${it.id}" }) { item ->
                    WatchlistItemCard(
                        item = item,
                        statusLabel = statusLabel(item.status),
                        onEdit = { editingItem = item },
                        onCycleStatus = { onCycleWatchlistStatus(item) },
                        onDelete = { onDeleteRequest(item) },
                        onAdjustEpisodes = { delta -> onAdjustWatchlistWatchedEpisodes(item, delta) }
                    )
                }
            }
        }
    }

    if (showWatchDialog) {
        var title by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        var series by remember { mutableStateOf(false) }
        var totalEpisodes by remember { mutableStateOf("") }
        var rating by remember { mutableIntStateOf(0) }
        OSFormDialog(
            title = "فیلم یا سریال",
            emoji = "🎬",
            onDismiss = { showWatchDialog = false },
            onConfirm = {
                if (title.isNotBlank()) {
                    val total = totalEpisodes.filter { it.isDigit() }.toIntOrNull() ?: 0
                    onAddWatchlistItem(
                        title.trim(),
                        if (series) "SERIES" else "MOVIE",
                        note.trim(),
                        if (series) total else 0,
                        rating
                    )
                    showWatchDialog = false
                }
            },
            confirmLabel = "ثبت",
            confirmEnabled = title.isNotBlank()
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("یادداشت") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("سریال است", modifier = Modifier.weight(1f))
                Switch(checked = series, onCheckedChange = { series = it })
            }
            if (series) {
                OutlinedTextField(
                    value = totalEpisodes,
                    onValueChange = { totalEpisodes = it.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text("تعداد کل قسمت‌ها (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text("امتیاز (اختیاری)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            WatchlistStarRating(rating = rating, onRatingChange = { rating = it })
        }
    }
    editingItem?.let { item ->
        var title by remember(item.id) { mutableStateOf(item.title) }
        var note by remember(item.id) { mutableStateOf(item.note) }
        var series by remember(item.id) { mutableStateOf(item.mediaType == "SERIES") }
        var status by remember(item.id) { mutableStateOf(item.status) }
        var totalEpisodes by remember(item.id) {
            mutableStateOf(if (item.totalEpisodes > 0) item.totalEpisodes.toString() else "")
        }
        var watchedEpisodes by remember(item.id) {
            mutableStateOf(item.watchedEpisodes.coerceAtLeast(0).toString())
        }
        var rating by remember(item.id) { mutableIntStateOf(item.rating.coerceIn(0, 5)) }
        OSFormDialog(
            title = "ویرایش",
            emoji = if (series) "📺" else "🎬",
            onDismiss = { editingItem = null },
            onConfirm = {
                if (title.isNotBlank()) {
                    val total = totalEpisodes.filter { it.isDigit() }.toIntOrNull() ?: 0
                    val watched = watchedEpisodes.filter { it.isDigit() }.toIntOrNull() ?: 0
                    onUpdateWatchlistItem(
                        item,
                        title.trim(),
                        if (series) "SERIES" else "MOVIE",
                        note.trim(),
                        status,
                        if (series) total else 0,
                        if (series) watched else 0,
                        rating
                    )
                    editingItem = null
                }
            },
            confirmLabel = "ذخیره",
            confirmEnabled = title.isNotBlank()
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("یادداشت") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("سریال است", modifier = Modifier.weight(1f))
                Switch(checked = series, onCheckedChange = { series = it })
            }
            Text("وضعیت", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "WANT" to "می‌خواهیم ببینیم",
                    "WATCHING" to "در حال تماشا",
                    "DONE" to "دیدیم"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = status == key,
                        onClick = { status = key },
                        label = { Text(label) }
                    )
                }
            }
            if (series) {
                OutlinedTextField(
                    value = totalEpisodes,
                    onValueChange = { totalEpisodes = it.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text("تعداد کل قسمت‌ها") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = watchedEpisodes,
                    onValueChange = { watchedEpisodes = it.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text("قسمت‌های دیده‌شده") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text("امتیاز", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            WatchlistStarRating(rating = rating, onRatingChange = { rating = it })
        }
    }
}


@Composable
private fun WatchlistStarRating(
    rating: Int,
    onRatingChange: ((Int) -> Unit)?,
    starSize: androidx.compose.ui.unit.Dp = 28.dp
) {
    val value = rating.coerceIn(0, 5)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        (1..5).forEach { star ->
            val filled = star <= value
            Icon(
                imageVector = if (filled) Icons.Filled.Star else Icons.Outlined.Star,
                contentDescription = "امتیاز ${star}",
                tint = if (filled) Color(0xFFFFB300) else MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier
                    .size(starSize)
                    .then(
                        if (onRatingChange != null) {
                            Modifier.clickable {
                                // لمس دوباره همان ستاره = حذف امتیاز
                                onRatingChange(if (value == star) 0 else star)
                            }
                        } else Modifier
                    )
            )
        }
        if (onRatingChange != null) {
            Text(
                if (value == 0) "بدون امتیاز" else "${PersianDateFormatter.toPersianDigits(value)} از ۵",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 6.dp)
            )
        }
    }
}

@Composable
private fun WatchlistStatChip(
    label: String,
    count: Int,
    color: Color,
    onClick: () -> Unit,
    selected: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else color
        ),
        border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                PersianDateFormatter.toPersianDigits(count),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun WatchlistSectionHeader(title: String, count: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            modifier = Modifier.weight(1f)
        )
        Text(
            PersianDateFormatter.toPersianDigits(count),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun WatchlistItemCard(
    item: WatchlistItemEntity,
    statusLabel: String,
    onEdit: () -> Unit,
    onCycleStatus: () -> Unit,
    onDelete: () -> Unit,
    onAdjustEpisodes: (Int) -> Unit
) {
    val accent = when (item.status) {
        "WATCHING" -> MaterialTheme.colorScheme.tertiary
        "DONE" -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
        ) {
            Box(
                Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(accent)
            )
            Column(
                Modifier
                    .weight(1f)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            (if (item.mediaType == "SERIES") "📺 " else "🎬 ") + item.title,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            statusLabel + if (item.mediaType == "SERIES") " · سریال" else " · فیلم",
                            style = MaterialTheme.typography.labelMedium,
                            color = accent,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (item.rating > 0) {
                            WatchlistStarRating(
                                rating = item.rating,
                                onRatingChange = null,
                                starSize = 16.dp
                            )
                        }
                    }
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Outlined.Edit, contentDescription = "ویرایش")
                    }
                }
                if (item.note.isNotBlank()) {
                    Text(
                        item.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (item.mediaType == "SERIES") {
                    val total = item.totalEpisodes
                    val watched = item.watchedEpisodes.coerceAtLeast(0)
                    val progress = if (total > 0) (watched.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                    Text(
                        if (total > 0)
                            "قسمت ${PersianDateFormatter.toPersianDigits(watched)} از ${PersianDateFormatter.toPersianDigits(total)}"
                        else
                            "قسمت دیده‌شده: ${PersianDateFormatter.toPersianDigits(watched)}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (total > 0) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(999.dp)),
                            color = accent
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { onAdjustEpisodes(-1) },
                            enabled = watched > 0
                        ) { Text("−۱ قسمت") }
                        OutlinedButton(
                            onClick = { onAdjustEpisodes(+1) },
                            enabled = total <= 0 || watched < total
                        ) { Text("+۱ قسمت") }
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TextButton(onClick = onCycleStatus) { Text("وضعیت") }
                    TextButton(onClick = onEdit) { Text("ویرایش") }
                    TextButton(onClick = onDelete) { Text("حذف") }
                }
            }
        }
    }
}

@Composable
private fun MemoryMonthCalendar(
    year: Int,
    month: Int,
    memories: List<MemoryEntity>,
    selectedDayKey: String?,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDay: (Int) -> Unit
) {
    val daysInMonth = PersianDateFormatter.daysInJalaliMonth(year, month)
    val firstDayMillis = remember(year, month) { PersianDateFormatter.toEpochMillis(year, month, 1, 12, 0) }
    val firstWeekdayOffset = remember(firstDayMillis) {
        Calendar.getInstance().apply { timeInMillis = firstDayMillis }.get(Calendar.DAY_OF_WEEK) % 7
    } // Saturday-first: Saturday=0, Sunday=1, ... Friday=6
    val memoryCounts = remember(memories, year, month) {
        memories.mapNotNull { memory ->
            val date = PersianDateFormatter.jalaliDate(memory.occurredAt)
            if (date.year == year && date.month == month) date.day else null
        }.groupingBy { it }.eachCount()
    }
    val today = remember { PersianDateFormatter.jalaliDate(System.currentTimeMillis()) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPreviousMonth) { Text("‹", style = MaterialTheme.typography.headlineMedium) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("تقویم خاطرات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    Text("${PersianDateFormatter.jalaliMonthName(month)} ${PersianDateFormatter.toPersianDigits(year)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onNextMonth) { Text("›", style = MaterialTheme.typography.headlineMedium) }
            }
            Row(Modifier.fillMaxWidth()) {
                listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEach { label ->
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    }
                }
            }
            val cells = (List(firstWeekdayOffset) { 0 } + (1..daysInMonth).toList())
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth()) {
                    week.forEach { day ->
                        if (day == 0) {
                            Box(Modifier.weight(1f).padding(2.dp).aspectRatio(0.86f))
                        } else {
                            val key = "$year-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}"
                            val count = memoryCounts[day] ?: 0
                            val selected = selectedDayKey == key
                            val isToday = today.year == year && today.month == month && today.day == day
                            Column(
                                modifier = Modifier.weight(1f).padding(2.dp).aspectRatio(0.86f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(when {
                                        selected -> MaterialTheme.colorScheme.primaryContainer
                                        isToday -> MaterialTheme.colorScheme.secondaryContainer
                                        else -> Color.Transparent
                                    })
                                    .clickable { onSelectDay(day) }
                                    .padding(vertical = 3.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    PersianDateFormatter.toPersianDigits(day),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (selected || isToday || count > 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                if (count > 0) {
                                    Box(
                                        Modifier.padding(top = 2.dp).size(17.dp).clip(CircleShape)
                                            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(PersianDateFormatter.toPersianDigits(count), style = MaterialTheme.typography.labelSmall, color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onTertiary)
                                    }
                                } else Spacer(Modifier.height(19.dp))
                            }
                        }
                    }
                    repeat((7 - week.size).coerceAtLeast(0)) { Box(Modifier.weight(1f).padding(2.dp).aspectRatio(0.86f)) }
                }
            }
            Text("عدد روی هر روز، تعداد خاطرات ثبت‌شده را نشان می‌دهد. برای دیدن خاطرات یک روز روی آن بزنید.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CoupleHero(profile: CoupleProfileEntity?, onEdit: () -> Unit) {
    val daysTogether = profile?.relationshipStartedAt?.let { startedAt ->
        PersianDateFormatter.daysTogether(startedAt)
    }
    val title = listOfNotNull(
        profile?.firstPersonName?.takeIf { it.isNotBlank() },
        profile?.secondPersonName?.takeIf { it.isNotBlank() }
    ).joinToString(" و ").ifBlank { "ما دو نفر" }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val gradient = Brush.linearGradient(
        if (dark) listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer)
        else listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
    )
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(34.dp)).background(gradient).padding(23.dp)) {
        Box(Modifier.size(160.dp).align(Alignment.TopStart).background(Color.White.copy(alpha = .08f), CircleShape))
        Box(Modifier.size(110.dp).align(Alignment.BottomEnd).background(Color.White.copy(alpha = .06f), CircleShape))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("فضای خصوصی ما", color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .90f) else Color.White.copy(alpha = .88f), style = MaterialTheme.typography.labelLarge)
                    Text(title, color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                }
                IconButton(onClick = onEdit) { Icon(Icons.Outlined.Edit, "ویرایش پروفایل", tint = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White) }
            }
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FloatingMotion(enabled = false) {
                    Box(Modifier.size(58.dp).background(Color.White.copy(alpha = .17f), CircleShape), contentAlignment = Alignment.Center) {
                        Text("♥", color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White, style = MaterialTheme.typography.headlineMedium)
                    }
                }
                Column(Modifier.padding(horizontal = 13.dp)) {
                    AnimatedContent(
                        targetState = daysTogether,
                        transitionSpec = { (fadeIn() + scaleIn(initialScale = .9f)).togetherWith(fadeOut()) },
                        label = "days-together"
                    ) { days ->
                        Text(
                            days?.let { "${PersianDateFormatter.toPersianDigits(it)} روز کنار هم" } ?: "تاریخ شروع رابطه را ثبت کنید",
                            color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(PersianDateFormatter.todayLabel(), color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .82f) else Color.White.copy(alpha = .78f))
                }
            }
        }
    }
}

@Composable
private fun MoodCard(
    ownMood: MoodCheckInEntity?,
    partnerMood: MoodCheckInEntity?,
    onMoodSelected: (MoodOption, String) -> Unit
) {
    var noteDraft by remember(ownMood?.id, ownMood?.note) {
        mutableStateOf(ownMood?.note.orEmpty())
    }
    var selectedCode by remember(ownMood?.mood) {
        mutableStateOf(ownMood?.mood)
    }
    Card(
        Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("امروز چه حالی داری؟", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(
                        partnerMood?.let {
                            val base = "حال همراهت: ${moodFor(it.mood).emoji} ${moodFor(it.mood).label}"
                            if (it.note.isNotBlank()) "$base — ${it.note}" else base
                        } ?: "با یک لمس حال امروزت را به اشتراک بگذار.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                ownMood?.let { Text(moodFor(it.mood).emoji, style = MaterialTheme.typography.headlineMedium) }
            }
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(moods, key = { it.code }) { mood ->
                    val selected = (selectedCode ?: ownMood?.mood) == mood.code
                    MotionCard(
                        onClick = {
                            selectedCode = mood.code
                            onMoodSelected(mood, noteDraft.trim())
                        },
                        modifier = Modifier.background(
                            if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(18.dp)
                        ),
                        cornerRadius = 18
                    ) {
                        Column(Modifier.padding(horizontal = 11.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(mood.emoji, style = MaterialTheme.typography.titleLarge)
                            Text(mood.label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }
            }
            // Optional short reason — a few words only
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = noteDraft,
                onValueChange = { noteDraft = it.take(80) },
                label = { Text("توضیح کوتاه (اختیاری)") },
                placeholder = { Text("مثلاً: امروز خیلی خسته بودم…") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                supportingText = {
                    Text("حداکثر چند کلمه — چرا این حال را انتخاب کردی؟")
                }
            )
            val canSaveNote = selectedCode != null || ownMood != null
            if (canSaveNote) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    val code = selectedCode ?: ownMood?.mood
                    TextButton(
                        onClick = {
                            val option = moods.firstOrNull { it.code == code }
                                ?: MoodOption(code.orEmpty(), "🙂", "حال")
                            onMoodSelected(option, noteDraft.trim())
                        },
                        enabled = code != null
                    ) {
                        Text("ذخیره توضیح")
                    }
                }
            }
        }
    }
}

@Composable
private fun RelationshipStats(memories: Int, favorites: Int, dates: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        StatCard("خاطره", memories, "♡", Modifier.weight(1f))
        StatCard("محبوب", favorites, "★", Modifier.weight(1f))
        StatCard("مناسبت", dates, "✦", Modifier.weight(1f))
    }
}

@Composable
private fun StatCard(label: String, value: Int, symbol: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(symbol, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge)
            Text(PersianDateFormatter.toPersianDigits(value), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SectionHeader(title: String, caption: String, modifier: Modifier = Modifier) {
    Column(modifier.padding(top = 6.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        Text(caption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun SpecialDateCard(
    date: SpecialDateEntity,
    now: Long,
    modifier: Modifier = Modifier.width(230.dp),
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .72f))
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(MaterialTheme.colorScheme.surface.copy(alpha = .75f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.DateRange, null, tint = MaterialTheme.colorScheme.primary)
                }
                Text(date.title, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f).padding(horizontal = 9.dp), maxLines = 2)
                IconButton(onClick = onEdit, modifier = Modifier.size(30.dp)) { Icon(Icons.Outlined.Edit, "ویرایش", modifier = Modifier.size(17.dp)) }
                IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) { Icon(Icons.Outlined.Delete, "حذف", modifier = Modifier.size(17.dp)) }
            }
            val nextAt = nextSpecialDateOccurrence(date, now)
            val daysUntil = calendarDayDifference(now, nextAt)
            Text(
                if (date.repeatYearly) "نوبت بعدی: ${PersianDateFormatter.formatDate(nextAt)}" else PersianDateFormatter.formatDateTime(date.occurredAt),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 12.dp)
            )
            if (date.repeatYearly) {
                Text(
                    when {
                        daysUntil < 0 -> "تاریخ این مناسبت گذشته است"
                        daysUntil == 0 -> "امروز ✨"
                        daysUntil == 1 -> "فردا"
                        else -> "${PersianDateFormatter.toPersianDigits(daysUntil)} روز دیگر"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text("تکرار سالانه • تاریخ ثبت اولیه: ${PersianDateFormatter.formatDate(date.occurredAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun MemoryCard(
    memory: MemoryEntity,
    images: List<AttachmentEntity>,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    isAddingImage: Boolean,
    onOpenGallery: (Int) -> Unit,
    onAddImage: () -> Unit,
    onEdit: () -> Unit,
    onFavorite: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit = {}
) {
    val mood = moodFor(memory.mood)
    val cover = images.firstOrNull()
    val preview by produceState<Bitmap?>(initialValue = null, cover?.id, cover?.sha256) {
        val selected = cover
        val full = if (selected != null) onLoadAttachment(selected.id) else null
        val bytes = full?.content
        value = if (bytes != null && bytes.isNotEmpty()) {
            withContext(Dispatchers.Default) { decodeMemoryPreview(bytes) }
        } else null
    }
    val previewBitmap = preview
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column {
            if (previewBitmap != null) {
                Box {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "تصویر ${memory.title}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clickable { onOpenGallery(0) }
                    )
                    if (images.size > 1) {
                        Text(
                            "+${PersianDateFormatter.toPersianDigits(images.size - 1)}",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                                .background(Color.Black.copy(alpha = .58f), CircleShape)
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
            if (images.size > 1) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(top = 9.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(images.drop(1), key = { _, image -> image.id }) { offset, image ->
                        MemoryPhotoThumbnail(
                            attachment = image,
                            onLoadAttachment = onLoadAttachment,
                            onClick = { onOpenGallery(offset + 1) }
                        )
                    }
                }
            }
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.size(52.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) { Text(mood.emoji, style = MaterialTheme.typography.headlineSmall) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(memory.title, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    if (memory.note.isNotBlank()) {
                        Text(memory.note, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text(PersianDateFormatter.formatDateTime(memory.occurredAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 6.dp))
                }
                Column {
                    IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Outlined.Edit, "ویرایش خاطره", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onAddImage, enabled = !isAddingImage, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Add, "افزودن تصویر", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onFavorite, modifier = Modifier.size(34.dp)) {
                        Icon(
                            if (memory.isFavorite) Icons.Outlined.Star else Icons.Outlined.FavoriteBorder,
                            "محبوب",
                            tint = if (memory.isFavorite) Color(0xFFE59B18) else MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(onClick = onShare, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Outlined.Share, "اشتراک در چت", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Outlined.Delete, "حذف", tint = MaterialTheme.colorScheme.outline)
                    }
                }
            }
        }
    }
}


@Composable
private fun MemoryImageRotateDialog(
    uriValue: String,
    rotationDegrees: Int,
    isBusy: Boolean,
    onRotateLeft: () -> Unit,
    onRotateRight: () -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preview by produceState<Bitmap?>(initialValue = null, uriValue) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val uri = android.net.Uri.parse(uriValue)
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    decodeMemoryPreview(stream.readBytes())
                }
            }.getOrNull()
        }
    }
    OSFormDialog(
        title = "چرخش تصویر",
        subtitle = "قبل از افزودن به خاطره، جهت عکس را تنظیم کنید",
        emoji = "🔄",
        onDismiss = onDismiss,
        onConfirm = onConfirm,
        confirmLabel = if (isBusy) "در حال ذخیره…" else "افزودن به خاطره",
        confirmEnabled = !isBusy && preview != null,
        dismissLabel = "انصراف"
    ) {
        if (preview != null) {
            Image(
                bitmap = preview!!.asImageBitmap(),
                contentDescription = "پیش‌نمایش تصویر",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .graphicsLayer { rotationZ = rotationDegrees.toFloat() }
            )
        } else {
            Text("در حال بارگذاری تصویر…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onRotateLeft, enabled = !isBusy, modifier = Modifier.weight(1f)) {
                Text("↶ ۹۰°")
            }
            OutlinedButton(onClick = onRotateRight, enabled = !isBusy, modifier = Modifier.weight(1f)) {
                Text("↷ ۹۰°")
            }
        }
        Text(
            "چرخش فعلی: ${rotationDegrees}°",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}


@Composable
private fun FullscreenImageViewer(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    onDismiss: () -> Unit
) {
    val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
        val full = onLoadAttachment(attachment.id)
        val bytes = full?.content
        value = if (bytes != null && bytes.isNotEmpty()) {
            withContext(Dispatchers.Default) { decodeMemoryPreview(bytes) }
        } else null
    }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            if (preview != null) {
                Image(
                    bitmap = preview!!.asImageBitmap(),
                    contentDescription = attachment.fileName,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 56.dp, bottom = 24.dp)
                        .clickable(onClick = onDismiss)
                )
            } else {
                Text(
                    "در حال بارگذاری…",
                    color = Color.White,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = "بازگشت",
                        tint = Color.White
                    )
                }
                Text(
                    attachment.fileName,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MemorySlideshowOverlay(
    memories: List<MemoryEntity>,
    attachmentsByMemory: Map<String, List<AttachmentEntity>>,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    onDismiss: () -> Unit,
    onOpenImage: (AttachmentEntity) -> Unit
) {
    data class Slide(
        val memory: MemoryEntity,
        val attachment: AttachmentEntity?,
        val imageIndex: Int,
        val imageCount: Int
    )
    val slides = remember(memories, attachmentsByMemory) {
        buildList {
            memories.forEach { memory ->
                val images = attachmentsByMemory[memory.id].orEmpty()
                    .filter { it.mimeType.startsWith("image/") && !it.isDeleted }
                    .sortedBy { it.createdAt }
                if (images.isEmpty()) {
                    add(Slide(memory, null, 0, 0))
                } else {
                    images.forEachIndexed { index, attachment ->
                        add(Slide(memory, attachment, index, images.size))
                    }
                }
            }
        }
    }
    val pagerState = rememberPagerState(pageCount = { slides.size.coerceAtLeast(1) })
    var autoPlay by remember { mutableStateOf(true) }
    var showFullCaption by remember { mutableStateOf(false) }
    val currentSlide = slides.getOrNull(pagerState.currentPage)

    LaunchedEffect(autoPlay, slides.size) {
        if (!autoPlay || slides.size <= 1) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(4_200L)
            if (!autoPlay) break
            snapshotFlow { pagerState.isScrollInProgress }.first { !it }
            val settled = pagerState.settledPage
            val next = (settled + 1) % slides.size
            if (next != settled) {
                // افکت‌های مختلف با مدت/easing متفاوت هنگام تعویض خودکار
                val effect = settled % 5
                val spec = when (effect) {
                    0 -> tween<Float>(900, easing = FastOutSlowInEasing)
                    1 -> tween<Float>(700, easing = LinearOutSlowInEasing)
                    2 -> tween<Float>(1_100, easing = FastOutLinearInEasing)
                    3 -> spring<Float>(dampingRatio = 0.85f, stiffness = 180f)
                    else -> tween<Float>(800, easing = EaseInOutCubic)
                }
                runCatching {
                    pagerState.animateScrollToPage(next, animationSpec = spec)
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF05050A))
        ) {
            if (slides.isEmpty()) {
                Text(
                    "خاطره‌ای برای نمایش نیست",
                    color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(0.dp),
                    pageSpacing = 0.dp,
                    userScrollEnabled = true
                ) { page ->
                    val slide = slides[page]
                    val memory = slide.memory
                    val cover = slide.attachment
                    val preview by produceState<Bitmap?>(initialValue = null, cover?.id, cover?.sha256) {
                        val selected = cover
                        val full = if (selected != null) onLoadAttachment(selected.id) else null
                        val bytes = full?.content
                        value = if (bytes != null && bytes.isNotEmpty()) {
                            withContext(Dispatchers.Default) { decodeSlideshowImage(bytes) }
                        } else null
                    }
                    val mood = moodFor(memory.mood)
                    // افکت بصری بر اساس ایندکس اسلاید و موقعیت صفحه
                    val pageOffset = (
                        (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                    ).coerceIn(-1f, 1f)
                    val effectKind = page % 5

                    Box(Modifier.fillMaxSize()) {
                        if (preview != null) {
                            val imageBitmap = preview!!.asImageBitmap()
                            Image(
                                bitmap = imageBitmap,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = 1.15f
                                        scaleY = 1.15f
                                        alpha = 0.35f
                                    }
                            )
                            Image(
                                bitmap = imageBitmap,
                                contentDescription = memory.title,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        when (effectKind) {
                                            0 -> { // محو + بزرگ‌نمایی ملایم
                                                val t = 1f - kotlin.math.abs(pageOffset)
                                                alpha = 0.35f + 0.65f * t
                                                val s = 0.88f + 0.12f * t
                                                scaleX = s
                                                scaleY = s
                                            }
                                            1 -> { // اسلاید افقی با پارالاکس
                                                translationX = pageOffset * size.width * 0.35f
                                                alpha = 1f - kotlin.math.abs(pageOffset) * 0.5f
                                            }
                                            2 -> { // زوم به داخل
                                                val t = 1f - kotlin.math.abs(pageOffset)
                                                val s = 1.12f - 0.12f * t
                                                scaleX = s
                                                scaleY = s
                                                alpha = 0.4f + 0.6f * t
                                            }
                                            3 -> { // چرخش ملایم
                                                rotationZ = pageOffset * 8f
                                                translationY = pageOffset * size.height * 0.08f
                                                alpha = 1f - kotlin.math.abs(pageOffset) * 0.45f
                                            }
                                            else -> { // مکعب‌مانند (پرسپکتیو ساده)
                                                rotationY = pageOffset * 28f
                                                cameraDistance = 12f * density
                                                alpha = 1f - kotlin.math.abs(pageOffset) * 0.4f
                                                val s = 1f - kotlin.math.abs(pageOffset) * 0.08f
                                                scaleX = s
                                                scaleY = s
                                            }
                                        }
                                    }
                                    .clickable { cover?.let(onOpenImage) }
                            )
                        } else {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.verticalGradient(
                                            listOf(Color(0xFF1A0B2E), Color(0xFF2D1B4E), Color(0xFF0F172A))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(mood.emoji, style = MaterialTheme.typography.displayLarge)
                                    if (cover != null) {
                                        Text(
                                            "در حال بارگذاری…",
                                            color = Color.White.copy(alpha = 0.6f),
                                            style = MaterialTheme.typography.labelMedium,
                                            modifier = Modifier.padding(top = 12.dp)
                                        )
                                    }
                                }
                            }
                        }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .align(Alignment.TopCenter)
                                .background(
                                    brush = Brush.verticalGradient(
                                        listOf(Color.Black.copy(alpha = 0.65f), Color.Transparent)
                                    )
                                )
                        )
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(280.dp)
                                .align(Alignment.BottomCenter)
                                .background(
                                    brush = Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color.Black.copy(alpha = 0.55f),
                                            Color.Black.copy(alpha = 0.88f)
                                        )
                                    )
                                )
                        )
                        // کپشن — لمس برای متن کامل
                        Column(
                            Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .padding(start = 20.dp, end = 88.dp, bottom = 72.dp)
                                .clickable {
                                    showFullCaption = true
                                }
                        ) {
                            Text(
                                memory.title.ifBlank { "خاطره بدون عنوان" },
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Text(
                                buildString {
                                    append(PersianDateFormatter.formatDate(memory.occurredAt))
                                    append(" · ")
                                    append(mood.emoji)
                                    append(" ")
                                    append(mood.label)
                                    if (slide.imageCount > 1) {
                                        append(" · عکس ")
                                        append(PersianDateFormatter.toPersianDigits(slide.imageIndex + 1))
                                        append(" از ")
                                        append(PersianDateFormatter.toPersianDigits(slide.imageCount))
                                    }
                                },
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                            if (memory.note.isNotBlank()) {
                                Text(
                                    memory.note,
                                    color = Color.White.copy(alpha = 0.92f),
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 10.dp)
                                )
                                Text(
                                    "برای متن کامل لمس کنید",
                                    color = Color.White.copy(alpha = 0.55f),
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // دکمه پخش/توقف روی گوشه تصویر
            if (slides.isNotEmpty()) {
                Surface(
                    onClick = { autoPlay = !autoPlay },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .navigationBarsPadding()
                        .padding(end = 18.dp, bottom = 88.dp)
                        .size(56.dp),
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.55f),
                    contentColor = Color.White,
                    shadowElevation = 6.dp
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = if (autoPlay) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (autoPlay) "توقف" else "پخش",
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            }

            // نوار بالا
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, "بازگشت", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        "اسلایدشو خاطرات",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (slides.isNotEmpty()) {
                        Text(
                            "${PersianDateFormatter.toPersianDigits(slides.size)} اسلاید · افکت تعویض خودکار",
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            // نشانگر پایین
            if (slides.isNotEmpty()) {
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    val progress = if (slides.size <= 1) 1f
                    else (pagerState.currentPage + 1).toFloat() / slides.size.toFloat()
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.White.copy(alpha = 0.2f))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(progress)
                                .height(3.dp)
                                .background(Color.White, RoundedCornerShape(2.dp))
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${PersianDateFormatter.toPersianDigits(pagerState.currentPage + 1)} از ${PersianDateFormatter.toPersianDigits(slides.size)}",
                        color = Color.White.copy(alpha = 0.9f),
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }

            // دیالوگ متن کامل
            if (showFullCaption && currentSlide != null) {
                val mem = currentSlide.memory
                val mood = moodFor(mem.mood)
                AlertDialog(
                    onDismissRequest = { showFullCaption = false },
                    title = {
                        Text(mem.title.ifBlank { "خاطره" }, fontWeight = FontWeight.Bold)
                    },
                    text = {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                "${PersianDateFormatter.formatDate(mem.occurredAt)} · ${mood.emoji} ${mood.label}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                mem.note.ifBlank { "توضیحی برای این خاطره ثبت نشده است." },
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showFullCaption = false }) {
                            Text("بستن")
                        }
                    }
                )
            }
        }
    }
}



private fun decodeMemoryPreview(bytes: ByteArray) = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 1_200 || bounds.outHeight / sample > 1_200) sample *= 2
    BitmapFactory.decodeByteArray(
        bytes,
        0,
        bytes.size,
        BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
    )
}.getOrNull()

private fun decodeMemoryThumbnail(bytes: ByteArray) = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 360 || bounds.outHeight / sample > 360) sample *= 2
    BitmapFactory.decodeByteArray(
        bytes,
        0,
        bytes.size,
        BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
    )
}.getOrNull()

/** وضوح بالاتر برای اسلایدشوی تمام‌صفحه */
private fun decodeSlideshowImage(bytes: ByteArray) = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    // تا حدود 2400px برای گوشی‌های با DPI بالا
    while (bounds.outWidth / sample > 2_400 || bounds.outHeight / sample > 2_400) sample *= 2
    BitmapFactory.decodeByteArray(
        bytes,
        0,
        bytes.size,
        BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
    )
}.getOrNull()

@Composable
private fun MemoryPhotoThumbnail(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    onClick: () -> Unit
) {
    val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
        val full = onLoadAttachment(attachment.id)
        val bytes = full?.content
        value = if (bytes != null && bytes.isNotEmpty()) {
            withContext(Dispatchers.Default) { decodeMemoryThumbnail(bytes) }
        } else null
    }
    Box(
        modifier = Modifier.size(72.dp).clip(RoundedCornerShape(13.dp))
            .background(Color(0xFF25252B)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (preview != null) {
            Image(
                bitmap = preview!!.asImageBitmap(),
                contentDescription = "نمایش ${attachment.fileName}",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text("🖼️", color = Color.White.copy(alpha = .8f))
        }
    }
}

@Composable
private fun MemoryGalleryDialog(
    images: List<AttachmentEntity>,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    initialPosition: Int,
    onPositionChange: (Int) -> Unit,
    isBusy: Boolean,
    onRotateLeft: () -> Unit = {},
    onRotateRight: () -> Unit = {},
    onSave: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var confirmDelete by remember { mutableStateOf(false) }
    val pagerState = rememberPagerState(
        initialPage = initialPosition.coerceIn(images.indices),
        pageCount = { images.size }
    )
    val scope = rememberCoroutineScope()
    var currentPageZoomed by remember { mutableStateOf(false) }
    LaunchedEffect(pagerState.currentPage) {
        currentPageZoomed = false
        onPositionChange(pagerState.currentPage)
    }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                // وقتی تصویر بزرگ است، کشیدن تک‌انگشتی باید تصویر را جابه‌جا کند، نه صفحهٔ گالری را.
                userScrollEnabled = images.size > 1 && !currentPageZoomed
            ) { page ->
                val attachment = images[page]
                val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
                    val full = onLoadAttachment(attachment.id)
                    val bytes = full?.content
                    value = if (bytes != null && bytes.isNotEmpty()) {
                        withContext(Dispatchers.Default) { decodeMemoryPreview(bytes) }
                    } else null
                }
                val zoomAnim = remember(attachment.id) { Animatable(1f) }
                val panAnim = remember(attachment.id) { Animatable(Offset.Zero, Offset.VectorConverter) }
                var viewport by remember(attachment.id) { mutableStateOf(IntSize.Zero) }
                val imageScale = zoomAnim.value
                val imagePan = panAnim.value
                val zoomed = imageScale > 1.01f

                fun clampPan(value: Offset, scale: Float): Offset {
                    val image = preview ?: return Offset.Zero
                    if (scale <= 1.01f || viewport.width <= 0 || viewport.height <= 0) return Offset.Zero
                    // ContentScale.Fit leaves letterboxing on one axis; calculate the actual
                    // displayed image bounds so panning never exposes empty space unnecessarily.
                    val fitScale = minOf(
                        viewport.width.toFloat() / image.width,
                        viewport.height.toFloat() / image.height
                    )
                    val maxX = ((image.width * fitScale * scale - viewport.width) / 2f).coerceAtLeast(0f)
                    val maxY = ((image.height * fitScale * scale - viewport.height) / 2f).coerceAtLeast(0f)
                    return Offset(value.x.coerceIn(-maxX, maxX), value.y.coerceIn(-maxY, maxY))
                }

                LaunchedEffect(zoomed, page, pagerState.currentPage) {
                    if (page == pagerState.currentPage) currentPageZoomed = zoomed
                }
                LaunchedEffect(viewport, preview) {
                    panAnim.snapTo(clampPan(panAnim.value, zoomAnim.value))
                }

                Box(
                    Modifier.fillMaxSize().padding(top = 78.dp, bottom = 154.dp)
                        .clipToBounds()
                        .onSizeChanged { viewport = it },
                    contentAlignment = Alignment.Center
                ) {
                    if (preview != null) {
                        Image(
                            bitmap = preview!!.asImageBitmap(),
                            contentDescription = attachment.fileName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                                .graphicsLayer {
                                    scaleX = imageScale
                                    scaleY = imageScale
                                    translationX = imagePan.x
                                    translationY = imagePan.y
                                }
                                // Pinch to zoom; drag with one finger to explore the enlarged image.
                                .pointerInput(attachment.id) {
                                    awaitEachGesture {
                                        awaitFirstDown(requireUnconsumed = false)
                                        var previousCentroid: Offset? = null
                                        var previousSpan = 0f
                                        var previousPointerCount = 0
                                        do {
                                            val event = awaitPointerEvent()
                                            val pressed = event.changes.filter { it.pressed }
                                            if (pressed.isEmpty()) break

                                            val pointerCount = pressed.size
                                            val centroid = Offset(
                                                pressed.map { it.position.x }.average().toFloat(),
                                                pressed.map { it.position.y }.average().toFloat()
                                            )
                                            val span = if (pointerCount > 1) {
                                                pressed.map { (it.position - centroid).getDistance() }
                                                    .average().toFloat()
                                            } else 0f

                                            // A finger being added/removed changes the centroid abruptly;
                                            // reset the baseline instead of turning that into an image jump.
                                            if (pointerCount != previousPointerCount) {
                                                previousCentroid = centroid
                                                previousSpan = span
                                                previousPointerCount = pointerCount
                                                continue
                                            }

                                            val currentScale = zoomAnim.value
                                            val canTransform = currentScale > 1.01f || pointerCount > 1
                                            val oldCentroid = previousCentroid ?: centroid
                                            val panDelta = centroid - oldCentroid
                                            val gestureZoom = if (pointerCount > 1 && previousSpan > 0f) {
                                                (span / previousSpan).coerceIn(0.85f, 1.18f)
                                            } else 1f
                                            if (canTransform &&
                                                (panDelta.getDistance() > 0.25f || kotlin.math.abs(gestureZoom - 1f) > 0.001f)
                                            ) {
                                                pressed.forEach { change ->
                                                    if (change.position != change.previousPosition) change.consume()
                                                }
                                                val newScale = (currentScale * gestureZoom).coerceIn(1f, 5f)
                                                val factor = newScale / currentScale
                                                val center = Offset(viewport.width / 2f, viewport.height / 2f)
                                                val relativeCentroid = centroid - center
                                                val targetPan = if (newScale <= 1.01f) {
                                                    Offset.Zero
                                                } else {
                                                    clampPan(
                                                        panAnim.value * factor +
                                                            relativeCentroid * (1f - factor) + panDelta,
                                                        newScale
                                                    )
                                                }
                                                scope.launch {
                                                    zoomAnim.snapTo(newScale)
                                                    panAnim.snapTo(targetPan)
                                                }
                                            }
                                            previousCentroid = centroid
                                            previousSpan = span
                                            previousPointerCount = pointerCount
                                        } while (event.changes.any { it.pressed })
                                    }
                                }
                                .pointerInput(attachment.id) {
                                    detectTapGestures(
                                        onDoubleTap = {
                                            scope.launch {
                                                if (zoomAnim.value > 1.01f) {
                                                    zoomAnim.animateTo(1f)
                                                    panAnim.animateTo(Offset.Zero)
                                                } else {
                                                    zoomAnim.animateTo(2f)
                                                }
                                            }
                                        }
                                    )
                                }
                        )
                    } else {
                        Text("در حال بارگذاری تصویر…", color = Color.White.copy(alpha = .8f))
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().background(Color.Black.copy(alpha = .58f))
                    .statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "بستن گالری", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text("خاطره", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(
                        "${PersianDateFormatter.toPersianDigits(pagerState.currentPage + 1)} از ${PersianDateFormatter.toPersianDigits(images.size)}",
                        color = Color.White.copy(alpha = .78f),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                Text(
                    if (currentPageZoomed) "برای جابه‌جایی بکشید · دوبار لمس برای بازگشت"
                    else "برای بزرگ‌نمایی دوبار لمس یا نیشگون کنید",
                    color = Color.White.copy(alpha = .78f),
                    style = MaterialTheme.typography.labelSmall
                )
            }

            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .96f))))
                    .navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (images.size > 1) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(
                            onClick = {
                                val target = if (pagerState.currentPage == 0) images.lastIndex else pagerState.currentPage - 1
                                scope.launch { pagerState.animateScrollToPage(target) }
                            },
                            enabled = !isBusy
                        ) { Text("قبلی", color = Color.White) }
                        TextButton(
                            onClick = {
                                val target = (pagerState.currentPage + 1) % images.size
                                scope.launch { pagerState.animateScrollToPage(target) }
                            },
                            enabled = !isBusy
                        ) { Text("بعدی", color = Color.White) }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRotateLeft, enabled = !isBusy, modifier = Modifier.weight(1f)) {
                        Text("چرخش ↶")
                    }
                    OutlinedButton(onClick = onRotateRight, enabled = !isBusy, modifier = Modifier.weight(1f)) {
                        Text("چرخش ↷")
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onSave, enabled = !isBusy, modifier = Modifier.weight(1f)) {
                        Text("ذخیره تصویر")
                    }
                    TextButton(onClick = { confirmDelete = true }, enabled = !isBusy) {
                        Text("حذف تصویر", color = Color(0xFFFF7777))
                    }
                }
            }
        }
    }
    if (confirmDelete) {
        OSConfirmDialog(
            title = "حذف تصویر خاطره؟",
            message = "این تصویر از این خاطره حذف می‌شود و پس از همگام‌سازی، حذف به گوشی مقابل نیز منتقل خواهد شد.",
            confirmLabel = "حذف تصویر",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "🖼️",
            onConfirm = { confirmDelete = false; onDelete() },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
private fun EmptyRelationshipCard(icon: String, title: String, body: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f))
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(title, fontWeight = FontWeight.Black)
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("‹", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun AppearanceCard(
    palette: AppPalette,
    themeMode: AppThemeMode,
    dynamicColor: Boolean,
    onSetPalette: (AppPalette) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit,
    onSetDynamicColor: (Boolean) -> Unit
) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(27.dp)) {
        Column(Modifier.padding(19.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Settings, null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    "ظاهر OurSpace",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 9.dp)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "رنگ پویا (Material You)",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        "رنگ از والپیپر و تم سیستم",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                Switch(checked = dynamicColor, onCheckedChange = onSetDynamicColor)
            }
            Text(
                "پالت اختصاصی",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 14.dp)
            )
            Text(
                if (dynamicColor) "برای اعمال پالت، رنگ پویا را خاموش کن."
                else "یکی از پالت‌ها را انتخاب کن.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppPalette.entries.forEach { item ->
                    val selected = !dynamicColor && palette == item
                    val preview = when (item) {
                        AppPalette.ROSE -> Color(0xFFE85D8C)
                        AppPalette.OCEAN -> Color(0xFF2BB0C7)
                        AppPalette.FOREST -> Color(0xFF6BBF59)
                        AppPalette.SUNSET -> Color(0xFFFF8A5C)
                        AppPalette.LAVENDER -> Color(0xFFB794F6)
                        AppPalette.MIDNIGHT -> Color(0xFF5B7C99)
                        AppPalette.HONEY -> Color(0xFFE8B84A)
                    }
                    Box(
                        modifier = Modifier
                            .size(if (selected) 40.dp else 34.dp)
                            .background(preview, CircleShape)
                            .clickable { onSetPalette(item) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) {
                            Text("✓", color = Color.White, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
            if (!dynamicColor) {
                Text(
                    palette.persianLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                AppThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = themeMode == mode,
                        onClick = { onSetThemeMode(mode) },
                        label = { Text(mode.persianLabel) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}


@Composable
private fun DeviceCard(role: DeviceRole, onReset: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(27.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(19.dp)) {
            Text("دستگاه و امنیت", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(if (role == DeviceRole.HOST) "گوشی میزبان" else "گوشی همراه", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text("سرور شخصی • همگام‌سازی سریع • Android 10+", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("نسخه ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 6.dp))
            TextButton(onClick = onReset, modifier = Modifier.align(Alignment.End)) { Text("بازنشانی نسخه آزمایشی") }
        }
    }
}

@Composable
private fun ProfileDialog(
    profile: CoupleProfileEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, Long?) -> Unit
) {
    var first by remember { mutableStateOf(profile?.firstPersonName.orEmpty()) }
    var second by remember { mutableStateOf(profile?.secondPersonName.orEmpty()) }
    var startedAt by remember { mutableStateOf(profile?.relationshipStartedAt) }
    var showDatePicker by remember { mutableStateOf(false) }
    OSFormDialog(
        title = "پروفایل دونفره",
        emoji = "💑",
        onDismiss = onDismiss,
        onConfirm = { onSave(first, second, startedAt) },
        confirmLabel = "ذخیره"
    ) {

                OutlinedTextField(first, { first = it.take(80) }, label = { Text("نام نفر اول") }, singleLine = true)
                OutlinedTextField(second, { second = it.take(80) }, label = { Text("نام نفر دوم") }, singleLine = true)
                Button(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(startedAt?.let { "تاریخ شروع: ${PersianDateFormatter.formatDate(it)}" } ?: "انتخاب تاریخ شروع رابطه")
                }
                if (startedAt != null) TextButton(onClick = { startedAt = null }) { Text("حذف تاریخ شروع") }
                Text("تاریخ شروع به‌صورت امن بین دو گوشی همگام می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "تاریخ شروع رابطه",
            initialEpochMillis = startedAt ?: System.currentTimeMillis(),
            onDismiss = { showDatePicker = false },
            onConfirm = { startedAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun MemoryDialog(
    memory: MemoryEntity? = null,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Long) -> Unit
) {
    var title by remember(memory?.id) { mutableStateOf(memory?.title.orEmpty()) }
    var note by remember(memory?.id) { mutableStateOf(memory?.note.orEmpty()) }
    var mood by remember(memory?.id) { mutableStateOf(memory?.mood ?: "HAPPY") }
    var occurredAt by remember(memory?.id) { mutableStateOf(memory?.occurredAt ?: System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    OSFormDialog(
        title = if (memory == null) "خاطره جدید" else "ویرایش خاطره",
        emoji = "📷",
        onDismiss = onDismiss,
        onConfirm = { onSave(title, note, mood, occurredAt) },
        confirmLabel = if (memory == null) "ثبت خاطره" else "ذخیره تغییرات",
        confirmEnabled = title.isNotBlank()
    ) {
LazyColumn(verticalArrangement = Arrangement.spacedBy(11.dp), modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                item { OutlinedTextField(title, { title = it.take(200) }, label = { Text("عنوان خاطره") }, modifier = Modifier.fillMaxWidth()) }
                item {
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it.take(8_000) },
                        label = { Text("داستان این لحظه") },
                        placeholder = { Text("هرچقدر لازم است بنویسید…") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 220.dp, max = 360.dp),
                        minLines = 9,
                        maxLines = 14,
                        supportingText = {
                            Text("${note.length} از ۸۰۰۰ نویسه")
                        }
                    )
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(moods) { item ->
                            FilterChip(selected = mood == item.code, onClick = { mood = item.code }, label = { Text("${item.emoji} ${item.label}") })
                        }
                    }
                }
                item {
                    Button(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("تاریخ خاطره: ${PersianDateFormatter.formatDate(occurredAt)}")
                    }
                }
            }
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "تاریخ خاطره",
            initialEpochMillis = occurredAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { occurredAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun SpecialDateDialog(date: SpecialDateEntity? = null, onDismiss: () -> Unit, onSave: (String, String, Long, Boolean) -> Unit) {
    var title by remember(date?.id) { mutableStateOf(date?.title.orEmpty()) }
    var note by remember(date?.id) { mutableStateOf(date?.note.orEmpty()) }
    var occurredAt by remember(date?.id) { mutableStateOf(date?.occurredAt ?: System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var repeat by remember(date?.id) { mutableStateOf(date?.repeatYearly ?: true) }
    OSFormDialog(
        title = if (date == null) "مناسبت جدید" else "ویرایش مناسبت",
        emoji = "🎉",
        onDismiss = onDismiss,
        onConfirm = { onSave(title, note, occurredAt, repeat) },
        confirmLabel = if (date == null) "ذخیره مناسبت" else "ذخیره تغییرات",
        confirmEnabled = title.isNotBlank()
    ) {

                OutlinedTextField(title, { title = it.take(200) }, label = { Text("عنوان مناسبت") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(note, { note = it.take(8_000) }, label = { Text("متن خاطره") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), maxLines = 20)
                Button(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("تاریخ مناسبت: ${PersianDateFormatter.formatDate(occurredAt)}")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("هر سال تکرار شود", modifier = Modifier.weight(1f))
                    Switch(checked = repeat, onCheckedChange = { repeat = it })
                }
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "تاریخ مناسبت",
            initialEpochMillis = occurredAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { occurredAt = it; showDatePicker = false }
        )
    }
}

private fun nextSpecialDateOccurrence(date: SpecialDateEntity, now: Long): Long {
    if (!date.repeatYearly) return date.occurredAt
    val original = PersianDateFormatter.jalaliDate(date.occurredAt)
    val current = PersianDateFormatter.jalaliDate(now)
    fun candidate(year: Int): Long {
        val day = original.day.coerceAtMost(PersianDateFormatter.daysInJalaliMonth(year, original.month))
        return PersianDateFormatter.toEpochMillis(year, original.month, day, 12, 0)
    }
    val thisYear = candidate(current.year)
    return if (calendarDayDifference(now, thisYear) < 0) candidate(current.year + 1) else thisYear
}

private fun calendarDayDifference(from: Long, to: Long): Int {
    val zone = ZoneId.systemDefault()
    val fromDate = Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
    val toDate = Instant.ofEpochMilli(to).atZone(zone).toLocalDate()
    return ChronoUnit.DAYS.between(fromDate, toDate).toInt()
}

private fun moodFor(code: String): MoodOption = moods.firstOrNull { it.code == code } ?: moods[1]


@Composable
private fun CycleTrackerCard(
    logs: List<CycleLogEntity>,
    settings: CycleSettingsEntity?,
    onStartPeriod: () -> Unit,
    onEndOpenPeriod: (CycleLogEntity) -> Unit,
    onDeleteLog: (CycleLogEntity) -> Unit,
    onOpenSettings: () -> Unit,
    now: Long
) {
    val insight = remember(logs, settings, now) { CycleInsights.snapshot(logs, settings, now) }
    val activeLogs = remember(logs) { logs.filter { !it.isDeleted }.sortedBy { it.startAt } }
    val cycleLengths = remember(activeLogs) {
        activeLogs.zipWithNext { a, b ->
            calendarDayDifference(a.startAt, b.startAt)
        }.filter { it in 15..60 }.takeLast(8)
    }
    val actualPeriodLengths = remember(activeLogs) {
        activeLogs.mapNotNull { log ->
            log.endAt?.let { end ->
                (calendarDayDifference(log.startAt, end) + 1).takeIf { it in 1..15 }
            }
        }.takeLast(8)
    }
    val range = if (cycleLengths.size >= 2) cycleLengths.maxOrNull()!! - cycleLengths.minOrNull()!! else 0
    val currentDay = insight.dayInCycle ?: 1
    val periodDays = settings?.averagePeriodDays?.coerceIn(2, 12) ?: 5
    val ovulationDay = (insight.averageCycleDays - 14).coerceIn(periodDays + 1, insight.averageCycleDays - 2)
    val phase = when {
        insight.lastStartAt == null -> "داده کافی نیست"
        currentDay <= periodDays -> "قاعدگی"
        currentDay in (ovulationDay - 1)..(ovulationDay + 1) -> "پنجره تقریبی تخمک‌گذاری"
        currentDay < ovulationDay -> "فاز فولیکولی"
        else -> "فاز لوتئال"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .55f)
        )
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("چرخه قاعدگی", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "نمایش آماری و پیش‌بینی محلی — جایگزین تشخیص پزشکی نیست",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = onOpenSettings) { Text("تنظیمات") }
            }

            if (insight.lastStartAt != null) {
                Spacer(Modifier.height(12.dp))
                CyclePhaseRing(
                    currentDay = currentDay,
                    cycleDays = insight.averageCycleDays,
                    periodDays = periodDays,
                    ovulationDay = ovulationDay,
                    phaseLabel = phase
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CycleInfoTile("روز چرخه", PersianDateFormatter.toPersianDigits(currentDay), Modifier.weight(1f))
                    CycleInfoTile("میانگین", "${PersianDateFormatter.toPersianDigits(insight.averageCycleDays)} روز", Modifier.weight(1f))
                    CycleInfoTile("فاز", phase, Modifier.weight(1.35f))
                }
                Spacer(Modifier.height(12.dp))
                val until = insight.daysUntilNext
                Text(
                    when {
                        until == null -> "پیش‌بینی شروع بعدی در دسترس نیست"
                        until <= 0 -> "شروع تقریبی دوره فعلی/بعدی نزدیک است"
                        until == 1 -> "پیش‌بینی شروع دوره: فردا"
                        else -> "پیش‌بینی شروع دوره: ${PersianDateFormatter.toPersianDigits(until)} روز دیگر"
                    },
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "شروع آخرین دوره: ${PersianDateFormatter.formatDate(insight.lastStartAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (insight.openLog != null) {
                Button(
                    onClick = { onEndOpenPeriod(insight.openLog) },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                ) { Text("پایان دوره فعال") }
            } else {
                Button(
                    onClick = onStartPeriod,
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                ) { Text(if (insight.lastStartAt == null) "ثبت شروع دوره" else "شروع دوره جدید") }
            }

            if (cycleLengths.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("طول چرخه‌های اخیر", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                CycleLengthChart(cycleLengths, insight.averageCycleDays)
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("میانگین: ${PersianDateFormatter.toPersianDigits(insight.averageCycleDays)} روز", style = MaterialTheme.typography.labelSmall)
                    Text(
                        if (range == 0) "نوسان ثبت‌شده: —" else "دامنه تغییر: ${PersianDateFormatter.toPersianDigits(range)} روز",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (actualPeriodLengths.isNotEmpty()) {
                val avgBleeding = actualPeriodLengths.average().toInt().coerceAtLeast(1)
                Text(
                    "میانگین طول خونریزی ثبت‌شده: ${PersianDateFormatter.toPersianDigits(avgBleeding)} روز",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (activeLogs.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("ثبت‌های اخیر", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                activeLogs.asReversed().take(5).forEach { log ->
                    Row(
                        Modifier.fillMaxWidth().padding(top = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                PersianDateFormatter.formatDate(log.startAt) +
                                    (log.endAt?.let { " تا ${PersianDateFormatter.formatDate(it)}" } ?: " • فعال"),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                flowLabel(log.flowLevel),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextButton(onClick = { onDeleteLog(log) }) { Text("حذف") }
                    }
                }
            }
        }
    }
}

@Composable
private fun CycleInfoTile(title: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .78f))
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 2)
        }
    }
}

@Composable
private fun CyclePhaseRing(
    currentDay: Int,
    cycleDays: Int,
    periodDays: Int,
    ovulationDay: Int,
    phaseLabel: String
) {
    val periodColor = Color(0xFFE57373)
    val follicularColor = Color(0xFF81C784)
    val ovulationColor = Color(0xFFFFB74D)
    val lutealColor = Color(0xFF9575CD)
    val trackColor = MaterialTheme.colorScheme.surface.copy(alpha = .55f)
    val onSurface = MaterialTheme.colorScheme.onSurface
    val total = cycleDays.coerceIn(15, 60).toFloat()
    val day = currentDay.coerceIn(1, cycleDays.coerceIn(15, 60)).toFloat()
    val periodEnd = periodDays.coerceIn(1, cycleDays - 1).toFloat()
    val ovStart = (ovulationDay - 1).coerceAtLeast(periodDays + 1).toFloat()
    val ovEnd = (ovulationDay + 1).coerceAtMost(cycleDays).toFloat()

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(196.dp)) {
            Canvas(Modifier.size(196.dp)) {
                val stroke = 18.dp.toPx()
                val diameter = size.minDimension - stroke
                val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                val arcSize = Size(diameter, diameter)
                fun sweep(fromDay: Float, toDay: Float): Pair<Float, Float> {
                    val start = ((fromDay - 1f) / total) * 360f - 90f
                    val sweep = ((toDay - fromDay + 1f).coerceAtLeast(0f) / total) * 360f
                    return start to sweep
                }
                // background track
                drawArc(
                    color = trackColor,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                // period
                val (pStart, pSweep) = sweep(1f, periodEnd)
                drawArc(
                    color = periodColor,
                    startAngle = pStart,
                    sweepAngle = pSweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Butt)
                )
                // follicular
                if (ovStart > periodEnd + 1f) {
                    val (fStart, fSweep) = sweep(periodEnd + 1f, ovStart - 1f)
                    drawArc(
                        color = follicularColor,
                        startAngle = fStart,
                        sweepAngle = fSweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Butt)
                    )
                }
                // ovulation window
                val (oStart, oSweep) = sweep(ovStart, ovEnd)
                drawArc(
                    color = ovulationColor,
                    startAngle = oStart,
                    sweepAngle = oSweep.coerceAtLeast(8f),
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Butt)
                )
                // luteal
                if (ovEnd < total) {
                    val (lStart, lSweep) = sweep(ovEnd + 1f, total)
                    drawArc(
                        color = lutealColor,
                        startAngle = lStart,
                        sweepAngle = lSweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Butt)
                    )
                }
                // current day marker
                val angle = Math.toRadians((((day - 1f) / total) * 360.0) - 90.0)
                val radius = diameter / 2f
                val cx = size.width / 2f + (radius * kotlin.math.cos(angle)).toFloat()
                val cy = size.height / 2f + (radius * kotlin.math.sin(angle)).toFloat()
                drawCircle(color = Color.White, radius = 9.dp.toPx(), center = Offset(cx, cy))
                drawCircle(color = onSurface, radius = 5.dp.toPx(), center = Offset(cx, cy))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    PersianDateFormatter.toPersianDigits(currentDay),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black
                )
                Text(
                    "از ${PersianDateFormatter.toPersianDigits(cycleDays)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    phaseLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            PhaseLegendDot("قاعدگی", periodColor)
            PhaseLegendDot("فولیکولی", follicularColor)
            PhaseLegendDot("تخمک‌گذاری", ovulationColor)
            PhaseLegendDot("لوتئال", lutealColor)
        }
    }
}

@Composable
private fun PhaseLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun CycleLengthChart(values: List<Int>, average: Int) {
    val maxValue = maxOf(values.maxOrNull() ?: average, average, 30)
    val minValue = minOf(values.minOrNull() ?: average, average, 18)
    val primaryColor = MaterialTheme.colorScheme.primary
    val avgColor = MaterialTheme.colorScheme.tertiary
    val barColor = MaterialTheme.colorScheme.primary.copy(alpha = .75f)
    Canvas(Modifier.fillMaxWidth().height(140.dp).padding(top = 8.dp)) {
        if (values.isEmpty()) return@Canvas
        val n = values.size
        val gap = 8.dp.toPx()
        val barWidth = ((size.width - gap * (n + 1)) / n).coerceAtLeast(10.dp.toPx())
        val range = (maxValue - minValue).coerceAtLeast(1).toFloat()
        val avgY = size.height - ((average - minValue) / range) * size.height * 0.85f
        // average guide
        drawLine(
            color = avgColor.copy(alpha = .45f),
            start = Offset(0f, avgY),
            end = Offset(size.width, avgY),
            strokeWidth = 2.dp.toPx()
        )
        values.forEachIndexed { index, value ->
            val x = gap + index * (barWidth + gap)
            val h = ((value - minValue) / range) * size.height * 0.85f
            drawRoundRect(
                color = if (value >= average) barColor else primaryColor.copy(alpha = .45f),
                topLeft = Offset(x, size.height - h),
                size = Size(barWidth, h.coerceAtLeast(4.dp.toPx())),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
            )
        }
    }
}

private fun flowLabel(level: String): String = when (level.uppercase()) {
    "LIGHT" -> "خفیف"
    "MEDIUM" -> "متوسط"
    "HEAVY" -> "سنگین"
    "SPOTTING" -> "لکه‌بینی"
    else -> "شدت نامشخص"
}

@Composable
private fun CycleSettingsDialog(
    settings: CycleSettingsEntity?,
    onDismiss: () -> Unit,
    onSave: (Int, Int, Boolean) -> Unit
) {
    var cycleDays by remember { mutableStateOf((settings?.averageCycleDays ?: 28).toString()) }
    var periodDays by remember { mutableStateOf((settings?.averagePeriodDays ?: 5).toString()) }
    var enabled by remember { mutableStateOf(settings?.trackingEnabled ?: true) }
    OSFormDialog(
        title = "تنظیمات چرخه",
        emoji = "🌙",
        onDismiss = onDismiss,
        onConfirm = {
            onSave(
                cycleDays.toIntOrNull() ?: 28,
                periodDays.toIntOrNull() ?: 5,
                enabled
            )
        },
        confirmLabel = "ذخیره تنظیمات"
    ) {

                OutlinedTextField(
                    value = cycleDays,
                    onValueChange = { cycleDays = it.filter { ch -> ch.isDigit() }.take(2) },
                    label = { Text("طول میانگین چرخه (روز)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = periodDays,
                    onValueChange = { periodDays = it.filter { ch -> ch.isDigit() }.take(2) },
                    label = { Text("طول میانگین دوره (روز)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("نمایش پیش‌بینی", modifier = Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }
    }
}

@Composable
private fun StartPeriodDialog(
    onDismiss: () -> Unit,
    onConfirm: (Long, String, String) -> Unit
) {
    var selectedStartAt by remember { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var flow by remember { mutableStateOf("MEDIUM") }
    var note by remember { mutableStateOf("") }
    OSFormDialog(
        title = "شروع دوره",
        emoji = "🌸",
        onDismiss = onDismiss,
        onConfirm = { onConfirm(selectedStartAt, flow, note) },
        confirmLabel = "ثبت شروع"
    ) {

                Text("روز اول پریود", style = MaterialTheme.typography.labelLarge)
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                ) {
                    Text(PersianDateFormatter.formatDate(selectedStartAt))
                }
                Text(
                    "محاسبه روز چرخه، فاز و پیش‌بینی دوره بعدی از همین تاریخ انجام می‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text("شدت جریان", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "LIGHT" to "خفیف",
                        "MEDIUM" to "متوسط",
                        "HEAVY" to "سنگین",
                        "SPOTTING" to "لکه"
                    ).forEach { (code, label) ->
                        FilterChip(
                            selected = flow == code,
                            onClick = { flow = code },
                            label = { Text(label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it.take(200) },
                    label = { Text("یادداشت (اختیاری)") },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    maxLines = 2
                )
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "تاریخ شروع پریود",
            initialEpochMillis = selectedStartAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { selectedStartAt = it; showDatePicker = false }
        )
    }
}
