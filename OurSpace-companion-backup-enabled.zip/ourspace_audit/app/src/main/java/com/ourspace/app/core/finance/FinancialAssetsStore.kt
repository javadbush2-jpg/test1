package com.ourspace.app.core.finance

import android.content.Context
import android.content.SharedPreferences
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.database.SyncChangeEntity
import com.ourspace.app.core.notification.NotificationCategory
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.server.HostServerService
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.launch
import org.json.JSONObject

/** مقدارهای دستی دارایی‌های غیرنقدی؛ تمام نرخ‌ها به تومان هستند. */
data class FinancialAssetInputs(
    val goldGrams: String = "",
    val goldRateTomanPerGram: String = "",
    val dollars: String = "",
    val dollarRateToman: String = "",
    val updatedAt: Long = 0L,
    /** Sync watermark used to clear device-local pending SMS finance reviews on both peers. */
    val financialDataClearedAt: Long = 0L
)

data class FinancialAssetValues(
    val goldValueToman: Long,
    val dollarValueToman: Long
) {
    val totalToman: Long
        get() = FinancialAssetCalculator.addSafely(goldValueToman, dollarValueToman)
}

/** محاسبهٔ امن مقادیر واردشده با دقت اعشاری و گردکردن به نزدیک‌ترین تومان. */
object FinancialAssetCalculator {
    private val inputPattern = Regex("""(?:\d+(?:\.\d*)?|\.\d+)""")
    private val maxLongDecimal = BigDecimal.valueOf(Long.MAX_VALUE)

    fun isValidNumber(raw: String): Boolean = raw.isBlank() || parseNumber(raw) != null

    fun parseNumber(raw: String): BigDecimal? {
        val normalized = normalizeNumber(raw)
        if (normalized.isBlank() || !inputPattern.matches(normalized)) return null
        return runCatching { BigDecimal(normalized) }
            .getOrNull()
            ?.takeIf { it.signum() >= 0 }
    }

    fun valueToman(quantity: String, rateToman: String): Long {
        val quantityValue = parseNumber(quantity) ?: BigDecimal.ZERO
        val rateValue = parseNumber(rateToman) ?: BigDecimal.ZERO
        val rounded = quantityValue.multiply(rateValue).setScale(0, RoundingMode.HALF_UP)
        return (if (rounded > maxLongDecimal) maxLongDecimal else rounded).toLong()
    }

    fun calculate(inputs: FinancialAssetInputs): FinancialAssetValues = FinancialAssetValues(
        goldValueToman = valueToman(inputs.goldGrams, inputs.goldRateTomanPerGram),
        dollarValueToman = valueToman(inputs.dollars, inputs.dollarRateToman)
    )

    fun addSafely(first: Long, second: Long): Long = try {
        Math.addExact(first, second)
    } catch (_: ArithmeticException) {
        if (first >= 0L && second >= 0L) Long.MAX_VALUE else Long.MIN_VALUE
    }

    fun totalWealthToman(bankBalancesToman: Long, inputs: FinancialAssetInputs): Long =
        addSafely(bankBalancesToman, calculate(inputs).totalToman)

    private fun normalizeNumber(raw: String): String = buildString(raw.length) {
        raw.trim().forEach { char ->
            when (char) {
                in '۰'..'۹' -> append(('0'.code + (char.code - '۰'.code)).toChar())
                in '٠'..'٩' -> append(('0'.code + (char.code - '٠'.code)).toChar())
                '٫' -> append('.')
                ',', '٬', '،', ' ', '\u00a0' -> Unit
                else -> append(char)
            }
        }
    }
}

/** محلی نگه‌داری می‌شود و از outbox همگام‌سازی مالی نیز عبور می‌کند. */
object FinancialAssetsStore {
    private const val PREFS = "ourspace_financial_assets_v1"
    private const val KEY_RECORD = "portfolio_record"
    const val ENTITY_TYPE = "financialAssets"
    const val ENTITY_ID = "portfolio"

    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun preferences(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context): FinancialAssetInputs {
        val json = runCatching { JSONObject(preferences(context).getString(KEY_RECORD, "{}") ?: "{}") }
            .getOrDefault(JSONObject())
        return fromJson(json)
    }

    fun save(context: Context, inputs: FinancialAssetInputs): FinancialAssetInputs {
        val prefs = preferences(context)
        val previous = load(context)
        val updated = inputs.copy(
            updatedAt = maxOf(System.currentTimeMillis(), previous.updatedAt + 1L),
            financialDataClearedAt = maxOf(inputs.financialDataClearedAt, previous.financialDataClearedAt)
        )
        prefs.edit().putString(KEY_RECORD, updated.toJson().toString()).apply()
        scheduleSync(context.applicationContext, updated.updatedAt)
        return updated
    }

    /** Clears portfolio values and broadcasts a watermark to clear local-only finance queues on peers. */
    fun clearAll(context: Context): FinancialAssetInputs {
        val prefs = preferences(context)
        val previous = load(context)
        val updatedAt = maxOf(System.currentTimeMillis(), previous.updatedAt + 1L)
        val cleared = FinancialAssetInputs(
            updatedAt = updatedAt,
            financialDataClearedAt = updatedAt
        )
        prefs.edit().putString(KEY_RECORD, cleared.toJson().toString()).apply()
        scheduleSync(context.applicationContext, updatedAt)
        return cleared
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun observe(context: Context): Flow<FinancialAssetInputs> = callbackFlow {
        val prefs = preferences(context)
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == KEY_RECORD) trySend(load(context))
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(load(context))
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }.conflate()

    fun exportSyncRecord(context: Context, entityId: String): JSONObject? {
        if (entityId != ENTITY_ID) return null
        val raw = preferences(context).getString(KEY_RECORD, null) ?: return null
        return runCatching { JSONObject(raw) }.getOrNull()?.let { JSONObject(it.toString()) }
    }

    fun exportAllSyncRecords(context: Context): List<JSONObject> =
        exportSyncRecord(context, ENTITY_ID)?.let { listOf(it) }.orEmpty()

    fun syncRecordUpdatedAt(context: Context?, entityId: String): Long? {
        context ?: return null
        if (entityId != ENTITY_ID) return null
        val raw = preferences(context).getString(KEY_RECORD, null) ?: return null
        return runCatching { JSONObject(raw).optLong("updatedAt", -1L) }
            .getOrNull()
            ?.takeIf { it >= 0L }
    }

    /** اعمال رکورد پذیرفته‌شده از همگام‌سازی، بدون echo کردن آن به outbox. */
    fun applySyncedRecord(context: Context?, json: JSONObject) {
        context ?: return
        if (json.optString("id") != ENTITY_ID || json.optLong("updatedAt", -1L) < 0L) return
        val previous = load(context)
        val incoming = fromJson(json)
        if (incoming.financialDataClearedAt > previous.financialDataClearedAt) {
            PendingSmsStore.clear(context)
            OurSpaceNotificationCenter(context).clearNotificationsForCategory(NotificationCategory.BANK_SMS)
        }
        preferences(context).edit().putString(KEY_RECORD, incoming.toJson().toString()).apply()
    }

    private fun scheduleSync(context: Context, updatedAt: Long) {
        syncScope.launch {
            delay(500L)
            if (load(context).updatedAt != updatedAt) return@launch
            if (exportSyncRecord(context, ENTITY_ID) == null) return@launch
            runCatching {
                OurSpaceDatabase.getInstance(context).syncChangeDao().upsert(
                    SyncChangeEntity(
                        changeId = "$ENTITY_TYPE:$updatedAt:${UUID.randomUUID()}",
                        entityType = ENTITY_TYPE,
                        entityId = ENTITY_ID,
                        changedAt = updatedAt,
                        priority = 700,
                        createdAt = updatedAt
                    )
                )
                runCatching { HostServerService.requestImmediateSync(context) }
            }
        }
    }

    private fun FinancialAssetInputs.toJson(): JSONObject = JSONObject()
        .put("id", ENTITY_ID)
        .put("goldGrams", goldGrams)
        .put("goldRateTomanPerGram", goldRateTomanPerGram)
        .put("dollars", dollars)
        .put("dollarRateToman", dollarRateToman)
        .put("updatedAt", updatedAt)
        .put("financialDataClearedAt", financialDataClearedAt)

    private fun fromJson(json: JSONObject): FinancialAssetInputs = FinancialAssetInputs(
        goldGrams = json.optString("goldGrams").take(40),
        goldRateTomanPerGram = json.optString("goldRateTomanPerGram").take(40),
        dollars = json.optString("dollars").take(40),
        dollarRateToman = json.optString("dollarRateToman").take(40),
        updatedAt = json.optLong("updatedAt", 0L).coerceAtLeast(0L),
        financialDataClearedAt = json.optLong("financialDataClearedAt", 0L).coerceAtLeast(0L)
    )
}
