package com.ourspace.app.feature.location

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Toast
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.ourspace.app.core.database.LocationShareEntity
import com.ourspace.app.core.database.SharedPlaceEntity
import com.ourspace.app.core.time.PersianDateFormatter
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun LocationMapScreen(
    ownDeviceId: String,
    isPaired: Boolean,
    sharingEnabled: Boolean,
    hasPermission: Boolean,
    isUpdating: Boolean,
    statusMessage: String?,
    statusError: String?,
    locations: List<LocationShareEntity>,
    sharedPlaces: List<com.ourspace.app.core.database.SharedPlaceEntity> = emptyList(),
    onToggleSharing: (Boolean) -> Unit,
    onRequestPermission: () -> Unit,
    onRefreshNow: () -> Unit,
    onRefreshPartnerLocation: () -> Unit = {},
    onShareLocationToChat: (LocationShareEntity) -> Unit = {},
    onAddPlace: (String, String, Double, Double, String) -> Unit = { _, _, _, _, _ -> },
    onDeletePlace: (com.ourspace.app.core.database.SharedPlaceEntity) -> Unit = {}
) {
    // Keep stale points visible but label them clearly; never imply they are live.
    var clockNow by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            clockNow = System.currentTimeMillis()
        }
    }
    val context = LocalContext.current
    val markers = remember(locations) { locations.filter { it.isSharing && !it.isDeleted } }
    val visiblePlaces = remember(sharedPlaces) { sharedPlaces.filterNot { it.isDeleted } }
    var selectedPlaceId by remember { mutableStateOf<String?>(null) }
    var selectedPlaceCategory by remember { mutableStateOf("ALL") }
    var pendingMapCoordinate by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    val pageScrollState = rememberScrollState()
    val pageScope = rememberCoroutineScope()
    val filteredPlaces = remember(visiblePlaces, selectedPlaceCategory) {
        if (selectedPlaceCategory == "ALL") visiblePlaces
        else visiblePlaces.filter { normalizePlaceCategory(it.category) == selectedPlaceCategory }
    }
    val placeCategoryFilters = listOf(
        "ALL" to "همه",
        "HOME" to "خانه",
        "CAFE" to "کافه",
        "TRAVEL" to "سفر",
        "MEMORY" to "خاطره",
        "OTHER" to "سایر"
    )
    val own = markers.firstOrNull { it.id == ownDeviceId }
    val partner = markers.firstOrNull { it.id != ownDeviceId }
    // Give the map most of a phone viewport while keeping the entire page scrollable.
    val mapHeight = (LocalConfiguration.current.screenHeightDp * 0.62f)
        .coerceIn(440f, 640f)
        .dp

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(pageScrollState)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Compact controls — leave room for a large map.
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .7f)
            )
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "موقعیت آنلاین",
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleSmall
                        )
                        if (!isPaired) {
                            Text(
                                "ابتدا جفت‌سازی کنید",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    if (isPaired) {
                        Text("اشتراک", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.size(8.dp))
                        Switch(
                            checked = sharingEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled && !hasPermission) onRequestPermission()
                                else onToggleSharing(enabled)
                            }
                        )
                    }
                }
                if (isPaired) {
                    locations.firstOrNull { it.id == ownDeviceId && !it.isDeleted }?.let { mine ->
                        OutlinedButton(
                            onClick = { onShareLocationToChat(mine) },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) { Text("ارسال موقعیت من در چت") }
                    }
                    locations.firstOrNull { it.id != ownDeviceId && !it.isDeleted }?.let { peer ->
                        OutlinedButton(
                            onClick = { onShareLocationToChat(peer) },
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) { Text("ارسال موقعیت شریک در چت") }
                    }

                    if (!hasPermission && sharingEnabled) {
                        Text(
                            "مجوز موقعیت لازم است.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        OutlinedButton(
                            onClick = onRequestPermission,
                            modifier = Modifier.padding(top = 4.dp)
                        ) { Text("درخواست مجوز") }
                    }
                    statusMessage?.let {
                        Text(
                            it,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    statusError?.let {
                        Text(
                            it,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onRefreshNow,
                            enabled = isPaired && sharingEnabled && hasPermission && !isUpdating,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                if (isUpdating) "در حال به‌روزرسانی…" else "به‌روزرسانی موقعیت",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        Text(
            "برای ثبت مکان مشترک، روی نقطهٔ دلخواه نقشه چند لحظه نگه دارید.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            placeCategoryFilters.forEach { (code, label) ->
                val count = if (code == "ALL") visiblePlaces.size else visiblePlaces.count { normalizePlaceCategory(it.category) == code }
                FilterChip(
                    selected = selectedPlaceCategory == code,
                    onClick = {
                        selectedPlaceCategory = code
                        selectedPlaceId = null
                    },
                    label = { Text("$label · $count") }
                )
            }
        }

        // Large map area — occupies most of the viewport and is not covered by status cards.
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(mapHeight),
            shape = RoundedCornerShape(22.dp)
        ) {
            OsmMapView(
                markers = markers,
                places = filteredPlaces,
                selectedPlaceId = selectedPlaceId,
                freshnessTick = clockNow / 60_000L,
                ownDeviceId = ownDeviceId,
                onMapLongPress = { latitude, longitude ->
                    pendingMapCoordinate = latitude to longitude
                },
                onOpenPlace = { id ->
                    visiblePlaces.firstOrNull { it.id == id }?.let { openInGoogleMaps(context, it) }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Location details are kept below the map, not layered over it.
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "موقعیت‌های من و همراه",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LocationStatusChip(
                    title = "موقعیت من",
                    share = own,
                    clockNow = clockNow,
                    ownDeviceId = ownDeviceId,
                    isPaired = isPaired,
                    isUpdating = isUpdating,
                    onRefreshPartnerLocation = onRefreshPartnerLocation,
                    modifier = Modifier.weight(1f)
                )
                LocationStatusChip(
                    title = "موقعیت همراه",
                    share = partner,
                    clockNow = clockNow,
                    ownDeviceId = ownDeviceId,
                    isPaired = isPaired,
                    isUpdating = isUpdating,
                    onRefreshPartnerLocation = onRefreshPartnerLocation,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        SharedPlacesSection(
            places = sharedPlaces,
            liveLocations = markers,
            ownDeviceId = ownDeviceId,
            onAddPlace = onAddPlace,
            onOpenPlace = { place -> openInGoogleMaps(context, place) },
            initialMapCoordinate = pendingMapCoordinate,
            initialMapCategory = selectedPlaceCategory,
            onMapCoordinateHandled = {
                val handledCoordinate = pendingMapCoordinate
                pageScope.launch {
                    delay(160)
                    pageScrollState.animateScrollTo(pageScrollState.maxValue)
                    if (pendingMapCoordinate == handledCoordinate) pendingMapCoordinate = null
                }
            },
            onSelectPlace = { id ->
                selectedPlaceId = id
                visiblePlaces.firstOrNull { it.id == id }?.let { place ->
                    selectedPlaceCategory = normalizePlaceCategory(place.category)
                }
            },
            onDelete = onDeletePlace
        )
    }
}

@Composable
private fun LocationStatusChip(
    title: String,
    share: LocationShareEntity?,
    clockNow: Long,
    ownDeviceId: String,
    isPaired: Boolean,
    isUpdating: Boolean,
    onRefreshPartnerLocation: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            if (share == null) {
                Text(
                    if (!isPaired) "جفت‌سازی نشده" else "هنوز موقعیتی دریافت نشده",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    "دقت حدود ${PersianDateFormatter.toPersianDigits(share.accuracyMeters.toInt())} متر",
                    style = MaterialTheme.typography.bodySmall
                )
                val stale = clockNow - share.updatedAt > 15 * 60 * 1000L
                Text(
                    (if (stale) "موقعیت قدیمی · " else "آخرین به‌روزرسانی ") + PersianDateFormatter.relativeTime(share.updatedAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (stale) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // دکمه همیشه برای کارت «همراه» دیده شود (حتی وقتی هنوز موقعیتی نیست)
            val isPartnerChip = share == null || share.id != ownDeviceId
            if (isPartnerChip && title.contains("همراه")) {
                OutlinedButton(
                    onClick = onRefreshPartnerLocation,
                    enabled = isPaired && !isUpdating,
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Text(
                        if (isUpdating) "در حال دریافت از گوشی مقابل…"
                        else "به‌روزرسانی موقعیت گوشی مقابل"
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun OsmMapView(
    markers: List<LocationShareEntity>,
    places: List<com.ourspace.app.core.database.SharedPlaceEntity>,
    selectedPlaceId: String?,
    freshnessTick: Long,
    ownDeviceId: String,
    onMapLongPress: (Double, Double) -> Unit,
    onOpenPlace: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val markerJson = remember(markers, ownDeviceId) { buildLocationMarkersJson(markers, ownDeviceId) }
    val placesJson = remember(places) { buildPlacesJson(places) }
    val currentLongPressCallback = rememberUpdatedState(onMapLongPress)
    val currentOpenPlaceCallback = rememberUpdatedState(onOpenPlace)
    val mapJavascriptBridge = remember {
        MapLongPressJavascriptInterface(
            onMapLongPress = { latitude, longitude ->
                currentLongPressCallback.value(latitude, longitude)
            },
            onOpenPlace = { id -> currentOpenPlaceCallback.value(id) }
        )
    }
    val selectedJson = JSONObject.quote(selectedPlaceId ?: "")
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                webViewClient = WebViewClient()
                addJavascriptInterface(mapJavascriptBridge, "OurSpaceMap")
                loadDataWithBaseURL("https://leafletjs.com/", buildMapHtml(), "text/html", "UTF-8", null)
                tag = listOf(markerJson, placesJson, selectedPlaceId, freshnessTick)
                postDelayed({
                    evaluateJavascript("window.ourSpacePending={markers:$markerJson,places:$placesJson,selected:$selectedJson};if(window.renderOurSpaceMap){renderOurSpaceMap($markerJson,$placesJson,$selectedJson)}", null)
                }, 250)
            }
        },
        update = { webView ->
            val previous = webView.tag as? List<*>
            if (previous?.getOrNull(0) != markerJson || previous?.getOrNull(1) != placesJson || previous?.getOrNull(2) != selectedPlaceId || previous?.getOrNull(3) != freshnessTick) {
                webView.tag = listOf(markerJson, placesJson, selectedPlaceId, freshnessTick)
                // Update markers in-place so recomposition does not reload the map.
                webView.evaluateJavascript("window.ourSpacePending={markers:$markerJson,places:$placesJson,selected:$selectedJson};if(window.renderOurSpaceMap){renderOurSpaceMap($markerJson,$placesJson,$selectedJson)}", null)
            }
        }
    )
}

private class MapLongPressJavascriptInterface(
    private val onMapLongPress: (Double, Double) -> Unit,
    private val onOpenPlace: (String) -> Unit
) {
    @JavascriptInterface
    fun onLongPress(latitude: Double, longitude: Double) {
        if (!latitude.isFinite() || !longitude.isFinite() || latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return
        Handler(Looper.getMainLooper()).post { onMapLongPress(latitude, longitude) }
    }

    @JavascriptInterface
    fun openPlace(placeId: String) {
        if (placeId.isBlank() || placeId.length > 128) return
        Handler(Looper.getMainLooper()).post { onOpenPlace(placeId) }
    }
}

private fun buildLocationMarkersJson(markers: List<LocationShareEntity>, ownDeviceId: String): String = JSONArray().apply {
    markers.forEach { m ->
        put(JSONObject()
            .put("lat", m.latitude)
            .put("lng", m.longitude)
            .put("label", if (m.id == ownDeviceId) "من" else "همراه")
            .put("own", m.id == ownDeviceId)
            .put("updatedAt", m.updatedAt)
        )
    }
}.toString()

private fun buildPlacesJson(places: List<com.ourspace.app.core.database.SharedPlaceEntity>): String = JSONArray().apply {
    places.forEach { p ->
        put(JSONObject()
            .put("id", p.id)
            .put("lat", p.latitude)
            .put("lng", p.longitude)
            .put("title", p.title)
            .put("categoryCode", normalizePlaceCategory(p.category))
            .put("category", placeCategoryLabel(p.category))
        )
    }
}.toString()

private fun buildMapHtml(): String = """
<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
html,body,#map{height:100%;margin:0;padding:0} .map-error{font:14px sans-serif;padding:20px;line-height:1.8;color:#333}
.legend{position:absolute;z-index:999;bottom:8px;left:8px;background:#fff;padding:7px 9px;border-radius:8px;font:12px sans-serif;box-shadow:0 1px 5px #888}
</style></head><body><div id="map"><div class="map-error">در حال بارگذاری نقشه…</div></div>
<script>
(function(){
  var map=null, liveLayer=null, placeLayer=null, errorShown=false, hasInitialView=false;
  function showError(msg){var el=document.getElementById('map');if(el && !map){el.innerHTML='<div class="map-error">'+msg+'<br/>برای نمایش نقشه اتصال اینترنت را بررسی کنید. فهرست مکان‌های ثبت‌شده همچنان در پایین صفحه در دسترس است.</div>';}}
  function requestPlaceAt(clientX,clientY){
    var now=Date.now(); if(now-lastLongPressAt<900)return; lastLongPressAt=now;
    var rect=map.getContainer().getBoundingClientRect();
    var point=L.point(clientX-rect.left,clientY-rect.top); var latlng=map.containerPointToLatLng(point);
    if(window.OurSpaceMap && window.OurSpaceMap.onLongPress) window.OurSpaceMap.onLongPress(latlng.lat,latlng.lng);
  }
  var longPressTimer=null, touchStart=null, lastLongPressAt=0;
  window.renderOurSpaceMap=function(markers,places,selectedId){
    if(!window.L){showError('کتابخانه نقشه بارگذاری نشد.');return;}
    if(!map){
      document.getElementById('map').innerHTML='';
      map=L.map('map').setView([35.7,51.4],5);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map)
        .on('tileerror',function(){if(!errorShown){errorShown=true;var n=document.createElement('div');n.className='legend';n.textContent='بارگذاری نقشه با مشکل روبه‌رو شد؛ اینترنت را بررسی کنید.';document.getElementById('map').appendChild(n);}});
      liveLayer=L.layerGroup().addTo(map); placeLayer=L.layerGroup().addTo(map);
      var container=map.getContainer();
      container.addEventListener('touchstart',function(ev){
        if(ev.touches.length!==1){clearTimeout(longPressTimer);touchStart=null;return;}
        var touch=ev.touches[0];touchStart={x:touch.clientX,y:touch.clientY};
        var x=touch.clientX,y=touch.clientY;
        clearTimeout(longPressTimer);
        longPressTimer=setTimeout(function(){if(touchStart){requestPlaceAt(x,y);touchStart=null;}},650);
      },{passive:true});
      container.addEventListener('touchmove',function(ev){
        if(!touchStart)return;
        if(ev.touches.length!==1){clearTimeout(longPressTimer);touchStart=null;return;}
        var touch=ev.touches[0];
        if(Math.hypot(touch.clientX-touchStart.x,touch.clientY-touchStart.y)>12){clearTimeout(longPressTimer);touchStart=null;}
      },{passive:true});
      var clearPress=function(){clearTimeout(longPressTimer);touchStart=null;};
      container.addEventListener('touchend',clearPress,{passive:true});
      container.addEventListener('touchcancel',clearPress,{passive:true});
      container.addEventListener('contextmenu',function(ev){ev.preventDefault();requestPlaceAt(ev.clientX,ev.clientY);});
    }
    liveLayer.clearLayers(); placeLayer.clearLayers(); var bounds=[]; var now=Date.now();
    markers.forEach(function(m){
      var stale=(now-m.updatedAt)>900000; var color=stale?'#D97706':(m.own?'#2E7D32':'#1565C0');
      var marker=L.circleMarker([m.lat,m.lng],{radius:10,color:color,fillColor:color,fillOpacity:stale?0.45:0.85,weight:2}).addTo(liveLayer);
      var pop=document.createElement('div');var title=document.createElement('strong');title.textContent=m.label;pop.appendChild(title);
      var detail=document.createElement('div');detail.textContent=stale?'موقعیت قدیمی — آخرین ثبت بیش از ۱۵ دقیقه قبل':'آخرین ثبت: '+new Date(m.updatedAt).toLocaleString();pop.appendChild(detail);marker.bindPopup(pop);bounds.push([m.lat,m.lng]);
    });
    places.forEach(function(p){
      var categoryCode=String(p.categoryCode||'OTHER').toUpperCase();
      var colors={HOME:'#7C3AED',CAFE:'#D97706',TRAVEL:'#0284C7',MEMORY:'#DB2777',OTHER:'#64748B'};
      var symbols={HOME:'⌂',CAFE:'☕',TRAVEL:'✈',MEMORY:'♥',OTHER:'•'};
      var color=colors[categoryCode]||colors.OTHER;
      var symbol=symbols[categoryCode]||symbols.OTHER;
      var icon=L.divIcon({className:'ourspace-place-pin',html:'<div style="width:32px;height:32px;border:2px solid #fff;border-radius:50% 50% 50% 4px;transform:rotate(-45deg);background:'+color+';color:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 2px 5px #555"><span style="transform:rotate(45deg)">'+symbol+'</span></div>',iconSize:[34,38],iconAnchor:[17,34]});
      var marker=L.marker([p.lat,p.lng],{icon:icon}).addTo(placeLayer);var pop=document.createElement('div');
      var title=document.createElement('strong');title.textContent=p.title;pop.appendChild(title);
      var category=document.createElement('div');category.textContent=p.category;pop.appendChild(category);marker.bindPopup(pop);
      marker.on('click',function(){if(window.OurSpaceMap && window.OurSpaceMap.openPlace)window.OurSpaceMap.openPlace(p.id);});
      bounds.push([p.lat,p.lng]);
    });
    var selected=places.find(function(p){return p.id===selectedId;});
    if(selected){map.setView([selected.lat,selected.lng],16);}
    else if(!hasInitialView && bounds.length>1){map.fitBounds(bounds,{padding:[35,35],maxZoom:15});hasInitialView=true;}
    else if(!hasInitialView && bounds.length===1){map.setView(bounds[0],15);hasInitialView=true;}
    setTimeout(function(){map.invalidateSize();},100);
  };
  if(window.ourSpacePending){var d=window.ourSpacePending;window.renderOurSpaceMap(d.markers,d.places,d.selected);}
  setTimeout(function(){if(!window.L)showError('نقشه در دسترس نیست.');},3500);
})();
</script></body></html>
""".trimIndent()

@Composable
private fun SharedPlacesSection(
    places: List<com.ourspace.app.core.database.SharedPlaceEntity>,
    liveLocations: List<LocationShareEntity>,
    ownDeviceId: String,
    onAddPlace: (String, String, Double, Double, String) -> Unit,
    onOpenPlace: (SharedPlaceEntity) -> Unit,
    initialMapCoordinate: Pair<Double, Double>?,
    initialMapCategory: String,
    onMapCoordinateHandled: () -> Unit,
    onSelectPlace: (String) -> Unit,
    onDelete: (com.ourspace.app.core.database.SharedPlaceEntity) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("MEMORY") }
    var latitudeText by remember { mutableStateOf("") }
    var longitudeText by remember { mutableStateOf("") }
    LaunchedEffect(initialMapCoordinate) {
        initialMapCoordinate?.let { (latitude, longitude) ->
            latitudeText = String.format(Locale.US, "%.6f", latitude)
            longitudeText = String.format(Locale.US, "%.6f", longitude)
            title = ""
            category = if (initialMapCategory == "ALL") "MEMORY" else initialMapCategory
            showAdd = true
            onMapCoordinateHandled()
        }
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "مکان‌های مشترک",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                )
                OutlinedButton(onClick = { showAdd = !showAdd }) {
                    Text(if (showAdd) "بستن" else "افزودن مکان")
                }
            }
            Text(
                "کافه، سفر، خانه و خاطره — روی نقشهٔ ذهنی دونفره",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
            if (showAdd) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it.take(80) },
                    label = { Text("نام مکان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = latitudeText, onValueChange = { latitudeText = it.take(20) }, label = { Text("عرض جغرافیایی") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = longitudeText, onValueChange = { longitudeText = it.take(20) }, label = { Text("طول جغرافیایی") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                val mine = liveLocations.firstOrNull { it.id == ownDeviceId }
                if (mine != null) TextButton(onClick = { latitudeText = mine.latitude.toString(); longitudeText = mine.longitude.toString() }) { Text("استفاده از مختصات فعلی من") }
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "HOME" to "خانه",
                        "CAFE" to "کافه",
                        "TRAVEL" to "سفر",
                        "MEMORY" to "خاطره",
                        "OTHER" to "سایر"
                    ).forEach { (code, label) ->
                        FilterChip(
                            selected = category == code,
                            onClick = { category = code },
                            label = { Text(label) }
                        )
                    }
                }
                Button(
                    onClick = {
                        val lat = latitudeText.trim().toDoubleOrNull()
                        val lon = longitudeText.trim().toDoubleOrNull()
                        if (title.isNotBlank() && lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0) {
                            onAddPlace(title.trim(), "", lat, lon, category)
                            title = ""
                            latitudeText = ""
                            longitudeText = ""
                            showAdd = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("ذخیره مکان") }
                if (latitudeText.isNotBlank() || longitudeText.isNotBlank()) {
                    val latValue = latitudeText.toDoubleOrNull()
                    val lonValue = longitudeText.toDoubleOrNull()
                    val latOk = latValue != null && latValue in -90.0..90.0
                    val lonOk = lonValue != null && lonValue in -180.0..180.0
                    if (!latOk || !lonOk) Text("مختصات معتبر وارد کنید؛ عرض بین ۹۰- تا ۹۰ و طول بین ۱۸۰- تا ۱۸۰.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (places.isEmpty()) {
                Text(
                    "هنوز مکان مشترکی ثبت نشده است.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 10.dp)
                )
            } else {
                places.take(8).forEach { place ->
                    Row(
                        Modifier.fillMaxWidth().padding(top = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            TextButton(onClick = { onSelectPlace(place.id) }) { Text(place.title, fontWeight = FontWeight.SemiBold) }
                            Text(
                                placeCategoryLabel(place.category) + " · ${String.format(Locale.US, "%.5f", place.latitude)}, ${String.format(Locale.US, "%.5f", place.longitude)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextButton(onClick = { onOpenPlace(place) }) { Text("بازکردن نقشه") }
                        TextButton(onClick = { onDelete(place) }) { Text("حذف") }
                    }
                }
            }
        }
    }
}

private fun normalizePlaceCategory(code: String): String = when (code.uppercase(Locale.ROOT)) {
    "HOME", "CAFE", "TRAVEL", "MEMORY" -> code.uppercase(Locale.ROOT)
    else -> "OTHER"
}

private fun openInGoogleMaps(context: Context, place: SharedPlaceEntity) {
    val latitude = String.format(Locale.US, "%.6f", place.latitude)
    val longitude = String.format(Locale.US, "%.6f", place.longitude)
    val label = Uri.encode(place.title)
    val geoUri = Uri.parse("geo:0,0?q=$latitude,$longitude($label)")
    val mapsIntent = Intent(Intent.ACTION_VIEW, geoUri)
        .setPackage("com.google.android.apps.maps")
    runCatching { context.startActivity(mapsIntent) }.onFailure {
        val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude%2C$longitude")
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, webUri)) }
            .onFailure {
                Toast.makeText(context, "برنامهٔ نقشه در دسترس نیست.", Toast.LENGTH_SHORT).show()
            }
    }
}

private fun placeCategoryLabel(code: String): String = when (normalizePlaceCategory(code)) {
    "HOME" -> "خانه"
    "CAFE" -> "کافه"
    "TRAVEL" -> "سفر"
    "MEMORY" -> "خاطره"
    else -> "سایر"
}
