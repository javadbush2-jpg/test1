package com.ourspace.app.core.finance

import android.content.Context
import android.content.SharedPreferences
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.database.SyncChangeEntity
import com.ourspace.app.core.server.HostServerService
import com.ourspace.app.core.time.PersianDateFormatter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * قالب‌های سفارشی کاربر برای خواندن پیامک بانکی.
 *
 * متغیرهای مجاز در الگو (همه به‌جز {amount} اختیاری‌اند و در یادداشت تراکنش
 * و گزارش آزمایش قالب استخراج می‌شوند):
 *  - {amount}   : مبلغ تراکنش (الزامی) — گروه عددی
 *  - {balance}  : موجودی/مانده — عدد
 *  - {card}     : شماره/بخش کارت (مثل ****6060)
 *  - {account}  : شماره حساب/شبا
 *  - {date}     : تاریخ تراکنش (مثل 1403/05/12)
 *  - {time}     : ساعت تراکنش (مثل 14:30)
 *  - {ref}      : کد پیگیری/رهگیری (حرف و عدد)
 *  - {merchant} : نام پذیرنده/فروشگاه (متن)
 *
 * مثال: «مبلغ: {amount} ریال · مانده: {balance} · کارت {card} · ساعت {time}»
 */
data class UserSmsTemplate(
    val id: String = UUID.randomUUID().toString().replace("-", "").take(16),
    val name: String,
    /** بخشی از شماره/نام فرستنده — خالی = هر فرستنده */
    val senderContains: String = "",
    /** کلمات ضروری (با کاما جدا) */
    val mustContain: String = "",
    /** الگو با placeholderها؛ حداقل باید {amount} داشته باشد */
    val amountPattern: String = "مبلغ {amount}",
    /** EXPENSE | INCOME | AUTO */
    val kind: String = "AUTO",
    val category: String = "سایر",
    /** اگر مبلغ به ریال است true (تبدیل ÷۱۰ به تومان) */
    val amountIsRial: Boolean = true,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    /** نحوهٔ تطبیق کلمات ضروری: ALL = همه باید باشند، ANY = وجود هرکدام کافی است */
    val matchMode: String = "ALL",
    /** کلمات ردکننده (با کاما) — اگر هرکدام در متن باشد قالب رد می‌شود (مثل ناموفق، لغو) */
    val excludeContain: String = "",
    /** اولویت ارزیابی؛ عدد کوچک‌تر زودتر بررسی می‌شود */
    val priority: Int = 0,
    /** متن نمونهٔ همراه قالب برای آزمایش زنده در ویرایشگر */
    val sampleBody: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("senderContains", senderContains)
        .put("mustContain", mustContain)
        .put("amountPattern", amountPattern)
        .put("kind", kind)
        .put("category", category)
        .put("amountIsRial", amountIsRial)
        .put("enabled", enabled)
        .put("createdAt", createdAt)
        .put("matchMode", matchMode)
        .put("excludeContain", excludeContain)
        .put("priority", priority)
        .put("sampleBody", sampleBody)

    companion object {
        fun fromJson(o: JSONObject): UserSmsTemplate = UserSmsTemplate(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString().take(16) },
            name = o.optString("name").ifBlank { "قالب" },
            senderContains = o.optString("senderContains"),
            mustContain = o.optString("mustContain"),
            amountPattern = o.optString("amountPattern").ifBlank { "مبلغ {amount}" },
            kind = o.optString("kind").ifBlank { "AUTO" },
            category = o.optString("category").ifBlank { "سایر" },
            amountIsRial = o.optBoolean("amountIsRial", true),
            enabled = o.optBoolean("enabled", true),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            matchMode = o.optString("matchMode").ifBlank { "ALL" },
            excludeContain = o.optString("excludeContain"),
            priority = o.optInt("priority", 0),
            sampleBody = o.optString("sampleBody")
        )
    }
}

/**
 * نتیجهٔ بررسی یک قالب روی یک متن — هم برای پارس واقعی و هم برای عیب‌یابی رابط.
 */
data class TemplateDiagnostic(
    val templateId: String,
    val templateName: String,
    val matched: Boolean,
    val reason: String,
    val amount: Long? = null,
    val kind: String? = null,
    val extras: Map<String, String> = emptyMap(),
    val transactionDateMillis: Long? = null
)

object SmsTemplateStore {
    private const val PREFS = "ourspace_sms_templates"
    private const val KEY = "templates_json"
    private const val KEY_SYNC_RECORDS = "template_sync_records"
    private const val KEY_SYNC_SEEDED = "template_sync_seeded"
    private const val KEY_DEFAULT_TEMPLATES_MIGRATION = "default_templates_migration_v6"
    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val PLACEHOLDER = Regex("""\{(amount|balance|card|[a-zA-Z_][a-zA-Z0-9_]*)\}""")
    private const val AMOUNT_TOKEN = "{amount}"

    fun list(context: Context): List<UserSmsTemplate> {
        ensureLegacyTemplatesSeeded(context)
        migrateDefaultTemplates(context)
        return readTemplates(preferences(context))
    }

    /** Save local edits and enqueue only changed template rows; remote materialization uses applySyncedRecord. */
    fun saveAll(context: Context, items: List<UserSmsTemplate>) {
        ensureLegacyTemplatesSeeded(context)
        val prefs = preferences(context)
        val oldItems = readTemplates(prefs)
        val newItems = items.distinctBy { it.id }
        writeTemplates(prefs, newItems)

        val oldById = oldItems.associateBy { it.id }
        val newById = newItems.associateBy { it.id }
        val changed = mutableListOf<JSONObject>()
        (oldById.keys - newById.keys).forEach { id ->
            oldById[id]?.let { changed += putLocalRecord(prefs, it, deleted = true) }
        }
        newItems.forEach { template ->
            if (oldById[template.id] != template) {
                changed += putLocalRecord(prefs, template, deleted = false)
            }
        }
        prefs.edit().putBoolean(KEY_SYNC_SEEDED, true).apply()
        enqueueChanges(context, changed)
    }

    /** A live signal lets the settings page reflect templates received from the other phone. */
    @OptIn(ExperimentalCoroutinesApi::class)
    fun observeChanges(context: Context): Flow<Int> = callbackFlow {
        val prefs = preferences(context)
        var revision = 0
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == KEY) trySend(++revision)
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(revision)
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }.conflate()

    fun exportSyncRecord(context: Context, entityId: String): JSONObject? {
        ensureLegacyTemplatesSeeded(context)
        return readSyncRecords(preferences(context)).optJSONObject(entityId)?.let { JSONObject(it.toString()) }
    }

    fun exportAllSyncRecords(context: Context): List<JSONObject> {
        ensureLegacyTemplatesSeeded(context)
        val records = readSyncRecords(preferences(context))
        return records.keys().asSequence()
            .mapNotNull { key -> records.optJSONObject(key)?.let { JSONObject(it.toString()) } }
            .sortedBy { it.optString("id") }
            .toList()
    }

    fun syncRecordUpdatedAt(context: Context?, entityId: String): Long? {
        context ?: return null
        ensureLegacyTemplatesSeeded(context)
        return readSyncRecords(preferences(context)).optJSONObject(entityId)?.optLong("updatedAt")
    }

    /** Applies a record accepted by the sync conflict resolver without echoing it back to outbox. */
    fun applySyncedRecord(context: Context?, json: JSONObject) {
        context ?: return
        ensureLegacyTemplatesSeeded(context)
        val id = json.optString("id")
        val updatedAt = json.optLong("updatedAt", -1L)
        val templateJson = json.optJSONObject("template") ?: return
        val template = runCatching { UserSmsTemplate.fromJson(templateJson) }.getOrNull() ?: return
        if (id.isBlank() || template.id != id || updatedAt < 0L) return

        val prefs = preferences(context)
        val records = readSyncRecords(prefs)
        records.put(id, JSONObject()
            .put("id", id)
            .put("deleted", json.optBoolean("deleted"))
            .put("updatedAt", updatedAt)
            .put("template", template.toJson()))
        prefs.edit().putString(KEY_SYNC_RECORDS, records.toString()).apply()
        rebuildVisibleTemplates(prefs, records)
    }

    fun upsert(context: Context, template: UserSmsTemplate) {
        val cur = list(context).toMutableList()
        val idx = cur.indexOfFirst { it.id == template.id }
        if (idx >= 0) cur[idx] = template else cur.add(0, template)
        saveAll(context, cur)
    }

    fun delete(context: Context, id: String) {
        saveAll(context, list(context).filterNot { it.id == id })
    }

    /**
     * جابه‌جایی قالب در ترتیب اولویت (قالب‌های بالایی زودتر ارزیابی می‌شوند).
         */
    fun move(context: Context, id: String, up: Boolean) {
        val cur = list(context)
        val idx = cur.indexOfFirst { it.id == id }
        val target = if (up) idx - 1 else idx + 1
        if (idx < 0 || target !in cur.indices) return
        val renumbered = cur.mapIndexed { i, t -> t.copy(priority = i) }.toMutableList()
        val tmp = renumbered[idx]
        renumbered[idx] = renumbered[target]
        renumbered[target] = tmp
        saveAll(context, renumbered)
    }

    /** افزودن قالب آماده؛ اگر قالبی با همین نام موجود باشد اضافه نمی‌شود. */
    fun addPreset(context: Context, preset: UserSmsTemplate): Boolean {
        val cur = list(context)
        if (cur.any { it.name == preset.name }) return false
        saveAll(context, cur + preset.copy(priority = cur.size))
        return true
    }

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun readTemplates(prefs: SharedPreferences): List<UserSmsTemplate> {
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) add(UserSmsTemplate.fromJson(array.getJSONObject(index)))
            }.sortedWith(
                compareBy<UserSmsTemplate> { it.priority }
                    .thenByDescending { it.createdAt }
                    .thenBy { it.id }
            )
        }.getOrDefault(emptyList())
    }

    private fun writeTemplates(prefs: SharedPreferences, items: List<UserSmsTemplate>) {
        val array = JSONArray()
        items.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private fun readSyncRecords(prefs: SharedPreferences): JSONObject =
        runCatching { JSONObject(prefs.getString(KEY_SYNC_RECORDS, "{}") ?: "{}") }
            .getOrDefault(JSONObject())

    /** Migrate per-device templates from older versions and give matching legacy names a stable ID. */
    private fun ensureLegacyTemplatesSeeded(context: Context) {
        val prefs = preferences(context)
        if (prefs.getBoolean(KEY_SYNC_SEEDED, false)) return
        synchronized(this) {
            if (prefs.getBoolean(KEY_SYNC_SEEDED, false)) return
            val oldTemplates = readTemplates(prefs)
            val usedIds = mutableSetOf<String>()
            val migrated = oldTemplates.map { template ->
                val stableId = stableLegacyId(template.name)
                val id = if (stableId !in usedIds) stableId else template.id
                usedIds += id
                if (id == template.id) template else template.copy(id = id)
            }
            if (migrated != oldTemplates) writeTemplates(prefs, migrated)
            val records = readSyncRecords(prefs)
            val changed = mutableListOf<JSONObject>()
            migrated.forEach { template ->
                if (!records.has(template.id)) {
                    changed += putLocalRecord(
                        prefs,
                        template,
                        deleted = false,
                        timestampFloor = template.createdAt.coerceAtLeast(1L)
                    )
                }
            }
            prefs.edit().putBoolean(KEY_SYNC_SEEDED, true).apply()
            enqueueChanges(context, changed)
        }
    }

    private fun migrateDefaultTemplates(context: Context) {
        val prefs = preferences(context)
        if (prefs.getBoolean(KEY_DEFAULT_TEMPLATES_MIGRATION, false)) return
        synchronized(this) {
            if (prefs.getBoolean(KEY_DEFAULT_TEMPLATES_MIGRATION, false)) return
            val current = readTemplates(prefs)
            val obsoleteIds = current.filter { existing ->
                LEGACY_DEFAULT_SEEDS.any { legacy ->
                    existing.id == stableLegacyId(legacy.name) && existing.matchesSeedDefinition(legacy)
                }
            }.mapTo(mutableSetOf()) { it.id }

            val base = if (obsoleteIds.isEmpty()) {
                current
            } else {
                val replacement = DEFAULT_SEEDS.mapIndexed { index, template ->
                    template.copy(id = stableLegacyId(template.name), priority = index)
                }.filter { template ->
                    current.none { it.id == template.id && it.id !in obsoleteIds }
                }
                replacement + current.filterNot { it.id in obsoleteIds }
            }
            val syncRecords = readSyncRecords(prefs)
            val additions = DEFAULT_SEEDS.map { seed ->
                seed.copy(id = stableLegacyId(seed.name), priority = base.size)
            }.filter { seed ->
                val alreadyPresent = base.any { it.id == seed.id || it.name == seed.name }
                val wasDeleted = syncRecords.optJSONObject(seed.id)?.optBoolean("deleted", false) == true
                !alreadyPresent && !wasDeleted
            }
            val updated = base + additions
            if (updated != current) {
                saveAll(context, updated.mapIndexed { index, template -> template.copy(priority = index) })
            }
            prefs.edit().putBoolean(KEY_DEFAULT_TEMPLATES_MIGRATION, true).apply()
        }
    }

    private fun UserSmsTemplate.matchesSeedDefinition(seed: UserSmsTemplate): Boolean =
        name == seed.name &&
            senderContains == seed.senderContains &&
            mustContain == seed.mustContain &&
            amountPattern == seed.amountPattern &&
            kind == seed.kind &&
            category == seed.category &&
            amountIsRial == seed.amountIsRial &&
            enabled == seed.enabled &&
            matchMode == seed.matchMode &&
            excludeContain == seed.excludeContain &&
            sampleBody == seed.sampleBody

    private fun stableLegacyId(name: String): String =
        UUID.nameUUIDFromBytes(
            ("ourspace-sms-template:" + name.trim().lowercase(Locale.ROOT)).toByteArray(Charsets.UTF_8)
        ).toString().replace("-", "").take(16)

    private fun putLocalRecord(
        prefs: SharedPreferences,
        template: UserSmsTemplate,
        deleted: Boolean,
        timestampFloor: Long? = null
    ): JSONObject {
        val records = readSyncRecords(prefs)
        val previousUpdatedAt = records.optJSONObject(template.id)?.optLong("updatedAt") ?: 0L
        val updatedAt = maxOf(timestampFloor ?: System.currentTimeMillis(), previousUpdatedAt + 1L)
        val record = JSONObject()
            .put("id", template.id)
            .put("deleted", deleted)
            .put("updatedAt", updatedAt)
            .put("template", template.toJson())
        records.put(template.id, record)
        prefs.edit().putString(KEY_SYNC_RECORDS, records.toString()).apply()
        return JSONObject(record.toString())
    }

    private fun rebuildVisibleTemplates(prefs: SharedPreferences, records: JSONObject) {
        val active = records.keys().asSequence()
            .mapNotNull { key -> records.optJSONObject(key) }
            .filterNot { it.optBoolean("deleted") }
            .mapNotNull { record -> record.optJSONObject("template")?.let { UserSmsTemplate.fromJson(it) } }
            .sortedWith(
                compareBy<UserSmsTemplate> { it.priority }
                    .thenByDescending { it.createdAt }
                    .thenBy { it.id }
            )
            .toList()
        writeTemplates(prefs, active)
    }

    private fun enqueueChanges(context: Context, records: List<JSONObject>) {
        if (records.isEmpty()) return
        val appContext = context.applicationContext
        syncScope.launch {
            runCatching {
                val changeDao = OurSpaceDatabase.getInstance(appContext).syncChangeDao()
                records.forEach { record ->
                    val updatedAt = record.getLong("updatedAt")
                    val entityId = record.getString("id")
                    changeDao.upsert(SyncChangeEntity(
                        changeId = "smsTemplates:$updatedAt:${UUID.randomUUID()}",
                        entityType = "smsTemplates",
                        entityId = entityId,
                        changedAt = updatedAt,
                        priority = 650,
                        createdAt = updatedAt
                    ))
                }
                runCatching { HostServerService.requestImmediateSync(appContext) }
            }
        }
    }

    internal data class PlaceholderMatch(
        val amountGroup: Int,
        /** نام توکن → شماره گروه ضبط در regex */
        val groups: Map<String, Int>
    )

    /**
     * توضیح هر متغیر برای رابط کاربری (نام، برچسب فارسی، توضیح کوتاه).
     * ترتیب همین فهرست، ترتیب دکمه‌های درج متغیر در ویرایشگر است.
     */
    val PLACEHOLDER_DOCS: List<Triple<String, String, String>> = listOf(
        Triple("{amount}", "مبلغ", "مبلغ تراکنش — عدد (الزامی)"),
        Triple("{balance}", "مانده", "موجودی/مانده حساب — عدد"),
        Triple("{card}", "کارت", "شماره کارت مثل ****6060"),
        Triple("{account}", "حساب", "شماره حساب/شبای فرستنده"),
        Triple("{date}", "تاریخ", "تاریخ تراکنش مثل 1403/05/12"),
        Triple("{time}", "ساعت", "ساعت تراکنش مثل 14:30"),
        Triple("{ref}", "کد پیگیری", "کد رهگیری/پیگیری (حرف و عدد)"),
        Triple("{merchant}", "پذیرنده", "نام فروشگاه/پذیرنده (متن)")
    )

    /** الگوی regex هر توکن شناخته‌شده. */
    private fun tokenRegex(token: String): String = when (token) {
        "amount", "balance" -> """([\d\u066C\u060C,،\h]+)"""
        "card", "account" -> """([0-9*＊xX\-–_ \u0640]+)"""
        "date" -> """([\d\/\-.,،\h]+)"""
        "time" -> """([\d:：\h]+)"""
        "ref" -> """([0-9A-Za-z؀-ۿ\-]+)"""
        "merchant" -> """([^\n]+)"""
        else -> """(\S+)"""
    }

    /** برچسب فارسی و نوع استخراج هر توکن (NUM = عدد، TXT = متن). */
    private val TOKEN_LABELS: Map<String, Pair<String, Boolean>> = mapOf(
        "balance" to ("مانده" to true),
        "card" to ("کارت" to false),
        "account" to ("حساب" to false),
        "date" to ("تاریخ" to false),
        "time" to ("ساعت" to false),
        "ref" to ("کد پیگیری" to false),
        "merchant" to ("پذیرنده" to false)
    )

    /**
     * تبدیل الگوی کاربر به Regex؛ بخش‌های ثابت escape و هر placeholder به یک گروه
     * ضبط تبدیل می‌شود. شمارهٔ گروه {amount} برای استخراج برگردانده می‌شود.
     */
    private val FLEXIBLE_LITERAL_SEPARATOR = Regex("""(?:\r?\n)+|[ \t]+""")

    private fun appendFlexibleLiteral(builder: StringBuilder, literal: String) {
        var cursor = 0
        FLEXIBLE_LITERAL_SEPARATOR.findAll(literal).forEach { match ->
            builder.append(Regex.escape(literal.substring(cursor, match.range.first)))
            builder.append(if (match.value.startsWith("\n") || match.value.startsWith("\r")) """(?:\r?\n)+""" else """\h+""")
            cursor = match.range.last + 1
        }
        builder.append(Regex.escape(literal.substring(cursor)))
    }

    internal fun buildPattern(pattern: String): Pair<Regex, PlaceholderMatch> {
        val trimmed = pattern.trim().ifBlank { "مبلغ $AMOUNT_TOKEN" }
        val signedLine = when (trimmed) {
            "{amount}+" -> "+"
            "{amount}-" -> "-"
            "{amount}−" -> "−"
            else -> null
        }
        if (signedLine != null) {
            // Signed bank amounts must occupy a whole line. This avoids mistaking a date such as
            // 1405/7/30-11:51 or a long account/reference number for the transaction amount.
            val regex = Regex(
                """(?m)^[\h]*([\d\u066C\u060C,،\h]+?)[\h]*${Regex.escape(signedLine)}[\h]*$"""
            )
            return regex to PlaceholderMatch(amountGroup = 1, groups = mapOf("amount" to 1))
        }
        val sb = StringBuilder()
        var amountGroup = -1
        val groups = LinkedHashMap<String, Int>()
        var group = 0
        var cursor = 0
        for (m in PLACEHOLDER.findAll(trimmed)) {
            appendFlexibleLiteral(sb, trimmed.substring(cursor, m.range.first))
            group += 1
            val token = m.groupValues[1].lowercase()
            if (token == "amount") amountGroup = group
            groups[token] = group
            sb.append(tokenRegex(token))
            cursor = m.range.last + 1
        }
        appendFlexibleLiteral(sb, trimmed.substring(cursor))
        if (amountGroup < 0) {
            // الگو بدون {amount}؛ کل عدد به‌عنوان گروه مبلغ در نظر گرفته می‌شود
            sb.setLength(0)
            sb.append(Regex.escape(trimmed))
            amountGroup = 0
        }
        return Regex(sb.toString(), RegexOption.IGNORE_CASE) to
            PlaceholderMatch(amountGroup, groups)
    }

    /** سازگاری با نسخهٔ قبل: فقط Regex الگوی مبلغ. */
    fun amountRegexFromPattern(pattern: String): Regex = buildPattern(pattern).first

    private fun splitWords(raw: String): List<String> =
        raw.split(",", "،").map { it.trim() }.filter { it.isNotEmpty() }

    private data class EvalOutcome(
        val ok: Boolean,
        val reason: String,
        val parsed: BankSmsParser.ParsedSmsTransaction? = null,
        val extras: Map<String, String> = emptyMap()
    )

    private fun parseJalaliDateTime(dateRaw: String?, timeRaw: String?): Long? {
        val date = dateRaw?.let { BankSmsParser.normalizeDigitsPublic(it).trim() } ?: return null
        val time = timeRaw?.let { BankSmsParser.normalizeDigitsPublic(it).trim() } ?: return null
        val dateMatch = Regex("""^(\d{4})[/.-](\d{1,2})[/.-](\d{1,2})$""")
            .matchEntire(date) ?: return null
        val timeMatch = Regex("""^(\d{1,2})[:：](\d{1,2})(?:[:：](\d{1,2}))?$""")
            .matchEntire(time) ?: return null
        val year = dateMatch.groupValues[1].toIntOrNull() ?: return null
        val month = dateMatch.groupValues[2].toIntOrNull() ?: return null
        val day = dateMatch.groupValues[3].toIntOrNull() ?: return null
        val hour = timeMatch.groupValues[1].toIntOrNull() ?: return null
        val minute = timeMatch.groupValues[2].toIntOrNull() ?: return null
        val secondRaw = timeMatch.groupValues.getOrNull(3).orEmpty()
        val second = if (secondRaw.isEmpty()) 0 else secondRaw.toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59 || second !in 0..59) return null
        return runCatching {
            PersianDateFormatter.toEpochMillis(year, month, day, hour, minute) + second.toLong() * 1_000L
        }.getOrNull()
    }

    private fun evaluate(
        tpl: UserSmsTemplate,
        body: String,
        address: String
    ): EvalOutcome {
        if (!tpl.enabled) return EvalOutcome(false, "قالب خاموش است")
        val normalized = BankSmsParser.normalizeDigitsPublic(body)
            .replace("\r\n", "\n")
            .replace('\r', '\n')
        val addr = address.lowercase()

        if (tpl.senderContains.isNotBlank()) {
            val hint = tpl.senderContains.trim().lowercase()
            if (!addr.contains(hint) && !normalized.lowercase().contains(hint) &&
                !body.lowercase().contains(hint)
            ) {
                return EvalOutcome(false, "فرستنده شامل «${tpl.senderContains.trim()}» نیست")
            }
        }

        val excludes = splitWords(tpl.excludeContain)
        excludes.firstOrNull { normalized.contains(it) || body.contains(it) }?.let {
            return EvalOutcome(false, "کلمهٔ ردکنندهٔ «$it» در متن هست")
        }

        val must = splitWords(tpl.mustContain)
        if (must.isNotEmpty()) {
            val present = must.filter { normalized.contains(it) || body.contains(it) }
            val modeAny = tpl.matchMode.equals("ANY", ignoreCase = true)
            if (modeAny) {
                if (present.isEmpty()) {
                    return EvalOutcome(false, "هیچ‌یک از کلمات ضروری در متن نیست")
                }
            } else if (present.size != must.size) {
                val missing = (must - present.toSet()).firstOrNull().orEmpty()
                return EvalOutcome(false, "کلمهٔ ضروری «$missing» پیدا نشد")
            }
        }

        val (regex, mapping) = buildPattern(tpl.amountPattern)
        val match = regex.find(normalized) ?: regex.find(body)
            ?: return EvalOutcome(false, "الگو در متن پیدا نشد")
        if (mapping.amountGroup <= 0) {
            return EvalOutcome(false, "الگو فاقد $AMOUNT_TOKEN است")
        }
        val amountRaw = match.groupValues.getOrNull(mapping.amountGroup).orEmpty()
        var amount = BankSmsParser.parseNumberPublic(amountRaw)
            ?: return EvalOutcome(false, "عدد مبلغ قابل خواندن نیست")
        if (amount <= 0L) return EvalOutcome(false, "مبلغ باید بزرگ‌تر از صفر باشد")
        if (tpl.amountIsRial && amount >= 10L && amount >= 1000L) {
            amount /= 10L
        }

        val extras = LinkedHashMap<String, String>()
        mapping.groups.forEach { (token, g) ->
            if (token == "amount") return@forEach
            val raw = match.groupValues.getOrNull(g)?.trim().orEmpty()
            if (raw.isBlank()) return@forEach
            val (label, isNumeric) = TOKEN_LABELS[token] ?: return@forEach
            if (isNumeric) {
                BankSmsParser.parseNumberPublic(raw)?.let { extras[label] = formatDigits(it.toString()) }
            } else {
                extras[label] = raw
            }
        }

        val kind = when (tpl.kind.uppercase()) {
            "EXPENSE", "INCOME" -> tpl.kind.uppercase()
            else -> BankSmsParser.guessKindPublic(normalized)
        }
        val note = buildString {
            append("قالب: ${tpl.name}")
            extras.forEach { (label, value) -> append(" · $label: $value") }
        }.take(500)

        val parsed = BankSmsParser.ParsedSmsTransaction(
            amount = amount,
            kind = kind,
            category = tpl.category.ifBlank { "سایر" },
            note = note,
            confidence = 0.96f,
            templateId = "user:${tpl.id}",
            transactionDateMillis = parseJalaliDateTime(extras["تاریخ"], extras["ساعت"]),
            extras = extras
        )
        return EvalOutcome(
            ok = true,
            reason = "تطبیق موفق",
            parsed = parsed,
            extras = extras
        )
    }

    fun tryParse(context: Context, body: String, address: String): BankSmsParser.ParsedSmsTransaction? {
        for (tpl in list(context).filter { it.enabled }) {
            val outcome = evaluate(tpl, body, address)
            if (outcome.ok) return outcome.parsed
        }
        return null
    }

    /** آزمایش یک قالب تنها روی متن (بدون نیاز به ذخیره) — برای آزمایش زندهٔ ویرایشگر. */
    fun testTemplate(tpl: UserSmsTemplate, body: String, address: String = ""): TemplateDiagnostic {
        if (body.isBlank()) {
            return TemplateDiagnostic(tpl.id, tpl.name, false, "متن نمونه خالی است")
        }
        val enabledTpl = if (tpl.enabled) tpl else tpl.copy(enabled = true)
        val outcome = evaluate(enabledTpl, body, address)
        return TemplateDiagnostic(
            templateId = tpl.id,
            templateName = tpl.name,
            matched = outcome.ok,
            reason = outcome.reason,
            amount = outcome.parsed?.amount,
            kind = outcome.parsed?.kind,
            extras = outcome.extras,
            transactionDateMillis = outcome.parsed?.transactionDateMillis
        )
    }

    /** تحلیل متن با همهٔ قالب‌ها؛ دلیل موفقیت یا شکست هر قالب جداگانه گزارش می‌شود. */
    fun diagnoseAll(context: Context, body: String, address: String = ""): List<TemplateDiagnostic> =
        list(context).map { tpl ->
            val outcome = evaluate(tpl, body, address)
            TemplateDiagnostic(
                templateId = tpl.id,
                templateName = tpl.name,
                matched = outcome.ok,
                reason = outcome.reason,
                amount = outcome.parsed?.amount,
                kind = outcome.parsed?.kind,
                extras = outcome.extras,
                transactionDateMillis = outcome.parsed?.transactionDateMillis
            )
        }

    private fun formatDigits(rawDigits: String): String =
        rawDigits.reversed().chunked(3).joinToString("٬").reversed()

    /** چند قالب نمونه برای شروع */
    fun seedDefaultsIfEmpty(context: Context) {
        if (list(context).isNotEmpty()) return
        // Do not resurrect a list that was deliberately emptied on either paired device.
        if (readSyncRecords(preferences(context)).length() > 0) return
        saveAll(context, DEFAULT_SEEDS.mapIndexed { index, template ->
            template.copy(id = stableLegacyId(template.name), priority = index)
        })
    }

    /**
     * گالری قالب‌های آمادهٔ بانک‌های پرکاربر؛ کاربر با یک لمس اضافه می‌کند.
     * نام‌ها یکتا هستند و افزودن تکراری جلوگیری می‌شود.
     */
    val PRESETS: List<UserSmsTemplate> = listOf(
        UserSmsTemplate(
            name = "ملت · برداشت",
            senderContains = "mellat",
            mustContain = "برداشت,خرید",
            excludeContain = "ناموفق,لغو,برگشت",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "ملت · واریز",
            senderContains = "mellat",
            mustContain = "واریز",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "INCOME"
        ),
        UserSmsTemplate(
            name = "ملی · برداشت",
            senderContains = "bmi",
            mustContain = "برداشت,خرید,پرداخت",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "سامان · برداشت",
            senderContains = "saman",
            mustContain = "برداشت,خرید,پرداخت",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "پاسارگاد · برداشت",
            senderContains = "pasargad",
            mustContain = "برداشت,خرید",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "بلوبانک · برداشت",
            senderContains = "blu",
            mustContain = "برداشت,خرید,پرداخت",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "بلوبانک · واریز",
            senderContains = "blu",
            mustContain = "واریز",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "INCOME"
        ),
        UserSmsTemplate(
            name = "الگوی کامل با همهٔ متغیرها",
            mustContain = "مبلغ",
            amountPattern = "مبلغ {amount} ریال · مانده: {balance} · کارت {card} · ساعت {time} · کد پیگیری {ref}",
            kind = "AUTO",
            sampleBody = "مبلغ 1,250,000 ریال · مانده: 8,400,000 · کارت ****6060 · ساعت 14:30 · کد پیگیری 9876543210"
        ),
        UserSmsTemplate(
            name = "خرید با پذیرنده و تاریخ",
            mustContain = "خرید",
            excludeContain = "ناموفق,لغو",
            amountPattern = "خرید {amount} تومان از {merchant} در تاریخ {date}",
            kind = "EXPENSE",
            amountIsRial = false,
            sampleBody = "خرید 125,000 تومان از فروشگاه رفاه در تاریخ 1403/05/12 انجام شد"
        ),
        UserSmsTemplate(
            name = "نادیده‌گرفتن تراکنش ناموفق",
            mustContain = "مبلغ",
            excludeContain = "ناموفق,لغو,خطا,برگشت خورد",
            amountPattern = "مبلغ {amount}",
            kind = "AUTO"
        )
    )

    /** نسخه‌های قبلی قالب‌های پیش‌فرض؛ فقط برای مهاجرت امن داده‌های موجود نگه داشته شده‌اند. */
    private val LEGACY_DEFAULT_SEEDS: List<UserSmsTemplate> = listOf(
        UserSmsTemplate(
            name = "بانک مهر · واریز (+)",
            senderContains = "mehr",
            mustContain = "مانده",
            amountPattern = "{amount}+",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "بانک مهر · برداشت (−)",
            senderContains = "mehr",
            mustContain = "مانده",
            amountPattern = "{amount}-",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "برداشت عمومی",
            mustContain = "برداشت",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "واریز عمومی",
            mustContain = "واریز",
            amountPattern = "مبلغ {amount}",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true
        ),
        // Previous release: same templates, but with a generic placeholder sample body.
        UserSmsTemplate(
            name = "بانک مهر · واریز (+)",
            senderContains = "300102513345478001",
            mustContain = "مانده",
            amountPattern = "{amount}+",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "300102513345478001\n\n49,500,000+\n\n1405/7/30-11:51\n\nمانده:294,046,569"
        ),
        UserSmsTemplate(
            name = "بانک مهر · برداشت (−)",
            senderContains = "300102513345478001",
            mustContain = "مانده",
            amountPattern = "{amount}-",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "300102513345478001\n\n49,500,000-\n\n1405/7/30-11:51\n\nمانده:294,046,569"
        ),
        UserSmsTemplate(
            name = "بانک مهر · برداشت (−)",
            senderContains = "300102513345478001",
            mustContain = "مانده",
            amountPattern = "{amount}-",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "300102513345478001\n\n7,011,000-\n\n1405/8/8-9:19\n\nمانده:236,974,569"
        )
    )

    private val DEFAULT_SEEDS: List<UserSmsTemplate> = listOf(
        UserSmsTemplate(
            name = "بانک مهر · واریز (+)",
            senderContains = "300102513345478001",
            mustContain = "مانده",
            amountPattern = "{amount}+\n{date}-{time}\nمانده:{balance}",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "300102513345478001\n\n49,500,000+\n\n1405/7/30-11:51\n\nمانده:294,046,569"
        ),
        UserSmsTemplate(
            name = "بانک مهر · برداشت (−)",
            senderContains = "300102513345478001",
            mustContain = "مانده",
            amountPattern = "{amount}-\n{date}-{time}\nمانده:{balance}",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "300102513345478001\n\n7,011,000-\n\n1405/8/8-9:19\n\nمانده:236,974,569"
        ),
        UserSmsTemplate(
            name = "برداشت عمومی",
            mustContain = "برداشت",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "واریز عمومی",
            mustContain = "واریز",
            amountPattern = "مبلغ {amount}",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "بلو · واریز ریالی",
            mustContain = "موجودی",
            amountPattern = "{amount}ریال به حساب شما نشست.\nموجودی: {balance} ریال\n{time}\n{date}",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "واریز پول\n\nپریسا عزیز، 7,000,000ریال به حساب شما نشست.\n\nموجودی: 1,070,650,159 ریال\n\n۹:۱۹\n\n۱۴۰۵.۰۸.۰۸"
        ),
        UserSmsTemplate(
            name = "بلو · برداشت ریالی",
            mustContain = "موجودی",
            amountPattern = "{amount}ریال از حساب شما پرید.\nموجودی: {balance} ریال\n{time}\n{date}",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "برداشت پول\n\nپریسا عزیز، 7,010,000ریال از حساب شما پرید.\n\nموجودی: 1,063,650,159 ریال\n\n۱۵:۴۹\n\n۱۴۰۵.۰۸.۰۷"
        ),
        UserSmsTemplate(
            name = "شهر · کارمزد برداشت ریالی",
            mustContain = "مبلغ:,موجود",
            amountPattern = "مبلغ:{amount}ريال\nموجودي:{balance} ريال\n{date} {time}",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true,
            sampleBody = "کارمزد\n\nبرداشت از:7001025513733\n\nمبلغ:375,000ريال\n\nموجودي:566,617,973 ريال\n\n1405/08/7 08:19:21"
        )
    )
}
