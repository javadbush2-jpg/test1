package com.ourspace.app.core.relay

import android.util.Base64
import android.util.JsonWriter
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.IOException
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.coroutineContext

/**
 * Uploads/restores a full household Room snapshot to the private relay.
 *
 * Storage is **per household mailbox** (access token), not per physical phone.
 * The latest successful upload is what any device in the same household restores.
 *
 * Both upload and download support long transfers, progress callbacks, and
 * automatic retry after network drops (full request is restarted; server keeps
 * one atomic backup blob per mailbox).
 */
class RelayBackupClient(
    endpoint: String,
    private val accessToken: String,
    private val deviceRole: String? = null,
    private val deviceId: String? = RelayDeviceHeaders.currentDeviceId(),
    private val tempDirectory: File? = null
) {
    private val baseUrl = RelayEndpointValidator.normalize(endpoint)

    /**
     * Progress callback:
     * - [phase] human-readable Persian status
     * - [percent] 0..100 overall estimate
     */
    fun interface ProgressListener {
        fun onProgress(phase: String, percent: Int)
    }

    /**
     * Upload a full snapshot. Protects against accidentally overwriting a richer
     * server backup with a thinner local database (e.g. after reinstall).
     */
    suspend fun upload(
        snapshot: JSONObject,
        progress: ProgressListener? = null
    ): Long = withContext(Dispatchers.IO) {
        val updatedAt = System.currentTimeMillis()
        progress?.onProgress("در حال آماده‌سازی داده برای ارسال…", 5)
        val backupSourceId = RelayDeviceHeaders.validDeviceId(deviceId)
        val backupSourceRole = RelayDeviceHeaders.validRole(deviceRole)
        if (backupSourceId != null && backupSourceRole != null) {
            snapshot.put(BACKUP_SOURCE_DEVICE_ID, backupSourceId)
            snapshot.put(BACKUP_SOURCE_ROLE, backupSourceRole)
            annotateBackupMessageRoles(snapshot, backupSourceId, backupSourceRole)
        }
        val newRecords = recordCount(snapshot)
        progress?.onProgress(
            "بررسی پشتیبان فعلی سرور (${newRecords} رکورد محلی)…",
            12
        )

        // Read only compact metadata here. Downloading the previous full snapshot just to
        // compare its size used to allocate another 64+ MiB JSON tree on the phone.
        val existing = try {
            request(
                method = "GET",
                bodyFile = null,
                progress = null,
                mode = TransferMode.DOWNLOAD,
                path = BACKUP_METADATA_PATH
            )
        } catch (_: BackupNotFoundException) {
            null
        } catch (error: UnsupportedBackupMetadataException) {
            throw IOException(
                "برای پشتیبان‌گیری امن، سرور را به نسخه جدید ارتقا بده؛ اطلاعات قبلی تغییر نکرده‌اند.",
                error
            )
        }
        if (existing != null && existing.optBoolean("found", true)) {
            val oldSize = existing.optLong("bytes", 0L)
            val oldRecords = existing.optLong("recordCount", -1L)
            if (oldRecords >= 0 && oldRecords > newRecords) {
                throw IllegalStateException(
                    "پشتیبان سرور از اطلاعات این گوشی کامل‌تر است؛ برای جلوگیری از جایگزینی اطلاعات، ابتدا «بازیابی اطلاعات از سرور» را اجرا کن."
                )
            }
            progress?.onProgress("در حال آماده‌سازی فایل پشتیبان روی حافظه موقت…", 15)
            val currentFile = serializeUploadBody(snapshot, updatedAt)
            try {
                val newSize = currentFile.length()
                if (oldSize > 8 * 1024 && newSize < oldSize * 0.75) {
                    throw IllegalStateException(
                        "پشتیبان سرور از اطلاعات این گوشی کامل‌تر است؛ برای جلوگیری از جایگزینی اطلاعات، ابتدا «بازیابی اطلاعات از سرور» را اجرا کن."
                    )
                }
                return@withContext uploadFile(currentFile, updatedAt, progress)
            } finally {
                currentFile.delete()
            }
        }

        progress?.onProgress("در حال آماده‌سازی فایل پشتیبان روی حافظه موقت…", 15)
        val bodyFile = serializeUploadBody(snapshot, updatedAt)
        try {
            uploadFile(bodyFile, updatedAt, progress)
        } finally {
            bodyFile.delete()
        }
    }

    private suspend fun uploadFile(
        bodyFile: File,
        updatedAt: Long,
        progress: ProgressListener?
    ): Long {
        var attempt = 0
        var lastError: Exception? = null
        while (attempt < MAX_TRANSFER_ATTEMPTS) {
            attempt++
            coroutineContext.ensureActive()
            try {
                if (attempt > 1) {
                    progress?.onProgress(
                        "اتصال قطع شد؛ تلاش مجدد ارسال ($attempt از $MAX_TRANSFER_ATTEMPTS)…",
                        20
                    )
                    delay(retryDelayMs(attempt))
                } else {
                    progress?.onProgress("در حال ارسال پشتیبان کامل به سرور…", 20)
                }
                val response = request(
                    method = "POST",
                    bodyFile = bodyFile,
                    progress = progress,
                    mode = TransferMode.UPLOAD
                )
                require(response.optBoolean("stored")) { "سرور ذخیره پشتیبان را تأیید نکرد." }
                progress?.onProgress("پشتیبان روی سرور ذخیره شد.", 100)
                return updatedAt
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                if (!isRetryableNetworkError(e) || attempt >= MAX_TRANSFER_ATTEMPTS) throw e
            }
        }
        throw lastError ?: IOException("ارسال پشتیبان ناموفق بود.")
    }

    /** Serialize the envelope directly to disk; never materialize the full JSON as String/ByteArray. */
    private fun serializeUploadBody(snapshot: JSONObject, updatedAt: Long): File {
        val file = tempDirectory?.let {
            File.createTempFile("ourspace-backup-", ".json", it)
        } ?: File.createTempFile("ourspace-backup-", ".json")
        try {
            BufferedOutputStream(FileOutputStream(file)).use { output ->
                output.write("{\"updatedAt\":$updatedAt,\"backup\":{\"v\":2,\"snapshot\":".toByteArray(Charsets.UTF_8))
                val limited = LimitedOutputStream(output, MAX_PLAINTEXT_BYTES)
                val writer = JsonWriter(OutputStreamWriter(limited, Charsets.UTF_8))
                // Android JsonWriter serializes null members by default, matching JSONObject output.
                writeJsonValue(snapshot, writer)
                writer.flush()
                output.write("}}".toByteArray(Charsets.UTF_8))
                output.flush()
            }
            require(file.length() <= MAX_REQUEST_BYTES) {
                "پشتیبان از حد مجاز انتقال بزرگ‌تر است."
            }
            return file
        } catch (error: SnapshotTooLargeException) {
            file.delete()
            throw IllegalArgumentException(
                "پشتیبان بزرگ‌تر از حد مجاز است؛ عکس‌های حجیم را جداگانه نگه دار یا نسخه سبک‌تری تهیه کن.",
                error
            )
        } catch (error: Exception) {
            file.delete()
            throw error
        }
    }

    private fun writeJsonValue(value: Any?, writer: JsonWriter) {
        when {
            value == null || value === JSONObject.NULL -> writer.nullValue()
            value is JSONObject -> {
                writer.beginObject()
                val keys = value.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    writer.name(key)
                    writeJsonValue(value.get(key), writer)
                }
                writer.endObject()
            }
            value is JSONArray -> {
                writer.beginArray()
                for (index in 0 until value.length()) writeJsonValue(value.get(index), writer)
                writer.endArray()
            }
            value is String -> writer.value(value)
            value is Boolean -> writer.value(value)
            value is Number -> writer.value(value)
            else -> writer.value(value.toString())
        }
    }

    private class LimitedOutputStream(
        output: OutputStream,
        private val maxBytes: Long
    ) : FilterOutputStream(output) {
        private var bytesWritten = 0L

        override fun write(value: Int) {
            ensureWithinLimit(1)
            out.write(value)
            bytesWritten++
        }

        override fun write(buffer: ByteArray, offset: Int, length: Int) {
            ensureWithinLimit(length)
            out.write(buffer, offset, length)
            bytesWritten += length
        }

        private fun ensureWithinLimit(incoming: Int) {
            if (bytesWritten + incoming > maxBytes) throw SnapshotTooLargeException()
        }
    }

    private class SnapshotTooLargeException : IOException("snapshot_too_large")
    private class BackupNotFoundException : IOException("backup_not_found")
    private class UnsupportedBackupMetadataException : IOException("backup_metadata_unsupported")

    /**
     * Download full household backup with progress + automatic retry on network failure.
     */
    suspend fun download(progress: ProgressListener? = null): Pair<Long, JSONObject> = withContext(Dispatchers.IO) {
        var attempt = 0
        var lastError: Exception? = null
        while (attempt < MAX_TRANSFER_ATTEMPTS) {
            attempt++
            coroutineContext.ensureActive()
            try {
                if (attempt > 1) {
                    progress?.onProgress(
                        "اتصال قطع شد؛ تلاش مجدد ($attempt از $MAX_TRANSFER_ATTEMPTS)…",
                        5
                    )
                    delay(retryDelayMs(attempt))
                } else {
                    progress?.onProgress("در حال اتصال به سرور…", 2)
                }
                val response = request(
                    method = "GET",
                    bodyFile = null,
                    progress = progress,
                    mode = TransferMode.DOWNLOAD
                )
                progress?.onProgress("در حال پردازش فایل پشتیبان…", 88)
                val updatedAt = response.getLong("updatedAt")
                val backup = response.getJSONObject("backup")
                val snapshot = when (backup.optInt("v")) {
                    2 -> backup.getJSONObject("snapshot")
                    1 -> {
                        progress?.onProgress("رمزگشایی پشتیبان قدیمی…", 90)
                        val nonce = Base64.decode(backup.getString("nonce"), Base64.URL_SAFE or Base64.NO_WRAP)
                        val encrypted = Base64.decode(backup.getString("ciphertext"), Base64.URL_SAFE or Base64.NO_WRAP)
                        require(nonce.size == 12 && encrypted.size <= MAX_CIPHERTEXT_BYTES) { "فایل پشتیبان نامعتبر است." }
                        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, nonce))
                        val plain = cipher.doFinal(encrypted)
                        require(plain.size <= MAX_PLAINTEXT_BYTES) { "فایل پشتیبان بزرگ‌تر از حد مجاز است." }
                        JSONObject(String(plain, Charsets.UTF_8))
                    }
                    else -> throw IllegalStateException("نسخه پشتیبان پشتیبانی نمی‌شود.")
                }
                // Older snapshots did not embed the source identity. The relay supplies it
                // from the matching backup_upload audit event when that record is available.
                if (!snapshot.has(BACKUP_SOURCE_DEVICE_ID)) {
                    RelayDeviceHeaders.validDeviceId(response.optString("sourceDeviceId"))?.let {
                        snapshot.put(BACKUP_SOURCE_DEVICE_ID, it)
                    }
                }
                if (!snapshot.has(BACKUP_SOURCE_ROLE)) {
                    RelayDeviceHeaders.validRole(response.optString("sourceRole"))?.let {
                        snapshot.put(BACKUP_SOURCE_ROLE, it)
                    }
                }
                progress?.onProgress("دانلود کامل شد؛ آمادهٔ ادغام…", 92)
                return@withContext updatedAt to snapshot
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                if (!isRetryableNetworkError(e) || attempt >= MAX_TRANSFER_ATTEMPTS) throw e
            }
        }
        throw lastError ?: IOException("بازیابی پشتیبان ناموفق بود.")
    }

    /**
     * Map message authorship onto this phone's current ID. New backups carry a role per
     * message, so either household role can restore safely after reinstall. For older
     * snapshots, use the relay-recorded source ID and only infer the opposite ID when
     * the snapshot unambiguously contains exactly two senders.
     */
    fun senderDeviceIdRemapFor(snapshot: JSONObject): Map<String, String> {
        val targetRole = RelayDeviceHeaders.validRole(deviceRole) ?: return emptyMap()
        val targetId = RelayDeviceHeaders.validDeviceId(deviceId) ?: return emptyMap()
        val messages = snapshot.optJSONArray("messages") ?: return emptyMap()
        val sourceId = RelayDeviceHeaders.validDeviceId(snapshot.optString(BACKUP_SOURCE_DEVICE_ID))
        val sourceRole = RelayDeviceHeaders.validRole(snapshot.optString(BACKUP_SOURCE_ROLE))
        val roleTaggedIds = linkedSetOf<String>()
        var hasRoleTags = false
        val allSenderIds = linkedSetOf<String>()
        for (index in 0 until messages.length()) {
            val message = messages.optJSONObject(index) ?: continue
            val senderId = RelayDeviceHeaders.validDeviceId(message.optString("senderDeviceId"))
            if (senderId != null) allSenderIds += senderId
            val senderRole = RelayDeviceHeaders.validRole(message.optString("senderRole"))
            if (senderRole != null) {
                hasRoleTags = true
                if (senderRole == targetRole && senderId != null) roleTaggedIds += senderId
            }
            val reactionId = RelayDeviceHeaders.validDeviceId(message.optString("reactionByDeviceId"))
            val reactionRole = RelayDeviceHeaders.validRole(message.optString("reactionByDeviceRole"))
            if (reactionRole != null) {
                hasRoleTags = true
                if (reactionRole == targetRole && reactionId != null) roleTaggedIds += reactionId
            }
            val reaction2Id = RelayDeviceHeaders.validDeviceId(message.optString("reaction2ByDeviceId"))
            val reaction2Role = RelayDeviceHeaders.validRole(message.optString("reaction2ByDeviceRole"))
            if (reaction2Role != null) {
                hasRoleTags = true
                if (reaction2Role == targetRole && reaction2Id != null) roleTaggedIds += reaction2Id
            }
        }

        val idsToMap = if (hasRoleTags) {
            roleTaggedIds
        } else {
            if (sourceId == null || sourceRole == null) return emptyMap()
            if (targetRole == sourceRole) {
                setOf(sourceId)
            } else {
                val oppositeIds = allSenderIds.filter { it != sourceId }
                if (sourceId in allSenderIds && oppositeIds.size == 1) oppositeIds.toSet()
                else emptySet()
            }
        }
        return idsToMap.asSequence()
            .filter { it != targetId }
            .associateWith { targetId }
    }

    private fun annotateBackupMessageRoles(snapshot: JSONObject, sourceId: String, sourceRole: String) {
        val otherRole = if (sourceRole == "host") "companion" else "host"
        val messages = snapshot.optJSONArray("messages") ?: return
        for (index in 0 until messages.length()) {
            val message = messages.optJSONObject(index) ?: continue
            RelayDeviceHeaders.validDeviceId(message.optString("senderDeviceId"))?.let { id ->
                message.put("senderRole", if (id == sourceId) sourceRole else otherRole)
            }
            RelayDeviceHeaders.validDeviceId(message.optString("reactionByDeviceId"))?.let { id ->
                message.put("reactionByDeviceRole", if (id == sourceId) sourceRole else otherRole)
            }
            RelayDeviceHeaders.validDeviceId(message.optString("reaction2ByDeviceId"))?.let { id ->
                message.put("reaction2ByDeviceRole", if (id == sourceId) sourceRole else otherRole)
            }
        }
    }

    /** Count logical records across all known snapshot arrays (for safety compare). */
    private fun recordCount(snapshot: JSONObject): Long {
        var count = 0L
        ALL_SNAPSHOT_ARRAY_KEYS.forEach { key ->
            count += snapshot.optJSONArray(key)?.length() ?: 0
        }
        // Single-object sections
        if (snapshot.has("cycleSettings") && snapshot.optJSONArray("cycleSettings") == null) {
            count += 1
        }
        if (snapshot.has("workScheduleSettings")) count += 1
        return count
    }

    private fun key(): SecretKeySpec {
        require(accessToken.isNotBlank()) { "کلید مشترک خانه تنظیم نشده است." }
        val material = "ourspace-household-backup-v1:$accessToken".toByteArray(Charsets.UTF_8)
        return SecretKeySpec(MessageDigest.getInstance("SHA-256").digest(material), "AES")
    }

    private enum class TransferMode { UPLOAD, DOWNLOAD }

    private fun request(
        method: String,
        bodyFile: File?,
        progress: ProgressListener?,
        mode: TransferMode,
        path: String = BACKUP_PATH
    ): JSONObject {
        val connection = URL("$baseUrl$path").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            // Long transfers: generous connect, no short read timeout
            connection.connectTimeout = 60_000
            connection.readTimeout = 0
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            RelayDeviceHeaders.apply(connection, deviceId, deviceRole)
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Connection", "close")
            if (bodyFile != null) {
                val total = bodyFile.length()
                require(total <= MAX_REQUEST_BYTES) { "پشتیبان از حد مجاز انتقال بزرگ‌تر است." }
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.setFixedLengthStreamingMode(total)
                bodyFile.inputStream().buffered().use { input ->
                    connection.outputStream.use { out ->
                        val buffer = ByteArray(64 * 1024)
                        var offset = 0L
                        var lastPct = -1
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            out.write(buffer, 0, count)
                            offset += count
                            if (progress != null && mode == TransferMode.UPLOAD) {
                                val fraction = offset.toDouble() / total.toDouble()
                                // Map upload body to 20%..90%
                                val pct = (20 + (fraction * 70).toInt()).coerceIn(20, 90)
                                if (pct != lastPct) {
                                    lastPct = pct
                                    val mb = offset / (1024.0 * 1024.0)
                                    val totalMb = total / (1024.0 * 1024.0)
                                    progress.onProgress(
                                        "در حال ارسال پشتیبان… ${"%.1f".format(mb)} / ${"%.1f".format(totalMb)} مگابایت",
                                        pct
                                    )
                                }
                            }
                        }
                        out.flush()
                    }
                }
            }
            val code = connection.responseCode
            val contentLength = connection.contentLengthLong.coerceAtLeast(-1L)
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val bytes = stream?.use { input ->
                val output = ByteArrayOutputStream(
                    if (contentLength > 0 && contentLength < Int.MAX_VALUE) contentLength.toInt() else 256 * 1024
                )
                val buffer = ByteArray(64 * 1024)
                var total = 0L
                var lastReportedPct = -1
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_RESPONSE_BYTES) throw IOException("پاسخ پشتیبان بیش از حد بزرگ است.")
                    output.write(buffer, 0, count)
                    if (progress != null && mode == TransferMode.DOWNLOAD) {
                        val pct = if (contentLength > 0) {
                            val fraction = (total.toDouble() / contentLength.toDouble()).coerceIn(0.0, 1.0)
                            (5 + (fraction * 80).toInt()).coerceIn(5, 85)
                        } else {
                            (5 + (total / (256 * 1024)).toInt()).coerceAtMost(70)
                        }
                        if (pct != lastReportedPct) {
                            lastReportedPct = pct
                            val mb = total / (1024.0 * 1024.0)
                            val phase = if (contentLength > 0) {
                                val totalMb = contentLength / (1024.0 * 1024.0)
                                "در حال دریافت اطلاعات از سرور… ${"%.1f".format(mb)} / ${"%.1f".format(totalMb)} مگابایت"
                            } else {
                                "در حال دریافت اطلاعات از سرور… ${"%.1f".format(mb)} مگابایت"
                            }
                            progress.onProgress(phase, pct)
                        }
                    }
                }
                output.toByteArray()
            } ?: ByteArray(0)
            val text = String(bytes, Charsets.UTF_8)
            if (code !in 200..299) {
                val message = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
                if (code == 404 && path == BACKUP_METADATA_PATH) {
                    if (message == "backup_not_found") throw BackupNotFoundException()
                    throw UnsupportedBackupMetadataException()
                }
                if (code == 404) throw IOException("هنوز هیچ پشتیبانی روی سرور وجود ندارد.")
                throw IOException("خطای سرور هنگام پشتیبان‌گیری ($code): ${message.ifBlank { text.take(180) }}")
            }
            if (progress != null && mode == TransferMode.UPLOAD) {
                progress.onProgress("در حال تأیید ذخیره روی سرور…", 95)
            }
            return JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val BACKUP_PATH = "/v1/backup"
        private const val BACKUP_METADATA_PATH = "/v1/backup/metadata"
        private const val BACKUP_SOURCE_DEVICE_ID = "backupSourceDeviceId"
        private const val BACKUP_SOURCE_ROLE = "backupSourceRole"
        private const val MAX_PLAINTEXT_BYTES = 64L * 1024 * 1024
        private const val MAX_CIPHERTEXT_BYTES = 65 * 1024 * 1024
        private const val MAX_REQUEST_BYTES = 92 * 1024 * 1024
        private const val MAX_RESPONSE_BYTES = 92 * 1024 * 1024
        private const val MAX_TRANSFER_ATTEMPTS = 12

        /** All array keys produced by SyncSnapshotCodec.exportSnapshot (schema 6). */
        private val ALL_SNAPSHOT_ARRAY_KEYS = arrayOf(
            "tasks", "events", "shopping", "messages",
            "financialAccounts", "financeTransactions", "financeBudgets",
            "sharedDebts", "recurringTransactions",
            "memories", "moodCheckIns", "specialDates",
            "cycleLogs", "cycleSettings", "locationShares", "heartPulses",
            "sharedPlaces", "habits", "watchlistItems", "foodItems", "bookItems",
            "coupleProfile", "telegramStickerPacks", "telegramStickers",
            "attachments"
        )

        private fun retryDelayMs(attempt: Int): Long {
            val base = 2_000L * (1L shl (attempt - 2).coerceAtLeast(0))
            return base.coerceAtMost(30_000L)
        }

        private fun isRetryableNetworkError(error: Exception): Boolean {
            var e: Throwable? = error
            while (e != null) {
                when (e) {
                    is SocketTimeoutException,
                    is SocketException,
                    is UnknownHostException,
                    is java.io.InterruptedIOException -> return true
                    is IOException -> {
                        val msg = e.message?.lowercase().orEmpty()
                        if (msg.contains("timeout") ||
                            msg.contains("connection reset") ||
                            msg.contains("connection refused") ||
                            msg.contains("network is unreachable") ||
                            msg.contains("software caused connection abort") ||
                            msg.contains("broken pipe") ||
                            msg.contains("failed to connect") ||
                            msg.contains("unable to resolve")
                        ) return true
                    }
                }
                e = e.cause
            }
            return false
        }
    }
}
