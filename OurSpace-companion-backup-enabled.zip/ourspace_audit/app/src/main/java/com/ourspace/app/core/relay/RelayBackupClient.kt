package com.ourspace.app.core.relay

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.coroutines.coroutineContext

/**
 * Uploads/restores a full household Room snapshot to the private relay.
 *
 * Storage is **per household mailbox** (access token), not per physical phone.
 * The latest successful upload is what any device in the same household restores.
 *
 * Both upload and download support long transfers, progress callbacks, and
 * automatic retry after network drops (full request is restarted; server keeps
 * one atomic backup blob per mailbox).
 */
class RelayBackupClient(
    endpoint: String,
    private val accessToken: String,
    private val deviceRole: String? = null,
    private val deviceId: String? = RelayDeviceHeaders.currentDeviceId()
) {
    private val baseUrl = RelayEndpointValidator.normalize(endpoint)

    /**
     * Progress callback:
     * - [phase] human-readable Persian status
     * - [percent] 0..100 overall estimate
     */
    fun interface ProgressListener {
        fun onProgress(phase: String, percent: Int)
    }

    /**
     * Upload a full snapshot. Protects against accidentally overwriting a richer
     * server backup with a thinner local database (e.g. after reinstall).
     */
    suspend fun upload(
        snapshot: JSONObject,
        progress: ProgressListener? = null
    ): Long = withContext(Dispatchers.IO) {
        val updatedAt = System.currentTimeMillis()
        progress?.onProgress("در حال آماده‌سازی داده برای ارسال…", 5)
        val plain = snapshot.toString().toByteArray(Charsets.UTF_8)
        require(plain.size <= MAX_PLAINTEXT_BYTES) {
            "پشتیبان بزرگ‌تر از حد مجاز است؛ عکس‌های حجیم را جداگانه نگه دار یا نسخه سبک‌تری تهیه کن."
        }
        val newRecords = recordCount(snapshot)
        progress?.onProgress(
            "بررسی پشتیبان فعلی سرور (${newRecords} رکورد محلی)…",
            12
        )
        // Never replace a larger existing backup with a suspiciously small/empty local DB.
        // This protects a valid server backup if a host was reinstalled before restoration.
        val existing = runCatching { download(null) }.getOrNull()
        if (existing != null) {
            val oldSize = existing.second.toString().toByteArray(Charsets.UTF_8).size
            val oldRecords = recordCount(existing.second)
            if (oldRecords > newRecords || (oldSize > 8 * 1024 && plain.size < (oldSize * 0.75).toInt())) {
                throw IllegalStateException(
                    "پشتیبان سرور از اطلاعات این گوشی کامل‌تر است؛ برای جلوگیری از جایگزینی اطلاعات، ابتدا «بازیابی اطلاعات از سرور» را اجرا کن."
                )
            }
        }

        val backup = JSONObject()
            .put("v", 2)
            .put("snapshot", snapshot)
        val body = JSONObject().put("updatedAt", updatedAt).put("backup", backup).toString()
        val bodyBytes = body.toByteArray(Charsets.UTF_8)

        var attempt = 0
        var lastError: Exception? = null
        while (attempt < MAX_TRANSFER_ATTEMPTS) {
            attempt++
            coroutineContext.ensureActive()
            try {
                if (attempt > 1) {
                    progress?.onProgress(
                        "اتصال قطع شد؛ تلاش مجدد ارسال ($attempt از $MAX_TRANSFER_ATTEMPTS)…",
                        20
                    )
                    delay(retryDelayMs(attempt))
                } else {
                    progress?.onProgress("در حال ارسال پشتیبان کامل به سرور…", 20)
                }
                val response = request(
                    method = "POST",
                    bodyBytes = bodyBytes,
                    progress = progress,
                    mode = TransferMode.UPLOAD
                )
                require(response.optBoolean("stored")) { "سرور ذخیره پشتیبان را تأیید نکرد." }
                progress?.onProgress("پشتیبان روی سرور ذخیره شد.", 100)
                return@withContext updatedAt
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                if (!isRetryableNetworkError(e) || attempt >= MAX_TRANSFER_ATTEMPTS) throw e
            }
        }
        throw lastError ?: IOException("ارسال پشتیبان ناموفق بود.")
    }

    /**
     * Download full household backup with progress + automatic retry on network failure.
     */
    suspend fun download(progress: ProgressListener? = null): Pair<Long, JSONObject> = withContext(Dispatchers.IO) {
        var attempt = 0
        var lastError: Exception? = null
        while (attempt < MAX_TRANSFER_ATTEMPTS) {
            attempt++
            coroutineContext.ensureActive()
            try {
                if (attempt > 1) {
                    progress?.onProgress(
                        "اتصال قطع شد؛ تلاش مجدد ($attempt از $MAX_TRANSFER_ATTEMPTS)…",
                        5
                    )
                    delay(retryDelayMs(attempt))
                } else {
                    progress?.onProgress("در حال اتصال به سرور…", 2)
                }
                val response = request(
                    method = "GET",
                    bodyBytes = null,
                    progress = progress,
                    mode = TransferMode.DOWNLOAD
                )
                progress?.onProgress("در حال پردازش فایل پشتیبان…", 88)
                val updatedAt = response.getLong("updatedAt")
                val backup = response.getJSONObject("backup")
                val snapshot = when (backup.optInt("v")) {
                    2 -> backup.getJSONObject("snapshot")
                    1 -> {
                        progress?.onProgress("رمزگشایی پشتیبان قدیمی…", 90)
                        val nonce = Base64.decode(backup.getString("nonce"), Base64.URL_SAFE or Base64.NO_WRAP)
                        val encrypted = Base64.decode(backup.getString("ciphertext"), Base64.URL_SAFE or Base64.NO_WRAP)
                        require(nonce.size == 12 && encrypted.size <= MAX_CIPHERTEXT_BYTES) { "فایل پشتیبان نامعتبر است." }
                        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, nonce))
                        val plain = cipher.doFinal(encrypted)
                        require(plain.size <= MAX_PLAINTEXT_BYTES) { "فایل پشتیبان بزرگ‌تر از حد مجاز است." }
                        JSONObject(String(plain, Charsets.UTF_8))
                    }
                    else -> throw IllegalStateException("نسخه پشتیبان پشتیبانی نمی‌شود.")
                }
                progress?.onProgress("دانلود کامل شد؛ آمادهٔ ادغام…", 92)
                return@withContext updatedAt to snapshot
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                if (!isRetryableNetworkError(e) || attempt >= MAX_TRANSFER_ATTEMPTS) throw e
            }
        }
        throw lastError ?: IOException("بازیابی پشتیبان ناموفق بود.")
    }

    /** Count logical records across all known snapshot arrays (for safety compare). */
    private fun recordCount(snapshot: JSONObject): Long {
        var count = 0L
        ALL_SNAPSHOT_ARRAY_KEYS.forEach { key ->
            count += snapshot.optJSONArray(key)?.length() ?: 0
        }
        // Single-object sections
        if (snapshot.has("cycleSettings") && snapshot.optJSONArray("cycleSettings") == null) {
            count += 1
        }
        if (snapshot.has("workScheduleSettings")) count += 1
        return count
    }

    private fun key(): SecretKeySpec {
        require(accessToken.isNotBlank()) { "کلید مشترک خانه تنظیم نشده است." }
        val material = "ourspace-household-backup-v1:$accessToken".toByteArray(Charsets.UTF_8)
        return SecretKeySpec(MessageDigest.getInstance("SHA-256").digest(material), "AES")
    }

    private enum class TransferMode { UPLOAD, DOWNLOAD }

    private fun request(
        method: String,
        bodyBytes: ByteArray?,
        progress: ProgressListener?,
        mode: TransferMode
    ): JSONObject {
        val connection = URL("$baseUrl/v1/backup").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            // Long transfers: generous connect, no short read timeout
            connection.connectTimeout = 60_000
            connection.readTimeout = 0
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            RelayDeviceHeaders.apply(connection, deviceId, deviceRole)
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Connection", "close")
            if (bodyBytes != null) {
                require(bodyBytes.size <= MAX_REQUEST_BYTES) { "پشتیبان از حد مجاز انتقال بزرگ‌تر است." }
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.setFixedLengthStreamingMode(bodyBytes.size)
                connection.outputStream.use { out ->
                    var offset = 0
                    var lastPct = -1
                    val total = bodyBytes.size
                    while (offset < total) {
                        val chunk = minOf(64 * 1024, total - offset)
                        out.write(bodyBytes, offset, chunk)
                        offset += chunk
                        if (progress != null && mode == TransferMode.UPLOAD) {
                            val fraction = offset.toDouble() / total.toDouble()
                            // Map upload body to 20%..90%
                            val pct = (20 + (fraction * 70).toInt()).coerceIn(20, 90)
                            if (pct != lastPct) {
                                lastPct = pct
                                val mb = offset / (1024.0 * 1024.0)
                                val totalMb = total / (1024.0 * 1024.0)
                                progress.onProgress(
                                    "در حال ارسال پشتیبان… ${"%.1f".format(mb)} / ${"%.1f".format(totalMb)} مگابایت",
                                    pct
                                )
                            }
                        }
                    }
                    out.flush()
                }
            }
            val code = connection.responseCode
            val contentLength = connection.contentLengthLong.coerceAtLeast(-1L)
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val bytes = stream?.use { input ->
                val output = ByteArrayOutputStream(
                    if (contentLength > 0 && contentLength < Int.MAX_VALUE) contentLength.toInt() else 256 * 1024
                )
                val buffer = ByteArray(64 * 1024)
                var total = 0L
                var lastReportedPct = -1
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_RESPONSE_BYTES) throw IOException("پاسخ پشتیبان بیش از حد بزرگ است.")
                    output.write(buffer, 0, count)
                    if (progress != null && mode == TransferMode.DOWNLOAD) {
                        val pct = if (contentLength > 0) {
                            val fraction = (total.toDouble() / contentLength.toDouble()).coerceIn(0.0, 1.0)
                            (5 + (fraction * 80).toInt()).coerceIn(5, 85)
                        } else {
                            (5 + (total / (256 * 1024)).toInt()).coerceAtMost(70)
                        }
                        if (pct != lastReportedPct) {
                            lastReportedPct = pct
                            val mb = total / (1024.0 * 1024.0)
                            val phase = if (contentLength > 0) {
                                val totalMb = contentLength / (1024.0 * 1024.0)
                                "در حال دریافت اطلاعات از سرور… ${"%.1f".format(mb)} / ${"%.1f".format(totalMb)} مگابایت"
                            } else {
                                "در حال دریافت اطلاعات از سرور… ${"%.1f".format(mb)} مگابایت"
                            }
                            progress.onProgress(phase, pct)
                        }
                    }
                }
                output.toByteArray()
            } ?: ByteArray(0)
            val text = String(bytes, Charsets.UTF_8)
            if (code !in 200..299) {
                val message = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
                if (code == 404) throw IOException("هنوز هیچ پشتیبانی روی سرور وجود ندارد.")
                throw IOException("خطای سرور هنگام پشتیبان‌گیری ($code): ${message.ifBlank { text.take(180) }}")
            }
            if (progress != null && mode == TransferMode.UPLOAD) {
                progress.onProgress("در حال تأیید ذخیره روی سرور…", 95)
            }
            return JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val MAX_PLAINTEXT_BYTES = 64 * 1024 * 1024
        private const val MAX_CIPHERTEXT_BYTES = 65 * 1024 * 1024
        private const val MAX_REQUEST_BYTES = 92 * 1024 * 1024
        private const val MAX_RESPONSE_BYTES = 92 * 1024 * 1024
        private const val MAX_TRANSFER_ATTEMPTS = 12

        /** All array keys produced by SyncSnapshotCodec.exportSnapshot (schema 6). */
        private val ALL_SNAPSHOT_ARRAY_KEYS = arrayOf(
            "tasks", "events", "shopping", "messages",
            "financialAccounts", "financeTransactions", "financeBudgets",
            "sharedDebts", "recurringTransactions",
            "memories", "moodCheckIns", "specialDates",
            "cycleLogs", "cycleSettings", "locationShares", "heartPulses",
            "sharedPlaces", "habits", "watchlistItems", "foodItems", "bookItems",
            "coupleProfile", "telegramStickerPacks", "telegramStickers",
            "attachments"
        )

        private fun retryDelayMs(attempt: Int): Long {
            val base = 2_000L * (1L shl (attempt - 2).coerceAtLeast(0))
            return base.coerceAtMost(30_000L)
        }

        private fun isRetryableNetworkError(error: Exception): Boolean {
            var e: Throwable? = error
            while (e != null) {
                when (e) {
                    is SocketTimeoutException,
                    is SocketException,
                    is UnknownHostException,
                    is java.io.InterruptedIOException -> return true
                    is IOException -> {
                        val msg = e.message?.lowercase().orEmpty()
                        if (msg.contains("timeout") ||
                            msg.contains("connection reset") ||
                            msg.contains("connection refused") ||
                            msg.contains("network is unreachable") ||
                            msg.contains("software caused connection abort") ||
                            msg.contains("broken pipe") ||
                            msg.contains("failed to connect") ||
                            msg.contains("unable to resolve")
                        ) return true
                    }
                }
                e = e.cause
            }
            return false
        }
    }
}
