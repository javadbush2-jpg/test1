package com.ourspace.app.data

import androidx.room.withTransaction
import com.ourspace.app.core.attachment.AttachmentIntegrity
import com.ourspace.app.core.database.AttachmentDao
import com.ourspace.app.core.database.TelegramStickerDao
import com.ourspace.app.core.database.TelegramStickerEntity
import com.ourspace.app.core.database.TelegramStickerPackDao
import com.ourspace.app.core.database.TelegramStickerPackEntity
import com.ourspace.app.core.telegram.TelegramStickerClient
import com.ourspace.app.core.database.AttachmentEntity
import com.ourspace.app.core.database.CoupleProfileDao
import com.ourspace.app.core.database.CoupleProfileEntity
import com.ourspace.app.core.database.CycleLogDao
import com.ourspace.app.core.database.HeartPulseDao
import com.ourspace.app.core.database.SharedPlaceDao
import com.ourspace.app.core.database.HabitDao
import com.ourspace.app.core.database.WatchlistDao
import com.ourspace.app.core.database.BookDao
import com.ourspace.app.core.database.FoodDao
import com.ourspace.app.core.database.FoodItemEntity
import com.ourspace.app.core.database.IranianFoodsDefaults
import com.ourspace.app.core.database.BookItemEntity
import com.ourspace.app.core.database.SharedPlaceEntity
import com.ourspace.app.core.database.HabitEntity
import com.ourspace.app.core.database.WatchlistItemEntity
import com.ourspace.app.core.database.HeartPulseEntity
import com.ourspace.app.core.database.LocationShareDao
import com.ourspace.app.core.database.LocationShareEntity
import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.CycleSettingsDao
import com.ourspace.app.core.database.CycleSettingsEntity
import com.ourspace.app.core.database.EventDao
import com.ourspace.app.core.database.EventEntity
import com.ourspace.app.core.database.FinanceBudgetDao
import com.ourspace.app.core.database.FinanceBudgetEntity
import com.ourspace.app.core.database.RecurringTransactionDao
import com.ourspace.app.core.database.RecurringTransactionEntity
import com.ourspace.app.core.database.SharedDebtDao
import com.ourspace.app.core.database.SharedDebtEntity
import com.ourspace.app.core.database.FinanceTransactionDao
import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.finance.FinanceBalanceReconciler
import com.ourspace.app.core.finance.FinanceBalanceReconciliation
import com.ourspace.app.core.finance.SmsFinanceImport
import com.ourspace.app.core.database.FinancialAccountDao
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.database.MemoryDao
import com.ourspace.app.core.database.MemoryEntity
import com.ourspace.app.core.database.MessageDao
import com.ourspace.app.core.database.MessageEntity
import com.ourspace.app.core.database.MoodCheckInDao
import com.ourspace.app.core.database.MoodCheckInEntity
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.database.ShoppingDao
import com.ourspace.app.core.database.ShoppingItemEntity
import com.ourspace.app.core.database.SpecialDateDao
import com.ourspace.app.core.database.SpecialDateEntity
import com.ourspace.app.core.database.TaskDao
import com.ourspace.app.core.database.TaskEntity
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.core.sync.GameMessageProtocol
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private const val CHAT_PAGE_SIZE = 200

class OurSpaceRepository(
    private val database: OurSpaceDatabase,
    private val taskDao: TaskDao,
    private val eventDao: EventDao,
    private val shoppingDao: ShoppingDao,
    private val messageDao: MessageDao,
    private val financialAccountDao: FinancialAccountDao,
    private val financeTransactionDao: FinanceTransactionDao,
    private val financeBudgetDao: FinanceBudgetDao,
    private val sharedDebtDao: SharedDebtDao,
    private val recurringTransactionDao: RecurringTransactionDao,
    private val memoryDao: MemoryDao,
    private val moodCheckInDao: MoodCheckInDao,
    private val specialDateDao: SpecialDateDao,
    private val coupleProfileDao: CoupleProfileDao,
    private val cycleLogDao: CycleLogDao,
    private val cycleSettingsDao: CycleSettingsDao,
    private val locationShareDao: LocationShareDao,
    private val heartPulseDao: HeartPulseDao,
    private val sharedPlaceDao: SharedPlaceDao,
    private val habitDao: HabitDao,
    private val watchlistDao: WatchlistDao,
    private val bookDao: BookDao,
    private val foodDao: FoodDao,
    private val attachmentDao: AttachmentDao,
    private val telegramStickerPackDao: TelegramStickerPackDao,
    private val telegramStickerDao: TelegramStickerDao
) {
    val telegramStickerPacks: Flow<List<TelegramStickerPackEntity>> = telegramStickerPackDao.observeAll()

    val tasks: Flow<List<TaskEntity>> = taskDao.observeAll()
    val events: Flow<List<EventEntity>> = eventDao.observeAll()
    val shoppingItems: Flow<List<ShoppingItemEntity>> = shoppingDao.observeAll()
    val latestMessages: Flow<List<MessageEntity>> =
        messageDao.observeLatest(CHAT_PAGE_SIZE).map { it.asReversed() }
    val latestPinnedMessage: Flow<MessageEntity?> = messageDao.observeLatestPinned()
    val gameMessages: Flow<List<MessageEntity>> =
        messageDao.observeGameMessages(GameMessageProtocol.SQLITE_CHAT_EXCLUSION_PATTERN)

    suspend fun loadOlderMessages(before: MessageEntity, limit: Int = CHAT_PAGE_SIZE): List<MessageEntity> =
        messageDao.loadOlder(before.createdAt, before.id, limit).asReversed()

    suspend fun searchMessages(query: String): List<MessageEntity> {
        val clean = query.trim().take(120)
        if (clean.isBlank()) return emptyList()
        return messageDao.searchActiveMessages(clean).asReversed()
    }

    suspend fun findMessage(messageId: String): MessageEntity? = messageDao.findChatById(messageId)

    val financialAccounts: Flow<List<FinancialAccountEntity>> = financialAccountDao.observeAll()
    val financeTransactions: Flow<List<FinanceTransactionEntity>> = financeTransactionDao.observeAll()
    val financeBudgets: Flow<List<FinanceBudgetEntity>> = financeBudgetDao.observeAll()
    val sharedDebts: Flow<List<SharedDebtEntity>> = sharedDebtDao.observeAll()
    val recurringTransactions: Flow<List<RecurringTransactionEntity>> = recurringTransactionDao.observeAll()
    val memories: Flow<List<MemoryEntity>> = memoryDao.observeAll()
    val moodCheckIns: Flow<List<MoodCheckInEntity>> = moodCheckInDao.observeAll()
    val specialDates: Flow<List<SpecialDateEntity>> = specialDateDao.observeAll()
    val coupleProfile: Flow<CoupleProfileEntity?> = coupleProfileDao.observe()
    val cycleLogs: Flow<List<CycleLogEntity>> = cycleLogDao.observeAll()
    val cycleSettings: Flow<CycleSettingsEntity?> = cycleSettingsDao.observe()
    val locationShares: Flow<List<LocationShareEntity>> = locationShareDao.observeAll()
    val heartPulses: Flow<List<HeartPulseEntity>> = heartPulseDao.observeAll()
    val sharedPlaces: Flow<List<SharedPlaceEntity>> = sharedPlaceDao.observeAll()
    val habits: Flow<List<HabitEntity>> = habitDao.observeAll()
    val watchlistItems: Flow<List<WatchlistItemEntity>> = watchlistDao.observeAll()
    val bookItems: Flow<List<BookItemEntity>> = bookDao.observeAll()
    val foodItems: Flow<List<FoodItemEntity>> = foodDao.observeAll()
    val attachments: Flow<List<AttachmentEntity>> = attachmentDao.observeAll()

    suspend fun findAttachment(id: String): AttachmentEntity? = attachmentDao.findById(id)

    fun unreadMessages(ownDeviceId: String): Flow<Int> = messageDao.observeUnreadCount(ownDeviceId)

    suspend fun addTask(title: String, priority: Int, assignee: String, dueAt: Long? = null, durationMinutes: Int = 60) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        taskDao.upsert(
            TaskEntity(
                id = UUID.randomUUID().toString(),
                title = clean,
                assignee = assignee,
                dueAt = dueAt,
                durationMinutes = durationMinutes.coerceIn(15, 720),
                priority = priority.coerceIn(0, 2),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateTaskSchedule(task: TaskEntity, startAt: Long, durationMinutes: Int) {
        taskDao.update(task.copy(dueAt = startAt, durationMinutes = durationMinutes.coerceIn(15, 720), updatedAt = System.currentTimeMillis()))
    }

    suspend fun updateTask(
        task: TaskEntity,
        title: String,
        priority: Int,
        assignee: String,
        dueAt: Long?,
        durationMinutes: Int
    ) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        taskDao.update(
            task.copy(
                title = clean,
                priority = priority.coerceIn(0, 2),
                assignee = assignee,
                dueAt = dueAt,
                durationMinutes = durationMinutes.coerceIn(15, 720),
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearCheckedShopping() {
        val now = System.currentTimeMillis()
        shoppingDao.getAllOnce()
            .filter { !it.isDeleted && it.isChecked }
            .forEach { item ->
                if (item.isRecurring) {
                    // Recurring items stay on the list; just uncheck for the next cycle.
                    shoppingDao.update(item.copy(isChecked = false, updatedAt = now))
                } else {
                    shoppingDao.update(item.copy(isDeleted = true, updatedAt = now))
                }
            }
    }

    suspend fun toggleTask(task: TaskEntity) {
        taskDao.update(task.copy(isCompleted = !task.isCompleted, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteTask(task: TaskEntity) {
        taskDao.update(task.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun addShoppingItem(title: String, quantity: String, category: String, isRecurring: Boolean = false) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        shoppingDao.upsert(
            ShoppingItemEntity(
                id = UUID.randomUUID().toString(),
                title = clean,
                quantity = quantity.trim().ifEmpty { "۱ عدد" },
                category = category,
                isRecurring = isRecurring,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun toggleShoppingItem(item: ShoppingItemEntity) {
        shoppingDao.update(item.copy(isChecked = !item.isChecked, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteShoppingItem(item: ShoppingItemEntity) {
        shoppingDao.update(item.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun addEvent(title: String, startAt: Long, durationMinutes: Int = 60) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        eventDao.upsert(
            EventEntity(
                id = UUID.randomUUID().toString(),
                title = clean,
                startAt = startAt,
                endAt = startAt + durationMinutes.coerceIn(15, 720) * 60_000L,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun addWorkScheduleEvents(events: List<EventEntity>) {
        if (events.isEmpty()) return
        events.forEach { event ->
            val clean = event.title.trim()
            if (clean.isNotEmpty() && event.details.startsWith("OS_WORK|")) {
                eventDao.upsert(event.copy(title = clean, endAt = (event.endAt ?: (event.startAt + 60L * 60_000L)).coerceAtLeast(event.startAt + 15L * 60_000L)))
            }
        }
    }

    suspend fun updateEvent(event: EventEntity, title: String, startAt: Long) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val duration = ((event.endAt ?: (event.startAt + 60L * 60_000L)) - event.startAt).coerceIn(15L * 60_000L, 12L * 60L * 60_000L)
        eventDao.update(event.copy(title = clean, startAt = startAt, endAt = startAt + duration, updatedAt = System.currentTimeMillis()))
    }

    suspend fun updateEventSchedule(event: EventEntity, startAt: Long, endAt: Long) {
        val safeEnd = endAt.coerceAtLeast(startAt + 15L * 60_000L)
        eventDao.update(event.copy(startAt = startAt, endAt = safeEnd, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteEvent(event: EventEntity) {
        eventDao.update(event.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun sendMessage(senderDeviceId: String, text: String, replyToId: String?): String? {
        val clean = text.trim().take(5_000)
        if (clean.isEmpty()) return null
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        messageDao.upsert(
            MessageEntity(
                id = id,
                senderDeviceId = senderDeviceId,
                text = clean,
                replyToId = replyToId,
                createdAt = now,
                updatedAt = now
            )
        )
        return id
    }

    suspend fun stampIncomingDelivered(ownDeviceId: String): Int {
        val now = System.currentTimeMillis()
        return messageDao.stampIncomingDelivered(ownDeviceId, now)
    }

    fun observeTelegramStickers(packName: String): Flow<List<TelegramStickerEntity>> =
        telegramStickerDao.observeByPack(packName)

    suspend fun findTelegramSticker(id: String): TelegramStickerEntity? =
        telegramStickerDao.findById(id)

    /**
     * Import a public Telegram sticker pack using Bot API. Pack metadata and sticker bytes are
     * written to the durable sync outbox by Room triggers, so the paired device needs no bot token.
     */
    suspend fun importTelegramStickerPack(botToken: String, nameOrLink: String): TelegramStickerPackEntity {
        val client = TelegramStickerClient(botToken)
        val remote = client.getStickerSet(nameOrLink)
        val importedAt = System.currentTimeMillis()
        val stickers = ArrayList<TelegramStickerEntity>(remote.stickers.size)
        for (rs in remote.stickers) {
            val dl = client.downloadSticker(rs)
            stickers.add(
                TelegramStickerEntity(
                    id = "${remote.name}:${rs.fileUniqueId}",
                    packName = remote.name,
                    fileUniqueId = rs.fileUniqueId,
                    emoji = rs.emoji,
                    isAnimated = rs.isAnimated || dl.mimeType == TelegramStickerClient.MIME_TGS,
                    mimeType = dl.mimeType,
                    fileName = dl.fileName,
                    sizeBytes = dl.bytes.size.toLong(),
                    content = dl.bytes,
                    createdAt = importedAt,
                    updatedAt = importedAt
                )
            )
        }
        database.withTransaction {
            val existingPack = telegramStickerPackDao.findByName(remote.name)
            val packUpdatedAt = maxOf(importedAt, (existingPack?.updatedAt ?: 0L) + 1L)
            telegramStickerDao.deleteByPack(remote.name)
            telegramStickerPackDao.upsert(
                TelegramStickerPackEntity(
                    name = remote.name,
                    title = remote.title,
                    isAnimated = remote.isAnimated,
                    stickerCount = stickers.size,
                    importedAt = importedAt,
                    isDeleted = false,
                    updatedAt = packUpdatedAt
                )
            )
            telegramStickerDao.upsertAll(stickers.map { it.copy(updatedAt = packUpdatedAt) })
        }
        return telegramStickerPackDao.findByName(remote.name)
            ?: error("ذخیره پک استیکر ناموفق بود")
    }

    suspend fun deleteTelegramStickerPack(name: String) {
        database.withTransaction {
            val pack = telegramStickerPackDao.findByName(name) ?: return@withTransaction
            if (pack.isDeleted) return@withTransaction
            val deletedAt = maxOf(System.currentTimeMillis(), pack.updatedAt + 1L)
            telegramStickerPackDao.upsert(
                pack.copy(stickerCount = 0, isDeleted = true, updatedAt = deletedAt)
            )
            // Keep the small pack tombstone for sync conflict resolution; remove the binary cache.
            telegramStickerDao.deleteByPack(name)
        }
    }

    /** Send a cached Telegram sticker as a normal message attachment (synced to peer). */
    suspend fun sendTelegramSticker(
        senderDeviceId: String,
        stickerId: String,
        replyToId: String? = null
    ) {
        val sticker = telegramStickerDao.findById(stickerId)
            ?: throw IllegalArgumentException("استیکر پیدا نشد")
        sendMessageAttachment(
            senderDeviceId = senderDeviceId,
            fileName = sticker.fileName,
            mimeType = sticker.mimeType,
            content = sticker.content,
            caption = sticker.emoji.take(16),
            replyToId = replyToId
        )
    }



    suspend fun sendMessageAttachment(
        senderDeviceId: String,
        fileName: String,
        mimeType: String,
        content: ByteArray,
        caption: String = "",
        replyToId: String? = null
    ) {
        require(content.isNotEmpty() && content.size <= MAX_ATTACHMENT_BYTES) {
            "Attachment size is invalid"
        }
        val cleanFileName = fileName.trim().filterNot { it.isISOControl() }
            .ifEmpty { "پیوست" }.take(180)
        val cleanMime = mimeType.trim().ifEmpty { "application/octet-stream" }.take(120)
        val now = System.currentTimeMillis()
        val messageId = UUID.randomUUID().toString()
        val attachmentId = UUID.randomUUID().toString()
        val digest = AttachmentIntegrity.sha256Hex(content)
        database.withTransaction {
            require(attachmentDao.activeCount() < MAX_ACTIVE_ATTACHMENTS) {
                "حداکثر تعداد پیوست‌های فعال پر شده است."
            }
            require(attachmentDao.activeSizeBytes() + content.size <= MAX_ACTIVE_ATTACHMENT_STORAGE_BYTES) {
                "فضای امن پیوست‌ها به سقف ۵۱۲ مگابایت رسیده است."
            }
            messageDao.upsert(
                MessageEntity(
                    id = messageId,
                    senderDeviceId = senderDeviceId.take(80),
                    text = caption.trim().take(5_000),
                    replyToId = replyToId?.take(80),
                    createdAt = now,
                    updatedAt = now
                )
            )
            attachmentDao.upsert(
                AttachmentEntity(
                    id = attachmentId,
                    messageId = messageId,
                    fileName = cleanFileName,
                    mimeType = cleanMime,
                    sizeBytes = content.size.toLong(),
                    sha256 = digest,
                    content = content.copyOf(),
                    createdByDeviceId = senderDeviceId.take(80),
                    createdAt = now,
                    updatedAt = now
                )
            )
        }
    }

    suspend fun deleteAttachment(attachment: AttachmentEntity) {
        if (attachment.isDeleted) return
        attachmentDao.update(
            attachment.copy(
                content = ByteArray(0),
                isDeleted = true,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /** جایگزینی باینری تصویر (مثلاً بعد از چرخش) با به‌روزرسانی hash و اندازه. */
    suspend fun replaceAttachmentContent(
        attachmentId: String,
        content: ByteArray,
        mimeType: String = "image/jpeg",
        fileName: String? = null
    ) {
        require(content.isNotEmpty() && content.size <= MAX_ATTACHMENT_BYTES) {
            "حجم تصویر معتبر نیست."
        }
        database.withTransaction {
            val existing = attachmentDao.findById(attachmentId)
                ?: throw IllegalArgumentException("پیوست پیدا نشد.")
            require(!existing.isDeleted) { "این پیوست حذف شده است." }
            val storageDelta = content.size.toLong() - existing.sizeBytes
            if (storageDelta > 0) {
                require(attachmentDao.activeSizeBytes() + storageDelta <= MAX_ACTIVE_ATTACHMENT_STORAGE_BYTES) {
                    "فضای امن پیوست‌ها به سقف ۵۱۲ مگابایت رسیده است."
                }
            }
            val digest = AttachmentIntegrity.sha256Hex(content)
            val now = System.currentTimeMillis()
            attachmentDao.update(
                existing.copy(
                    fileName = fileName?.take(180) ?: existing.fileName,
                    mimeType = mimeType.take(120),
                    sizeBytes = content.size.toLong(),
                    sha256 = digest,
                    content = content.copyOf(),
                    updatedAt = now
                )
            )
        }
    }

    suspend fun verifiedAttachmentForExport(id: String): AttachmentEntity {
        val attachment = attachmentDao.findById(id)
            ?: throw IllegalArgumentException("پیوست پیدا نشد.")
        require(!attachment.isDeleted) { "این پیوست حذف شده است." }
        require(attachment.content.isNotEmpty() && attachment.content.size <= MAX_ATTACHMENT_BYTES) {
            "محتوای پیوست معتبر نیست."
        }
        require(attachment.sizeBytes == attachment.content.size.toLong()) {
            "اندازه پیوست با اطلاعات ذخیره‌شده مطابقت ندارد."
        }
        require(AttachmentIntegrity.verify(attachment.content, attachment.sizeBytes, attachment.sha256)) {
            "یکپارچگی پیوست تأیید نشد."
        }
        return attachment
    }

    suspend fun editMessage(message: MessageEntity, newText: String) {
        val clean = newText.trim().take(5_000)
        if (clean.isEmpty()) return
        val current = messageDao.findById(message.id) ?: return
        if (current.isDeleted) return
        val now = System.currentTimeMillis()
        // Update only text-related columns, so a concurrent read receipt/reaction is preserved.
        messageDao.updateText(current.id, clean, now)
    }

    suspend fun togglePinnedMessage(message: MessageEntity) {
        val current = messageDao.findById(message.id) ?: return
        if (current.isDeleted || GameMessageProtocol.isProtocolMessage(current.text)) return
        val nextPinnedAt = maxOf(System.currentTimeMillis(), (current.pinnedUpdatedAt ?: 0L) + 1L)
        messageDao.updatePinned(current.id, !current.isPinned, nextPinnedAt)
    }

    suspend fun deleteMessage(message: MessageEntity) {
        val now = System.currentTimeMillis()
        database.withTransaction {
            val current = messageDao.findById(message.id) ?: return@withTransaction
            if (current.isDeleted) return@withTransaction
            if (messageDao.markDeleted(current.id, now) == 0) return@withTransaction
            attachmentDao.findActiveByMessage(message.id).forEach { attachment ->
                attachmentDao.update(attachment.copy(content = ByteArray(0), isDeleted = true, updatedAt = now))
            }
        }
    }

    suspend fun reactToMessage(message: MessageEntity, reaction: String, ownDeviceId: String) {
        val current = messageDao.findById(message.id) ?: return
        if (current.isDeleted) return
        val now = System.currentTimeMillis()
        val cleanReaction = reaction.take(8)
        when {
            current.reactionByDeviceId == ownDeviceId -> {
                val remove = current.reaction == cleanReaction
                messageDao.updateReaction(current.id, if (remove) null else cleanReaction, ownDeviceId, now)
            }
            current.reaction2ByDeviceId == ownDeviceId -> {
                val remove = current.reaction2 == cleanReaction
                messageDao.updateReaction2(current.id, if (remove) null else cleanReaction, ownDeviceId, now)
            }
            current.reactionByDeviceId == null -> {
                messageDao.updateReaction(current.id, cleanReaction, ownDeviceId, now)
            }
            current.reaction2ByDeviceId == null -> {
                messageDao.updateReaction2(current.id, cleanReaction, ownDeviceId, now)
            }
            else -> {
                // Normally unreachable for a two-device pair; replace the older slot if stale data
                // contains an unexpected third reaction owner.
                val firstAt = current.reactionUpdatedAt ?: Long.MIN_VALUE
                val secondAt = current.reaction2UpdatedAt ?: Long.MIN_VALUE
                if (firstAt <= secondAt) messageDao.updateReaction(current.id, cleanReaction, ownDeviceId, now)
                else messageDao.updateReaction2(current.id, cleanReaction, ownDeviceId, now)
            }
        }
    }

    suspend fun markIncomingMessagesRead(ownDeviceId: String): Int =
        messageDao.markIncomingRead(ownDeviceId, System.currentTimeMillis())

    suspend fun markVisibleIncomingMessagesRead(ids: List<String>, ownDeviceId: String): Int {
        if (ids.isEmpty()) return 0
        return messageDao.markIncomingReadByIds(ids.distinct(), ownDeviceId, System.currentTimeMillis())
    }

    suspend fun addFinancialAccount(
        name: String,
        type: String,
        openingBalance: Long,
        colorSeed: Int,
        cardNumber: String,
        accountNumber: String
    ) {
        val cleanName = name.trim().take(120)
        if (cleanName.isEmpty()) return
        val now = System.currentTimeMillis()
        financialAccountDao.upsert(
            FinancialAccountEntity(
                id = UUID.randomUUID().toString(),
                name = cleanName,
                type = type.take(32),
                openingBalance = openingBalance.coerceAtLeast(0),
                colorSeed = colorSeed.coerceIn(0, 5),
                createdAt = now,
                updatedAt = now,
                cardNumber = cardNumber.trim().take(32),
                accountNumber = accountNumber.trim().take(40)
            )
        )
    }

    suspend fun updateFinancialAccount(account: FinancialAccountEntity) {
        financialAccountDao.update(account)
    }

    suspend fun addFinanceTransaction(
        accountId: String,
        targetAccountId: String?,
        kind: String,
        amount: Long,
        category: String,
        note: String,
        payerDeviceId: String,
        occurredAt: Long = System.currentTimeMillis(),
        source: String = "MANUAL"
    ) {
        if (accountId.isBlank() || amount <= 0) return
        val normalizedKind = when (kind) {
            "INCOME" -> "INCOME"
            "TRANSFER" -> "TRANSFER"
            else -> "EXPENSE"
        }
        val cleanTarget = if (normalizedKind == "TRANSFER") {
            targetAccountId?.takeIf { it.isNotBlank() && it != accountId }?.take(80)
        } else {
            null
        }
        if (normalizedKind == "TRANSFER" && cleanTarget == null) return
        val now = System.currentTimeMillis()
        financeTransactionDao.upsert(
            FinanceTransactionEntity(
                id = UUID.randomUUID().toString(),
                accountId = accountId.take(80),
                targetAccountId = cleanTarget,
                kind = normalizedKind,
                amount = amount.coerceAtMost(MAX_FINANCE_AMOUNT),
                category = if (normalizedKind == "TRANSFER") "جابجایی" else category.trim().ifEmpty { "سایر" }.take(100),
                note = note.trim().take(1_000),
                payerDeviceId = payerDeviceId.take(80),
                occurredAt = occurredAt,
                source = if (source == "SMS") "SMS" else "MANUAL",
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun importSmsFinanceTransactions(
        imports: List<SmsFinanceImport>,
        payerDeviceId: String
    ): FinanceBalanceReconciliation = database.withTransaction {
        val accounts = financialAccountDao.getAllOnce().filter { !it.isDeleted && !it.isArchived }
        val accountIds = accounts.map { it.id }.toHashSet()
        val validImports = imports.filter {
            it.accountId in accountIds && it.amount in 1L..MAX_FINANCE_AMOUNT
        }.map { row ->
            row.copy(kind = if (row.kind.equals("INCOME", true)) "INCOME" else "EXPENSE")
        }
        if (validImports.isEmpty()) throw IllegalArgumentException("حساب یا مبلغ تراکنش معتبر نیست؛ پیامک وارد نشد.")

        val existingTransactions = financeTransactionDao.getAllOnce().filterNot { it.isDeleted }
        val now = System.currentTimeMillis()
        validImports.forEach { row ->
            financeTransactionDao.upsert(
                FinanceTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    accountId = row.accountId,
                    kind = row.kind,
                    amount = row.amount,
                    category = row.category.trim().ifBlank { "سایر" }.take(100),
                    note = row.note.trim().take(1_000),
                    payerDeviceId = payerDeviceId.take(80),
                    occurredAt = row.occurredAt,
                    source = "SMS",
                    createdAt = now,
                    updatedAt = now
                )
            )
        }

        val reconciliation = FinanceBalanceReconciler.reconcile(accounts, existingTransactions, validImports)
        reconciliation.adjustments.filter { it.difference != 0L }.forEach { adjustment ->
            val account = accounts.firstOrNull { it.id == adjustment.accountId } ?: return@forEach
            financialAccountDao.update(
                account.copy(
                    openingBalance = adjustment.correctedOpeningBalance,
                    updatedAt = now
                )
            )
        }
        reconciliation
    }

    suspend fun deleteFinanceTransaction(transaction: FinanceTransactionEntity) {
        if (transaction.isSmsLocked) return
        financeTransactionDao.update(
            transaction.copy(isDeleted = true, updatedAt = System.currentTimeMillis())
        )
    }

    /**
     * Redacts all financial records locally while retaining sync tombstones, so a paired device
     * receives the deletions instead of restoring older financial data on the next sync.
     */
    suspend fun clearFinancialData() = database.withTransaction {
        val now = System.currentTimeMillis()
        financialAccountDao.getAllOnce().forEach { account ->
            financialAccountDao.upsert(account.copy(
                name = "",
                type = "",
                openingBalance = 0,
                isArchived = true,
                isDeleted = true,
                cardNumber = "",
                accountNumber = "",
                createdAt = 0L,
                updatedAt = maxOf(now, account.updatedAt + 1L)
            ))
        }
        financeTransactionDao.getAllOnce().forEach { transaction ->
            financeTransactionDao.upsert(transaction.copy(
                accountId = "",
                targetAccountId = null,
                amount = 0,
                category = "",
                note = "",
                payerDeviceId = "",
                occurredAt = 0L,
                isDeleted = true,
                createdAt = 0L,
                updatedAt = maxOf(now, transaction.updatedAt + 1L)
            ))
        }
        financeBudgetDao.getAllOnce().forEach { budget ->
            financeBudgetDao.upsert(budget.copy(
                category = "",
                periodKey = "",
                monthlyLimit = 0,
                isDeleted = true,
                createdAt = 0L,
                updatedAt = maxOf(now, budget.updatedAt + 1L)
            ))
        }
        sharedDebtDao.getAllOnce().forEach { debt ->
            sharedDebtDao.upsert(debt.copy(
                title = "",
                amount = 0,
                creditorDeviceId = "",
                debtorDeviceId = "",
                note = "",
                dueAt = null,
                settledAt = null,
                isDeleted = true,
                createdAt = 0L,
                updatedAt = maxOf(now, debt.updatedAt + 1L)
            ))
        }
        recurringTransactionDao.getAllOnce().forEach { rule ->
            recurringTransactionDao.upsert(rule.copy(
                accountId = "",
                targetAccountId = null,
                amount = 0,
                category = "",
                note = "",
                nextRunAt = 0L,
                lastGeneratedAt = null,
                createdByDeviceId = "",
                isActive = false,
                isDeleted = true,
                createdAt = 0L,
                updatedAt = maxOf(now, rule.updatedAt + 1L)
            ))
        }
    }

    suspend fun setFinanceBudget(category: String, periodKey: String, monthlyLimit: Long) {
        val cleanCategory = category.trim().ifEmpty { "سایر" }.take(100)
        val cleanPeriod = periodKey.take(16)
        if (monthlyLimit <= 0 || cleanPeriod.isEmpty()) return
        val now = System.currentTimeMillis()
        financeBudgetDao.upsert(
            FinanceBudgetEntity(
                id = "$cleanPeriod:$cleanCategory",
                category = cleanCategory,
                periodKey = cleanPeriod,
                monthlyLimit = monthlyLimit.coerceAtMost(MAX_FINANCE_AMOUNT),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun addSharedDebt(
        title: String,
        amount: Long,
        creditorDeviceId: String,
        debtorDeviceId: String,
        note: String,
        dueAt: Long?
    ) {
        val cleanTitle = title.trim().take(200)
        if (cleanTitle.isEmpty() || amount <= 0) return
        if (creditorDeviceId.isBlank() || debtorDeviceId.isBlank() || creditorDeviceId == debtorDeviceId) return
        val now = System.currentTimeMillis()
        sharedDebtDao.upsert(
            SharedDebtEntity(
                id = UUID.randomUUID().toString(),
                title = cleanTitle,
                amount = amount.coerceAtMost(MAX_FINANCE_AMOUNT),
                creditorDeviceId = creditorDeviceId.take(80),
                debtorDeviceId = debtorDeviceId.take(80),
                note = note.trim().take(1_000),
                dueAt = dueAt,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun toggleDebtSettled(debt: SharedDebtEntity) {
        if (debt.isDeleted) return
        val now = System.currentTimeMillis()
        sharedDebtDao.update(
            debt.copy(settledAt = if (debt.settledAt == null) now else null, updatedAt = now)
        )
    }

    suspend fun deleteSharedDebt(debt: SharedDebtEntity) {
        sharedDebtDao.update(debt.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun addRecurringTransaction(
        accountId: String,
        targetAccountId: String?,
        kind: String,
        amount: Long,
        category: String,
        note: String,
        interval: String,
        firstRunAt: Long,
        createdByDeviceId: String
    ) {
        if (accountId.isBlank() || amount <= 0 || createdByDeviceId.isBlank()) return
        val normalizedKind = when (kind) {
            "INCOME" -> "INCOME"
            "TRANSFER" -> "TRANSFER"
            else -> "EXPENSE"
        }
        val cleanTarget = if (normalizedKind == "TRANSFER") {
            targetAccountId?.takeIf { it.isNotBlank() && it != accountId }?.take(80)
        } else null
        if (normalizedKind == "TRANSFER" && cleanTarget == null) return
        val cleanInterval = interval.takeIf { it in RECURRING_INTERVALS } ?: "MONTHLY"
        val now = System.currentTimeMillis()
        recurringTransactionDao.upsert(
            RecurringTransactionEntity(
                id = UUID.randomUUID().toString(),
                accountId = accountId.take(80),
                targetAccountId = cleanTarget,
                kind = normalizedKind,
                amount = amount.coerceAtMost(MAX_FINANCE_AMOUNT),
                category = if (normalizedKind == "TRANSFER") "جابجایی" else category.trim().ifEmpty { "سایر" }.take(100),
                note = note.trim().take(1_000),
                interval = cleanInterval,
                anchorJalaliDay = PersianDateFormatter.jalaliDate(firstRunAt).day,
                nextRunAt = firstRunAt,
                createdByDeviceId = createdByDeviceId.take(80),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun toggleRecurringTransaction(rule: RecurringTransactionEntity) {
        if (rule.isDeleted) return
        recurringTransactionDao.update(
            rule.copy(isActive = !rule.isActive, updatedAt = System.currentTimeMillis())
        )
    }

    suspend fun deleteRecurringTransaction(rule: RecurringTransactionEntity) {
        recurringTransactionDao.update(
            rule.copy(isDeleted = true, isActive = false, updatedAt = System.currentTimeMillis())
        )
    }

    suspend fun materializeDueRecurringTransactions(deviceId: String, now: Long = System.currentTimeMillis()): Int {
        if (deviceId.isBlank()) return 0
        var generated = 0
        database.withTransaction {
            recurringTransactionDao.dueForOwner(deviceId.take(80), now, MAX_DUE_RULES_PER_RUN).forEach { rule ->
                var nextRunAt = rule.nextRunAt
                var lastGeneratedAt = rule.lastGeneratedAt
                var generatedForRule = 0
                while (nextRunAt <= now && generatedForRule < MAX_OCCURRENCES_PER_RULE) {
                    financeTransactionDao.upsert(
                        FinanceTransactionEntity(
                            id = "rec:${rule.id}:$nextRunAt",
                            accountId = rule.accountId,
                            targetAccountId = rule.targetAccountId,
                            kind = rule.kind,
                            amount = rule.amount,
                            category = rule.category,
                            note = rule.note,
                            payerDeviceId = rule.createdByDeviceId,
                            occurredAt = nextRunAt,
                            createdAt = nextRunAt,
                            updatedAt = now
                        )
                    )
                    lastGeneratedAt = nextRunAt
                    nextRunAt = PersianDateFormatter.advanceRecurringDate(
                        nextRunAt,
                        rule.interval,
                        rule.anchorJalaliDay
                    )
                    generated++
                    generatedForRule++
                }
                recurringTransactionDao.update(
                    rule.copy(nextRunAt = nextRunAt, lastGeneratedAt = lastGeneratedAt, updatedAt = now)
                )
            }
        }
        return generated
    }

    suspend fun addMemory(
        title: String,
        note: String,
        mood: String,
        createdByDeviceId: String,
        occurredAt: Long = System.currentTimeMillis()
    ) {
        val cleanTitle = title.trim().take(200)
        if (cleanTitle.isEmpty()) return
        val now = System.currentTimeMillis()
        memoryDao.upsert(
            MemoryEntity(
                id = UUID.randomUUID().toString(),
                title = cleanTitle,
                note = note.trim().take(8_000),
                mood = mood.take(24),
                createdByDeviceId = createdByDeviceId.take(80),
                occurredAt = occurredAt,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun addMemoryAttachment(
        memoryId: String,
        createdByDeviceId: String,
        fileName: String,
        mimeType: String,
        content: ByteArray
    ) {
        require(content.isNotEmpty() && content.size <= MAX_ATTACHMENT_BYTES) {
            "حجم تصویر معتبر نیست."
        }
        require(mimeType.startsWith("image/")) { "برای خاطره باید یک تصویر انتخاب شود." }
        val cleanFileName = fileName.trim().filterNot { it.isISOControl() }
            .ifEmpty { "تصویر خاطره" }.take(180)
        val cleanMime = mimeType.trim().filterNot { it.isISOControl() }.take(120)
        val now = System.currentTimeMillis()
        val digest = AttachmentIntegrity.sha256Hex(content)
        database.withTransaction {
            val memory = memoryDao.findById(memoryId)
            require(memory != null && !memory.isDeleted) { "خاطره انتخاب‌شده پیدا نشد." }
            require(attachmentDao.activeCount() < MAX_ACTIVE_ATTACHMENTS) {
                "حداکثر تعداد پیوست‌های فعال پر شده است."
            }
            require(attachmentDao.activeCountByMemory(memoryId) < MAX_MEMORY_IMAGES) {
                "هر خاطره می‌تواند حداکثر ۱۲ تصویر داشته باشد."
            }
            require(attachmentDao.activeSizeBytes() + content.size <= MAX_ACTIVE_ATTACHMENT_STORAGE_BYTES) {
                "فضای امن پیوست‌ها به سقف ۵۱۲ مگابایت رسیده است."
            }
            attachmentDao.upsert(
                AttachmentEntity(
                    id = UUID.randomUUID().toString(),
                    memoryId = memoryId.take(80),
                    fileName = cleanFileName,
                    mimeType = cleanMime,
                    sizeBytes = content.size.toLong(),
                    sha256 = digest,
                    content = content.copyOf(),
                    createdByDeviceId = createdByDeviceId.take(80),
                    createdAt = now,
                    updatedAt = now
                )
            )
        }
    }

    suspend fun updateMemory(
        memory: MemoryEntity,
        title: String,
        note: String,
        mood: String,
        occurredAt: Long
    ) {
        val cleanTitle = title.trim().take(200)
        if (cleanTitle.isEmpty() || memory.isDeleted) return
        memoryDao.update(
            memory.copy(
                title = cleanTitle,
                note = note.trim().take(8_000),
                mood = mood.take(24),
                occurredAt = occurredAt,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun toggleMemoryFavorite(memory: MemoryEntity) {
        memoryDao.update(
            memory.copy(isFavorite = !memory.isFavorite, updatedAt = System.currentTimeMillis())
        )
    }

    suspend fun deleteMemory(memory: MemoryEntity) {
        val now = System.currentTimeMillis()
        database.withTransaction {
            memoryDao.update(memory.copy(isDeleted = true, updatedAt = now))
            attachmentDao.findActiveByMemory(memory.id).forEach { attachment ->
                attachmentDao.update(
                    attachment.copy(content = ByteArray(0), isDeleted = true, updatedAt = now)
                )
            }
        }
    }

    suspend fun setDailyMood(deviceId: String, dayKey: String, mood: String, note: String) {
        val cleanDeviceId = deviceId.take(80)
        val cleanDayKey = dayKey.take(16)
        val id = "$cleanDayKey:$cleanDeviceId"
        val now = System.currentTimeMillis()
        val existing = moodCheckInDao.findById(id)
        moodCheckInDao.upsert(
            MoodCheckInEntity(
                id = id,
                deviceId = cleanDeviceId,
                dayKey = cleanDayKey,
                mood = mood.take(24),
                note = note.trim().take(500),
                isDeleted = false,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now
            )
        )
    }

    suspend fun addSpecialDate(
        title: String,
        note: String,
        occurredAt: Long,
        repeatYearly: Boolean
    ) {
        val cleanTitle = title.trim().take(200)
        if (cleanTitle.isEmpty()) return
        val now = System.currentTimeMillis()
        specialDateDao.upsert(
            SpecialDateEntity(
                id = UUID.randomUUID().toString(),
                title = cleanTitle,
                note = note.trim().take(1_000),
                occurredAt = occurredAt,
                repeatYearly = repeatYearly,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateSpecialDate(
        existing: SpecialDateEntity,
        title: String,
        note: String,
        occurredAt: Long,
        repeatYearly: Boolean
    ) {
        val cleanTitle = title.trim().take(200)
        if (cleanTitle.isEmpty()) return
        specialDateDao.update(
            existing.copy(
                title = cleanTitle,
                note = note.trim().take(1_000),
                occurredAt = occurredAt,
                repeatYearly = repeatYearly,
                isDeleted = false,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteSpecialDate(specialDate: SpecialDateEntity) {
        specialDateDao.update(
            specialDate.copy(isDeleted = true, updatedAt = System.currentTimeMillis())
        )
    }

    suspend fun saveCoupleProfile(firstName: String, secondName: String, startedAt: Long?) {
        val now = System.currentTimeMillis()
        val existing = coupleProfileDao.getOnce()
        coupleProfileDao.upsert(
            CoupleProfileEntity(
                firstPersonName = firstName.trim().take(80),
                secondPersonName = secondName.trim().take(80),
                relationshipStartedAt = startedAt,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now
            )
        )
    }

    private companion object {
        const val MAX_FINANCE_AMOUNT = 999_999_999_999_999L
        const val MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024
        const val MAX_ACTIVE_ATTACHMENTS = 1_000
        const val MAX_MEMORY_IMAGES = 12
        const val MAX_ACTIVE_ATTACHMENT_STORAGE_BYTES = 512L * 1024 * 1024
        const val MAX_DUE_RULES_PER_RUN = 50
        const val MAX_OCCURRENCES_PER_RULE = 24
        val RECURRING_INTERVALS = setOf("WEEKLY", "MONTHLY", "YEARLY")
    }

    suspend fun startPeriod(deviceId: String, startAt: Long, flowLevel: String = "UNKNOWN", note: String = "") {
        val now = System.currentTimeMillis()
        // Close any open period first.
        cycleLogDao.getAllOnce()
            .filter { !it.isDeleted && it.endAt == null }
            .forEach { open ->
                cycleLogDao.upsert(
                    open.copy(endAt = startAt.coerceAtLeast(open.startAt), updatedAt = now)
                )
            }
        cycleLogDao.upsert(
            CycleLogEntity(
                id = UUID.randomUUID().toString(),
                startAt = startAt,
                endAt = null,
                flowLevel = flowLevel.take(24).ifBlank { "UNKNOWN" },
                note = note.trim().take(500),
                recordedByDeviceId = deviceId.take(80),
                createdAt = now,
                updatedAt = now
            )
        )
        ensureCycleSettings(now)
    }

    suspend fun endPeriod(log: CycleLogEntity, endAt: Long = System.currentTimeMillis()) {
        if (log.isDeleted) return
        val now = System.currentTimeMillis()
        cycleLogDao.upsert(
            log.copy(
                endAt = endAt.coerceAtLeast(log.startAt),
                updatedAt = now
            )
        )
    }

    suspend fun deleteCycleLog(log: CycleLogEntity) {
        cycleLogDao.upsert(log.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun updateCycleSettings(averageCycleDays: Int, averagePeriodDays: Int, trackingEnabled: Boolean) {
        val now = System.currentTimeMillis()
        val existing = cycleSettingsDao.getOnce()
        cycleSettingsDao.upsert(
            CycleSettingsEntity(
                id = "cycle-settings",
                averageCycleDays = averageCycleDays.coerceIn(15, 60),
                averagePeriodDays = averagePeriodDays.coerceIn(1, 15),
                trackingEnabled = trackingEnabled,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now
            )
        )
    }

    private suspend fun ensureCycleSettings(now: Long = System.currentTimeMillis()) {
        if (cycleSettingsDao.getOnce() == null) {
            cycleSettingsDao.upsert(
                CycleSettingsEntity(
                    id = "cycle-settings",
                    averageCycleDays = 28,
                    averagePeriodDays = 5,
                    trackingEnabled = true,
                    createdAt = now,
                    updatedAt = now
                )
            )
        }
    }


    suspend fun publishLocation(
        deviceId: String,
        latitude: Double,
        longitude: Double,
        accuracyMeters: Float,
        isSharing: Boolean = true
    ) {
        val now = System.currentTimeMillis()
        val existing = locationShareDao.findById(deviceId)
        locationShareDao.upsert(
            LocationShareEntity(
                id = deviceId.take(80),
                latitude = latitude,
                longitude = longitude,
                accuracyMeters = accuracyMeters.coerceAtLeast(0f),
                isSharing = isSharing,
                isDeleted = false,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now
            )
        )
    }

    suspend fun stopLocationSharing(deviceId: String) {
        val existing = locationShareDao.findById(deviceId) ?: return
        locationShareDao.upsert(
            existing.copy(isSharing = false, updatedAt = System.currentTimeMillis())
        )
    }


    suspend fun sendHeartPulse(deviceId: String) {
        val now = System.currentTimeMillis()
        heartPulseDao.upsert(
            HeartPulseEntity(
                id = UUID.randomUUID().toString(),
                senderDeviceId = deviceId.take(80),
                consumedAt = null,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun markHeartPulseConsumed(pulse: HeartPulseEntity) {
        if (pulse.consumedAt != null) return
        val now = System.currentTimeMillis()
        heartPulseDao.upsert(pulse.copy(consumedAt = now, updatedAt = now))
    }


    suspend fun pendingHeartToAcknowledge(ownDeviceId: String): HeartPulseEntity? =
        heartPulseDao.getAllOnce()
            .filter { !it.isDeleted && it.senderDeviceId != ownDeviceId && it.acknowledgedAt == null }
            .maxByOrNull { it.createdAt }

    suspend fun acknowledgeHeartPulse(pulse: HeartPulseEntity) {
        if (pulse.acknowledgedAt != null) return
        val now = System.currentTimeMillis()
        heartPulseDao.upsert(
            pulse.copy(
                acknowledgedAt = now,
                consumedAt = pulse.consumedAt ?: now,
                updatedAt = now
            )
        )
    }

    suspend fun addSharedPlace(
        title: String,
        note: String,
        latitude: Double,
        longitude: Double,
        category: String,
        deviceId: String
    ) {
        val clean = title.trim().take(200)
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        sharedPlaceDao.upsert(
            SharedPlaceEntity(
                id = UUID.randomUUID().toString(),
                title = clean,
                note = note.trim().take(1_000),
                latitude = latitude.coerceIn(-90.0, 90.0),
                longitude = longitude.coerceIn(-180.0, 180.0),
                category = category.take(24).ifBlank { "OTHER" },
                createdByDeviceId = deviceId.take(80),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun deleteSharedPlace(place: SharedPlaceEntity) {
        sharedPlaceDao.upsert(place.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    /** Titles of shopping items used before, most frequent first. */
    suspend fun shoppingSuggestions(limit: Int = 12): List<String> {
        return shoppingDao.getAllOnce()
            .filter { !it.isDeleted }
            .groupingBy { it.title.trim() }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { it.key }
            .filter { it.isNotBlank() }
            .take(limit)
    }


    data class HabitDraft(
        val title: String,
        val kind: String = "HABIT",
        val scheduleNote: String = "",
        val note: String = "",
        val frequency: String = "DAILY",
        val timesPerWeek: Int = 7,
        val timesPerDay: Int = 1,
        val weekDays: String = "",
        val priority: String = "NORMAL"
    )

    suspend fun addHabit(title: String, kind: String, scheduleNote: String, note: String = "") {
        addHabit(
            HabitDraft(
                title = title,
                kind = kind,
                scheduleNote = scheduleNote,
                note = note
            )
        )
    }

    suspend fun addHabit(draft: HabitDraft) {
        val clean = draft.title.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        val frequency = draft.frequency.ifBlank { "DAILY" }.uppercase()
        val timesPerDay = draft.timesPerDay.coerceIn(1, 10)
        val timesPerWeek = when (frequency) {
            "DAILY" -> 7 * timesPerDay
            "WEEKDAYS" -> 5 * timesPerDay
            "WEEKENDS" -> 2 * timesPerDay
            else -> draft.timesPerWeek.coerceIn(1, 14)
        }
        habitDao.upsert(
            HabitEntity(
                id = java.util.UUID.randomUUID().toString(),
                title = clean,
                note = draft.note.trim(),
                kind = draft.kind.ifBlank { "HABIT" },
                scheduleNote = draft.scheduleNote.trim(),
                frequency = frequency,
                timesPerWeek = timesPerWeek,
                timesPerDay = timesPerDay,
                weekDays = draft.weekDays.trim(),
                priority = draft.priority.ifBlank { "NORMAL" }.uppercase(),
                completionsToday = 0,
                lastCompletedDayKey = "",
                completionsThisWeek = 0,
                weekKey = currentHabitWeekKey(),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    /**
     * ثبت یک بار انجام برای امروز (تا سقف timesPerDay).
     * ضربه مجدد وقتی به سقف رسیده باشد، شمارش امروز را صفر می‌کند (لغو).
     */
    suspend fun toggleHabitDoneToday(habit: HabitEntity) {
        val today = com.ourspace.app.core.time.PersianDateFormatter.currentJalaliDayKey()
        val weekKey = currentHabitWeekKey()
        val now = System.currentTimeMillis()
        val sameDay = habit.lastCompletedDayKey == today
        val sameWeek = habit.weekKey == weekKey
        val perDay = habit.timesPerDay.coerceIn(1, 10)
        val todayCount = if (sameDay) habit.completionsToday.coerceIn(0, perDay) else 0
        val weekCount = if (sameWeek) habit.completionsThisWeek.coerceAtLeast(0) else 0

        val (newToday, newWeek) = if (todayCount >= perDay) {
            // لغو کامل انجام امروز
            0 to (weekCount - todayCount).coerceAtLeast(0)
        } else {
            (todayCount + 1) to (weekCount + 1)
        }

        habitDao.upsert(
            habit.copy(
                completionsToday = newToday,
                lastCompletedDayKey = if (newToday > 0) today else if (sameDay) "" else habit.lastCompletedDayKey,
                completionsThisWeek = newWeek,
                weekKey = weekKey,
                updatedAt = now
            )
        )
    }

    private fun currentHabitWeekKey(): String {
        val cal = java.util.Calendar.getInstance()
        return "${cal.get(java.util.Calendar.YEAR)}-W${cal.get(java.util.Calendar.WEEK_OF_YEAR)}"
    }

    suspend fun deleteHabit(habit: HabitEntity) {
        habitDao.upsert(habit.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun addWatchlistItem(
        title: String,
        mediaType: String,
        note: String = "",
        totalEpisodes: Int = 0,
        rating: Int = 0
    ) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        val type = mediaType.ifBlank { "MOVIE" }
        val total = if (type == "SERIES") totalEpisodes.coerceIn(0, 10_000) else 0
        watchlistDao.upsert(
            WatchlistItemEntity(
                id = java.util.UUID.randomUUID().toString(),
                title = clean,
                note = note.trim(),
                mediaType = type,
                status = "WANT",
                totalEpisodes = total,
                watchedEpisodes = 0,
                rating = rating.coerceIn(0, 5),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateWatchlistItem(
        item: WatchlistItemEntity,
        title: String,
        mediaType: String,
        note: String,
        status: String,
        totalEpisodes: Int,
        watchedEpisodes: Int,
        rating: Int = item.rating
    ) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val type = mediaType.ifBlank { item.mediaType }.ifBlank { "MOVIE" }
        val total = if (type == "SERIES") totalEpisodes.coerceIn(0, 10_000) else 0
        val watched = if (type == "SERIES") {
            watchedEpisodes.coerceIn(0, if (total > 0) total else 10_000)
        } else 0
        val normalizedStatus = when (status) {
            "WATCHING", "DONE", "WANT" -> status
            else -> item.status
        }
        watchlistDao.upsert(
            item.copy(
                title = clean,
                note = note.trim(),
                mediaType = type,
                status = normalizedStatus,
                totalEpisodes = total,
                watchedEpisodes = watched,
                rating = rating.coerceIn(0, 5),
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun adjustWatchlistWatchedEpisodes(item: WatchlistItemEntity, delta: Int) {
        if (item.mediaType != "SERIES" || delta == 0) return
        val total = item.totalEpisodes.coerceAtLeast(0)
        val next = (item.watchedEpisodes + delta).coerceIn(0, if (total > 0) total else 10_000)
        if (next == item.watchedEpisodes) return
        val status = when {
            total > 0 && next >= total -> "DONE"
            next > 0 -> if (item.status == "WANT") "WATCHING" else item.status
            else -> item.status
        }
        watchlistDao.upsert(
            item.copy(
                watchedEpisodes = next,
                status = status,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun cycleWatchlistStatus(item: WatchlistItemEntity) {
        val next = when (item.status) {
            "WANT" -> "WATCHING"
            "WATCHING" -> "DONE"
            else -> "WANT"
        }
        val watched = when {
            next == "DONE" && item.mediaType == "SERIES" && item.totalEpisodes > 0 -> item.totalEpisodes
            next == "WANT" && item.mediaType == "SERIES" -> 0
            else -> item.watchedEpisodes
        }
        watchlistDao.upsert(
            item.copy(
                status = next,
                watchedEpisodes = watched,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteWatchlistItem(item: WatchlistItemEntity) {
        watchlistDao.upsert(item.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun addBookItem(
        title: String,
        author: String = "",
        note: String = "",
        totalPages: Int = 0
    ) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        bookDao.upsert(
            BookItemEntity(
                id = java.util.UUID.randomUUID().toString(),
                title = clean,
                author = author.trim(),
                note = note.trim(),
                status = "WANT",
                totalPages = totalPages.coerceIn(0, 100_000),
                readPages = 0,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateBookItem(
        item: BookItemEntity,
        title: String,
        author: String,
        note: String,
        status: String,
        totalPages: Int,
        readPages: Int
    ) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val total = totalPages.coerceIn(0, 100_000)
        val read = readPages.coerceIn(0, if (total > 0) total else 100_000)
        val normalizedStatus = when (status) {
            "READING", "DONE", "WANT" -> status
            else -> item.status
        }
        bookDao.upsert(
            item.copy(
                title = clean,
                author = author.trim(),
                note = note.trim(),
                status = normalizedStatus,
                totalPages = total,
                readPages = read,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun adjustBookReadPages(item: BookItemEntity, delta: Int) {
        if (delta == 0) return
        val total = item.totalPages.coerceAtLeast(0)
        val next = (item.readPages + delta).coerceIn(0, if (total > 0) total else 100_000)
        if (next == item.readPages) return
        val status = when {
            total > 0 && next >= total -> "DONE"
            next > 0 -> if (item.status == "WANT") "READING" else item.status
            else -> item.status
        }
        bookDao.upsert(
            item.copy(
                readPages = next,
                status = status,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun cycleBookStatus(item: BookItemEntity) {
        val next = when (item.status) {
            "WANT" -> "READING"
            "READING" -> "DONE"
            else -> "WANT"
        }
        val read = when {
            next == "DONE" && item.totalPages > 0 -> item.totalPages
            next == "WANT" -> 0
            else -> item.readPages
        }
        bookDao.upsert(
            item.copy(
                status = next,
                readPages = read,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteBookItem(item: BookItemEntity) {
        bookDao.upsert(item.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun ensureDefaultFoodsSeeded() {
        if (foodDao.countAll() > 0) return
        foodDao.upsertAll(IranianFoodsDefaults.seedEntities())
    }

    suspend fun addFoodItem(name: String, note: String = "") {
        val clean = name.trim()
        if (clean.isEmpty()) return
        val now = System.currentTimeMillis()
        foodDao.upsert(
            FoodItemEntity(
                id = java.util.UUID.randomUUID().toString(),
                name = clean.take(120),
                note = note.trim().take(500),
                isFavorite = false,
                isDeleted = false,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun toggleFoodFavorite(item: FoodItemEntity) {
        foodDao.upsert(item.copy(isFavorite = !item.isFavorite, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteFoodItem(item: FoodItemEntity) {
        foodDao.upsert(item.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }


}
