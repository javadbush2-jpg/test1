package com.ourspace.app.core.finance

import com.ourspace.app.core.database.FinancialAccountEntity

/** Matches bank SMS text to a saved account using its card/account number. */
object FinancialAccountMatcher {
    private val accountLabel = Regex(
        """(?:شماره\s*(?:کارت|حساب)|(?:کارت|حساب)(?:\s*بانکی)?(?:\s*شماره)?|card|account)\s*[:：#-]?\s*[\d*Xx\s-]{3,48}""",
        RegexOption.IGNORE_CASE
    )
    /** Returns an id only when one account is the strongest unambiguous match. */
    fun matchId(accounts: List<FinancialAccountEntity>, message: String): String? {
        val active = accounts.filter { !it.isDeleted && !it.isArchived }
        if (active.isEmpty() || message.isBlank()) return null
        val normalizedMessage = normalizeDigits(message)
        val digitsOnlyMessage = normalizedMessage.filter(Char::isDigit)
        val labeledNumbers = accountLabel.findAll(normalizedMessage)
            .map { match -> match.value.filter(Char::isDigit) }
            .filter { it.length >= 4 }
            .toList()

        val scored = active.mapNotNull { account ->
            val savedNumbers = listOf(account.cardNumber, account.accountNumber)
                .map(::digitsOnly)
                .filter { it.length >= 4 }
                .distinct()
            if (savedNumbers.isEmpty()) return@mapNotNull null

            val score = savedNumbers.maxOfOrNull { number ->
                when {
                    number.length >= 6 && digitsOnlyMessage.contains(number) -> 100
                    labeledNumbers.any { it.endsWith(number.takeLast(4)) } -> 80
                    else -> 0
                }
            } ?: 0
            account.id.takeIf { score > 0 }?.let { it to score }
        }.sortedByDescending { it.second }

        val best = scored.firstOrNull() ?: return null
        if (scored.getOrNull(1)?.second == best.second) return null
        return best.first
    }

    private fun digitsOnly(value: String): String = normalizeDigits(value).filter(Char::isDigit)

    private fun normalizeDigits(value: String): String = buildString(value.length) {
        value.forEach { char ->
            when (char) {
                in '۰'..'۹' -> append(('0'.code + char.code - '۰'.code).toChar())
                in '٠'..'٩' -> append(('0'.code + char.code - '٠'.code).toChar())
                else -> append(char)
            }
        }
    }
}
