package com.ourspace.app.core.finance

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.Telephony

data class SmsCandidate(
    val smsId: String,
    val address: String,
    val body: String,
    val dateMillis: Long,
    val parsed: BankSmsParser.ParsedSmsTransaction
)

/**
 * خواندن پیامک‌های دستگاه و استخراج تراکنش‌های بانکی.
 * فقط با مجوز READ_SMS و انتخاب صریح کاربر.
 */
object SmsTransactionImporter {

    private const val PREFS = "ourspace_sms_import"
    private const val KEY_IMPORTED_IDS = "imported_sms_ids"

    fun loadImportedIds(context: Context): Set<String> =
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_IMPORTED_IDS, emptySet())
            ?.toSet()
            ?: emptySet()

    fun markImported(context: Context, ids: Collection<String>) {
        if (ids.isEmpty()) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val next = (prefs.getStringSet(KEY_IMPORTED_IDS, emptySet()) ?: emptySet()).toMutableSet()
        next.addAll(ids)
        // محدودیت اندازه
        val trimmed = if (next.size > 5_000) next.toList().takeLast(4_000).toSet() else next
        prefs.edit().putStringSet(KEY_IMPORTED_IDS, trimmed).apply()
    }

    /**
     * @param lookbackDays فقط پیامک‌های N روز اخیر
     * @param maxScan حداکثر تعداد پیامک برای اسکن
     */
    fun scan(
        context: Context,
        lookbackDays: Int = 30,
        maxScan: Int = 400
    ): List<SmsCandidate> {
        SmsTemplateStore.seedDefaultsIfEmpty(context)

        val imported = loadImportedIds(context)
        val minDate = System.currentTimeMillis() - lookbackDays.coerceIn(1, 90) * 24L * 60 * 60 * 1000
        val uri: Uri = Telephony.Sms.Inbox.CONTENT_URI
        val projection = arrayOf(
            Telephony.Sms._ID,
            Telephony.Sms.ADDRESS,
            Telephony.Sms.BODY,
            Telephony.Sms.DATE
        )
        val selection = "${Telephony.Sms.DATE} >= ?"
        val selectionArgs = arrayOf(minDate.toString())
        val sort = "${Telephony.Sms.DATE} DESC"

        val results = mutableListOf<SmsCandidate>()
        val resolver = context.applicationContext.contentResolver
        var cursor: Cursor? = null
        try {
            cursor = resolver.query(uri, projection, selection, selectionArgs, sort)
            if (cursor == null) return emptyList()
            var scanned = 0
            val idIdx = cursor.getColumnIndex(Telephony.Sms._ID)
            val addrIdx = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
            val bodyIdx = cursor.getColumnIndex(Telephony.Sms.BODY)
            val dateIdx = cursor.getColumnIndex(Telephony.Sms.DATE)
            while (cursor.moveToNext() && scanned < maxScan) {
                scanned++
                val id = if (idIdx >= 0) cursor.getString(idIdx) else continue
                if (id.isNullOrBlank() || id in imported) continue
                val address = if (addrIdx >= 0) cursor.getString(addrIdx).orEmpty() else ""
                val body = if (bodyIdx >= 0) cursor.getString(bodyIdx).orEmpty() else ""
                val date = if (dateIdx >= 0) cursor.getLong(dateIdx) else 0L
                if (body.isBlank()) continue
                val parsed = BankSmsParser.parse(body, address, context) ?: continue
                if (!BankSmsParser.isReviewWorthy(parsed, body, address)) continue
                results += SmsCandidate(
                    smsId = id,
                    address = address,
                    body = body,
                    dateMillis = parsed.transactionDateMillis ?: date,
                    parsed = parsed
                )
            }
        } catch (_: SecurityException) {
            return emptyList()
        } catch (_: Exception) {
            return emptyList()
        } finally {
            cursor?.close()
        }
        return results.sortedByDescending { it.dateMillis }
    }
}
