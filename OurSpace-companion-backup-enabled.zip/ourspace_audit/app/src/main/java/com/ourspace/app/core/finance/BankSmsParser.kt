package com.ourspace.app.core.finance

/**
 * پارس پیامک بانکی ایران با دو لایه:
 * 1) قالب‌های ساخت‌یافته بانک‌ها (دقت بالا)
 * 2) قواعد عمومی (پوشش پیامک‌های ناشناخته)
 *
 * فقط روی دستگاه اجرا می‌شود؛ متن پیامک به سرور نمی‌رود.
 */
object BankSmsParser {

    data class ParsedSmsTransaction(
        val amount: Long,
        val kind: String, // EXPENSE / INCOME
        val category: String,
        val note: String,
        val confidence: Float,
        /** نام قالب تطبیق‌یافته؛ برای دیباگ و تنظیمات بعدی */
        val templateId: String = "generic",
        /** تاریخ/ساعت خود تراکنش، اگر از پیامک قابل استخراج باشد. */
        val transactionDateMillis: Long? = null,
        /** داده‌های استخراج‌شدهٔ دیگر مثل مانده، تاریخ و ساعت. */
        val extras: Map<String, String> = emptyMap()
    )

    /**
     * قالب یک بانک/نوع پیام.
     * @param id شناسه پایدار
     * @param bankLabel نام نمایشی بانک
     * @param addressHints بخشی از شماره فرستنده (اختیاری)
     * @param bodyMustContain حداقل یکی از این‌ها در متن باشد
     * @param amountRegex الگوی مبلغ؛ گروه ۱ = عدد
     * @param kind ثابت یا از کلمات متن
     * @param amountIsRial اگر true و واحد ریال باشد ÷۱۰ به تومان
     */
    data class SmsTemplate(
        val id: String,
        val bankLabel: String,
        val addressHints: List<String> = emptyList(),
        val bodyMustContain: List<String> = emptyList(),
        val amountRegex: Regex,
        val forceKind: String? = null, // EXPENSE / INCOME / null=auto
        val preferRialDivision: Boolean = true,
        val confidence: Float = 0.92f
    )

    // --- قالب‌های رایج (قابل گسترش) ---
    private val templates: List<SmsTemplate> = listOf(
        // بانک ملت
        SmsTemplate(
            id = "mellat_withdraw",
            bankLabel = "ملت",
            addressHints = listOf("mellat", "bmellat", "56144"),
            bodyMustContain = listOf("برداشت", "خرید"),
            amountRegex = Regex("""(?:مبلغ|برداشت|خرید)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "EXPENSE"
        ),
        SmsTemplate(
            id = "mellat_deposit",
            bankLabel = "ملت",
            addressHints = listOf("mellat", "bmellat", "56144"),
            bodyMustContain = listOf("واریز"),
            amountRegex = Regex("""(?:واریز|مبلغ)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "INCOME"
        ),
        // بانک ملی
        SmsTemplate(
            id = "melli_expense",
            bankLabel = "ملی",
            addressHints = listOf("bmi", "melli", "3000", "9999"),
            bodyMustContain = listOf("برداشت", "خرید", "پرداخت"),
            amountRegex = Regex("""(?:مبلغ|برداشت)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "EXPENSE"
        ),
        SmsTemplate(
            id = "melli_income",
            bankLabel = "ملی",
            addressHints = listOf("bmi", "melli"),
            bodyMustContain = listOf("واریز"),
            amountRegex = Regex("""(?:واریز|مبلغ)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "INCOME"
        ),
        // سامان
        SmsTemplate(
            id = "saman_expense",
            bankLabel = "سامان",
            addressHints = listOf("saman", "7040"),
            bodyMustContain = listOf("برداشت", "خرید", "پرداخت"),
            amountRegex = Regex("""(?:مبلغ|برداشت|خرید)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "EXPENSE"
        ),
        SmsTemplate(
            id = "saman_income",
            bankLabel = "سامان",
            addressHints = listOf("saman"),
            bodyMustContain = listOf("واریز"),
            amountRegex = Regex("""(?:واریز|مبلغ)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "INCOME"
        ),
        // پاسارگاد
        SmsTemplate(
            id = "pasargad_expense",
            bankLabel = "پاسارگاد",
            addressHints = listOf("pasargad", "bpi"),
            bodyMustContain = listOf("برداشت", "خرید", "پرداخت"),
            amountRegex = Regex("""(?:مبلغ|برداشت)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "EXPENSE"
        ),
        SmsTemplate(
            id = "pasargad_income",
            bankLabel = "پاسارگاد",
            addressHints = listOf("pasargad", "bpi"),
            bodyMustContain = listOf("واریز"),
            amountRegex = Regex("""(?:واریز|مبلغ)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "INCOME"
        ),
        // صادرات / تجارت / کشاورزی / مسکن / شهر / رسالت / آینده / دی / پارسیان
        SmsTemplate(
            id = "generic_bank_expense",
            bankLabel = "بانک",
            bodyMustContain = listOf("برداشت", "خرید", "پرداخت از", "کسر از"),
            amountRegex = Regex("""(?:مبلغ|برداشت|خرید|پرداخت)[^\d]{0,14}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "EXPENSE",
            confidence = 0.85f
        ),
        SmsTemplate(
            id = "generic_bank_income",
            bankLabel = "بانک",
            bodyMustContain = listOf("واریز به حساب", "واریزی", "وجه واریز"),
            amountRegex = Regex("""(?:واریز|مبلغ)[^\d]{0,14}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "INCOME",
            confidence = 0.85f
        ),
        // بلوبانک
        SmsTemplate(
            id = "blu_expense",
            bankLabel = "بلو",
            addressHints = listOf("blu", "blubank"),
            bodyMustContain = listOf("برداشت", "خرید", "پرداخت"),
            amountRegex = Regex("""(?:مبلغ|برداشت|خرید)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "EXPENSE"
        ),
        SmsTemplate(
            id = "blu_income",
            bankLabel = "بلو",
            addressHints = listOf("blu", "blubank"),
            bodyMustContain = listOf("واریز"),
            amountRegex = Regex("""(?:واریز|مبلغ)[^\d]{0,12}([\d٬,\s]+)""", RegexOption.IGNORE_CASE),
            forceKind = "INCOME"
        )
    )

    private val bankHints = listOf(
        "بانک", "ملت", "ملی", "سامان", "پاسارگاد", "صادرات", "تجارت", "کشاورزی",
        "مسکن", "شهر", "رسالت", "آینده", "سینا", "دی", "اقتصاد", "پارسیان",
        "کارآفرین", "گردشگری", "ایران‌زمین", "ایران زمین", "قرض‌الحسنه", "مهر",
        "سپه", "رفاه", "انصار", "حکمت", "خاورمیانه", "blu", "blubank", "saman",
        "mellat", "melli", "pasargad", "tejarat", "saderat", "bmi", "bank"
    )

    private val expenseKeywords = listOf(
        "برداشت", "خرید", "پرداخت", "کسر", "برداشت از", "خرج",
        "انتقال به", "pos", "خرید اینترنتی", "قبض", "کارمزد", "برداشت وجه"
    )

    private val incomeKeywords = listOf(
        "واریز", "واریزی", "دریافت", "سپرده", "حقوق", "عودت", "برگشت",
        "واریز به حساب", "وجه واریز", "deposit", "credit"
    )

    /** کلمات نزدیک موجودی — تا با مبلغ تراکنش اشتباه نشود */
    private val balanceWords = listOf("موجودی", "مانده", "بالانس", "balance", "باقیمانده")

    fun looksLikeBankSms(body: String, address: String = ""): Boolean {
        val text = normalizeDigits(body).lowercase()
        val addr = address.lowercase()
        if (bankHints.any { text.contains(it.lowercase()) || addr.contains(it.lowercase()) }) return true
        if (expenseKeywords.any { text.contains(it) }) return true
        if (incomeKeywords.any { text.contains(it) }) return true
        if (extractAmount(body) != null && (text.contains("موجودی") || text.contains("حساب") || text.contains("مانده"))) {
            return true
        }
        return false
    }

    fun parse(body: String, address: String = "", context: android.content.Context? = null): ParsedSmsTransaction? {
        if (body.isBlank()) return null
        // اول قالب‌های کاربر
        if (context != null) {
            SmsTemplateStore.tryParse(context, body, address)?.let { return it }
        }
        // قالب فشرده بانک مهر و مشابه: مبلغ با علامت +/− در خط جدا + مانده
        parseSignedLineStyle(body, address)?.let { return it }
        if (!looksLikeBankSms(body, address)) return null

        // لایه ۱: قالب ساخت‌یافته
        matchTemplate(body, address)?.let { return it }

        // لایه ۲: قواعد عمومی
        val amount = extractAmountPreferTransaction(body) ?: return null
        if (amount <= 0L) return null

        val lower = normalizeDigits(body).lowercase()
        val strongExpense = listOf("برداشت", "خرید", "پرداخت", "کسر", "کارمزد", "pos")
            .any { lower.contains(it) }
        val strongIncome = listOf("واریز به حساب شما", "واریزی", "وجه واریز شده", "دریافت وجه", "واریز به حساب")
            .any { lower.contains(it) }
        val isIncome = incomeKeywords.any { lower.contains(it) } &&
            !expenseKeywords.any { lower.contains(it) && it != "واریز به" }

        val kind = when {
            strongExpense && !strongIncome -> "EXPENSE"
            strongIncome && !strongExpense -> "INCOME"
            isIncome && !strongExpense -> "INCOME"
            else -> "EXPENSE"
        }

        val category = guessCategory(body, kind)
        val bank = bankHints.firstOrNull { body.contains(it, ignoreCase = true) }
        val note = buildNote(body, address, bank)
        val confidence = when {
            strongExpense || strongIncome -> 0.88f
            bank != null -> 0.72f
            else -> 0.55f
        }

        return ParsedSmsTransaction(
            amount = amount,
            kind = kind,
            category = category,
            note = note,
            confidence = confidence,
            templateId = "generic"
        )
    }

    /**
     * قالب بانک مهر (و مشابه):
     * 49,500,000+
     * مانده:294,046,569
     */
    fun parseSignedLineStyle(body: String, address: String = ""): ParsedSmsTransaction? {
        val norm = normalizeDigits(body)
            .replace("\u200e", "")
            .replace("\u200f", "")
            .replace("\u202a", "")
            .replace("\u202c", "")
        val hasBalance = norm.contains("مانده") || norm.contains("موجودی")
        val signedRe = Regex("""(?m)^[\s\u200e\u200f]*([\d,٬]{3,})([+\-−])[\s\u200e\u200f]*$""")
        if (!signedRe.containsMatchIn(norm)) return null
        if (!hasBalance && !address.lowercase().contains("mehr") && !norm.contains("مهر")) {
            return null
        }
        val amountLine = signedRe.findAll(norm).firstOrNull { match ->
            val lineStart = norm.lastIndexOf('\n', match.range.first).let { if (it < 0) 0 else it + 1 }
            val lineEnd = norm.indexOf('\n', match.range.last).let { if (it < 0) norm.length else it }
            val line = norm.substring(lineStart, lineEnd)
            !line.contains("مانده") && !line.contains("موجودی")
        } ?: return null
        val raw = amountLine.groupValues.getOrNull(1) ?: return null
        val sign = amountLine.groupValues.getOrNull(2) ?: return null
        var value = parseNumber(raw) ?: return null
        if (value <= 0L) return null
        if (value >= 1_000L) value = value / 10L
        if (value <= 0L || value > 50_000_000_000L) return null
        val kind = if (sign == "+") "INCOME" else "EXPENSE"
        val bank = when {
            address.lowercase().contains("mehr") || norm.contains("مهر") -> "مهر"
            else -> bankHints.firstOrNull { norm.contains(it, ignoreCase = true) } ?: "مهر"
        }
        return ParsedSmsTransaction(
            amount = value,
            kind = kind,
            category = guessCategory(norm, kind),
            note = buildNote(body, address, bank),
            confidence = 0.96f,
            templateId = "mehr_signed_line"
        )
    }

    private fun matchTemplate(body: String, address: String): ParsedSmsTransaction? {
        val norm = normalizeDigits(body)
        val lower = norm.lowercase()
        val addr = address.lowercase()

        for (t in templates) {
            val addrOk = t.addressHints.isEmpty() || t.addressHints.any { addr.contains(it) || lower.contains(it) }
            if (!addrOk && t.addressHints.isNotEmpty()) {
                // اگر آدرس نخورد ولی نام بانک در متن باشد، باز هم مجاز
                if (!lower.contains(t.bankLabel.lowercase()) && !t.bodyMustContain.any { lower.contains(it.lowercase()) }) {
                    continue
                }
            }
            if (t.bodyMustContain.isNotEmpty() && t.bodyMustContain.none { lower.contains(it.lowercase()) }) {
                continue
            }
            val m = t.amountRegex.find(norm) ?: continue
            val raw = m.groupValues.getOrNull(1) ?: continue
            val value = parseNumber(raw) ?: continue
            if (value <= 0L) continue

            val windowStart = (m.range.first - 16).coerceAtLeast(0)
            val windowEnd = (m.range.last + 16).coerceAtMost(norm.length - 1) + 1
            val window = norm.substring(windowStart, windowEnd).lowercase()
            // رد کردن اگر این عدد در واقع «موجودی» باشد
            if (balanceWords.any { window.contains(it) } && !window.contains("مبلغ") && !window.contains("برداشت") && !window.contains("واریز")) {
                continue
            }
            val isRial = window.contains("ریال") || window.contains("rial") || window.contains("rls")
            var toman = value
            // بانک مهر و بعضی بانک‌ها بدون نوشتن «ریال» مبلغ را ریال می‌فرستند
            val forceRial = t.preferRialDivision && (isRial || t.id.startsWith("mehr") || t.id.contains("signed"))
            if (forceRial && value >= 1_000L) {
                toman = value / 10
            }
            if (toman <= 0L || toman > 50_000_000_000L) continue

            val sign = m.groupValues.getOrNull(2)?.trim().orEmpty()
            val kind = when {
                t.forceKind != null -> t.forceKind!!
                sign == "+" -> "INCOME"
                sign == "-" || sign == "−" -> "EXPENSE"
                else -> detectKind(lower)
            }
            return ParsedSmsTransaction(
                amount = toman,
                kind = kind,
                category = guessCategory(body, kind),
                note = buildNote(body, address, t.bankLabel),
                confidence = t.confidence,
                templateId = t.id
            )
        }
        return null
    }

    private fun detectKind(lower: String): String {
        val strongExpense = listOf("برداشت", "خرید", "پرداخت", "کسر", "کارمزد").any { lower.contains(it) }
        val strongIncome = listOf("واریز", "واریزی", "دریافت").any { lower.contains(it) }
        return when {
            strongExpense && !strongIncome -> "EXPENSE"
            strongIncome && !strongExpense -> "INCOME"
            strongIncome -> "INCOME"
            else -> "EXPENSE"
        }
    }

    private fun buildNote(body: String, address: String, bank: String?): String {
        return buildString {
            append("از پیامک")
            if (!bank.isNullOrBlank()) append(" · $bank")
            if (address.isNotBlank()) append(" · $address")
            val short = body.replace("\n", " ").trim().take(120)
            if (short.isNotBlank()) append(" · $short")
        }.take(500)
    }

    fun extractAmount(body: String): Long? = extractAmountPreferTransaction(body)

    /**
     * مبلغ تراکنش را ترجیح می‌دهد نه موجودی حساب.
     */
    fun extractAmountPreferTransaction(body: String): Long? {
        val normalized = normalizeDigits(body)
        val patterns = listOf(
            Regex("""(?:مبلغ|برداشت|واریز|خرید|پرداخت)\s*[:：]?\s*([0-9][0-9٬,\s]{2,})\s*(?:ریال|تومان|rls|rial)?""", RegexOption.IGNORE_CASE),
            Regex("""([0-9][0-9٬,\s]{3,})\s*(?:ریال|تومان)""", RegexOption.IGNORE_CASE)
        )

        val candidates = mutableListOf<Triple<Long, Boolean, Int>>() // toman, nearBalance, priority
        for ((idx, pattern) in patterns.withIndex()) {
            for (match in pattern.findAll(normalized)) {
                val raw = match.groupValues.getOrNull(1) ?: continue
                val value = parseNumber(raw) ?: continue
                if (value <= 0L || value > 50_000_000_000L) continue
                val window = normalized.substring(
                    (match.range.first - 14).coerceAtLeast(0),
                    (match.range.last + 14).coerceAtMost(normalized.length - 1) + 1
                ).lowercase()
                val nearBalance = balanceWords.any { window.contains(it) }
                val isRial = window.contains("ریال") || window.contains("rial") || window.contains("rls")
                val toman = if (isRial && value >= 1000L) value / 10 else value
                val priority = when {
                    window.contains("مبلغ") || window.contains("برداشت") || window.contains("واریز") -> 3
                    idx == 0 -> 2
                    else -> 1
                }
                candidates += Triple(toman, nearBalance, priority)
            }
        }

        if (candidates.isEmpty()) {
            val all = Regex("""\b([0-9]{4,12})\b""").findAll(normalized)
                .mapNotNull { it.groupValues[1].toLongOrNull() }
                .filter { it in 1_000L..9_999_999_999L }
                .toList()
            return all.maxOrNull()
        }

        // اول غیرموجودی با اولویت بالا
        val preferred = candidates
            .filter { !it.second }
            .maxWithOrNull(compareBy<Triple<Long, Boolean, Int>> { it.third }.thenBy { it.first })
        if (preferred != null) return preferred.first
        return candidates.maxByOrNull { it.first }?.first
    }

    private fun parseNumber(raw: String): Long? {
        val digits = raw.replace(Regex("""[,،\s\u066C\u060C٬]"""), "")
        return digits.toLongOrNull()
    }

    fun normalizeDigitsPublic(body: String): String = normalizeDigits(body)

    fun parseNumberPublic(raw: String): Long? = parseNumber(raw)

    fun guessKindPublic(body: String): String {
        val b = body.lowercase()
        return when {
            listOf("واریز", "دریافت", "بستانکار", "deposit", "credit").any { b.contains(it) } &&
                !listOf("برداشت", "خرید", "پرداخت").any { b.contains(it) } -> "INCOME"
            else -> "EXPENSE"
        }
    }

    private fun normalizeDigits(body: String): String {
        return body
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3')
            .replace('۴', '4').replace('۵', '5').replace('۶', '6').replace('۷', '7')
            .replace('۸', '8').replace('۹', '9')
            .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3')
            .replace('٤', '4').replace('٥', '5').replace('٦', '6').replace('٧', '7')
            .replace('٨', '8').replace('٩', '9')
    }

    private fun guessCategory(body: String, kind: String): String {
        if (kind == "INCOME") {
            return when {
                body.contains("حقوق") -> "حقوق"
                body.contains("پاداش") -> "پاداش"
                else -> "سایر"
            }
        }
        return when {
            body.contains("سوپر") || body.contains("فروشگاه") || body.contains("هایپر") -> "خوراک"
            body.contains("اسنپ") || body.contains("تپسی") || body.contains("بنزین") || body.contains("metro") -> "رفت‌وآمد"
            body.contains("دارو") || body.contains("بیمارستان") || body.contains("درمان") -> "سلامت"
            body.contains("اجاره") || body.contains("برق") || body.contains("گاز") || body.contains("آب") -> "خانه"
            body.contains("سینما") || body.contains("کافه") -> "تفریح"
            else -> "سایر"
        }
    }
}
