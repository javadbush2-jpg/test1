package com.ourspace.app.core.finance

import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.database.FinancialAccountEntity

/** A confirmed bank-SMS transaction, optionally carrying the bank's post-transaction balance. */
data class SmsFinanceImport(
    val accountId: String,
    val kind: String,
    val amount: Long,
    val category: String,
    val note: String,
    val occurredAt: Long,
    val reportedBalanceToman: Long? = null,
    val sourceSmsId: String = "",
    val pendingSmsId: String = "",
    val pendingSmsKey: String = ""
)

data class SmsBalanceCheck(
    val accountId: String,
    val accountName: String,
    val occurredAt: Long,
    val kind: String,
    val transactionAmount: Long,
    val localBalanceBefore: Long,
    val bankImpliedPreviousBalance: Long,
    val expectedBalanceAfter: Long,
    val reportedBalance: Long,
    /** Positive means the bank reports more than the ledger expected. */
    val difference: Long
)

data class SmsBalanceAdjustment(
    val accountId: String,
    val accountName: String,
    val statementDate: Long,
    val reportedBalance: Long,
    val difference: Long,
    val correctedOpeningBalance: Long
)

data class FinanceBalanceReconciliation(
    val checks: List<SmsBalanceCheck> = emptyList(),
    val adjustments: List<SmsBalanceAdjustment> = emptyList()
) {
    val hasDiscrepancies: Boolean get() = checks.any { it.difference != 0L }
    val hasBalanceAdjustments: Boolean get() = adjustments.any { it.difference != 0L }
}

/**
 * Reconciles each account independently. A bank balance in a message is the balance AFTER that
 * message's transaction. Differences are reported and applied as a change to openingBalance, so
 * historical transactions remain intact and later transactions continue to move the corrected
 * balance normally.
 */
object FinanceBalanceReconciler {
    fun reconcile(
        accounts: List<FinancialAccountEntity>,
        transactions: List<FinanceTransactionEntity>,
        imports: List<SmsFinanceImport>
    ): FinanceBalanceReconciliation {
        val activeAccounts = accounts.filter { !it.isDeleted && !it.isArchived }.associateBy { it.id }
        val validImports = imports.withIndex()
            .filter { (_, row) -> row.accountId in activeAccounts && row.amount > 0L }
            .sortedWith(compareBy<IndexedValue<SmsFinanceImport>> { it.value.occurredAt }.thenBy { it.index })
        if (validImports.isEmpty()) return FinanceBalanceReconciliation()

        val checks = validImports.mapNotNull { current ->
            val row = current.value
            val reported = row.reportedBalanceToman ?: return@mapNotNull null
            val account = activeAccounts[row.accountId] ?: return@mapNotNull null
            val existingEffectBefore = transactions.asSequence()
                .filter { !it.isDeleted && it.occurredAt < row.occurredAt }
                .sumOf { effectOnAccount(row.accountId, it) }
            val priorImportedEffect = validImports.asSequence()
                .filter { earlier ->
                    earlier.value.accountId == row.accountId &&
                        earlier.value.occurredAt <= row.occurredAt &&
                        (earlier.value.occurredAt < row.occurredAt || earlier.index < current.index)
                }
                .sumOf { transactionEffect(it.value.kind, it.value.amount) }
            val localBefore = account.openingBalance + existingEffectBefore + priorImportedEffect
            val expectedAfter = localBefore + transactionEffect(row.kind, row.amount)
            SmsBalanceCheck(
                accountId = account.id,
                accountName = account.name,
                occurredAt = row.occurredAt,
                kind = row.kind,
                transactionAmount = row.amount,
                localBalanceBefore = localBefore,
                bankImpliedPreviousBalance = reported - transactionEffect(row.kind, row.amount),
                expectedBalanceAfter = expectedAfter,
                reportedBalance = reported,
                difference = reported - expectedAfter
            )
        }

        val adjustments = activeAccounts.values.mapNotNull { account ->
            val latest = validImports.lastOrNull {
                it.value.accountId == account.id && it.value.reportedBalanceToman != null
            } ?: return@mapNotNull null
            val row = latest.value
            val statementBalance = row.reportedBalanceToman ?: return@mapNotNull null
            val existingEffectAtStatement = transactions.asSequence()
                .filter { !it.isDeleted && it.occurredAt <= row.occurredAt }
                .sumOf { effectOnAccount(account.id, it) }
            val importedEffectAtStatement = validImports.asSequence()
                .filter { imported ->
                    imported.value.accountId == account.id &&
                        (imported.value.occurredAt < row.occurredAt ||
                            (imported.value.occurredAt == row.occurredAt && imported.index <= latest.index))
                }
                .sumOf { transactionEffect(it.value.kind, it.value.amount) }
            val calculatedAtStatement = account.openingBalance + existingEffectAtStatement + importedEffectAtStatement
            val difference = statementBalance - calculatedAtStatement
            SmsBalanceAdjustment(
                accountId = account.id,
                accountName = account.name,
                statementDate = row.occurredAt,
                reportedBalance = statementBalance,
                difference = difference,
                correctedOpeningBalance = account.openingBalance + difference
            )
        }

        return FinanceBalanceReconciliation(checks = checks, adjustments = adjustments)
    }

    private fun transactionEffect(kind: String, amount: Long): Long =
        if (kind.equals("INCOME", ignoreCase = true)) amount.coerceAtLeast(0L)
        else -amount.coerceAtLeast(0L)

    private fun effectOnAccount(accountId: String, transaction: FinanceTransactionEntity): Long {
        val amount = transaction.amount.coerceAtLeast(0L)
        return when {
            transaction.kind.equals("TRANSFER", ignoreCase = true) && transaction.targetAccountId == accountId -> amount
            transaction.kind.equals("INCOME", ignoreCase = true) && transaction.accountId == accountId -> amount
            transaction.accountId == accountId -> -amount
            else -> 0L
        }
    }
}
