package com.ourspace.app.core.sync

import android.graphics.BitmapFactory
import android.content.Context
import androidx.room.withTransaction
import com.ourspace.app.core.attachment.AttachmentIntegrity
import com.ourspace.app.core.finance.CategoryPreferences
import com.ourspace.app.core.finance.FinancialAssetsStore
import com.ourspace.app.core.finance.SmsTemplateStore
import com.ourspace.app.core.database.AttachmentEntity
import com.ourspace.app.core.database.CoupleProfileEntity
import com.ourspace.app.core.database.EventEntity
import com.ourspace.app.core.database.FinanceBudgetEntity
import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.database.RecurringTransactionEntity
import com.ourspace.app.core.database.SharedDebtEntity
import com.ourspace.app.core.database.MemoryEntity
import com.ourspace.app.core.database.MessageEntity
import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.HeartPulseEntity
import com.ourspace.app.core.database.SharedPlaceEntity
import com.ourspace.app.core.database.HabitEntity
import com.ourspace.app.core.database.WatchlistItemEntity
import com.ourspace.app.core.database.FoodItemEntity
import com.ourspace.app.core.database.BookItemEntity
import com.ourspace.app.core.database.LocationShareEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import com.ourspace.app.core.database.MoodCheckInEntity
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.database.ShoppingItemEntity
import com.ourspace.app.core.database.SpecialDateEntity
import com.ourspace.app.core.database.TaskEntity
import com.ourspace.app.core.database.TelegramStickerEntity
import com.ourspace.app.core.database.TelegramStickerPackEntity
import com.ourspace.app.core.telegram.TelegramStickerClient
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject

class SyncSnapshotCodec(private val database: OurSpaceDatabase, private val context: Context? = null) {
    private val workSchedulePrefsName = "work_hours_schedule_v1"
    private fun shouldApply(entityType: String, entityId: String, incomingUpdatedAt: Long, localUpdatedAt: Long?, forceEqualKeys: Set<String>): Boolean =
        localUpdatedAt == null || incomingUpdatedAt > localUpdatedAt ||
            (incomingUpdatedAt == localUpdatedAt && "$entityType:$entityId" in forceEqualKeys)

    suspend fun exportSnapshot(
        includeAttachments: Boolean = true,
        schemaVersion: Int = 6
    ): JSONObject = database.withTransaction {
        require(schemaVersion in 4..6)
        val snapshot = JSONObject()
        .put("schema", schemaVersion)
        .put("generatedAt", System.currentTimeMillis())
        .put("tasks", JSONArray().apply { database.taskDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("events", JSONArray().apply { database.eventDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("shopping", JSONArray().apply { database.shoppingDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("messages", JSONArray().apply { database.messageDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("financialAccounts", JSONArray().apply { database.financialAccountDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("financeTransactions", JSONArray().apply { database.financeTransactionDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("financeCategories", JSONArray().apply {
            context?.let { appContext -> CategoryPreferences.exportAllSyncRecords(appContext).forEach { put(it) } }
        })
        .put("financialAssets", JSONArray().apply {
            context?.let { appContext -> FinancialAssetsStore.exportAllSyncRecords(appContext).forEach { put(it) } }
        })
        .put("smsTemplates", JSONArray().apply {
            context?.let { appContext -> SmsTemplateStore.exportAllSyncRecords(appContext).forEach { put(it) } }
        })
        .put("financeBudgets", JSONArray().apply { database.financeBudgetDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("memories", JSONArray().apply { database.memoryDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("moodCheckIns", JSONArray().apply { database.moodCheckInDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("specialDates", JSONArray().apply { database.specialDateDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("cycleLogs", JSONArray().apply { database.cycleLogDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("cycleSettings", JSONArray().apply { database.cycleSettingsDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("locationShares", JSONArray().apply { database.locationShareDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("heartPulses", JSONArray().apply { database.heartPulseDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("sharedPlaces", JSONArray().apply { database.sharedPlaceDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("habits", JSONArray().apply { database.habitDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("watchlistItems", JSONArray().apply { database.watchlistDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("foodItems", JSONArray().apply { database.foodDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("bookItems", JSONArray().apply { database.bookDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("coupleProfile", JSONArray().apply { database.coupleProfileDao().getAllOnce().forEach { put(it.toJson()) } })
        .put("telegramStickerPacks", JSONArray().apply {
            database.telegramStickerPackDao().getAllForSync().forEach { put(it.toStickerSyncJson()) }
        })
        .put("workScheduleSettings", context?.getSharedPreferences(workSchedulePrefsName, Context.MODE_PRIVATE)?.let { prefs ->
            JSONObject().put("profiles", prefs.getString("profiles", "[]") ?: "[]")
                .put("exceptions", prefs.getString("exceptions", "[]") ?: "[]")
        } ?: JSONObject())
        if (schemaVersion >= 6) {
            snapshot.put("sharedDebts", JSONArray().apply {
                database.sharedDebtDao().getAllOnce().forEach { put(it.toJson()) }
            })
            snapshot.put("recurringTransactions", JSONArray().apply {
                database.recurringTransactionDao().getAllOnce().forEach { put(it.toJson()) }
            })
        }
        if (includeAttachments && schemaVersion >= 5) {
            snapshot.put(
                "attachments",
                JSONArray().apply { database.attachmentDao().getAllOnce().forEach { put(it.toSyncJson()) } }
            )
            // Pairing snapshots omit binaries; migrated sticker rows then use the bounded
            // incremental lane (each Telegram sticker is capped at 2 MiB). Encrypted backups
            // opt into both attachments and sticker content through this flag.
            snapshot.put("telegramStickers", JSONArray().apply {
                database.telegramStickerDao().getAllForSync().forEach { put(it.toStickerSyncJson()) }
            })
        }
        snapshot
    }

    suspend fun mergeSnapshot(
        snapshot: JSONObject,
        forceEqualKeys: Set<String> = emptySet(),
        senderDeviceIdRemap: Map<String, String> = emptyMap()
    ) = database.withTransaction {
        require(snapshot.optInt("schema") in 1..6) { "Unsupported sync schema" }
        database.syncRuntimeControlDao().setSuppressOutbox(true)
        try {
        remapBackupMessageDeviceIds(snapshot, senderDeviceIdRemap)
        snapshot.optJSONArray("tasks")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toTask()
            val localUpdatedAt = database.taskDao().updatedAt(incoming.id)
            if (shouldApply("tasks", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.taskDao().upsert(incoming)
        }
        snapshot.optJSONArray("events")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toEvent()
            val localUpdatedAt = database.eventDao().updatedAt(incoming.id)
            if (shouldApply("events", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.eventDao().upsert(incoming)
        }
        snapshot.optJSONArray("shopping")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toShopping()
            val localUpdatedAt = database.shoppingDao().updatedAt(incoming.id)
            if (shouldApply("shopping", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.shoppingDao().upsert(incoming)
        }
        snapshot.optJSONArray("messages")?.forEachObject(MAX_MESSAGES) { json ->
            mergeMessage(json.toMessage(), "messages:${json.getString("id")}" in forceEqualKeys)
        }
        snapshot.optJSONArray("financialAccounts")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toFinancialAccount()
            val localUpdatedAt = database.financialAccountDao().updatedAt(incoming.id)
            if (shouldApply("financialAccounts", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) {
                database.financialAccountDao().upsert(incoming)
            }
        }
        snapshot.optJSONArray("financeTransactions")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toFinanceTransaction()
            val localUpdatedAt = database.financeTransactionDao().updatedAt(incoming.id)
            if (shouldApply("financeTransactions", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) {
                database.financeTransactionDao().upsert(incoming)
            }
        }
        snapshot.optJSONArray("financeCategories")?.forEachObject(MAX_ITEMS) { json ->
            val id = json.optString("id")
            val incomingUpdatedAt = json.optLong("updatedAt", -1L)
            val localUpdatedAt = CategoryPreferences.syncRecordUpdatedAt(context, id)
            if (id.isNotBlank() && incomingUpdatedAt >= 0L &&
                shouldApply("financeCategories", id, incomingUpdatedAt, localUpdatedAt, forceEqualKeys)
            ) {
                CategoryPreferences.applySyncedRecord(context, json)
            }
        }
        snapshot.optJSONArray("financialAssets")?.forEachObject(1) { json ->
            val id = json.optString("id")
            val incomingUpdatedAt = json.optLong("updatedAt", -1L)
            val localUpdatedAt = FinancialAssetsStore.syncRecordUpdatedAt(context, id)
            if (id.isNotBlank() && incomingUpdatedAt >= 0L &&
                shouldApply("financialAssets", id, incomingUpdatedAt, localUpdatedAt, forceEqualKeys)
            ) {
                FinancialAssetsStore.applySyncedRecord(context, json)
            }
        }
        snapshot.optJSONArray("smsTemplates")?.forEachObject(MAX_ITEMS) { json ->
            val id = json.optString("id")
            val incomingUpdatedAt = json.optLong("updatedAt", -1L)
            val localUpdatedAt = SmsTemplateStore.syncRecordUpdatedAt(context, id)
            if (id.isNotBlank() && incomingUpdatedAt >= 0L &&
                shouldApply("smsTemplates", id, incomingUpdatedAt, localUpdatedAt, forceEqualKeys)
            ) {
                SmsTemplateStore.applySyncedRecord(context, json)
            }
        }
        snapshot.optJSONArray("financeBudgets")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toFinanceBudget()
            val localUpdatedAt = database.financeBudgetDao().updatedAt(incoming.id)
            if (shouldApply("financeBudgets", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) {
                database.financeBudgetDao().upsert(incoming)
            }
        }
        snapshot.optJSONArray("sharedDebts")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toSharedDebt()
            val localUpdatedAt = database.sharedDebtDao().updatedAt(incoming.id)
            if (shouldApply("sharedDebts", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.sharedDebtDao().upsert(incoming)
        }
        snapshot.optJSONArray("recurringTransactions")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toRecurringTransaction()
            val localUpdatedAt = database.recurringTransactionDao().updatedAt(incoming.id)
            if (shouldApply("recurringTransactions", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) {
                database.recurringTransactionDao().upsert(incoming)
            }
        }
        snapshot.optJSONArray("memories")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toMemory()
            val localUpdatedAt = database.memoryDao().updatedAt(incoming.id)
            if (shouldApply("memories", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.memoryDao().upsert(incoming)
        }
        snapshot.optJSONArray("moodCheckIns")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toMoodCheckIn()
            val localUpdatedAt = database.moodCheckInDao().updatedAt(incoming.id)
            if (shouldApply("moodCheckIns", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.moodCheckInDao().upsert(incoming)
        }
        snapshot.optJSONArray("specialDates")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toSpecialDate()
            val localUpdatedAt = database.specialDateDao().updatedAt(incoming.id)
            if (shouldApply("specialDates", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.specialDateDao().upsert(incoming)
        }
        snapshot.optJSONArray("cycleLogs")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toCycleLog()
            val localUpdatedAt = database.cycleLogDao().updatedAt(incoming.id)
            if (shouldApply("cycleLogs", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.cycleLogDao().upsert(incoming)
        }
        snapshot.optJSONArray("cycleSettings")?.forEachObject(1) { json ->
            val incoming = json.toCycleSettings()
            val localUpdatedAt = database.cycleSettingsDao().updatedAt(incoming.id)
            if (shouldApply("cycleSettings", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.cycleSettingsDao().upsert(incoming)
        }
        snapshot.optJSONArray("locationShares")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toLocationShare()
            val localUpdatedAt = database.locationShareDao().updatedAt(incoming.id)
            if (shouldApply("locationShares", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.locationShareDao().upsert(incoming)
        }
        snapshot.optJSONArray("heartPulses")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toHeartPulse()
            val localUpdatedAt = database.heartPulseDao().updatedAt(incoming.id)
            if (shouldApply("heartPulses", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.heartPulseDao().upsert(incoming)
        }
        snapshot.optJSONArray("habits")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toHabit()
            val localUpdatedAt = database.habitDao().updatedAt(incoming.id)
            if (shouldApply("habits", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.habitDao().upsert(incoming)
        }
        snapshot.optJSONArray("watchlistItems")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toWatchlistItem()
            val localUpdatedAt = database.watchlistDao().updatedAt(incoming.id)
            if (shouldApply("watchlistItems", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.watchlistDao().upsert(incoming)
        }
        snapshot.optJSONArray("foodItems")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toFoodItem()
            val localUpdatedAt = database.foodDao().updatedAt(incoming.id)
            if (shouldApply("foodItems", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.foodDao().upsert(incoming)
        }

        snapshot.optJSONArray("bookItems")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toBookItem()
            val localUpdatedAt = database.bookDao().updatedAt(incoming.id)
            if (shouldApply("bookItems", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.bookDao().upsert(incoming)
        }
        snapshot.optJSONArray("sharedPlaces")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toSharedPlace()
            val localUpdatedAt = database.sharedPlaceDao().updatedAt(incoming.id)
            if (shouldApply("sharedPlaces", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.sharedPlaceDao().upsert(incoming)
        }
        snapshot.optJSONArray("coupleProfile")?.forEachObject(1) { json ->
            val incoming = json.toCoupleProfile()
            val localUpdatedAt = database.coupleProfileDao().updatedAt(incoming.id)
            if (shouldApply("coupleProfile", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) database.coupleProfileDao().upsert(incoming)
        }
        snapshot.optJSONArray("telegramStickerPacks")?.forEachObject(MAX_ITEMS) { json ->
            val incoming = json.toTelegramStickerPack()
            val localUpdatedAt = database.telegramStickerPackDao().updatedAt(incoming.name)
            if (shouldApply("telegramStickerPacks", incoming.name, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) {
                database.telegramStickerPackDao().upsert(incoming)
                if (incoming.isDeleted) database.telegramStickerDao().deleteByPack(incoming.name)
            }
        }
        snapshot.optJSONArray("telegramStickers")?.forEachObject(MAX_TELEGRAM_STICKERS) { json ->
            val incoming = json.toTelegramSticker()
            val pack = database.telegramStickerPackDao().findByName(incoming.packName)
            // A removal tombstone wins over an older queued binary; do not let retries resurrect it.
            if (pack?.isDeleted == true) return@forEachObject
            val localUpdatedAt = database.telegramStickerDao().updatedAt(incoming.id)
            if (shouldApply("telegramStickers", incoming.id, incoming.updatedAt, localUpdatedAt, forceEqualKeys)) {
                database.telegramStickerDao().upsert(incoming)
            }
        }
        snapshot.optJSONArray("attachments")?.forEachObject(MAX_ATTACHMENTS) { json ->
            mergeAttachment(json.toAttachment(), "attachments:${json.getString("id")}" in forceEqualKeys)
        }
        } finally {
            database.syncRuntimeControlDao().setSuppressOutbox(false)
        }
        // Work schedule templates are device preferences rather than Room entities. Carry them
        // through full snapshot exchange and encrypted backup/restore without breaking old peers.
        snapshot.optJSONObject("workScheduleSettings")?.let { settings ->
            context?.getSharedPreferences(workSchedulePrefsName, Context.MODE_PRIVATE)?.edit()
                ?.putString("profiles", settings.optString("profiles", "[]"))
                ?.putString("exceptions", settings.optString("exceptions", "[]"))
                ?.apply()
        }
    }

    private suspend fun mergeAttachment(incoming: AttachmentEntity, forceEqual: Boolean = false) {
        val dao = database.attachmentDao()
        val local = dao.findById(incoming.id)
        if (local != null && incoming.updatedAt < local.updatedAt) return
        if (local != null && incoming.updatedAt == local.updatedAt && !forceEqual) return
        if (local != null) {
            require(local.messageId == incoming.messageId && local.memoryId == incoming.memoryId) {
                "Attachment parent cannot change"
            }
        }
        if (!incoming.isDeleted) {
            incoming.messageId?.let { messageId ->
                val message = database.messageDao().findById(messageId)
                require(message != null && !message.isDeleted) { "Missing message parent" }
            }
            incoming.memoryId?.let { memoryId ->
                val memory = database.memoryDao().findById(memoryId)
                require(memory != null && !memory.isDeleted) { "Missing memory parent" }
                val projectedMemoryCount = dao.activeCountByMemory(memoryId) -
                    (if (local?.isDeleted == false) 1 else 0) + 1
                require(projectedMemoryCount <= MAX_MEMORY_IMAGES) { "Too many memory images" }
            }
        }
        val projectedBytes = dao.activeSizeBytes() -
            (if (local?.isDeleted == false) local.sizeBytes else 0L) +
            (if (!incoming.isDeleted) incoming.sizeBytes else 0L)
        val projectedCount = dao.activeCount() -
            (if (local?.isDeleted == false) 1 else 0) +
            (if (!incoming.isDeleted) 1 else 0)
        require(projectedBytes <= MAX_ACTIVE_ATTACHMENT_STORAGE_BYTES) { "Attachment storage is full" }
        require(projectedCount <= MAX_ACTIVE_ATTACHMENTS) { "Too many attachments" }
        dao.upsert(incoming)
    }

    private suspend fun remapBackupMessageDeviceIds(
        snapshot: JSONObject,
        deviceIdRemap: Map<String, String>
    ) {
        if (deviceIdRemap.isEmpty()) return
        val messages = snapshot.optJSONArray("messages")
        deviceIdRemap.forEach { (oldId, newId) ->
            if (oldId.isBlank() || newId.isBlank() || oldId == newId) return@forEach
            // Correct rows already present locally as well as the incoming snapshot. This makes
            // rerunning Restore after an earlier misattributed restore repair the chat in place.
            database.messageDao().remapDeviceId(oldId, newId)
            if (messages != null) {
                for (index in 0 until messages.length()) {
                    val json = messages.optJSONObject(index) ?: continue
                    if (json.optString("senderDeviceId") == oldId) json.put("senderDeviceId", newId)
                    if (json.optString("reactionByDeviceId") == oldId) json.put("reactionByDeviceId", newId)
                    if (json.optString("reaction2ByDeviceId") == oldId) json.put("reaction2ByDeviceId", newId)
                }
            }
        }
    }

    private suspend fun mergeMessage(incoming: MessageEntity, forceEqual: Boolean = false) {
        val local = database.messageDao().findById(incoming.id)
        if (local == null) {
            database.messageDao().upsert(incoming)
            return
        }
        if (incoming.updatedAt < local.updatedAt) return
        if (incoming.updatedAt == local.updatedAt && !forceEqual) return
        val merged = mergeMessageState(local, incoming, preferIncomingOnTie = forceEqual)
        if (merged != local || forceEqual) database.messageDao().upsert(merged)
    }

    private fun TaskEntity.toJson() = JSONObject()
        .put("id", id).put("title", title).put("note", note).put("assignee", assignee)
        .putNullable("dueAt", dueAt).put("durationMinutes", durationMinutes).put("priority", priority).put("completed", isCompleted)
        .put("deleted", isDeleted).put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun EventEntity.toJson() = JSONObject()
        .put("id", id).put("title", title).put("details", details).put("startAt", startAt)
        .putNullable("endAt", endAt).put("shared", isShared).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun ShoppingItemEntity.toJson() = JSONObject()
        .put("id", id).put("title", title).put("quantity", quantity).put("category", category)
        .put("checked", isChecked).put("recurring", isRecurring).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun MessageEntity.toJson() = JSONObject()
        .put("id", id).put("senderDeviceId", senderDeviceId).put("text", text)
        .putNullableString("replyToId", replyToId)
        .putNullableString("reaction", reaction)
        .putNullableString("reactionByDeviceId", reactionByDeviceId)
        .putNullable("reactionUpdatedAt", reactionUpdatedAt)
        .putNullableString("reaction2", reaction2)
        .putNullableString("reaction2ByDeviceId", reaction2ByDeviceId)
        .putNullable("reaction2UpdatedAt", reaction2UpdatedAt)
        .put("isPinned", isPinned).putNullable("pinnedUpdatedAt", pinnedUpdatedAt)
        .putNullable("deliveredAt", deliveredAt).putNullable("readAt", readAt).putNullable("editedAt", editedAt)
        .put("deleted", isDeleted).put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun FinancialAccountEntity.toJson() = JSONObject()
        .put("id", id).put("name", name).put("type", type)
        .put("openingBalance", openingBalance).put("colorSeed", colorSeed)
        .put("cardNumber", cardNumber).put("accountNumber", accountNumber)
        .put("archived", isArchived).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun FinanceTransactionEntity.toJson() = JSONObject()
        .put("id", id).put("accountId", accountId).putNullableString("targetAccountId", targetAccountId)
        .put("kind", kind).put("amount", amount)
        .put("category", category).put("note", note).put("payerDeviceId", payerDeviceId)
        .put("occurredAt", occurredAt).put("source", source)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun FinanceBudgetEntity.toJson() = JSONObject()
        .put("id", id).put("category", category).put("periodKey", periodKey)
        .put("monthlyLimit", monthlyLimit).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun SharedDebtEntity.toJson() = JSONObject()
        .put("id", id)
        // Keep deletion payloads valid for older clients that still validate live debt fields.
        // Placeholders are intentionally non-sensitive; `deleted` is the authoritative tombstone.
        .put("title", if (isDeleted) "حذف‌شده" else title)
        .put("amount", if (isDeleted) 1L else amount)
        .put("creditorDeviceId", if (isDeleted) "deleted" else creditorDeviceId)
        .put("debtorDeviceId", if (isDeleted) "deleted-peer" else debtorDeviceId)
        .put("note", if (isDeleted) "" else note)
        .putNullable("dueAt", if (isDeleted) null else dueAt)
        .putNullable("settledAt", if (isDeleted) null else settledAt)
        .put("deleted", isDeleted).put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun RecurringTransactionEntity.toJson() = JSONObject()
        .put("id", id)
        .put("accountId", if (isDeleted) "deleted-account" else accountId)
        .putNullableString("targetAccountId", if (isDeleted) null else targetAccountId)
        .put("kind", if (isDeleted) "EXPENSE" else kind)
        .put("amount", if (isDeleted) 1L else amount)
        .put("category", if (isDeleted) "" else category)
        .put("note", if (isDeleted) "" else note)
        .put("interval", if (isDeleted) "MONTHLY" else interval)
        .put("anchorJalaliDay", if (isDeleted) 1 else anchorJalaliDay)
        .put("nextRunAt", if (isDeleted) 0L else nextRunAt)
        .putNullable("lastGeneratedAt", if (isDeleted) null else lastGeneratedAt)
        .put("createdByDeviceId", if (isDeleted) "deleted-device" else createdByDeviceId)
        .put("active", if (isDeleted) false else isActive).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun MemoryEntity.toJson() = JSONObject()
        .put("id", id).put("title", title).put("note", note).put("mood", mood)
        .put("createdByDeviceId", createdByDeviceId).put("occurredAt", occurredAt)
        .put("favorite", isFavorite).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun MoodCheckInEntity.toJson() = JSONObject()
        .put("id", id).put("deviceId", deviceId).put("dayKey", dayKey).put("mood", mood)
        .put("note", note).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun SpecialDateEntity.toJson() = JSONObject()
        .put("id", id).put("title", title).put("note", note).put("occurredAt", occurredAt)
        .put("repeatYearly", repeatYearly).put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun CycleLogEntity.toJson() = JSONObject()
        .put("id", id).put("startAt", startAt)
        .putNullable("endAt", endAt)
        .put("flowLevel", flowLevel).put("note", note)
        .put("recordedByDeviceId", recordedByDeviceId)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun CycleSettingsEntity.toJson() = JSONObject()
        .put("id", id)
        .put("averageCycleDays", averageCycleDays)
        .put("averagePeriodDays", averagePeriodDays)
        .put("trackingEnabled", trackingEnabled)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun LocationShareEntity.toJson() = JSONObject()
        .put("id", id)
        .put("latitude", latitude).put("longitude", longitude)
        .put("accuracyMeters", accuracyMeters.toDouble())
        .put("isSharing", isSharing)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun HeartPulseEntity.toJson() = JSONObject()
        .put("id", id)
        .put("senderDeviceId", senderDeviceId)
        .putNullable("consumedAt", consumedAt)
        .putNullable("acknowledgedAt", acknowledgedAt)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun HabitEntity.toJson() = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("note", note)
        .put("kind", kind)
        .put("scheduleNote", scheduleNote)
        .put("frequency", frequency)
        .put("timesPerWeek", timesPerWeek)
        .put("timesPerDay", timesPerDay)
        .put("weekDays", weekDays)
        .put("priority", priority)
        .put("completionsToday", completionsToday)
        .put("lastCompletedDayKey", lastCompletedDayKey)
        .put("completionsThisWeek", completionsThisWeek)
        .put("weekKey", weekKey)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)

    private fun FoodItemEntity.toJson() = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("note", note)
        .put("isFavorite", isFavorite)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)

    private fun JSONObject.toFoodItem() = FoodItemEntity(
        id = getString("id").take(80),
        name = getString("name").take(120),
        note = optString("note").take(500),
        isFavorite = optBoolean("isFavorite"),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun WatchlistItemEntity.toJson() = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("note", note)
        .put("mediaType", mediaType)
        .put("status", status)
        .put("totalEpisodes", totalEpisodes)
        .put("watchedEpisodes", watchedEpisodes)
        .put("rating", rating)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)

    private fun BookItemEntity.toJson() = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("author", author)
        .put("note", note)
        .put("status", status)
        .put("totalPages", totalPages)
        .put("readPages", readPages)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)

    private fun SharedPlaceEntity.toJson() = JSONObject()
        .put("id", id)
        .put("title", title).put("note", note)
        .put("latitude", latitude).put("longitude", longitude)
        .put("category", category)
        .put("createdByDeviceId", createdByDeviceId)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun CoupleProfileEntity.toJson() = JSONObject()
        .put("id", id).put("firstPersonName", firstPersonName).put("secondPersonName", secondPersonName)
        .putNullable("relationshipStartedAt", relationshipStartedAt)
        .put("createdAt", createdAt).put("updatedAt", updatedAt)

    private fun TelegramStickerPackEntity.toStickerSyncJson() = JSONObject()
        .put("id", name)
        .put("name", name)
        .put("title", title)
        .put("isAnimated", isAnimated)
        .put("stickerCount", stickerCount)
        .put("importedAt", importedAt)
        .put("deleted", isDeleted)
        .put("updatedAt", updatedAt)

    private fun TelegramStickerEntity.toStickerSyncJson(): JSONObject {
        require(content.isNotEmpty() && content.size <= TelegramStickerClient.MAX_STICKER_BYTES)
        require(sizeBytes == content.size.toLong())
        return JSONObject()
            .put("id", id)
            .put("packName", packName)
            .put("fileUniqueId", fileUniqueId)
            .put("emoji", emoji)
            .put("isAnimated", isAnimated)
            .put("mimeType", mimeType)
            .put("fileName", fileName)
            .put("sizeBytes", sizeBytes)
            .put("content", Base64.getUrlEncoder().withoutPadding().encodeToString(content))
            .put("createdAt", createdAt)
            .put("updatedAt", updatedAt)
    }

    /**
     * Exports exactly one entity. Incremental sync must never build a full-database
     * snapshot just to send one changed row.
     */
    suspend fun exportEntity(entityType: String, entityId: String): JSONObject? =
        when (entityType) {
                "tasks" -> database.taskDao().findById(entityId)?.toJson()
                "events" -> database.eventDao().findById(entityId)?.toJson()
                "shopping" -> database.shoppingDao().findById(entityId)?.toJson()
                "messages" -> database.messageDao().findById(entityId)?.toJson()
                "financialAccounts" -> database.financialAccountDao().findById(entityId)?.toJson()
                "financeTransactions" -> database.financeTransactionDao().findById(entityId)?.toJson()
                "financeCategories" -> context?.let { CategoryPreferences.exportSyncRecord(it, entityId) }
                "financialAssets" -> context?.let { FinancialAssetsStore.exportSyncRecord(it, entityId) }
                "smsTemplates" -> context?.let { SmsTemplateStore.exportSyncRecord(it, entityId) }
                "financeBudgets" -> database.financeBudgetDao().findById(entityId)?.toJson()
                "sharedDebts" -> database.sharedDebtDao().findById(entityId)?.toJson()
                "recurringTransactions" -> database.recurringTransactionDao().findById(entityId)?.toJson()
                "memories" -> database.memoryDao().findById(entityId)?.toJson()
                "moodCheckIns" -> database.moodCheckInDao().findById(entityId)?.toJson()
                "specialDates" -> database.specialDateDao().findById(entityId)?.toJson()
                "coupleProfile" -> database.coupleProfileDao().getAllOnce().firstOrNull { it.id == entityId }?.toJson()
                "cycleLogs" -> database.cycleLogDao().findById(entityId)?.toJson()
                "cycleSettings" -> database.cycleSettingsDao().getAllOnce().firstOrNull { it.id == entityId }?.toJson()
                "locationShares" -> database.locationShareDao().findById(entityId)?.toJson()
                "heartPulses" -> database.heartPulseDao().findById(entityId)?.toJson()
                "sharedPlaces" -> database.sharedPlaceDao().findById(entityId)?.toJson()
                "habits" -> database.habitDao().findById(entityId)?.toJson()
                "watchlistItems" -> database.watchlistDao().findById(entityId)?.toJson()
                "bookItems" -> database.bookDao().findById(entityId)?.toJson()
                "telegramStickerPacks" -> database.telegramStickerPackDao().findByName(entityId)?.toStickerSyncJson()
                "telegramStickers" -> database.telegramStickerDao().findById(entityId)?.toStickerSyncJson()
                "attachments" -> database.attachmentDao().findById(entityId)?.toSyncJson()
                else -> null
        }

    internal fun attachmentToJson(attachment: AttachmentEntity): JSONObject = attachment.toSyncJson()

    private fun AttachmentEntity.toSyncJson() = JSONObject()
        .put("id", id)
        .putNullableString("messageId", messageId)
        .putNullableString("memoryId", memoryId)
        .put("fileName", fileName)
        .put("mimeType", mimeType)
        .put("sizeBytes", sizeBytes)
        .put("sha256", sha256)
        .put("content", if (isDeleted) "" else Base64.getUrlEncoder().withoutPadding().encodeToString(content))
        .put("createdByDeviceId", createdByDeviceId)
        .put("deleted", isDeleted)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)

    private fun JSONObject.toTask() = TaskEntity(
        id = getString("id").take(80),
        title = getString("title").take(500),
        note = optString("note").take(2_000),
        assignee = optString("assignee", "مشترک").take(80),
        dueAt = nullableLong("dueAt"),
        durationMinutes = optInt("durationMinutes", 60).coerceIn(15, 720),
        priority = optInt("priority", 1).coerceIn(0, 2),
        isCompleted = optBoolean("completed"),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toEvent() = EventEntity(
        id = getString("id").take(80),
        title = getString("title").take(500),
        details = optString("details").take(2_000),
        startAt = getLong("startAt"),
        endAt = nullableLong("endAt"),
        isShared = optBoolean("shared", true),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toShopping() = ShoppingItemEntity(
        id = getString("id").take(80),
        title = getString("title").take(500),
        quantity = optString("quantity", "۱ عدد").take(100),
        category = optString("category", "سایر").take(100),
        isChecked = optBoolean("checked"),
        isRecurring = optBoolean("recurring"),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toMessage() = MessageEntity(
        id = getString("id").take(80),
        senderDeviceId = getString("senderDeviceId").take(80),
        text = getString("text").take(5_000),
        replyToId = nullableString("replyToId")?.take(80),
        reaction = nullableString("reaction")?.take(8),
        reactionByDeviceId = nullableString("reactionByDeviceId")?.take(80),
        reactionUpdatedAt = nullableLong("reactionUpdatedAt"),
        reaction2 = nullableString("reaction2")?.take(8),
        reaction2ByDeviceId = nullableString("reaction2ByDeviceId")?.take(80),
        reaction2UpdatedAt = nullableLong("reaction2UpdatedAt"),
        isPinned = optBoolean("isPinned", false),
        pinnedUpdatedAt = nullableLong("pinnedUpdatedAt"),
        deliveredAt = nullableLong("deliveredAt"),
        readAt = nullableLong("readAt"),
        editedAt = nullableLong("editedAt"),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toFinancialAccount() = FinancialAccountEntity(
        id = getString("id").take(80),
        name = getString("name").take(120),
        type = optString("type", "CASH").take(32),
        openingBalance = optLong("openingBalance").coerceAtLeast(0),
        colorSeed = optInt("colorSeed").coerceIn(0, 5),
        cardNumber = optString("cardNumber").take(32),
        accountNumber = optString("accountNumber").take(40),
        isArchived = optBoolean("archived"),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toFinanceTransaction(): FinanceTransactionEntity {
        val deleted = optBoolean("deleted")
        val amount = getLong("amount")
        return FinanceTransactionEntity(
            id = getString("id").take(80),
            accountId = getString("accountId").take(80),
            targetAccountId = nullableString("targetAccountId")?.take(80),
            kind = when (optString("kind")) {
                "INCOME" -> "INCOME"
                "TRANSFER" -> "TRANSFER"
                else -> "EXPENSE"
            },
            amount = if (deleted) amount.coerceIn(0, MAX_FINANCE_AMOUNT) else amount.coerceIn(1, MAX_FINANCE_AMOUNT),
            category = optString("category", "سایر").take(100),
            note = optString("note").take(1_000),
            payerDeviceId = optString("payerDeviceId").take(80),
            occurredAt = getLong("occurredAt"),
            source = if (optString("source") == "SMS") "SMS" else "MANUAL",
            isDeleted = deleted,
            createdAt = getLong("createdAt"),
            updatedAt = getLong("updatedAt")
        )
    }

    private fun JSONObject.toFinanceBudget(): FinanceBudgetEntity {
        val deleted = optBoolean("deleted")
        val amount = getLong("monthlyLimit")
        return FinanceBudgetEntity(
            id = getString("id").take(140),
            category = getString("category").take(100),
            periodKey = getString("periodKey").take(16),
            monthlyLimit = if (deleted) amount.coerceIn(0, MAX_FINANCE_AMOUNT) else amount.coerceIn(1, MAX_FINANCE_AMOUNT),
            isDeleted = deleted,
            createdAt = getLong("createdAt"),
            updatedAt = getLong("updatedAt")
        )
    }

    private fun JSONObject.toSharedDebt(): SharedDebtEntity {
        val deleted = optBoolean("deleted")
        val amount = getLong("amount")
        val creditor = getString("creditorDeviceId").take(80)
        val debtor = getString("debtorDeviceId").take(80)
        val title = getString("title").take(200)
        // Redacted tombstones intentionally zero private fields. Validate business data only
        // for live rows; otherwise one deletion could abort the entire incremental batch.
        if (!deleted) {
            require(amount in 1..MAX_FINANCE_AMOUNT)
            require(creditor.isNotBlank() && debtor.isNotBlank() && creditor != debtor && title.isNotBlank())
        }
        return SharedDebtEntity(
            id = getString("id").take(80),
            title = title,
            amount = if (deleted) amount.coerceIn(0, MAX_FINANCE_AMOUNT) else amount,
            creditorDeviceId = creditor,
            debtorDeviceId = debtor,
            note = optString("note").take(1_000),
            dueAt = nullableLong("dueAt"),
            settledAt = nullableLong("settledAt"),
            isDeleted = deleted,
            createdAt = getLong("createdAt"),
            updatedAt = getLong("updatedAt")
        )
    }

    private fun JSONObject.toRecurringTransaction(): RecurringTransactionEntity {
        val deleted = optBoolean("deleted")
        val kind = optString("kind").take(16)
        val target = nullableString("targetAccountId")?.take(80)
        val amount = optLong("amount", 0L)
        val interval = optString("interval").take(16)
        val anchorJalaliDay = optInt("anchorJalaliDay")
        val accountId = optString("accountId").take(80)
        val creatorId = optString("createdByDeviceId").take(80)
        if (!deleted) {
            require(kind in setOf("INCOME", "EXPENSE", "TRANSFER"))
            require(amount in 1..MAX_FINANCE_AMOUNT)
            require(interval in setOf("WEEKLY", "MONTHLY", "YEARLY"))
            require(anchorJalaliDay in 1..31)
            require(accountId.isNotBlank() && creatorId.isNotBlank())
            require(kind != "TRANSFER" || !target.isNullOrBlank())
        }
        return RecurringTransactionEntity(
            id = getString("id").take(80),
            accountId = accountId,
            targetAccountId = target,
            kind = kind,
            amount = if (deleted) amount.coerceIn(0, MAX_FINANCE_AMOUNT) else amount,
            category = optString("category").take(100),
            note = optString("note").take(1_000),
            interval = interval,
            anchorJalaliDay = anchorJalaliDay.coerceIn(0, 31),
            nextRunAt = optLong("nextRunAt"),
            lastGeneratedAt = nullableLong("lastGeneratedAt"),
            createdByDeviceId = creatorId,
            isActive = optBoolean("active", !deleted),
            isDeleted = deleted,
            createdAt = optLong("createdAt"),
            updatedAt = getLong("updatedAt")
        )
    }

    private fun JSONObject.toMemory() = MemoryEntity(
        id = getString("id").take(80),
        title = getString("title").take(200),
        note = optString("note").take(3_000),
        mood = optString("mood", "LOVE").take(24),
        createdByDeviceId = getString("createdByDeviceId").take(80),
        occurredAt = getLong("occurredAt"),
        isFavorite = optBoolean("favorite"),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toMoodCheckIn() = MoodCheckInEntity(
        id = getString("id").take(100),
        deviceId = getString("deviceId").take(80),
        dayKey = getString("dayKey").take(16),
        mood = getString("mood").take(24),
        note = optString("note").take(500),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toSpecialDate() = SpecialDateEntity(
        id = getString("id").take(80),
        title = getString("title").take(200),
        note = optString("note").take(1_000),
        occurredAt = getLong("occurredAt"),
        repeatYearly = optBoolean("repeatYearly", true),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toCycleLog() = CycleLogEntity(
        id = getString("id").take(80),
        startAt = getLong("startAt"),
        endAt = if (has("endAt") && !isNull("endAt")) getLong("endAt") else null,
        flowLevel = optString("flowLevel", "UNKNOWN").take(24),
        note = optString("note").take(1_000),
        recordedByDeviceId = optString("recordedByDeviceId").take(80),
        isDeleted = optBoolean("deleted", false),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toCycleSettings() = CycleSettingsEntity(
        id = optString("id", "cycle-settings").ifBlank { "cycle-settings" },
        averageCycleDays = optInt("averageCycleDays", 28).coerceIn(15, 60),
        averagePeriodDays = optInt("averagePeriodDays", 5).coerceIn(1, 15),
        trackingEnabled = optBoolean("trackingEnabled", true),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toLocationShare() = LocationShareEntity(
        id = getString("id").take(80),
        latitude = getDouble("latitude"),
        longitude = getDouble("longitude"),
        accuracyMeters = optDouble("accuracyMeters", 0.0).toFloat(),
        isSharing = optBoolean("isSharing", true),
        isDeleted = optBoolean("deleted", false),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toHeartPulse() = HeartPulseEntity(
        id = getString("id").take(80),
        senderDeviceId = optString("senderDeviceId").take(80),
        consumedAt = nullableLong("consumedAt"),
        acknowledgedAt = nullableLong("acknowledgedAt"),
        isDeleted = optBoolean("deleted", false),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toHabit() = HabitEntity(
        id = getString("id").take(80),
        title = getString("title").take(500),
        note = optString("note").take(2_000),
        kind = optString("kind", "HABIT").take(40),
        scheduleNote = optString("scheduleNote").take(500),
        frequency = optString("frequency", "DAILY").take(40),
        timesPerWeek = optInt("timesPerWeek", 7).coerceIn(1, 14),
        timesPerDay = optInt("timesPerDay", 1).coerceIn(1, 10),
        weekDays = optString("weekDays").take(40),
        priority = optString("priority", "NORMAL").take(20),
        completionsToday = optInt("completionsToday", 0).coerceIn(0, 20),
        lastCompletedDayKey = optString("lastCompletedDayKey").take(40),
        completionsThisWeek = optInt("completionsThisWeek", 0).coerceIn(0, 40),
        weekKey = optString("weekKey").take(40),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toWatchlistItem() = WatchlistItemEntity(
        id = getString("id").take(80),
        title = getString("title").take(500),
        note = optString("note").take(2_000),
        mediaType = optString("mediaType", "MOVIE").take(40),
        status = optString("status", "WANT").take(40),
        totalEpisodes = optInt("totalEpisodes", 0).coerceIn(0, 10_000),
        watchedEpisodes = optInt("watchedEpisodes", 0).coerceIn(0, 10_000),
        rating = optInt("rating", 0).coerceIn(0, 5),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toBookItem() = BookItemEntity(
        id = getString("id").take(80),
        title = getString("title").take(500),
        author = optString("author").take(300),
        note = optString("note").take(2_000),
        status = optString("status", "WANT").take(40),
        totalPages = optInt("totalPages", 0).coerceIn(0, 100_000),
        readPages = optInt("readPages", 0).coerceIn(0, 100_000),
        isDeleted = optBoolean("deleted"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toTelegramStickerPack(): TelegramStickerPackEntity {
        val id = optString("id").ifBlank { getString("name") }.take(MAX_TELEGRAM_PACK_NAME_LENGTH)
        val name = optString("name", id).take(MAX_TELEGRAM_PACK_NAME_LENGTH)
        require(id.isNotBlank() && id == name) { "Sticker pack id does not match its name" }
        val importedAt = getLong("importedAt")
        return TelegramStickerPackEntity(
            name = name,
            title = optString("title", name).filterNot { it.isISOControl() }.take(160).ifBlank { name },
            isAnimated = optBoolean("isAnimated", false),
            stickerCount = optInt("stickerCount", 0).coerceIn(0, MAX_TELEGRAM_STICKERS),
            importedAt = importedAt,
            isDeleted = optBoolean("deleted", false),
            updatedAt = optLong("updatedAt", importedAt)
        )
    }

    private fun JSONObject.toTelegramSticker(): TelegramStickerEntity {
        val id = getString("id").take(MAX_TELEGRAM_STICKER_ID_LENGTH)
        val packName = getString("packName").take(MAX_TELEGRAM_PACK_NAME_LENGTH)
        val fileUniqueId = getString("fileUniqueId").take(120)
        val expectedSize = getLong("sizeBytes")
        require(id.isNotBlank() && packName.isNotBlank() && fileUniqueId.isNotBlank()) {
            "Sticker identifiers are invalid"
        }
        require(expectedSize in 1..TelegramStickerClient.MAX_STICKER_BYTES.toLong()) {
            "Sticker file size is invalid"
        }
        val content = Base64.getUrlDecoder().decode(getString("content"))
        require(content.isNotEmpty() && content.size.toLong() == expectedSize) {
            "Sticker content does not match its declared size"
        }
        val mimeType = optString("mimeType", "image/webp")
            .filterNot { it.isISOControl() }.take(120).ifBlank { "image/webp" }
        require(mimeType == "image/webp" || mimeType == TelegramStickerClient.MIME_TGS) {
            "Sticker format is unsupported"
        }
        val createdAt = getLong("createdAt")
        return TelegramStickerEntity(
            id = id,
            packName = packName,
            fileUniqueId = fileUniqueId,
            emoji = optString("emoji", "⭐").filterNot { it.isISOControl() }.take(16).ifBlank { "⭐" },
            isAnimated = optBoolean("isAnimated", false),
            mimeType = mimeType,
            fileName = optString("fileName", "sticker.webp")
                .filterNot { it.isISOControl() }.take(180).ifBlank { "sticker.webp" },
            sizeBytes = expectedSize,
            content = content,
            createdAt = createdAt,
            updatedAt = optLong("updatedAt", createdAt)
        )
    }

    private fun JSONObject.toSharedPlace() = SharedPlaceEntity(
        id = getString("id").take(80),
        title = optString("title").take(160),
        note = optString("note").take(1_000),
        latitude = getDouble("latitude"),
        longitude = getDouble("longitude"),
        category = optString("category", "OTHER").take(24).ifBlank { "OTHER" },
        createdByDeviceId = optString("createdByDeviceId").take(80),
        isDeleted = optBoolean("deleted", false),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toCoupleProfile() = CoupleProfileEntity(
        id = getString("id").take(80),
        firstPersonName = optString("firstPersonName").take(80),
        secondPersonName = optString("secondPersonName").take(80),
        relationshipStartedAt = nullableLong("relationshipStartedAt"),
        createdAt = getLong("createdAt"),
        updatedAt = getLong("updatedAt")
    )

    private fun JSONObject.toAttachment(): AttachmentEntity {
        val isDeleted = optBoolean("deleted")
        val content = if (isDeleted) ByteArray(0) else Base64.getUrlDecoder().decode(getString("content"))
        val expectedSize = getLong("sizeBytes")
        require(expectedSize in 1..MAX_ATTACHMENT_BYTES.toLong()) { "Attachment size is invalid" }
        val expectedHash = getString("sha256").lowercase().take(64)
        if (!isDeleted) {
            require(content.isNotEmpty() && content.size <= MAX_ATTACHMENT_BYTES) { "Attachment is too large" }
            require(AttachmentIntegrity.verify(content, expectedSize, expectedHash)) {
                "Attachment hash or size does not match"
            }
        }
        val messageId = nullableString("messageId")?.take(80)
        val memoryId = nullableString("memoryId")?.take(80)
        require((messageId == null) != (memoryId == null)) { "Attachment must have exactly one parent" }
        val mimeType = optString("mimeType", "application/octet-stream")
            .filterNot { it.isISOControl() }.take(120).ifEmpty { "application/octet-stream" }
        if (memoryId != null) {
            require(mimeType.startsWith("image/")) { "Memory attachment must be an image" }
            if (!isDeleted) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(content, 0, content.size, bounds)
                require(bounds.outWidth in 1..MAX_IMAGE_DIMENSION && bounds.outHeight in 1..MAX_IMAGE_DIMENSION) {
                    "Memory image dimensions are invalid"
                }
            }
        }
        return AttachmentEntity(
            id = getString("id").take(80),
            messageId = messageId,
            memoryId = memoryId,
            fileName = getString("fileName").filterNot { it.isISOControl() }.take(180)
                .ifEmpty { "پیوست" },
            mimeType = mimeType,
            sizeBytes = expectedSize,
            sha256 = expectedHash,
            content = content,
            createdByDeviceId = getString("createdByDeviceId").take(80),
            isDeleted = isDeleted,
            createdAt = getLong("createdAt"),
            updatedAt = getLong("updatedAt")
        )
    }

    private fun JSONObject.putNullable(name: String, value: Long?): JSONObject =
        put(name, value ?: JSONObject.NULL)

    private fun JSONObject.putNullableString(name: String, value: String?): JSONObject =
        put(name, value ?: JSONObject.NULL)

    private fun JSONObject.nullableLong(name: String): Long? =
        if (isNull(name)) null else getLong(name)

    private fun JSONObject.nullableString(name: String): String? =
        if (isNull(name)) null else getString(name)

    private inline fun JSONArray.forEachObject(max: Int, block: (JSONObject) -> Unit) {
        require(length() <= max) { "Sync collection is too large" }
        for (index in 0 until length()) block(getJSONObject(index))
    }

    private companion object {
        const val MAX_ITEMS = 10_000
        const val MAX_MESSAGES = 20_000
        const val MAX_ATTACHMENTS = 2_000
        const val MAX_TELEGRAM_STICKERS = 10_000
        const val MAX_TELEGRAM_PACK_NAME_LENGTH = 128
        const val MAX_TELEGRAM_STICKER_ID_LENGTH = 220
        const val MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024
        const val MAX_IMAGE_DIMENSION = 24_000
        const val MAX_ACTIVE_ATTACHMENTS = 1_000
        const val MAX_MEMORY_IMAGES = 12
        const val MAX_ACTIVE_ATTACHMENT_STORAGE_BYTES = 512L * 1024 * 1024
        const val MAX_FINANCE_AMOUNT = 999_999_999_999_999L
    }
}

internal fun mergeMessageState(
    local: MessageEntity,
    incoming: MessageEntity,
    preferIncomingOnTie: Boolean = false
): MessageEntity {
    require(local.id == incoming.id) { "Cannot merge different messages" }
    val incomingIsNewest = incoming.updatedAt > local.updatedAt ||
        (preferIncomingOnTie && incoming.updatedAt == local.updatedAt)
    val newest = if (incomingIsNewest) incoming else local
    val localReactionAt = local.reactionUpdatedAt ?: if (local.reaction != null) local.updatedAt else Long.MIN_VALUE
    val incomingReactionAt = incoming.reactionUpdatedAt ?: if (incoming.reaction != null) incoming.updatedAt else Long.MIN_VALUE
    val reactionSource = if (incomingReactionAt > localReactionAt) incoming else local
    val localReaction2At = local.reaction2UpdatedAt ?: if (local.reaction2 != null) local.updatedAt else Long.MIN_VALUE
    val incomingReaction2At = incoming.reaction2UpdatedAt ?: if (incoming.reaction2 != null) incoming.updatedAt else Long.MIN_VALUE
    val reaction2Source = if (incomingReaction2At > localReaction2At) incoming else local
    val localPinnedAt = local.pinnedUpdatedAt ?: if (local.isPinned) local.updatedAt else Long.MIN_VALUE
    val incomingPinnedAt = incoming.pinnedUpdatedAt ?: if (incoming.isPinned) incoming.updatedAt else Long.MIN_VALUE
    val pinnedSource = when {
        incomingPinnedAt > localPinnedAt -> incoming
        incomingPinnedAt < localPinnedAt -> local
        incoming.isPinned != local.isPinned -> if (incoming.isPinned) incoming else local
        preferIncomingOnTie -> incoming
        else -> local
    }
    // متن و حذف: آخرین نسخه بر اساس updatedAt (نه OR حذف که پیام را برای همیشه پنهان می‌کرد)
    val textSource = when {
        local.isDeleted && !incoming.isDeleted && incoming.updatedAt >= local.updatedAt -> incoming
        incoming.isDeleted && !local.isDeleted && local.updatedAt > incoming.updatedAt -> local
        else -> newest
    }
    return newest.copy(
        senderDeviceId = local.senderDeviceId.ifBlank { incoming.senderDeviceId },
        text = when {
            textSource.text.isNotBlank() -> textSource.text
            local.text.isNotBlank() -> local.text
            else -> incoming.text
        },
        replyToId = local.replyToId ?: incoming.replyToId,
        reaction = reactionSource.reaction,
        reactionByDeviceId = reactionSource.reactionByDeviceId,
        reactionUpdatedAt = reactionSource.reactionUpdatedAt,
        reaction2 = reaction2Source.reaction2,
        reaction2ByDeviceId = reaction2Source.reaction2ByDeviceId,
        reaction2UpdatedAt = reaction2Source.reaction2UpdatedAt,
        isPinned = pinnedSource.isPinned,
        pinnedUpdatedAt = pinnedSource.pinnedUpdatedAt,
        deliveredAt = listOfNotNull(local.deliveredAt, incoming.deliveredAt).maxOrNull(),
        readAt = listOfNotNull(local.readAt, incoming.readAt).maxOrNull(),
        editedAt = listOfNotNull(local.editedAt, incoming.editedAt).maxOrNull(),
        isDeleted = newest.isDeleted,
        createdAt = minOf(local.createdAt, incoming.createdAt),
        updatedAt = maxOf(local.updatedAt, incoming.updatedAt)
    )
}
