package com.ourspace.app.core.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE isDeleted = 0 ORDER BY isCompleted ASC, priority DESC, COALESCE(dueAt, 9223372036854775807) ASC, createdAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Query("SELECT * FROM tasks")
    suspend fun getAllOnce(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): TaskEntity?


    @Query("SELECT updatedAt FROM tasks WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Update
    suspend fun update(task: TaskEntity)

    @Delete
    suspend fun delete(task: TaskEntity)
}

@Dao
interface EventDao {
    @Query("SELECT * FROM events WHERE isDeleted = 0 ORDER BY startAt ASC")
    fun observeAll(): Flow<List<EventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(event: EventEntity)

    @Update
    suspend fun update(event: EventEntity)

    @Query("SELECT * FROM events")
    suspend fun getAllOnce(): List<EventEntity>

    @Query("SELECT * FROM events WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): EventEntity?


    @Query("SELECT updatedAt FROM events WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Delete
    suspend fun delete(event: EventEntity)
}

@Dao
interface ShoppingDao {
    @Query("SELECT * FROM shopping_items WHERE isDeleted = 0 ORDER BY isChecked ASC, category ASC, createdAt DESC")
    fun observeAll(): Flow<List<ShoppingItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ShoppingItemEntity)

    @Query("SELECT * FROM shopping_items")
    suspend fun getAllOnce(): List<ShoppingItemEntity>

    @Query("SELECT * FROM shopping_items WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): ShoppingItemEntity?


    @Query("SELECT updatedAt FROM shopping_items WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Update
    suspend fun update(item: ShoppingItemEntity)

    @Delete
    suspend fun delete(item: ShoppingItemEntity)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' ORDER BY createdAt DESC, id DESC LIMIT :limit")
    fun observeLatest(limit: Int): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND (createdAt < :beforeCreatedAt OR (createdAt = :beforeCreatedAt AND id < :beforeId)) ORDER BY createdAt DESC, id DESC LIMIT :limit")
    suspend fun loadOlder(beforeCreatedAt: Long, beforeId: String, limit: Int): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE isDeleted = 0 AND text LIKE :gamePrefixPattern ORDER BY createdAt ASC, id ASC")
    fun observeGameMessages(gamePrefixPattern: String): Flow<List<MessageEntity>>

    @Query("SELECT COUNT(*) FROM messages WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%'")
    suspend fun countActive(): Int

    @Query("SELECT COUNT(*) FROM messages WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND senderDeviceId != :ownDeviceId AND readAt IS NULL")
    fun observeUnreadCount(ownDeviceId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM messages WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND senderDeviceId != :ownDeviceId AND readAt IS NULL")
    suspend fun unreadCountOnce(ownDeviceId: String): Int

    @Query("SELECT text FROM messages WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND senderDeviceId != :ownDeviceId AND readAt IS NULL ORDER BY createdAt DESC, id DESC LIMIT 1")
    suspend fun latestUnreadIncomingTextOnce(ownDeviceId: String): String?

    @Query("SELECT * FROM messages ORDER BY createdAt DESC LIMIT 20000")
    suspend fun getAllOnce(): List<MessageEntity>

    @Query("SELECT updatedAt FROM messages WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Query("SELECT * FROM messages WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): MessageEntity?

    @Query("SELECT * FROM messages WHERE id = :id AND text NOT LIKE '[[OSGAME1]]|%' LIMIT 1")
    suspend fun findChatById(id: String): MessageEntity?

    @Query("UPDATE messages SET senderDeviceId = CASE WHEN senderDeviceId = :oldId THEN :newId ELSE senderDeviceId END, reactionByDeviceId = CASE WHEN reactionByDeviceId = :oldId THEN :newId ELSE reactionByDeviceId END, reaction2ByDeviceId = CASE WHEN reaction2ByDeviceId = :oldId THEN :newId ELSE reaction2ByDeviceId END WHERE senderDeviceId = :oldId OR reactionByDeviceId = :oldId OR reaction2ByDeviceId = :oldId")
    suspend fun remapDeviceId(oldId: String, newId: String): Int

    @Query("SELECT * FROM messages WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND text LIKE '%' || :query || '%' COLLATE NOCASE ORDER BY createdAt DESC, id DESC")
    suspend fun searchActiveMessages(query: String): List<MessageEntity>

    @Query("UPDATE messages SET readAt = :readAt, updatedAt = :readAt WHERE id IN (:ids) AND isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND senderDeviceId != :ownDeviceId AND readAt IS NULL")
    suspend fun markIncomingReadByIds(ids: List<String>, ownDeviceId: String, readAt: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(message: MessageEntity)

    @Update
    suspend fun update(message: MessageEntity)

    @Query("UPDATE messages SET text = :text, editedAt = :editedAt, updatedAt = :editedAt WHERE id = :id AND isDeleted = 0")
    suspend fun updateText(id: String, text: String, editedAt: Long): Int

    @Query("UPDATE messages SET isDeleted = 1, updatedAt = :updatedAt WHERE id = :id AND isDeleted = 0")
    suspend fun markDeleted(id: String, updatedAt: Long): Int

    @Query("UPDATE messages SET reaction = :reaction, reactionByDeviceId = :reactionByDeviceId, reactionUpdatedAt = :updatedAt, updatedAt = :updatedAt WHERE id = :id AND isDeleted = 0")
    suspend fun updateReaction(id: String, reaction: String?, reactionByDeviceId: String?, updatedAt: Long): Int

    @Query("UPDATE messages SET reaction2 = :reaction, reaction2ByDeviceId = :reactionByDeviceId, reaction2UpdatedAt = :updatedAt, updatedAt = :updatedAt WHERE id = :id AND isDeleted = 0")
    suspend fun updateReaction2(id: String, reaction: String?, reactionByDeviceId: String?, updatedAt: Long): Int

    @Query("UPDATE messages SET readAt = :readAt, updatedAt = :readAt WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND senderDeviceId != :ownDeviceId AND readAt IS NULL")
    suspend fun markIncomingRead(ownDeviceId: String, readAt: Long): Int

    @Query("UPDATE messages SET deliveredAt = :deliveredAt, updatedAt = :deliveredAt WHERE isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND senderDeviceId != :ownDeviceId AND deliveredAt IS NULL")
    suspend fun stampIncomingDelivered(ownDeviceId: String, deliveredAt: Long): Int

    @Query("UPDATE messages SET deliveredAt = :deliveredAt, updatedAt = :deliveredAt WHERE id IN (:ids) AND isDeleted = 0 AND text NOT LIKE '[[OSGAME1]]|%' AND senderDeviceId != :ownDeviceId AND deliveredAt IS NULL")
    suspend fun stampIncomingDeliveredByIds(ids: List<String>, ownDeviceId: String, deliveredAt: Long): Int

}

@Dao
interface FinancialAccountDao {
    @Query("SELECT * FROM financial_accounts WHERE isDeleted = 0 AND isArchived = 0 ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<FinancialAccountEntity>>

    @Query("SELECT * FROM financial_accounts")
    suspend fun getAllOnce(): List<FinancialAccountEntity>

    @Query("SELECT * FROM financial_accounts WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): FinancialAccountEntity?


    @Query("SELECT updatedAt FROM financial_accounts WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(account: FinancialAccountEntity)

    @Update
    suspend fun update(account: FinancialAccountEntity)
}

@Dao
interface FinanceTransactionDao {
    @Query("SELECT * FROM finance_transactions WHERE isDeleted = 0 ORDER BY occurredAt DESC, createdAt DESC")
    fun observeAll(): Flow<List<FinanceTransactionEntity>>

    @Query("SELECT * FROM finance_transactions")
    suspend fun getAllOnce(): List<FinanceTransactionEntity>

    @Query("SELECT * FROM finance_transactions WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): FinanceTransactionEntity?


    @Query("SELECT updatedAt FROM finance_transactions WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(transaction: FinanceTransactionEntity)

    @Update
    suspend fun update(transaction: FinanceTransactionEntity)
}

@Dao
interface FinanceBudgetDao {
    @Query("SELECT * FROM finance_budgets WHERE isDeleted = 0 ORDER BY category ASC")
    fun observeAll(): Flow<List<FinanceBudgetEntity>>

    @Query("SELECT * FROM finance_budgets")
    suspend fun getAllOnce(): List<FinanceBudgetEntity>

    @Query("SELECT * FROM finance_budgets WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): FinanceBudgetEntity?


    @Query("SELECT updatedAt FROM finance_budgets WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(budget: FinanceBudgetEntity)
}

@Dao
interface SharedDebtDao {
    @Query("SELECT * FROM shared_debts WHERE isDeleted = 0 ORDER BY settledAt ASC, dueAt ASC, createdAt DESC")
    fun observeAll(): Flow<List<SharedDebtEntity>>

    @Query("SELECT * FROM shared_debts")
    suspend fun getAllOnce(): List<SharedDebtEntity>

    @Query("SELECT * FROM shared_debts WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): SharedDebtEntity?


    @Query("SELECT updatedAt FROM shared_debts WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(debt: SharedDebtEntity)

    @Update
    suspend fun update(debt: SharedDebtEntity)
}

@Dao
interface RecurringTransactionDao {
    @Query("SELECT * FROM recurring_transactions WHERE isDeleted = 0 ORDER BY isActive DESC, nextRunAt ASC")
    fun observeAll(): Flow<List<RecurringTransactionEntity>>

    @Query("SELECT * FROM recurring_transactions")
    suspend fun getAllOnce(): List<RecurringTransactionEntity>

    @Query("SELECT * FROM recurring_transactions WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): RecurringTransactionEntity?


    @Query("SELECT * FROM recurring_transactions WHERE isDeleted = 0 AND isActive = 1 AND createdByDeviceId = :deviceId AND nextRunAt <= :now ORDER BY nextRunAt ASC LIMIT :limit")
    suspend fun dueForOwner(deviceId: String, now: Long, limit: Int): List<RecurringTransactionEntity>

    @Query("SELECT updatedAt FROM recurring_transactions WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: RecurringTransactionEntity)

    @Update
    suspend fun update(rule: RecurringTransactionEntity)
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories WHERE isDeleted = 0 ORDER BY isFavorite DESC, occurredAt DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories")
    suspend fun getAllOnce(): List<MemoryEntity>

    @Query("SELECT updatedAt FROM memories WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Query("SELECT * FROM memories WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): MemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(memory: MemoryEntity)

    @Update
    suspend fun update(memory: MemoryEntity)
}

@Dao
interface MoodCheckInDao {
    @Query("SELECT * FROM mood_checkins WHERE isDeleted = 0 ORDER BY dayKey DESC, createdAt DESC")
    fun observeAll(): Flow<List<MoodCheckInEntity>>

    @Query("SELECT * FROM mood_checkins")
    suspend fun getAllOnce(): List<MoodCheckInEntity>

    @Query("SELECT * FROM mood_checkins WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): MoodCheckInEntity?


    @Query("SELECT updatedAt FROM mood_checkins WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(checkIn: MoodCheckInEntity)
}

@Dao
interface SpecialDateDao {
    @Query("SELECT * FROM special_dates WHERE isDeleted = 0 ORDER BY occurredAt ASC")
    fun observeAll(): Flow<List<SpecialDateEntity>>

    @Query("SELECT * FROM special_dates")
    suspend fun getAllOnce(): List<SpecialDateEntity>

    @Query("SELECT * FROM special_dates WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): SpecialDateEntity?


    @Query("SELECT updatedAt FROM special_dates WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(specialDate: SpecialDateEntity)

    @Update
    suspend fun update(specialDate: SpecialDateEntity)
}

@Dao
interface CoupleProfileDao {
    @Query("SELECT * FROM couple_profile WHERE id = 'couple-profile' LIMIT 1")
    fun observe(): Flow<CoupleProfileEntity?>

    @Query("SELECT * FROM couple_profile")
    suspend fun getAllOnce(): List<CoupleProfileEntity>

    @Query("SELECT * FROM couple_profile WHERE id = 'couple-profile' LIMIT 1")
    suspend fun getOnce(): CoupleProfileEntity?

    @Query("SELECT updatedAt FROM couple_profile WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: CoupleProfileEntity)
}

@Dao
interface AttachmentDao {
    @Query("SELECT id, messageId, memoryId, fileName, mimeType, sizeBytes, sha256, X'' AS content, createdByDeviceId, isDeleted, createdAt, updatedAt FROM attachments WHERE isDeleted = 0 ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<AttachmentEntity>>

    @Query("SELECT * FROM attachments ORDER BY createdAt ASC")
    suspend fun getAllOnce(): List<AttachmentEntity>

    @Query("SELECT * FROM attachments WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): AttachmentEntity?

    @Query("SELECT * FROM attachments WHERE messageId = :messageId AND isDeleted = 0")
    suspend fun findActiveByMessage(messageId: String): List<AttachmentEntity>

    @Query("SELECT * FROM attachments WHERE memoryId = :memoryId AND isDeleted = 0")
    suspend fun findActiveByMemory(memoryId: String): List<AttachmentEntity>

    @Query("SELECT updatedAt FROM attachments WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM attachments WHERE isDeleted = 0")
    suspend fun activeSizeBytes(): Long

    @Query("SELECT COUNT(*) FROM attachments WHERE isDeleted = 0")
    suspend fun activeCount(): Int

    @Query("SELECT COUNT(*) FROM attachments WHERE memoryId = :memoryId AND isDeleted = 0")
    suspend fun activeCountByMemory(memoryId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(attachment: AttachmentEntity)

    @Update
    suspend fun update(attachment: AttachmentEntity)
}

@Dao
interface SyncChangeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(change: SyncChangeEntity)

    @Query("SELECT * FROM sync_changes WHERE changeId = :changeId LIMIT 1")
    suspend fun find(changeId: String): SyncChangeEntity?

    @Query("SELECT * FROM sync_changes WHERE entityType = :entityType AND entityId = :entityId LIMIT 1")
    suspend fun findByEntity(entityType: String, entityId: String): SyncChangeEntity?

    @Query("SELECT * FROM sync_changes WHERE (state = 'PENDING' OR (state = 'SENDING' AND lastAttemptAt IS NOT NULL AND lastAttemptAt < :staleBefore)) AND nextAttemptAt <= :now ORDER BY priority DESC, changedAt ASC LIMIT :limit")
    suspend fun due(now: Long, staleBefore: Long, limit: Int): List<SyncChangeEntity>

    @Query("SELECT * FROM sync_changes ORDER BY priority DESC, changedAt ASC LIMIT :limit")
    suspend fun pending(limit: Int): List<SyncChangeEntity>

    @Query("SELECT COUNT(*) FROM sync_changes")
    fun observePendingCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_changes")
    suspend fun pendingCount(): Int

    @Query("SELECT COUNT(*) FROM sync_changes WHERE state = 'PENDING'")
    fun observePendingOnlyCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_changes WHERE state = 'SENDING'")
    fun observeSendingCount(): Flow<Int>

    @Query("UPDATE sync_changes SET state = 'SENDING', attempts = attempts + 1, lastAttemptAt = :now, lastMessageId = :messageId, nextAttemptAt = :nextAttemptAt WHERE changeId IN (:changeIds)")
    suspend fun markSending(changeIds: List<String>, now: Long, messageId: String, nextAttemptAt: Long)

    @Query("UPDATE sync_changes SET state = 'PENDING', nextAttemptAt = :nextAttemptAt, lastAttemptAt = :now WHERE changeId IN (:changeIds)")
    suspend fun markRetry(changeIds: List<String>, now: Long, nextAttemptAt: Long)

    @Query("DELETE FROM sync_changes WHERE changeId IN (:changeIds)")
    suspend fun deleteAcknowledged(changeIds: List<String>)

    @Query("DELETE FROM sync_changes WHERE entityType = :entityType AND entityId = :entityId AND state = 'PENDING' AND changeId != :keepChangeId")
    suspend fun coalescePending(entityType: String, entityId: String, keepChangeId: String)

    /** هر ردیف قدیمی‌تر همان موجودیت (PENDING یا SENDING) را حذف می‌کند تا صف گیر نکند. */
    @Query("DELETE FROM sync_changes WHERE entityType = :entityType AND entityId = :entityId AND changeId != :keepChangeId")
    suspend fun deleteOlderForEntity(entityType: String, entityId: String, keepChangeId: String)

    @Query("SELECT changeId FROM sync_changes WHERE state = 'SENDING'")
    suspend fun sendingIds(): List<String>

    @Query("UPDATE sync_changes SET state = 'PENDING', nextAttemptAt = 0, lastAttemptAt = :now WHERE state = 'SENDING'")
    suspend fun releaseAllSending(now: Long)

    /** Reclaim SENDING rows whose attempt window expired so transport can retry. */
    @Query(
        """
        UPDATE sync_changes
        SET state = 'PENDING', nextAttemptAt = 0, lastAttemptAt = :now
        WHERE state = 'SENDING' AND (lastAttemptAt IS NULL OR lastAttemptAt < :staleBefore)
        """
    )
    suspend fun releaseStaleSending(now: Long, staleBefore: Long): Int

    @Query("SELECT COUNT(*) FROM sync_changes WHERE state = 'PENDING' OR state = 'SENDING'")
    suspend fun pendingOrSendingCount(): Int
}

@Dao
interface SyncAcknowledgementDao {
    @Query("SELECT * FROM sync_acknowledgements ORDER BY receivedAt ASC LIMIT :limit")
    suspend fun pending(limit: Int): List<SyncAcknowledgementEntity>

    @Query("SELECT COUNT(*) FROM sync_acknowledgements")
    fun observePendingCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_acknowledgements")
    suspend fun pendingCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(acknowledgements: List<SyncAcknowledgementEntity>)

    @Query("DELETE FROM sync_acknowledgements WHERE changeId IN (:changeIds)")
    suspend fun deleteSent(changeIds: List<String>)
}


@Dao
interface SyncVersionDao {
    @Query("SELECT * FROM sync_versions WHERE entityType = :entityType AND entityId = :entityId LIMIT 1")
    suspend fun find(entityType: String, entityId: String): SyncVersionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(version: SyncVersionEntity)
}

@Dao
interface SyncRuntimeControlDao {
    @Query("SELECT * FROM sync_runtime_control WHERE id = 1 LIMIT 1")
    suspend fun get(): SyncRuntimeControlEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(control: SyncRuntimeControlEntity)

    @Query("UPDATE sync_runtime_control SET suppressOutbox = :suppress WHERE id = 1")
    suspend fun setSuppressOutbox(suppress: Boolean)
}

@Dao
interface SyncSessionStateDao {
    @Query("SELECT * FROM sync_session_state WHERE id = 1 LIMIT 1")
    suspend fun get(): SyncSessionStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: SyncSessionStateEntity)
}

@Dao
interface CycleLogDao {
    @Query("SELECT * FROM cycle_logs WHERE isDeleted = 0 ORDER BY startAt DESC")
    fun observeAll(): Flow<List<CycleLogEntity>>

    @Query("SELECT * FROM cycle_logs")
    suspend fun getAllOnce(): List<CycleLogEntity>

    @Query("SELECT * FROM cycle_logs WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): CycleLogEntity?


    @Query("SELECT updatedAt FROM cycle_logs WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: CycleLogEntity)

    @Update
    suspend fun update(log: CycleLogEntity)
}

@Dao
interface CycleSettingsDao {
    @Query("SELECT * FROM cycle_settings WHERE id = 'cycle-settings' LIMIT 1")
    fun observe(): Flow<CycleSettingsEntity?>

    @Query("SELECT * FROM cycle_settings")
    suspend fun getAllOnce(): List<CycleSettingsEntity>

    @Query("SELECT * FROM cycle_settings WHERE id = 'cycle-settings' LIMIT 1")
    suspend fun getOnce(): CycleSettingsEntity?

    @Query("SELECT updatedAt FROM cycle_settings WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(settings: CycleSettingsEntity)
}

@Dao
interface LocationShareDao {
    @Query("SELECT * FROM location_shares WHERE isDeleted = 0 ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<LocationShareEntity>>

    @Query("SELECT * FROM location_shares")
    suspend fun getAllOnce(): List<LocationShareEntity>

    @Query("SELECT * FROM location_shares WHERE id = :deviceId LIMIT 1")
    suspend fun findById(deviceId: String): LocationShareEntity?

    @Query("SELECT updatedAt FROM location_shares WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(share: LocationShareEntity)
}

@Dao
interface HeartPulseDao {
    @Query("SELECT * FROM heart_pulses WHERE isDeleted = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<HeartPulseEntity>>

    @Query("SELECT * FROM heart_pulses")
    suspend fun getAllOnce(): List<HeartPulseEntity>

    @Query("SELECT * FROM heart_pulses WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): HeartPulseEntity?

    @Query("SELECT updatedAt FROM heart_pulses WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pulse: HeartPulseEntity)

    @Update
    suspend fun update(pulse: HeartPulseEntity)
}

@Dao
interface SharedPlaceDao {
    @Query("SELECT * FROM shared_places WHERE isDeleted = 0 ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<SharedPlaceEntity>>

    @Query("SELECT * FROM shared_places")
    suspend fun getAllOnce(): List<SharedPlaceEntity>

    @Query("SELECT * FROM shared_places WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): SharedPlaceEntity?

    @Query("SELECT updatedAt FROM shared_places WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(place: SharedPlaceEntity)

    @Update
    suspend fun update(place: SharedPlaceEntity)
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits WHERE isDeleted = 0 ORDER BY kind ASC, updatedAt DESC")
    fun observeAll(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits")
    suspend fun getAllOnce(): List<HabitEntity>

    @Query("SELECT * FROM habits WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): HabitEntity?

    @Query("SELECT updatedAt FROM habits WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(habit: HabitEntity)

    @Update
    suspend fun update(habit: HabitEntity)
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist_items WHERE isDeleted = 0 ORDER BY status ASC, updatedAt DESC")
    fun observeAll(): Flow<List<WatchlistItemEntity>>

    @Query("SELECT * FROM watchlist_items")
    suspend fun getAllOnce(): List<WatchlistItemEntity>

    @Query("SELECT * FROM watchlist_items WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): WatchlistItemEntity?

    @Query("SELECT updatedAt FROM watchlist_items WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchlistItemEntity)

    @Update
    suspend fun update(item: WatchlistItemEntity)
}


@Dao
interface BookDao {
    @Query("SELECT * FROM book_items WHERE isDeleted = 0 ORDER BY status ASC, updatedAt DESC")
    fun observeAll(): Flow<List<BookItemEntity>>

    @Query("SELECT * FROM book_items")
    suspend fun getAllOnce(): List<BookItemEntity>

    @Query("SELECT * FROM book_items WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): BookItemEntity?

    @Query("SELECT updatedAt FROM book_items WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: BookItemEntity)

    @Update
    suspend fun update(item: BookItemEntity)
}

@Dao
interface FoodDao {
    @Query("SELECT * FROM food_items WHERE isDeleted = 0 ORDER BY isFavorite DESC, name ASC")
    fun observeAll(): Flow<List<FoodItemEntity>>

    @Query("SELECT * FROM food_items")
    suspend fun getAllOnce(): List<FoodItemEntity>

    @Query("SELECT COUNT(*) FROM food_items")
    suspend fun countAll(): Int

    @Query("SELECT * FROM food_items WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): FoodItemEntity?

    @Query("SELECT updatedAt FROM food_items WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: FoodItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<FoodItemEntity>)

    @Update
    suspend fun update(item: FoodItemEntity)
}

@Dao
interface TelegramStickerPackDao {
    @Query("SELECT * FROM telegram_sticker_packs WHERE isDeleted = 0 ORDER BY importedAt DESC")
    fun observeAll(): Flow<List<TelegramStickerPackEntity>>

    @Query("SELECT * FROM telegram_sticker_packs WHERE isDeleted = 0 ORDER BY importedAt DESC")
    suspend fun getAllOnce(): List<TelegramStickerPackEntity>

    /** Includes removal tombstones for full snapshots and incremental conflict resolution. */
    @Query("SELECT * FROM telegram_sticker_packs ORDER BY importedAt DESC")
    suspend fun getAllForSync(): List<TelegramStickerPackEntity>

    @Query("SELECT * FROM telegram_sticker_packs WHERE name = :name LIMIT 1")
    suspend fun findByName(name: String): TelegramStickerPackEntity?

    @Query("SELECT updatedAt FROM telegram_sticker_packs WHERE name = :name LIMIT 1")
    suspend fun updatedAt(name: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pack: TelegramStickerPackEntity)
}

@Dao
interface TelegramStickerDao {
    @Query("""
        SELECT s.* FROM telegram_stickers AS s
        INNER JOIN telegram_sticker_packs AS p ON p.name = s.packName
        WHERE s.packName = :packName AND p.isDeleted = 0
        ORDER BY s.createdAt ASC
    """)
    fun observeByPack(packName: String): Flow<List<TelegramStickerEntity>>

    @Query("""
        SELECT s.* FROM telegram_stickers AS s
        INNER JOIN telegram_sticker_packs AS p ON p.name = s.packName
        WHERE s.packName = :packName AND p.isDeleted = 0
        ORDER BY s.createdAt ASC
    """)
    suspend fun getByPack(packName: String): List<TelegramStickerEntity>

    @Query("""
        SELECT s.* FROM telegram_stickers AS s
        INNER JOIN telegram_sticker_packs AS p ON p.name = s.packName
        WHERE s.id = :id AND p.isDeleted = 0
        LIMIT 1
    """)
    suspend fun findById(id: String): TelegramStickerEntity?

    /** Full snapshot export excludes bytes left behind by a late, pre-delete delta. */
    @Query("""
        SELECT s.* FROM telegram_stickers AS s
        INNER JOIN telegram_sticker_packs AS p ON p.name = s.packName
        WHERE p.isDeleted = 0
        ORDER BY s.createdAt ASC
    """)
    suspend fun getAllForSync(): List<TelegramStickerEntity>

    @Query("SELECT updatedAt FROM telegram_stickers WHERE id = :id LIMIT 1")
    suspend fun updatedAt(id: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(sticker: TelegramStickerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(stickers: List<TelegramStickerEntity>)

    @Query("DELETE FROM telegram_stickers WHERE packName = :packName")
    suspend fun deleteByPack(packName: String)

    @Query("SELECT COUNT(*) FROM telegram_stickers")
    suspend fun countAll(): Int
}
