llama.cpp is NOT vendored in this repository (to keep project size small).

Use the shared install at:
  C:\Android\llama.cpp

One-time setup (Windows):
  powershell -ExecutionPolicy Bypass -File SETUP-LLAMA-SHARED.ps1

Or manually:
  git clone --depth 1 --branch b4381 https://github.com/ggml-org/llama.cpp.git C:\Android\llama.cpp

CMake / Gradle already point to that path via -DOURSPACE_LLAMA_DIR=C:/Android/llama.cpp
