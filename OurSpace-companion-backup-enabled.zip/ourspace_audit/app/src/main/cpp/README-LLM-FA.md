# تکمیل بومی OurSpace LLM

## هدف
اجرای واقعی مدل GGUF روی گوشی میزبان با llama.cpp.

## بیلد
- پیش‌فرض: `-DOURSPACE_ENABLE_LLAMA=ON`
- مسیر ترجیحی (خارج از پروژه برای حجم کم):
  `C:\Android\llama.cpp`
  یک‌بار: `powershell -ExecutionPolicy Bypass -File SETUP-LLAMA-SHARED.ps1`
  یا: `git clone --depth 1 --branch b4381 https://github.com/ggml-org/llama.cpp.git C:\Android\llama.cpp`
- در `app/build.gradle.kts` تنظیم شده: `-DOURSPACE_LLAMA_DIR=C:/Android/llama.cpp`
- اگر مسیر مشترک نبود، FetchContent به‌صورت آخرین راه‌حل دانلود می‌کند (اینترنت لازم است).

## بدون llama
`-DOURSPACE_ENABLE_LLAMA=OFF` → فقط پل بومی.

## جریان
1. دانلود/کپی `.gguf` در تنظیمات → هوش مصنوعی میزبان
2. لود مدل روی میزبان
3. همراه با ai_request از میزبان استفاده می‌کند
