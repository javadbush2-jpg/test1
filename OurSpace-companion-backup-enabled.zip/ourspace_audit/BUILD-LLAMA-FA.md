# بیلد قطعی با llama.cpp

> **توجه:** سورس `llama.cpp` از داخل پروژه حذف شده است.
> قبل از بیلد یک‌بار مسیر مشترک را آماده کنید:
> `powershell -ExecutionPolicy Bypass -File SETUP-LLAMA-SHARED.ps1`
> مسیر: `C:\Android\llama.cpp`


## ۱) پاک‌سازی اجباری (بدون این، APK قدیمی می‌ماند)

```powershell
cd C:\Users\javad\Desktop\apk
.\gradlew.bat --stop
Remove-Item -Recurse -Force app\.cxx -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force app\build -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force .gradle\caches\transforms-* -ErrorAction SilentlyContinue
```

## ۲) بیلد

```powershell
.\gradlew.bat assembleDebug --rerun-tasks
```

اولین بیلد با llama معمولاً **۱۵ تا ۴۰ دقیقه** طول می‌کشد.
اگر زیر ۲–۳ دقیقه تمام شد، یعنی native دوباره ساخته نشده.

در لاگ دنبال این بگردید (ممکن است به‌صورت WARNING باشد):

```text
OurSpace LLM: using OURSPACE_LLAMA_DIR=C:/Android/llama.cpp
OurSpace LLM: using shared path C:/Android/llama.cpp
OurSpace LLM: LINKED real llama.cpp (OURSPACE_HAS_LLAMA=1, static)
```

## ۳) تأیید اجباری قبل از نصب

```powershell
.\gradlew.bat verifyOurspaceLlmLinked
```

باید بگوید:

```text
OK: libourspace_llm.so appears to include llama.cpp
```

اگر `bridge-only` یا سایز خیلی کوچک بود، APK را نصب نکنید.

## ۴) نصب

APK معمولاً اینجاست:

```text
app\build\outputs\apk\debug\app-debug.apk
```

اپ قبلی را حذف کنید، بعد این APK را نصب کنید.

## ۵) در گوشی

تنظیمات → هوش مصنوعی میزبان باید باشد:

- **آماده · استنتاج واقعی llama.cpp**
- موتور: **local-llama**

اگر مدل ۷B لود نشد (کمبود رم)، مدل ۳B را امتحان کنید.
