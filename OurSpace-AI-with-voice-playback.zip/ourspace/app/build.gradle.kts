plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    // FCM/Firebase is optional. Plugin is applied only when google-services.json exists.
    // See FCM-SETUP-FA.md — without it the app uses WebSocket + long-poll + WorkManager.
}

// Apply Google Services only if the config file is present (avoids assembleDebug failure).
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

android {
    namespace = "com.ourspace.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ourspace.app"
        minSdk = 31
        targetSdk = 35
        versionCode = 173
        versionName = "0.9.0-alpha173-api31-dynamic-color"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true

        // Only ship ABIs used on real phones → big win for WebRTC + SQLCipher .so size.
        // Emulator (x86/x86_64): temporarily remove abiFilters while developing on emulator.
        ndk {
            // arm64 only: host LLM targets modern phones; speeds native llama build
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-fexceptions", "-frtti")
                arguments += listOf(
                    "-DANDROID_STL=c++_static",
                    "-DOURSPACE_ENABLE_LLAMA=ON",
                    // Fixed shared location (survives clean of app/.cxx):
                    "-DOURSPACE_LLAMA_DIR=C:/Android/llama.cpp",
                    "-DGGML_NATIVE=OFF",
                    "-DGGML_OPENMP=OFF",
                    "-DGGML_CCACHE=OFF",
                    "-DGGML_CPU_ARM_ARCH=armv8-a",
                    "-DGGML_BLAS=OFF",
                    "-DGGML_VULKAN=OFF"
                )
            }
        }

        // Keep only languages the app actually uses (Persian + fallback English).
        resourceConfigurations += listOf("en", "fa")
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // Prefer Android App Bundle when publishing; Play delivers per-ABI splits automatically.
    bundle {
        abi {
            enableSplit = true
        }
        language {
            enableSplit = true
        }
        density {
            enableSplit = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "META-INF/DEPENDENCIES",
            "META-INF/*.kotlin_module",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*",
            "META-INF/ASL2.0",
            "META-INF/INDEX.LIST",
            "DebugProbesKt.bin"
        )
        jniLibs {
            useLegacyPackaging = false
            excludes += setOf("**/x86/**", "**/x86_64/**")
        }
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    // Extended icons are tree-shaken by R8 in release when unused.
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // WebRTC — heaviest dependency (native). ABI filters above mitigate APK size.
    implementation("io.getstream:stream-webrtc-android:1.3.8")

    // Persistent WebSocket push to personal relay (/v1/push)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Animated Telegram stickers (TGS → Lottie)
    implementation("com.airbnb.android:lottie-compose:6.6.2")

    // FCM data-only wake (no message body on the push channel)
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-messaging")

    implementation("androidx.room:room-runtime:2.7.2")
    implementation("androidx.room:room-ktx:2.7.2")
    implementation("androidx.sqlite:sqlite-ktx:2.6.2")
    ksp("androidx.room:room-compiler:2.7.2")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.12.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
