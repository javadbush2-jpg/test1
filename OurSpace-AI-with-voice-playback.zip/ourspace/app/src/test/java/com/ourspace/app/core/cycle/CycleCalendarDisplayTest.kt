package com.ourspace.app.core.cycle

import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CycleCalendarDisplayTest {
    @Test
    fun longAutoClosedLogOnlyMarksFirstFiveDays() {
        val start = localDay(2026, Calendar.JANUARY, 2)
        val now = localDay(2026, Calendar.FEBRUARY, 1)
        val log = cycleLog(startAt = start, endAt = localDay(2026, Calendar.JANUARY, 30))

        for (offset in 0 until 5) {
            assertTrue(CycleCalendarDisplay.isActualPeriodOn(log, localDayAfter(start, offset), localDayEndAfter(start, offset), now))
        }
        assertFalse(CycleCalendarDisplay.isActualPeriodOn(log, localDayAfter(start, 5), localDayEndAfter(start, 5), now))
        assertEquals(localDayEndAfter(start, 4), CycleCalendarDisplay.actualPeriodEndAt(log, now))
    }

    @Test
    fun earlyRecordedEndIsPreserved() {
        val start = localDay(2026, Calendar.MARCH, 4)
        val end = localDay(2026, Calendar.MARCH, 6) + 8 * 60 * 60 * 1000L
        val now = localDay(2026, Calendar.MARCH, 20)
        val log = cycleLog(startAt = start, endAt = end)

        assertTrue(CycleCalendarDisplay.isActualPeriodOn(log, localDayAfter(start, 2), localDayEndAfter(start, 2), now))
        assertFalse(CycleCalendarDisplay.isActualPeriodOn(log, localDayAfter(start, 3), localDayEndAfter(start, 3), now))
    }

    @Test
    fun openLogDoesNotMarkDaysAfterToday() {
        val start = localDay(2026, Calendar.APRIL, 2)
        val today = localDayAfter(start, 2)
        val now = today + 12 * 60 * 60 * 1000L
        val log = cycleLog(startAt = start, endAt = null)

        assertTrue(CycleCalendarDisplay.isActualPeriodOn(log, today, localDayEndAfter(start, 2), now))
        assertFalse(CycleCalendarDisplay.isActualPeriodOn(log, localDayAfter(start, 3), localDayEndAfter(start, 3), now))
    }

    @Test
    fun upcomingPredictionMarksOnlyFirstThreeDays() {
        val now = localDay(2026, Calendar.MAY, 10) + 12 * 60 * 60 * 1000L
        val lastStart = Calendar.getInstance().apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, -18)
        }.timeInMillis
        val settings = settings(averageCycleDays = 28, averagePeriodDays = 5, trackingEnabled = true)
        val window = CycleCalendarDisplay.predictedNextPeriod(listOf(cycleLog(lastStart)), settings, now)

        assertNotNull(window)
        val actualWindow = requireNotNull(window)
        val start = actualWindow.startAt
        for (offset in 0 until 3) {
            assertTrue(actualWindow.overlaps(localDayAfter(start, offset), localDayEndAfter(start, offset)))
        }
        assertFalse(actualWindow.overlaps(localDayAfter(start, 3), localDayEndAfter(start, 3)))
    }

    @Test
    fun predictionHonorsTrackingSettingAndShorterConfiguredPeriod() {
        val now = localDay(2026, Calendar.JUNE, 10) + 12 * 60 * 60 * 1000L
        val lastStart = Calendar.getInstance().apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, -18)
        }.timeInMillis
        val logs = listOf(cycleLog(lastStart))

        assertNull(CycleCalendarDisplay.predictedNextPeriod(logs, settings(trackingEnabled = false), now))
        val twoDayWindow = CycleCalendarDisplay.predictedNextPeriod(
            logs,
            settings(averagePeriodDays = 2),
            now
        )
        assertNotNull(twoDayWindow)
        val actualWindow = requireNotNull(twoDayWindow)
        val start = actualWindow.startAt
        assertTrue(actualWindow.overlaps(localDayAfter(start, 1), localDayEndAfter(start, 1)))
        assertFalse(actualWindow.overlaps(localDayAfter(start, 2), localDayEndAfter(start, 2)))
    }

    private fun cycleLog(startAt: Long, endAt: Long? = null) = CycleLogEntity(
        id = "cycle-${startAt}",
        startAt = startAt,
        endAt = endAt,
        recordedByDeviceId = "test-device",
        createdAt = startAt,
        updatedAt = startAt
    )

    private fun settings(
        averageCycleDays: Int = 28,
        averagePeriodDays: Int = 5,
        trackingEnabled: Boolean = true
    ) = CycleSettingsEntity(
        averageCycleDays = averageCycleDays,
        averagePeriodDays = averagePeriodDays,
        trackingEnabled = trackingEnabled,
        createdAt = 1L,
        updatedAt = 1L
    )

    private fun localDay(year: Int, month: Int, day: Int): Long = Calendar.getInstance().apply {
        clear()
        set(year, month, day, 0, 0, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun localDayAfter(epoch: Long, days: Int): Long = Calendar.getInstance().apply {
        timeInMillis = epoch
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, days)
    }.timeInMillis

    private fun localDayEndAfter(epoch: Long, days: Int): Long = Calendar.getInstance().apply {
        timeInMillis = localDayAfter(epoch, days)
        add(Calendar.DAY_OF_YEAR, 1)
        add(Calendar.MILLISECOND, -1)
    }.timeInMillis
}
