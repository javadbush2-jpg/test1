package com.ourspace.app.core.relay

import org.junit.Assert.assertEquals
import org.junit.Test

class RelayEndpointValidatorTest {
    @Test
    fun productionDefaultUsesHttpsOriginRatherThanInternalRelayPort() {
        assertEquals("https://ourspace.iddns.ir", RelayConfig.DEFAULT_ENDPOINT)
    }

    @Test
    fun pastedAdminPageUrlNormalizesToRelayBase() {
        assertEquals(
            "https://sync.example.com",
            RelayEndpointValidator.normalize("https://sync.example.com/admin")
        )
        assertEquals(
            "https://sync.example.com/relay",
            RelayEndpointValidator.normalize("https://sync.example.com/relay/admin/")
        )
    }

    @Test
    fun hostAndExplicitHomeRelayPortRemainSupported() {
        assertEquals(
            "https://sync.example.com",
            RelayEndpointValidator.normalize("sync.example.com")
        )
        assertEquals(
            "http://192.168.1.50:8787",
            RelayEndpointValidator.normalize("192.168.1.50:8787")
        )
    }
}
