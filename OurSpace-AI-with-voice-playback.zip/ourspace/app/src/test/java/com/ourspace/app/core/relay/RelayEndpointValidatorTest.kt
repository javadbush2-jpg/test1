package com.ourspace.app.core.relay

import org.junit.Assert.assertEquals
import org.junit.Test

class RelayEndpointValidatorTest {
    @Test
    fun defaultUsesDirectHttpRelayEndpoint() {
        assertEquals("http://ourspace.iddns.ir:8787", RelayConfig.DEFAULT_ENDPOINT)
    }

    @Test
    fun pastedAdminPageUrlNormalizesToRelayBase() {
        assertEquals(
            "http://sync.example.com:8787",
            RelayEndpointValidator.normalize("http://sync.example.com:8787/admin")
        )
        assertEquals(
            "http://sync.example.com:8787/relay",
            RelayEndpointValidator.normalize("http://sync.example.com:8787/relay/admin/")
        )
    }

    @Test
    fun unqualifiedAndExplicitHomeRelayAddressesUseHttp() {
        assertEquals(
            "http://sync.example.com",
            RelayEndpointValidator.normalize("sync.example.com")
        )
        assertEquals(
            "http://192.168.1.50:8787",
            RelayEndpointValidator.normalize("192.168.1.50:8787")
        )
    }
}
