Clone llama.cpp here or use FetchContent.
