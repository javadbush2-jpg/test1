#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#define LOG_TAG "ourspace_llm"
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define ALOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifdef OURSPACE_HAS_LLAMA
#include "llama.h"
#endif

static std::mutex g_mu;
static std::string g_model_path;
static bool g_loaded = false;
static std::atomic<bool> g_cancel_requested{false};

#ifdef OURSPACE_HAS_LLAMA
static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static bool g_backend_inited = false;
#endif

static bool file_is_gguf(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    char magic[4] = {0};
    size_t n = fread(magic, 1, 4, f);
    fclose(f);
    return n == 4 && magic[0] == 'G' && magic[1] == 'G' && magic[2] == 'U' && magic[3] == 'F';
}

static std::string bridge_complete(const std::string &prompt) {
    bool has_draft = prompt.find("پیش‌نویس") != std::string::npos ||
                     prompt.find("بازنویسی") != std::string::npos;
    bool sad = prompt.find("SAD") != std::string::npos ||
               prompt.find("STRESSED") != std::string::npos ||
               prompt.find("ANXIOUS") != std::string::npos;
    bool happy = prompt.find("HAPPY") != std::string::npos ||
                 prompt.find("LOVED") != std::string::npos ||
                 prompt.find("GREAT") != std::string::npos;
    if (has_draft) {
        return "متن‌ت را کمی نرم‌تر می‌گویم: هر چه در دل داری را با آرامش بگو؛ من اینجام و می‌شنوم.";
    }
    if (sad) {
        return "کنارت هستم. لازم نیست تنها تحمل کنی؛ هر وقت خواستی حرف بزن، من گوش می‌دهم.";
    }
    if (happy) {
        return "از حال خوبت خوشحال شدم. دوست دارم بیشتر از روزت برام بگویی.";
    }
    return "سلام، دلم برایت تنگ شده بود. اگر الان وقت داری، از روزت بگو.";
}

#ifdef OURSPACE_HAS_LLAMA
static void free_llama_locked() {
    if (g_ctx) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model) {
        llama_free_model(g_model);
        g_model = nullptr;
    }
    g_loaded = false;
    g_model_path.clear();
}

static int load_llama_locked(const std::string &path) {
    free_llama_locked();
    if (!g_backend_inited) {
        llama_backend_init();
        g_backend_inited = true;
    }

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0;

    g_model = llama_load_model_from_file(path.c_str(), mparams);
    if (!g_model) {
        ALOGE("llama_load_model_from_file failed: %s", path.c_str());
        return 3;
    }

    llama_context_params cparams = llama_context_default_params();
    // Mobile-safe defaults: smaller KV cache/batch and fewer worker threads reduce
    // peak RAM, sustained CPU load, and thermal throttling on phones.
    cparams.n_ctx = 1024;
    cparams.n_batch = 128;
    int threads = (int) std::thread::hardware_concurrency();
    if (threads < 2) threads = 2;
    if (threads > 3) threads = 3;
    cparams.n_threads = threads;
    cparams.n_threads_batch = threads;

    g_ctx = llama_new_context_with_model(g_model, cparams);
    if (!g_ctx) {
        ALOGE("llama_new_context_with_model failed");
        llama_free_model(g_model);
        g_model = nullptr;
        return 4;
    }

    g_model_path = path;
    g_loaded = true;
    ALOGI("llama model ready path=%s threads=%d", path.c_str(), threads);
    return 0;
}

static std::string llama_complete_locked(const std::string &prompt, int max_tokens) {
    if (!g_loaded || !g_ctx || !g_model) return "";
    if (max_tokens < 16) max_tokens = 16;
    if (max_tokens > 256) max_tokens = 256;

    g_cancel_requested.store(false, std::memory_order_relaxed);
    llama_kv_cache_clear(g_ctx);

    std::vector<llama_token> tokens;
    tokens.resize(prompt.size() + 64);
    int n = llama_tokenize(
        g_model,
        prompt.c_str(),
        (int32_t) prompt.size(),
        tokens.data(),
        (int32_t) tokens.size(),
        true,
        true
    );
    if (n < 0) {
        tokens.resize((size_t) (-n) + 8);
        n = llama_tokenize(
            g_model,
            prompt.c_str(),
            (int32_t) prompt.size(),
            tokens.data(),
            (int32_t) tokens.size(),
            true,
            true
        );
    }
    if (n <= 0) {
        ALOGE("tokenize failed n=%d", n);
        return "";
    }
    tokens.resize(n);

    const int n_ctx = (int) llama_n_ctx(g_ctx);
    if (n >= n_ctx - 8) {
        const int keep = n_ctx - 64;
        if (keep > 0 && n > keep) {
            tokens.erase(tokens.begin(), tokens.begin() + (n - keep));
            n = (int) tokens.size();
        }
    }

    llama_batch batch = llama_batch_get_one(tokens.data(), n);
    if (llama_decode(g_ctx, batch) != 0) {
        ALOGE("llama_decode(prompt) failed");
        return "";
    }

    llama_sampler_chain_params sparams = llama_sampler_chain_default_params();
    llama_sampler * smpl = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.75f));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(0));

    std::string out;
    out.reserve(512);
    for (int i = 0; i < max_tokens; ++i) {
        if (g_cancel_requested.load(std::memory_order_relaxed)) {
            ALOGW("generation cancelled at token=%d", i);
            break;
        }
        llama_token id = llama_sampler_sample(smpl, g_ctx, -1);
        if (llama_token_is_eog(g_model, id)) {
            break;
        }
        char buf[256];
        int nn = llama_token_to_piece(g_model, id, buf, sizeof(buf), 0, true);
        if (nn > 0) {
            out.append(buf, buf + nn);
        }
        if (out.size() > 40 && out.find("\n\n") != std::string::npos) {
            break;
        }
        batch = llama_batch_get_one(&id, 1);
        if (llama_decode(g_ctx, batch) != 0) {
            ALOGW("decode step failed at i=%d", i);
            break;
        }
    }
    llama_sampler_free(smpl);

    while (!out.empty() && (out.back() == '\n' || out.back() == ' ' || out.back() == '\r')) {
        out.pop_back();
    }
    return out;
}
#endif

extern "C" JNIEXPORT jint JNICALL
Java_com_ourspace_app_core_ai_HostLlmRuntime_nativePing(JNIEnv *, jclass) {
#ifdef OURSPACE_HAS_LLAMA
    return 2;
#else
    return 1;
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_com_ourspace_app_core_ai_HostLlmRuntime_nativeBackendKind(JNIEnv *, jclass) {
#ifdef OURSPACE_HAS_LLAMA
    return 2;
#else
    return 1;
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_com_ourspace_app_core_ai_HostLlmRuntime_nativeLoadModel(JNIEnv *env, jclass, jstring jpath) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    if (!path) return -1;
    std::string p(path);
    env->ReleaseStringUTFChars(jpath, path);

    std::lock_guard<std::mutex> lock(g_mu);
    if (!file_is_gguf(p.c_str())) {
        ALOGW("not a GGUF file: %s", p.c_str());
        return 2;
    }
#ifdef OURSPACE_HAS_LLAMA
    return load_llama_locked(p);
#else
    g_model_path = p;
    g_loaded = true;
    return 0;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_ourspace_app_core_ai_HostLlmRuntime_nativeUnloadModel(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mu);
#ifdef OURSPACE_HAS_LLAMA
    free_llama_locked();
#else
    g_model_path.clear();
    g_loaded = false;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_ourspace_app_core_ai_HostLlmRuntime_nativeCancelGeneration(JNIEnv *, jclass) {
    // Atomic-only: must never wait for g_mu while nativeComplete holds it.
    g_cancel_requested.store(true, std::memory_order_relaxed);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ourspace_app_core_ai_HostLlmRuntime_nativeComplete(JNIEnv *env, jclass, jstring jprompt, jint maxTokens) {
    const char *promptChars = env->GetStringUTFChars(jprompt, nullptr);
    if (!promptChars) return nullptr;
    std::string prompt(promptChars);
    env->ReleaseStringUTFChars(jprompt, promptChars);

    std::lock_guard<std::mutex> lock(g_mu);
    if (!g_loaded) {
        return env->NewStringUTF("");
    }

    std::string out;
#ifdef OURSPACE_HAS_LLAMA
    out = llama_complete_locked(prompt, (int) maxTokens);
    if (out.empty()) {
        ALOGW("llama empty; bridge fallback");
        out = bridge_complete(prompt);
    }
#else
    (void) maxTokens;
    out = bridge_complete(prompt);
#endif
    if (out.size() > 2000) out.resize(2000);
    return env->NewStringUTF(out.c_str());
}
