# تکمیل بومی OurSpace LLM

## هدف
اجرای واقعی مدل GGUF روی گوشی میزبان با llama.cpp.

## بیلد
- پیش‌فرض: `-DOURSPACE_ENABLE_LLAMA=ON`
- اولین بیلد ممکن است llama.cpp را با FetchContent بگیرد (اینترنت).
- یا:
  `git clone --depth 1 https://github.com/ggml-org/llama.cpp.git app/src/main/cpp/third_party/llama.cpp`
- یا `-DOURSPACE_LLAMA_DIR=/path/to/llama.cpp`

## بدون llama
`-DOURSPACE_ENABLE_LLAMA=OFF` → فقط پل بومی.

## جریان
1. دانلود/کپی `.gguf` در تنظیمات → هوش مصنوعی میزبان
2. لود مدل روی میزبان
3. همراه با ai_request از میزبان استفاده می‌کند
