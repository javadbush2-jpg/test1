package com.ourspace.app.core.security

import org.json.JSONObject

/**
 * Application-level payload codec.
 *
 * Historically this wrapped payloads in AES-GCM. That path was unused on the live
 * relay/WebRTC exchange (envelopes already travel as plain JSON) and only added
 * complexity. encrypt/decrypt are now identity operations so any residual callers
 * stay compatible without crypto cost.
 */
object SyncPayloadCrypto {
    fun encrypt(payload: JSONObject, secret: ByteArray): JSONObject {
        // secret retained in signature for call-site compatibility; not used.
        return payload
    }

    fun decrypt(envelope: JSONObject, secret: ByteArray): JSONObject {
        if (envelope.optString("type") == "ourspace_encrypted") {
            // Legacy ciphertext is no longer supported after crypto removal.
            throw IllegalStateException("پیام رمزنگاری‌شده قدیمی پشتیبانی نمی‌شود؛ همگام‌سازی مجدد لازم است")
        }
        return envelope
    }
}
