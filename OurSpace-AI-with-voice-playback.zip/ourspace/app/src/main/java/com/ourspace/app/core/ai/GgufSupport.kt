package com.ourspace.app.core.ai

import java.io.File
import java.io.RandomAccessFile

/** Lightweight GGUF container checks (no full parse). */
object GgufSupport {
    private val MAGIC = byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte())

    fun isValidGguf(file: File): Boolean {
        if (!file.exists() || file.length() < 64) return false
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                val magic = ByteArray(4)
                raf.readFully(magic)
                magic.contentEquals(MAGIC)
            }
        }.getOrDefault(false)
    }

    fun describe(file: File): String {
        if (!file.exists()) return "فایل نیست"
        if (!isValidGguf(file)) return "فرمت GGUF معتبر نیست"
        val mb = file.length() / (1024L * 1024L)
        return "GGUF معتبر · حدود ${mb} مگابایت"
    }
}
