package com.ourspace.app.core.finance

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Telephony
import androidx.core.content.ContextCompat
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import java.security.MessageDigest

/**
 * با رسیدن هر پیامک، متن آن را با پارسر بانکی بررسی می‌کند. اگر تراکنش بانکی قابل‌اطمینان
 * تشخیص داده شود، در صف [PendingSmsStore] می‌نشیند و یک اعلان «انتخاب دسته‌بندی» می‌فرستد.
 * هیچ تراکنشی بدون تأیید دسته‌بندی توسط کاربر در دفتر مالی ثبت نمی‌شود.
 */
class BankSmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (!AutoSmsSettings.isEnabled(context)) return
        val granted = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.RECEIVE_SMS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (messages.isEmpty()) return

        // پیامک چندبخشی را بر اساس فرستنده به هم بچسبان.
        val bySender = LinkedHashMap<String, StringBuilder>()
        var timestamp = 0L
        for (msg in messages) {
            val sender = msg.displayOriginatingAddress.orEmpty()
            val bodyPart = msg.displayMessageBody.orEmpty()
            bySender.getOrPut(sender) { StringBuilder() }.append(bodyPart)
            if (timestamp == 0L) timestamp = msg.timestampMillis
        }
        if (timestamp <= 0L) timestamp = System.currentTimeMillis()

        val appContext = context.applicationContext
        val pendingResult = goAsync()
        Thread {
            try {
                SmsTemplateStore.seedDefaultsIfEmpty(appContext)
                val alreadyImported = SmsTransactionImporter.loadImportedIds(appContext)
                bySender.forEach { (sender, bodyBuilder) ->
                    processOne(
                        context = appContext,
                        sender = sender,
                        body = bodyBuilder.toString(),
                        timestamp = timestamp,
                        alreadyImported = alreadyImported
                    )
                }
            } catch (_: Throwable) {
                // گیرندهٔ پیامک هرگز نباید با استثنا باعث کرش شود.
            } finally {
                pendingResult.finish()
            }
        }.start()
    }

    private fun processOne(
        context: Context,
        sender: String,
        body: String,
        timestamp: Long,
        alreadyImported: Set<String>
    ) {
        if (body.isBlank()) return
        val smsKey = stableKey(sender, body, timestamp)
        // شناسهٔ ردیف ارائه‌دهنده در لحظهٔ پخش در دسترس نیست؛ از کلید محتوا برای
        // جلوگیری از تکرار استفاده می‌کنیم و بعداً در اسکن دستی هم همین کلید معیار است.
        if (smsKey in alreadyImported || PendingSmsStore.containsKey(context, smsKey)) return

        val parsed = BankSmsParser.parse(body, sender, context) ?: return
        if (parsed.kind !in setOf("EXPENSE", "INCOME")) return
        if (parsed.confidence < 0.5f || parsed.amount <= 0L) return

        val item = PendingSmsTransaction(
            id = java.util.UUID.randomUUID().toString().replace("-", ""),
            smsKey = smsKey,
            address = sender.take(80),
            body = body.take(500),
            dateMillis = timestamp,
            amount = parsed.amount,
            kind = parsed.kind,
            suggestedCategory = parsed.category.ifBlank { "سایر" },
            note = parsed.note,
            bankLabel = bankLabelFromNote(parsed.note),
            templateId = parsed.templateId,
            createdAt = System.currentTimeMillis()
        )
        if (!PendingSmsStore.add(context, item)) return
        runCatching {
            OurSpaceNotificationCenter(context).showSmsTransactionPending(item)
        }
    }

    private fun bankLabelFromNote(note: String): String {
        // note توسط BankSmsParser به شکل «از پیامک · ملت · 5000 · متن…» ساخته می‌شود.
        val parts = note.split("·").map { it.trim() }
        return parts.getOrNull(1).orEmpty()
    }

    private fun stableKey(sender: String, body: String, timestamp: Long): String {
        val raw = "$sender|${body.trim()}|$timestamp"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
