package com.ourspace.app.core.reminder

import android.content.Context

/**
 * چند ساعت قبل از موعد، برای هر نوع یادآوری اعلان بیاید.
 * ۰ یعنی نزدیک همان لحظهٔ موعد (حدود نیم‌ساعت قبل تا موعد).
 */
enum class ReminderLeadCategory(
    val key: String,
    val title: String,
    val description: String,
    val defaultHours: Int
) {
    EVENTS(
        key = "lead_events",
        title = "قرارها",
        description = "چند ساعت قبل از شروع قرار",
        defaultHours = 2
    ),
    TASKS(
        key = "lead_tasks",
        title = "کارها",
        description = "چند ساعت قبل از موعد کار",
        defaultHours = 3
    ),
    SPECIAL(
        key = "lead_special",
        title = "مناسبت‌ها",
        description = "چند ساعت قبل از مناسبت",
        defaultHours = 24
    ),
    CYCLE(
        key = "lead_cycle",
        title = "چرخه",
        description = "چند ساعت قبل از شروع تقریبی دوره",
        defaultHours = 48
    ),
    SHOPPING(
        key = "lead_shopping",
        title = "خرید",
        description = "یادآوری فهرست خرید در ساعت روزانه (۰ = فقط همان ساعت)",
        defaultHours = 0
    ),
    MOOD(
        key = "lead_mood",
        title = "حال روزانه",
        description = "یادآوری ثبت حال در ساعت روزانه (۰ = فقط همان ساعت)",
        defaultHours = 0
    ),
    OPEN_TASKS(
        key = "lead_open_tasks",
        title = "خلاصه کارها",
        description = "یادآوری کارهای باز در ساعت روزانه (۰ = فقط همان ساعت)",
        defaultHours = 0
    );

    companion object {
        /** گزینه‌های قابل انتخاب (ساعت) */
        val HOUR_OPTIONS = listOf(0, 1, 2, 3, 6, 12, 24, 48, 72)
    }
}

object ReminderLeadPreferences {
    private const val PREFS = "ourspace_reminder_lead_hours"

    fun hours(context: Context, category: ReminderLeadCategory): Int =
        preferences(context).getInt(category.key, category.defaultHours).coerceIn(0, 168)

    fun setHours(context: Context, category: ReminderLeadCategory, hours: Int) {
        preferences(context).edit().putInt(category.key, hours.coerceIn(0, 168)).apply()
    }

    fun readAll(context: Context): Map<ReminderLeadCategory, Int> =
        ReminderLeadCategory.values().associateWith { hours(context, it) }

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
