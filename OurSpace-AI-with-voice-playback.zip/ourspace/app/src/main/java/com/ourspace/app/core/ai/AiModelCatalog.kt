package com.ourspace.app.core.ai

/**
 * Recommended on-device models for the Host phone (phase 2).
 * Files are downloaded separately into app storage — not bundled in the APK.
 */
data class AiModelSpec(
    val id: String,
    val displayName: String,
    val description: String,
    val parameterSize: String,
    val quantLabel: String,
    /** Approximate download size in bytes (UI only). */
    val approxBytes: Long,
    /** Optional default HTTPS URL; user may paste another mirror. */
    val defaultUrl: String,
    val minRamGb: Int,
    val fileName: String
)

object AiModelCatalog {
    val RECOMMENDED = AiModelSpec(
        id = "os-chat-7b-q4",
        displayName = "OurSpace Chat 7B (Q4)",
        description = "پیشنهادشده برای کیفیت و سرعت روی میزبان قوی. نسخه Instruct برای پیام کوتاه.",
        parameterSize = "7B–9B",
        quantLabel = "Q4_K_M",
        approxBytes = 4_500_000_000L,
        defaultUrl = "",
        minRamGb = 8,
        fileName = "ourspace-chat-7b-q4.gguf"
    )

    val LIGHT = AiModelSpec(
        id = "os-chat-3b-q4",
        displayName = "OurSpace Chat 3B (Q4)",
        description = "سبک‌تر و سریع‌تر؛ کیفیت فارسی معمولاً کمتر از ۷B است.",
        parameterSize = "3B",
        quantLabel = "Q4_K_M",
        approxBytes = 2_000_000_000L,
        defaultUrl = "",
        minRamGb = 4,
        fileName = "ourspace-chat-3b-q4.gguf"
    )

    val LOCAL_IMPORT = AiModelSpec(
        id = "local-import",
        displayName = "مدل از حافظه",
        description = "فایل GGUF از حافظهٔ گوشی.",
        parameterSize = "—",
        quantLabel = "فایل شما",
        approxBytes = 0L,
        defaultUrl = "",
        minRamGb = 0,
        fileName = "imported.gguf"
    )

    val ALL = listOf(RECOMMENDED, LIGHT)

    fun byId(id: String?): AiModelSpec = when (id) {
        LOCAL_IMPORT.id -> LOCAL_IMPORT
        LIGHT.id -> LIGHT
        RECOMMENDED.id -> RECOMMENDED
        else -> ALL.firstOrNull { it.id == id } ?: RECOMMENDED
    }
}
