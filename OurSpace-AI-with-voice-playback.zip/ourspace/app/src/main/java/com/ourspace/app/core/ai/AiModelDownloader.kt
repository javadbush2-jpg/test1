package com.ourspace.app.core.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Downloads a GGUF (or compatible) weights file into [AiModelStore] private storage.
 * Cancel by cancelling the coroutine.
 */
class AiModelDownloader(
    private val context: Context,
    private val store: AiModelStore
) {
    suspend fun download(
        url: String,
        spec: AiModelSpec = AiModelCatalog.byId(store.state.value.selectedModelId)
    ): Result<File> = withContext(Dispatchers.IO) {
        val clean = url.trim()
        if (clean.isBlank() || !(clean.startsWith("https://") || clean.startsWith("http://"))) {
            store.markError("آدرس دانلود معتبر نیست (http/https).")
            return@withContext Result.failure(IllegalArgumentException("invalid_url"))
        }
        val target = store.modelFile(spec)
        val partial = File(target.absolutePath + ".part")
        try {
            val conn = (URL(clean).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 60_000
                instanceFollowRedirects = true
                requestMethod = "GET"
            }
            conn.connect()
            val code = conn.responseCode
            if (code !in 200..299) {
                store.markError("دانلود ناموفق بود (کد $code).")
                return@withContext Result.failure(IllegalStateException("http_$code"))
            }
            val total = conn.contentLengthLong.coerceAtLeast(0L)
            conn.inputStream.use { input ->
                FileOutputStream(partial).use { output ->
                    val buf = ByteArray(256 * 1024)
                    var readSum = 0L
                    while (true) {
                        ensureActive()
                        val n = input.read(buf)
                        if (n <= 0) break
                        output.write(buf, 0, n)
                        readSum += n
                        val progress = if (total > 0) readSum.toFloat() / total.toFloat() else 0f
                        store.markDownloading(progress, readSum, total)
                    }
                    output.fd.sync()
                }
            }
            if (partial.length() < 1_000_000L) {
                partial.delete()
                store.markError("فایل دانلودشده ناقص یا خیلی کوچک است.")
                return@withContext Result.failure(IllegalStateException("file_too_small"))
            }
            if (target.exists()) target.delete()
            if (!partial.renameTo(target)) {
                partial.copyTo(target, overwrite = true)
                partial.delete()
            }
            store.markInstalled(target, spec.id)
            Result.success(target)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            runCatching { partial.delete() }
            store.markError("دانلود لغو شد.")
            throw cancelled
        } catch (error: Exception) {
            runCatching { partial.delete() }
            store.markError(error.message ?: "خطای دانلود")
            Result.failure(error)
        }
    }
}
