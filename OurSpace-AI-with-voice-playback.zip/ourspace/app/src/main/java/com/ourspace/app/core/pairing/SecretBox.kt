package com.ourspace.app.core.pairing

import android.util.Base64

/** Simple storage codec: Base64 only, no encryption and no Android Keystore dependency. */
internal class SecretBox {
    fun seal(plain: ByteArray): String =
        Base64.encodeToString(plain, Base64.NO_WRAP)

    fun open(encoded: String): ByteArray =
        Base64.decode(encoded, Base64.NO_WRAP)
}
