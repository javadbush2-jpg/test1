package com.ourspace.app.core.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.server.HostServerService
import kotlinx.coroutines.runBlocking

/**
 * گیرندهٔ پاسخ سریع از روی نوتیفیکیشن پیام.
 *
 * دو مسیر ورودی دارد:
 *  1) RemoteInput سیستم (تایپ آزاد یا انتخاب یکی از پیام‌های نمونه/choices)
 *  2) اکشن‌های مستقیم با متن آماده داخل EXTRA_CANNED_REPLY (مثل «در جلسه هستم»)
 *
 * پیام مستقیم در دیتابیس نوشته و سپس همگام‌سازی فوری درخواست می‌شود؛ تریگرهای Room
 * آن را در صندوق خروجی sync می‌گذارند و سرویس میزبان برای ارسال به گوشی مقابل بیدار می‌شود.
 */
class QuickReplyReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_QUICK_REPLY) return

        val remoteText = RemoteInput.getResultsFromIntent(intent)
            ?.getCharSequence(KEY_QUICK_REPLY_TEXT)
            ?.toString()
        val canned = intent.getStringExtra(EXTRA_CANNED_REPLY)
        val text = (remoteText ?: canned)?.trim()?.take(5_000).orEmpty()
        if (text.isBlank()) return

        val appContext = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                val app = appContext as? OurSpaceApplication ?: return@Thread
                val deviceId = runCatching {
                    DeviceIdentityManager().getOrCreateIdentity().deviceId
                }.getOrNull() ?: return@Thread

                val sentId = runBlocking {
                    app.repository.sendMessage(deviceId, text, null)
                }
                if (sentId != null) {
                    runCatching { HostServerService.requestImmediateSync(appContext) }
                }
                // نوتیف پیام بعد از پاسخ حذف شود تا کاربر بداند پاسخش ثبت شد.
                runCatching {
                    NotificationManagerCompat.from(appContext)
                        .cancel(OurSpaceNotificationCenter.MESSAGE_NOTIFICATION_ID)
                }
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_QUICK_REPLY = "com.ourspace.app.action.QUICK_REPLY"
        const val KEY_QUICK_REPLY_TEXT = "ourspace_quick_reply_text"
        const val EXTRA_CANNED_REPLY = "ourspace_canned_reply"
    }
}
