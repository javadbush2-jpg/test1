package com.ourspace.app.core.relay

import android.util.Base64
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Uploads/restores a full Room snapshot.
 * v2 = plain JSON (faster, no AES). v1 ciphertext still readable for old backups.
 */
class RelayBackupClient(
    endpoint: String,
    private val accessToken: String,
    private val deviceRole: String? = null,
    private val deviceId: String? = RelayDeviceHeaders.currentDeviceId()
) {
    private val baseUrl = RelayEndpointValidator.normalize(endpoint)

    suspend fun upload(snapshot: JSONObject): Long = withContext(Dispatchers.IO) {
        val updatedAt = System.currentTimeMillis()
        val plain = snapshot.toString().toByteArray(Charsets.UTF_8)
        require(plain.size <= MAX_PLAINTEXT_BYTES) {
            "پشتیبان بزرگ‌تر از حد مجاز است؛ عکس‌های حجیم را جداگانه نگه دار یا نسخه سبک‌تری تهیه کن."
        }
        // Never replace a larger existing backup with a suspiciously small/empty local DB.
        // This protects a valid server backup if a host was reinstalled before restoration.
        val existing = runCatching { download() }.getOrNull()
        if (existing != null) {
            val oldSize = existing.second.toString().toByteArray(Charsets.UTF_8).size
            val oldRecords = recordCount(existing.second)
            val newRecords = recordCount(snapshot)
            if (oldRecords > newRecords || (oldSize > 8 * 1024 && plain.size < (oldSize * 0.75).toInt())) {
                throw IllegalStateException(
                    "پشتیبان سرور از اطلاعات این گوشی کامل‌تر است؛ برای جلوگیری از جایگزینی اطلاعات، ابتدا «بازیابی اطلاعات از سرور» را اجرا کن."
                )
            }
        }
        val backup = JSONObject()
            .put("v", 2)
            .put("snapshot", snapshot)
        val body = JSONObject().put("updatedAt", updatedAt).put("backup", backup).toString()
        val response = request("POST", body)
        require(response.optBoolean("stored")) { "سرور ذخیره پشتیبان را تأیید نکرد." }
        updatedAt
    }

    suspend fun download(): Pair<Long, JSONObject> = withContext(Dispatchers.IO) {
        val response = request("GET", null)
        val updatedAt = response.getLong("updatedAt")
        val backup = response.getJSONObject("backup")
        when (backup.optInt("v")) {
            2 -> {
                val snapshot = backup.getJSONObject("snapshot")
                updatedAt to snapshot
            }
            1 -> {
                // Legacy AES-GCM backup from older builds.
                val nonce = Base64.decode(backup.getString("nonce"), Base64.URL_SAFE or Base64.NO_WRAP)
                val encrypted = Base64.decode(backup.getString("ciphertext"), Base64.URL_SAFE or Base64.NO_WRAP)
                require(nonce.size == 12 && encrypted.size <= MAX_CIPHERTEXT_BYTES) { "فایل پشتیبان نامعتبر است." }
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, nonce))
                val plain = cipher.doFinal(encrypted)
                require(plain.size <= MAX_PLAINTEXT_BYTES) { "فایل پشتیبان بزرگ‌تر از حد مجاز است." }
                updatedAt to JSONObject(String(plain, Charsets.UTF_8))
            }
            else -> throw IllegalStateException("نسخه پشتیبان پشتیبانی نمی‌شود.")
        }
    }

    private fun recordCount(snapshot: JSONObject): Long {
        var count = 0L
        val keys = arrayOf(
            "tasks", "events", "shopping", "messages", "financialAccounts", "financeTransactions",
            "financeBudgets", "sharedDebts", "recurringTransactions", "memories", "moodCheckIns",
            "specialDates", "cycleLogs", "cycleSettings", "locationShares", "heartPulses",
            "sharedPlaces", "habits", "watchlistItems", "coupleProfile", "attachments"
        )
        keys.forEach { key -> count += snapshot.optJSONArray(key)?.length() ?: 0 }
        return count
    }

    private fun key(): SecretKeySpec {
        require(accessToken.isNotBlank()) { "کلید مشترک خانه تنظیم نشده است." }
        val material = "ourspace-household-backup-v1:$accessToken".toByteArray(Charsets.UTF_8)
        return SecretKeySpec(MessageDigest.getInstance("SHA-256").digest(material), "AES")
    }

    private fun request(method: String, body: String?): JSONObject {
        val connection = URL("$baseUrl/v1/backup").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 12_000
            connection.readTimeout = 45_000
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            RelayDeviceHeaders.apply(connection, deviceId, deviceRole)
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Connection", "close")
            if (body != null) {
                val bytes = body.toByteArray(Charsets.UTF_8)
                require(bytes.size <= MAX_REQUEST_BYTES) { "پشتیبان از حد مجاز انتقال بزرگ‌تر است." }
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.setFixedLengthStreamingMode(bytes.size)
                connection.outputStream.use { it.write(bytes) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val bytes = stream?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_RESPONSE_BYTES) throw IOException("پاسخ پشتیبان بیش از حد بزرگ است.")
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            } ?: ByteArray(0)
            val text = String(bytes, Charsets.UTF_8)
            if (code !in 200..299) {
                val message = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
                if (code == 404) throw IOException("هنوز هیچ پشتیبانی روی سرور وجود ندارد.")
                throw IOException("خطای سرور هنگام پشتیبان‌گیری ($code): ${message.ifBlank { text.take(180) }}")
            }
            return JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val MAX_PLAINTEXT_BYTES = 64 * 1024 * 1024
        private const val MAX_CIPHERTEXT_BYTES = 65 * 1024 * 1024
        private const val MAX_REQUEST_BYTES = 92 * 1024 * 1024
        private const val MAX_RESPONSE_BYTES = 92 * 1024 * 1024
    }
}
