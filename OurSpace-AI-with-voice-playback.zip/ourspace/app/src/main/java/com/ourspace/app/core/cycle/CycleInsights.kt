package com.ourspace.app.core.cycle

import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import java.util.Calendar
import java.time.Instant
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * Simple, local predictions from logged period starts — not medical advice.
 */
object CycleInsights {
    data class Snapshot(
        val lastStartAt: Long?,
        val openLog: CycleLogEntity?,
        val dayInCycle: Int?,
        val predictedNextStartAt: Long?,
        val daysUntilNext: Int?,
        val averageCycleDays: Int
    )

    fun snapshot(
        logs: List<CycleLogEntity>,
        settings: CycleSettingsEntity?,
        now: Long = System.currentTimeMillis()
    ): Snapshot {
        val active = logs.filter { !it.isDeleted }.sortedByDescending { it.startAt }
        val open = active.firstOrNull { it.endAt == null }
        val lastStart = active.firstOrNull()?.startAt
        val avg = settings?.averageCycleDays?.coerceIn(15, 60)
            ?: estimateAverageCycle(active)
            ?: 28
        val elapsedDays = lastStart?.let { calendarDayDifference(it, now).coerceAtLeast(0) }
        val dayInCycle = elapsedDays?.let { (it % avg) + 1 }
        val predicted = lastStart?.let { start ->
            val elapsed = elapsedDays ?: 0
            val cyclesToAdd = if (elapsed == 0) 1 else ((elapsed + avg - 1) / avg).coerceAtLeast(1)
            Calendar.getInstance().apply {
                timeInMillis = start
                add(Calendar.DAY_OF_YEAR, cyclesToAdd * avg)
            }.timeInMillis
        }
        val daysUntil = predicted?.let { calendarDayDifference(now, it) }
        return Snapshot(
            lastStartAt = lastStart,
            openLog = open,
            dayInCycle = dayInCycle,
            predictedNextStartAt = predicted,
            daysUntilNext = daysUntil,
            averageCycleDays = avg
        )
    }

    private fun calendarDayDifference(from: Long, to: Long): Int {
        val zone = ZoneId.systemDefault()
        val fromDate = Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
        val toDate = Instant.ofEpochMilli(to).atZone(zone).toLocalDate()
        return ChronoUnit.DAYS.between(fromDate, toDate).toInt()
    }

    private fun estimateAverageCycle(logs: List<CycleLogEntity>): Int? {
        val starts = logs.map { it.startAt }.sorted()
        if (starts.size < 2) return null
        val gaps = starts.zipWithNext { a, b -> calendarDayDifference(a, b) }
            .filter { it in 15..60 }
        if (gaps.isEmpty()) return null
        return gaps.average().toInt().coerceIn(15, 60)
    }
}
