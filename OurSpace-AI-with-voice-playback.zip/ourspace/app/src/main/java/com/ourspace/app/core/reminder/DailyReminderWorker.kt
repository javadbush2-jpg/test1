package com.ourspace.app.core.reminder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.core.cycle.CycleInsights
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.time.PersianDateFormatter
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * بررسی دوره‌ای یادآوری‌ها.
 * برای قرار/کار/مناسبت/چرخه از «ساعت قبل» کاربر استفاده می‌شود.
 * برای خلاصه کارها، حال و خرید در پنجرهٔ ساعت روزانه اعلان می‌شود.
 */
class DailyReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? OurSpaceApplication ?: return Result.success()
        val db = app.database
        val notifications = OurSpaceNotificationCenter(applicationContext)
        if (!notifications.canPostReminders()) return Result.success()

        val now = System.currentTimeMillis()
        val todayKey = PersianDateFormatter.currentJalaliDayKey()
        val deviceId = runCatching { DeviceIdentityManager().getOrCreateIdentity().deviceId }.getOrNull()
        val leads = ReminderLeadPreferences.readAll(applicationContext)
        val inDailyWindow = isNearDailyReminderHour(applicationContext, now)

        // —— قرارها: در بازهٔ [start - lead, start)
        val eventLeadMs = hoursToMs(leads[ReminderLeadCategory.EVENTS] ?: 2)
        db.eventDao().getAllOnce()
            .filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") }
            .filter { event ->
                val start = event.startAt
                val windowStart = start - eventLeadMs.coerceAtLeast(THIRTY_MIN_MS)
                now in windowStart until start
            }
            .sortedBy { it.startAt }
            .forEach { event ->
                notifyOnce("event:${event.id}", event.startAt.toString()) {
                    notifications.showUpcomingEvent(event.title, event.id)
                }
            }

        // —— کارها با موعد: در بازهٔ [due - lead, due) و هنوز انجام‌نشده
        val taskLeadMs = hoursToMs(leads[ReminderLeadCategory.TASKS] ?: 3)
        db.taskDao().getAllOnce()
            .filter { !it.isDeleted && !it.isCompleted && it.dueAt != null }
            .forEach { task ->
                val due = task.dueAt ?: return@forEach
                val windowStart = due - taskLeadMs.coerceAtLeast(THIRTY_MIN_MS)
                if (now in windowStart until due) {
                    notifyOnce("task-due:${task.id}", due.toString()) {
                        notifications.showTaskReminder(1)
                    }
                }
            }

        // —— مناسبت‌ها
        val specialLeadMs = hoursToMs(leads[ReminderLeadCategory.SPECIAL] ?: 24)
        db.specialDateDao().getAllOnce().filter { !it.isDeleted }.forEach { date ->
            val occurrence = PersianDateFormatter.nextSpecialDateOccurrence(
                date.occurredAt, date.repeatYearly, now
            ) ?: return@forEach
            val occurrenceAt = occurrence.epochMillis
            val windowStart = occurrenceAt - specialLeadMs.coerceAtLeast(THIRTY_MIN_MS)
            if (now in windowStart..occurrenceAt + DAY_MS) {
                notifyOnce("special:${date.id}:${occurrence.jalaliYear}", "lead") {
                    notifications.showUpcomingSpecialDate(date.title, occurrence.daysUntil, date.id)
                }
            }
        }

        // —— چرخه
        val cycleLeadMs = hoursToMs(leads[ReminderLeadCategory.CYCLE] ?: 48)
        val logs = db.cycleLogDao().getAllOnce()
        val settings = db.cycleSettingsDao().getOnce()
        if (settings?.trackingEnabled != false) {
            val insight = CycleInsights.snapshot(logs, settings, now)
            val until = insight.daysUntilNext
            if (until != null && until >= 0) {
                val targetAt = Calendar.getInstance().apply {
                    timeInMillis = now
                    add(Calendar.DAY_OF_YEAR, until)
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val windowStart = targetAt - cycleLeadMs.coerceAtLeast(THIRTY_MIN_MS)
                if (now in windowStart..targetAt + DAY_MS) {
                    val targetDay = dayKey(targetAt)
                    notifyOnce("cycle:$targetDay", "lead") {
                        notifications.showCycleReminder(until)
                    }
                }
            }
        }

        // —— یادآوری‌های «روزانه» فقط نزدیک ساعت تنظیم‌شده
        if (inDailyWindow) {
            val openTasks = db.taskDao().getAllOnce().filter { !it.isDeleted && !it.isCompleted }
            val overdue = openTasks.count { it.dueAt != null && it.dueAt!! < now }
            if (openTasks.isNotEmpty()) {
                notifyOnce("open-tasks", todayKey) {
                    notifications.showTaskReminder(openTasks.size)
                }
            }
            if (overdue > 0) {
                notifyOnce("overdue-tasks", todayKey) {
                    notifications.showOverdueTasks(overdue)
                }
            }

            if (deviceId != null) {
                val hasMood = db.moodCheckInDao().getAllOnce().any {
                    !it.isDeleted && it.deviceId == deviceId && it.dayKey == todayKey
                }
                if (!hasMood) {
                    notifyOnce("mood", todayKey) { notifications.showMoodReminder() }
                }
            }

            val shoppingOpen = db.shoppingDao().getAllOnce().count { !it.isDeleted && !it.isChecked }
            if (shoppingOpen >= 5) {
                notifyOnce("shopping", todayKey) {
                    notifications.showShoppingReminder(shoppingOpen)
                }
            }
        }

        return Result.success()
    }

    private inline fun notifyOnce(key: String, occurrence: String, action: () -> Unit) {
        val prefs = applicationContext.getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
        if (prefs.getString(key, null) == occurrence) return
        action()
        prefs.edit().putString(key, occurrence).apply()
    }

    private fun dayKey(timestamp: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = timestamp }
        return "${c.get(Calendar.YEAR)}-${c.get(Calendar.DAY_OF_YEAR)}"
    }

    companion object {
        private const val UNIQUE = "ourspace_daily_reminders"
        private const val DEDUP_PREFS = "ourspace_notification_dedupe"
        private const val DAY_MS = 24L * 60 * 60 * 1000
        private const val THIRTY_MIN_MS = 30L * 60 * 1000
        private const val HOUR_MS = 60L * 60 * 1000

        private fun hoursToMs(hours: Int): Long =
            if (hours <= 0) THIRTY_MIN_MS else hours.toLong() * HOUR_MS

        /** آیا الان نزدیک ساعت یادآوری روزانه هستیم؟ (±۴۵ دقیقه) */
        fun isNearDailyReminderHour(context: Context, now: Long = System.currentTimeMillis()): Boolean {
            val (hour, minute) = runBlocking {
                val prefs = AppPreferences(context.applicationContext)
                prefs.reminderHour.first() to prefs.reminderMinute.first()
            }
            val cal = Calendar.getInstance().apply { timeInMillis = now }
            val currentMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val targetMinutes = hour.coerceIn(0, 23) * 60 + minute.coerceIn(0, 59)
            val diff = kotlin.math.abs(currentMinutes - targetMinutes)
            val wrap = 24 * 60 - diff
            return minOf(diff, wrap) <= 45
        }

        fun schedule(context: Context) {
            val appContext = context.applicationContext
            // هر ساعت یک‌بار تا «ساعت قبل» دقیق‌تر اعمال شود
            val request = PeriodicWorkRequestBuilder<DailyReminderWorker>(
                1, TimeUnit.HOURS,
                15, TimeUnit.MINUTES
            )
                .setInitialDelay(2, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(appContext).enqueueUniquePeriodicWork(
                UNIQUE,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun millisUntilNext(hour: Int, minute: Int): Long {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(Calendar.MINUTE, minute.coerceIn(0, 59))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now.timeInMillis + 30_000L) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }
            return (target.timeInMillis - now.timeInMillis).coerceAtLeast(5_000L)
        }
    }
}
