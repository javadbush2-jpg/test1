package com.ourspace.app.feature.settings

import com.ourspace.app.core.security.AppLockSession

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.os.PowerManager
import androidx.activity.compose.BackHandler
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Sms
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.core.notification.NotificationCategory
import com.ourspace.app.core.notification.NotificationPreferenceStore
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.reminder.DailyReminderWorker
import com.ourspace.app.core.finance.CategoryPreferences
import com.ourspace.app.core.finance.SmsTemplateStore
import com.ourspace.app.core.reminder.ReminderLeadCategory
import com.ourspace.app.core.reminder.ReminderLeadPreferences
import com.ourspace.app.ui.design.OsTimePickerField
import com.ourspace.app.core.security.AppLock
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.launch
import com.ourspace.app.core.database.TelegramStickerPackEntity
import com.ourspace.app.ui.theme.AppFontFamily
import com.ourspace.app.core.ai.AiModelStatus
import com.ourspace.app.core.ai.AiModelState
import com.ourspace.app.core.ai.AiModelCatalog
import com.ourspace.app.ui.theme.toComposeFontFamily
import kotlinx.coroutines.launch
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.sync.SyncClient
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.core.webrtc.ConnectionDiagnostics
import com.ourspace.app.feature.home.DiagnosticsPanel
import com.ourspace.app.feature.home.PairingPanel
import com.ourspace.app.feature.home.PrivateServerPanel
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.AppViewModel
import com.ourspace.app.ui.design.OSGroupedSection
import com.ourspace.app.ui.design.OSGroupRow
import com.ourspace.app.ui.design.OSLargeTitle
import com.ourspace.app.ui.design.OSSectionSpacer
import com.ourspace.app.ui.design.OSSpacing
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode
import com.ourspace.app.ui.theme.WidgetAccent
import com.ourspace.app.ui.theme.ChatBackgroundStyle

/**
 * Central place for connection, pairing, appearance and device security.
 * Connection controls were moved here from the home dashboard to keep Home focused on daily life.
 */
@Composable
fun SettingsScreen(
    role: DeviceRole,
    aiModelState: AiModelState = AiModelState(),
    onSelectAiModel: (String) -> Unit = {},
    onImportAiModel: (android.net.Uri, String?) -> Unit = { _, _ -> },
    onDeleteAiModel: () -> Unit = {},
    onRefreshAiModel: () -> Unit = {},
    identity: DeviceIdentityManager.DeviceIdentity,
    pairingSnapshot: PairingStore.Snapshot,
    pairingAction: AppViewModel.PairingActionState,
    syncState: AppViewModel.SyncState,
    relayConfig: RelayConfig,
    relayAction: AppViewModel.RelayActionState,
    backupAction: AppViewModel.BackupActionState = AppViewModel.BackupActionState(),
    onBackupNow: () -> Unit = {},
    onRestoreBackup: () -> Unit = {},
    pendingSyncChanges: Int,
    pendingSyncUnsent: Int = 0,
    pendingSyncAwaitingAck: Int = 0,
    diagnostics: List<String>,
    syncHealth: ConnectionDiagnostics.Health,
    palette: AppPalette,
    themeMode: AppThemeMode,
    dynamicColor: Boolean,
    widgetAccent: WidgetAccent = WidgetAccent.ROSE,
    onSaveRelayConfig: (Boolean, String, String) -> Unit,
    onRunConnectionTest: () -> Unit,
    onClearDiagnostics: () -> Unit,
    onApprovePairing: () -> Unit,
    onRejectPairing: () -> Unit,
    onCheckPairing: () -> Unit,
    onCancelPairing: () -> Unit,
    onRevokeTrust: () -> Unit,
    onSync: () -> Unit,
    onPairPayload: (String) -> Unit,
    onScanCompanionReply: (String) -> Unit,
    onScanApproval: (String) -> Unit,
    onPairWithPin: (String) -> Unit = {},
    onGenerateHostPin: () -> Unit = {},
    onSetPalette: (AppPalette) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit,
    onSetDynamicColor: (Boolean) -> Unit,
    onSetWidgetAccent: (WidgetAccent) -> Unit = {},
    onReset: () -> Unit,
    telegramBotToken: String = "",
    onSetTelegramBotToken: (String) -> Unit = {},
    stickerImportAction: AppViewModel.StickerImportActionState = AppViewModel.StickerImportActionState(),
    onImportTelegramPack: (String) -> Unit = {},
    telegramStickerPacks: List<TelegramStickerPackEntity> = emptyList(),
    onDeleteTelegramPack: (String) -> Unit = {}
) {
    val isPaired = pairingSnapshot.trustedPeer != null
    var selectedSection by remember { mutableStateOf<SettingsSection?>(null) }
    BackHandler(enabled = selectedSection != null) { selectedSection = null }
    val context = LocalContext.current
    var notificationPreferences by remember(context) {
        mutableStateOf(NotificationPreferenceStore.readAll(context))
    }
    fun updateNotificationPreference(category: NotificationCategory, enabled: Boolean) {
        NotificationPreferenceStore.setEnabled(context, category, enabled)
        notificationPreferences = notificationPreferences + (category to enabled)
        if (!enabled) OurSpaceNotificationCenter(context).clearNotificationsForCategory(category)
    }
    val appNotificationsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
    val runtimePermissionGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val messageChannelEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || runCatching {
        context.getSystemService(NotificationManager::class.java)
            .getNotificationChannel("ourspace_private_updates")?.importance
            ?.let { it != NotificationManager.IMPORTANCE_NONE } ?: false
    }.getOrDefault(false)
    val heartChannelEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || runCatching {
        context.getSystemService(NotificationManager::class.java)
            .getNotificationChannel("ourspace_heart_pulse")?.importance
            ?.let { it != NotificationManager.IMPORTANCE_NONE } ?: false
    }.getOrDefault(false)
    val reminderChannelEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || runCatching {
        context.getSystemService(NotificationManager::class.java)
            .getNotificationChannel("ourspace_reminders")?.importance
            ?.let { it != NotificationManager.IMPORTANCE_NONE } ?: false
    }.getOrDefault(false)
    val notificationStatus = when {
        !appNotificationsEnabled -> "اعلان‌های برنامه در تنظیمات اندروید خاموش هستند"
        !runtimePermissionGranted -> "مجوز اعلان داده نشده است"
        !messageChannelEnabled -> "کانال پیام‌های گفتگو و تغییرات خاموش است"
        !heartChannelEnabled -> "کانال تپش قلب خاموش است"
        !reminderChannelEnabled -> "کانال یادآوری‌ها و هشدارهای بودجه خاموش است"
        else -> "دسته‌های موردنظر را از گزینه‌های زیر انتخاب کنید"
    }
    val activeSection = selectedSection
    if (activeSection == null) {
        SettingsHomeScreen(
                    role = role,
            isPaired = isPaired,
            notificationStatus = notificationStatus,
            pendingSyncChanges = pendingSyncChanges,
            telegramPackCount = telegramStickerPacks.size,
            onOpenSection = { selectedSection = it }
        )
    } else {
        Column(Modifier.fillMaxSize()) {
            SettingsDetailHeader(
                section = activeSection,
                onBack = { selectedSection = null }
            )
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 100.dp)
            ) {
                when (activeSection) {
                    SettingsSection.NOTIFICATIONS -> {
                        item {
                            OSGroupedSection(
                                title = "اجازهٔ اعلان‌ها",
                                footer = "مجوز و کانال‌های اندروید باید روشن باشند؛ نوع اعلان‌ها را در بخش‌های زیر جداگانه انتخاب کنید. اعلان دائمی و بی‌صدای سرویس میزبان برای حفظ همگام‌سازی باقی می‌ماند."
                            ) {
                                OSGroupRow(
                                    title = if (appNotificationsEnabled && runtimePermissionGranted) "اجازهٔ اعلان در اندروید فعال است" else "بررسی تنظیمات اعلان",
                                    subtitle = notificationStatus,
                                    leading = Icons.Outlined.Notifications,
                                    showDivider = false,
                                    onClick = {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                            )
                                        }
                                    }
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(title = "گفتگو و قلب", footer = "این انتخاب‌ها فقط روی همین گوشی ذخیره می‌شوند.") {
                                NotificationPreferenceRow(
                                    category = NotificationCategory.CHAT_MESSAGES,
                                    checked = notificationPreferences[NotificationCategory.CHAT_MESSAGES] ?: true,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.CHAT_MESSAGES, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.HEART_PULSES,
                                    checked = notificationPreferences[NotificationCategory.HEART_PULSES] ?: true,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.HEART_PULSES, it) },
                                    showDivider = false
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(title = "تغییرات و همگام‌سازی", footer = "خاموش‌کردن این اعلان‌ها، دریافت یا همگام‌سازی داده‌ها را متوقف نمی‌کند.") {
                                NotificationPreferenceRow(
                                    category = NotificationCategory.SHARED_DATA_UPDATES,
                                    checked = notificationPreferences[NotificationCategory.SHARED_DATA_UPDATES] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.SHARED_DATA_UPDATES, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.SYNC_STATUS,
                                    checked = notificationPreferences[NotificationCategory.SYNC_STATUS] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.SYNC_STATUS, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.PARTNER_MOOD_UPDATES,
                                    checked = notificationPreferences[NotificationCategory.PARTNER_MOOD_UPDATES] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.PARTNER_MOOD_UPDATES, it) },
                                    showDivider = false
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(title = "یادآوری‌ها و هشدارها", footer = "یادآوری‌ها شامل عادت و دارو، کارها، قرار و مناسبت، حال روزانه، چرخه و خرید هستند. زمان زیر، ساعت بررسی روزانه است.") {
                                NotificationPreferenceRow(
                                    category = NotificationCategory.REMINDERS,
                                    checked = notificationPreferences[NotificationCategory.REMINDERS] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.REMINDERS, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.BUDGET_ALERTS,
                                    checked = notificationPreferences[NotificationCategory.BUDGET_ALERTS] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.BUDGET_ALERTS, it) },
                                    showDivider = true
                                )
                            }
                            // زمان یادآوری روزانه
                            val appPrefs = remember(context) { AppPreferences(context.applicationContext) }
                            val reminderHour by appPrefs.reminderHour.collectAsState(initial = 9)
                            val reminderMinute by appPrefs.reminderMinute.collectAsState(initial = 0)
                            val reminderScope = rememberCoroutineScope()
                            OSGroupedSection(
                                title = "زمان یادآوری",
                                footer = "ساعت روزانه برای خلاصه کارها، حال و خرید است. برای قرار و کار و مناسبت، از «چند ساعت قبل» پایین استفاده کنید."
                            ) {
                                OsTimePickerField(
                                    hour = reminderHour,
                                    minute = reminderMinute,
                                    onTimeChange = { h, m ->
                                        reminderScope.launch {
                                            appPrefs.setReminderTime(h, m)
                                            DailyReminderWorker.schedule(context.applicationContext)
                                        }
                                    },
                                    label = "ساعت یادآوری روزانه",
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                                )
                            }
                            OSGroupedSection(
                                title = "چند ساعت قبل؟",
                                footer = "برای هر بخش مشخص کنید چند ساعت قبل از موعد اعلان بیاید. صفر یعنی نزدیک همان لحظهٔ موعد. سیستم هر ساعت وضعیت را بررسی می‌کند."
                            ) {
                                var leadMap by remember {
                                    mutableStateOf(ReminderLeadPreferences.readAll(context.applicationContext))
                                }
                                ReminderLeadCategory.values().forEachIndexed { index, category ->
                                    val hours = leadMap[category] ?: category.defaultHours
                                    Column(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            category.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            category.description + " · الان: " + formatLeadHours(hours),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Row(
                                            Modifier
                                                .fillMaxWidth()
                                                .horizontalScroll(rememberScrollState())
                                                .padding(top = 6.dp),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            ReminderLeadCategory.HOUR_OPTIONS.forEach { option ->
                                                FilterChip(
                                                    selected = hours == option,
                                                    onClick = {
                                                        ReminderLeadPreferences.setHours(
                                                            context.applicationContext,
                                                            category,
                                                            option
                                                        )
                                                        leadMap = ReminderLeadPreferences.readAll(
                                                            context.applicationContext
                                                        )
                                                        DailyReminderWorker.schedule(
                                                            context.applicationContext
                                                        )
                                                    },
                                                    label = {
                                                        Text(
                                                            if (option == 0) "موعد"
                                                            else PersianDateFormatter.toPersianDigits(option)
                                                        )
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    if (index < ReminderLeadCategory.values().lastIndex) {
                                        // soft separator via spacing only
                                    }
                                }
                            }
                        }

                        item { OSSectionSpacer() }
                    }
                    SettingsSection.CATEGORIES -> {
                        item {
                            var expenseCats by remember {
                                mutableStateOf(CategoryPreferences.expenseCategories(context))
                            }
                            var incomeCats by remember {
                                mutableStateOf(CategoryPreferences.incomeCategories(context))
                            }
                            var newExpense by remember { mutableStateOf("") }
                            var newIncome by remember { mutableStateOf("") }
                            OSGroupedSection(
                                title = "هزینه و خرید (مشترک)",
                                footer = "همین دسته‌ها برای تراکنش هزینه و فهرست خرید استفاده می‌شوند. «سایر» قابل حذف نیست."
                            ) {
                                expenseCats.forEach { name ->
                                    OSGroupRow(
                                        title = name,
                                        subtitle = if (name == "سایر") "پیش‌فرض — قابل حذف نیست" else "برای حذف لمس کنید",
                                        leading = Icons.Outlined.Category,
                                        trailingText = if (name == "سایر") null else "حذف",
                                        showDivider = true,
                                        onClick = if (name == "سایر") null else ({
                                            CategoryPreferences.removeExpenseCategory(context, name)
                                            expenseCats = CategoryPreferences.expenseCategories(context)
                                        })
                                    )
                                }
                            }
                            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                OutlinedTextField(
                                    value = newExpense,
                                    onValueChange = { newExpense = it.take(40) },
                                    label = { Text("دسته جدید هزینه/خرید") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                TextButton(
                                    onClick = {
                                        if (CategoryPreferences.addExpenseCategory(context, newExpense)) {
                                            newExpense = ""
                                            expenseCats = CategoryPreferences.expenseCategories(context)
                                        }
                                    },
                                    enabled = newExpense.isNotBlank()
                                ) { Text("افزودن دسته هزینه/خرید") }
                                TextButton(onClick = {
                                    CategoryPreferences.resetExpenseToDefault(context)
                                    expenseCats = CategoryPreferences.expenseCategories(context)
                                }) { Text("بازگشت به پیش‌فرض هزینه/خرید") }
                            }
                            OSGroupedSection(
                                title = "درآمد",
                                footer = "دسته‌های واریز و درآمد"
                            ) {
                                incomeCats.forEach { name ->
                                    OSGroupRow(
                                        title = name,
                                        subtitle = if (name == "سایر") "پیش‌فرض — قابل حذف نیست" else "برای حذف لمس کنید",
                                        leading = Icons.Outlined.Category,
                                        trailingText = if (name == "سایر") null else "حذف",
                                        showDivider = true,
                                        onClick = if (name == "سایر") null else ({
                                            CategoryPreferences.removeIncomeCategory(context, name)
                                            incomeCats = CategoryPreferences.incomeCategories(context)
                                        })
                                    )
                                }
                            }
                            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                OutlinedTextField(
                                    value = newIncome,
                                    onValueChange = { newIncome = it.take(40) },
                                    label = { Text("دسته جدید درآمد") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                TextButton(
                                    onClick = {
                                        if (CategoryPreferences.addIncomeCategory(context, newIncome)) {
                                            newIncome = ""
                                            incomeCats = CategoryPreferences.incomeCategories(context)
                                        }
                                    },
                                    enabled = newIncome.isNotBlank()
                                ) { Text("افزودن دسته درآمد") }
                            }
                        }
                    }
                    SettingsSection.CONNECTION -> {
                        item {
                            val powerManager = context.getSystemService(android.content.Context.POWER_SERVICE) as? PowerManager
                            val ignoringBattery = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
                            } else true
                            OSGroupedSection(
                                title = "پس‌زمینه و باتری",
                                footer = "برای دریافت سریع پیام وقتی اپ باز نیست، محدودیت بهینه‌سازی باتری را بردارید و اعلان‌ها را روشن نگه دارید."
                            ) {
                                OSGroupRow(
                                    title = if (ignoringBattery) "اجرای پس‌زمینه آزاد است" else "آزادسازی اجرای پس‌زمینه",
                                    subtitle = if (ignoringBattery) {
                                        "محدودیت بهینه‌سازی باتری برای OurSpace خاموش است"
                                    } else {
                                        "برای همگام‌سازی آنی در پس‌زمینه لمس کنید"
                                    },
                                    leading = Icons.Outlined.Settings,
                                    showDivider = true,
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !ignoringBattery) {
                                            runCatching {
                                                context.startActivity(
                                                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                                                        .setData(Uri.parse("package:${context.packageName}"))
                                                )
                                            }.onFailure {
                                                runCatching {
                                                    context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                                }
                                            }
                                        } else {
                                            runCatching {
                                                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                            }
                                        }
                                    }
                                )
                                OSGroupRow(
                                    title = "ثبت مجدد توکن اعلان سرور",
                                    subtitle = "اگر پیام در پس‌زمینه دیر می‌رسد، یک‌بار لمس کنید",
                                    leading = Icons.Outlined.Notifications,
                                    showDivider = false,
                                    onClick = {
                                        com.ourspace.app.core.push.FcmTokenRegistrar.refreshAndUpload(context)
                                    }
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(
                                title = "وضعیت اتصال",
                                footer = when (role) {
                                    DeviceRole.HOST -> "این گوشی میزبان فضای خصوصی است."
                                    DeviceRole.COMPANION -> "این گوشی به‌عنوان همراه متصل می‌شود."
                                }
                            ) {
                                OSGroupRow(
                                    title = when {
                                        syncState.isSyncing -> "در حال همگام‌سازی…"
                                        syncState.error != null -> "خطا در همگام‌سازی"
                                        isPaired -> "جفت‌سازی فعال"
                                        else -> "هنوز جفت نشده"
                                    },
                                    subtitle = when {
                                        syncState.error != null -> syncState.error
                                        pendingSyncChanges > 0 ->
                                            buildString {
                                                if (pendingSyncUnsent > 0) append("${PersianDateFormatter.toPersianDigits(pendingSyncUnsent)} در انتظار ارسال")
                                                if (pendingSyncUnsent > 0 && pendingSyncAwaitingAck > 0) append(" · ")
                                                if (pendingSyncAwaitingAck > 0) append("${PersianDateFormatter.toPersianDigits(pendingSyncAwaitingAck)} منتظر تأیید همراه")
                                                if (pendingSyncUnsent == 0 && pendingSyncAwaitingAck == 0)
                                                    append("${PersianDateFormatter.toPersianDigits(pendingSyncChanges)} تغییر در صف ارسال")
                                            }
                                        syncState.lastSyncAt != null ->
                                            "آخرین همگام‌سازی: ${PersianDateFormatter.formatDateTime(syncState.lastSyncAt)}"
                                        isPaired -> "آمادهٔ ارسال و دریافت"
                                        else -> "از بخش جفت‌سازی شروع کنید"
                                    },
                                    leading = Icons.Outlined.Wifi,
                                    showDivider = true,
                                    onClick = onSync
                                )
                                OSGroupRow(
                                    title = "نقش دستگاه",
                                    subtitle = if (role == DeviceRole.HOST) "میزبان" else "همراه",
                                    leading = Icons.Outlined.Info,
                                    showDivider = true
                                )
                                OSGroupRow(
                                    title = "سلامت اتصال",
                                    subtitle = buildString {
                                        append(ConnectionDiagnostics.statusLabelFa(syncHealth))
                                        append(" · ارسال ")
                                        append(PersianDateFormatter.toPersianDigits(syncHealth.sentCount.toInt()))
                                        append(" · دریافت ")
                                        append(PersianDateFormatter.toPersianDigits(syncHealth.receivedCount.toInt()))
                                        append(" · ACK رله ")
                                        append(PersianDateFormatter.toPersianDigits(syncHealth.ackCount.toInt()))
                                        if (syncHealth.failedCount > 0) {
                                            append(" · ناموفق ")
                                            append(PersianDateFormatter.toPersianDigits(syncHealth.failedCount.toInt()))
                                        }
                                        if (syncHealth.lastAckAt > 0L) {
                                            append(" · آخرین ACK رله ")
                                            append(PersianDateFormatter.formatTime(syncHealth.lastAckAt))
                                        }
                                    },
                                    leading = Icons.Outlined.Info,
                                    showDivider = true
                                )
                                OSGroupRow(
                                    title = "همگام‌سازی اکنون",
                                    subtitle = when {
                                        pendingSyncChanges > 0 ->
                                            "برای خالی کردن صف لمس کنید · ${PersianDateFormatter.toPersianDigits(pendingSyncChanges)} مورد مانده"
                                        syncState.lastSyncAt != null ->
                                            "آخرین موفقیت: ${PersianDateFormatter.formatDateTime(syncState.lastSyncAt)}"
                                        else -> "لمس کنید تا همگام‌سازی اجباری شود"
                                    },
                                    leading = Icons.Outlined.Wifi,
                                    showDivider = false,
                                    onClick = onSync
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Share, title = "سرور خصوصی")
                                PrivateServerPanel(
                                    config = relayConfig,
                                    action = relayAction,
                                    onSave = onSaveRelayConfig
                                )
                                Spacer(Modifier.height(12.dp))
                                OSGroupedSection(
                                    title = "پشتیبان و بازیابی",
                                    footer = backupAction.error ?: backupAction.message
                                        ?: "میزبان هر دقیقه پشتیبان رمزگذاری‌شده را به‌روزرسانی می‌کند؛ این گزینه برای اجرای فوری یا بازیابی روی گوشی جدید است."
                                ) {
                                    if (role == DeviceRole.HOST) {
                                        OSGroupRow(
                                            title = if (backupAction.isBusy) "در حال تهیه پشتیبان…" else "تهیه پشتیبان کامل اکنون",
                                            subtitle = "ذخیره پیام‌ها، خاطرات، برنامه‌ها، داده‌های مالی و پیوست‌ها روی سرور",
                                            leading = Icons.Outlined.Share,
                                            showDivider = true,
                                            onClick = if (backupAction.isBusy) null else onBackupNow
                                        )
                                    }
                                    OSGroupRow(
                                        title = if (backupAction.isBusy) "در حال پردازش…" else "بازیابی اطلاعات از سرور",
                                        subtitle = "برای گوشی جدید یا نصب مجدد؛ اطلاعات پشتیبان با داده‌های محلی ادغام می‌شوند",
                                        leading = Icons.Outlined.Info,
                                        showDivider = false,
                                        onClick = if (backupAction.isBusy) null else onRestoreBackup
                                    )
                                }
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Wifi, title = "سلامت اتصال")
                                DiagnosticsPanel(
                                    lines = diagnostics,
                                    health = syncHealth,
                                    onRunTest = onRunConnectionTest,
                                    onClear = onClearDiagnostics
                                )
                            }
                        }

                        item { OSSectionSpacer() }
                    }
                    SettingsSection.PAIRING -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Lock, title = "جفت‌سازی امن")
                            }
                        }

                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                PairingPanel(
                                    role = role,
                                    identity = identity,
                                    snapshot = pairingSnapshot,
                                    action = pairingAction,
                                    syncState = syncState,
                                    onApprove = onApprovePairing,
                                    onReject = onRejectPairing,
                                    onCheckStatus = onCheckPairing,
                                    onCancelOutgoing = onCancelPairing,
                                    onRevokeTrust = onRevokeTrust,
                                    onSync = onSync,
                                    onPairPayload = onPairPayload,
                                    onScanCompanionReply = onScanCompanionReply,
                                    onScanApproval = onScanApproval,
                                            onPairWithPin = onPairWithPin,
                                            onGenerateHostPin = onGenerateHostPin
                                )
                            }
                        }

                        item { OSSectionSpacer() }
                    }
                    SettingsSection.TELEGRAM_STICKERS -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Share, title = "استیکر تلگرام")
                                var tokenDraft by remember(telegramBotToken) { mutableStateOf(telegramBotToken) }
                                var telegramPackDraft by remember { mutableStateOf("") }
                                var pendingDeleteStickerPack by remember { mutableStateOf<TelegramStickerPackEntity?>(null) }
                                Card(
                                    Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(26.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                                    )
                                ) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text(
                                            "پک و فایل‌های استیکر پس از دریافت با گوشی دیگر همگام می‌شوند؛ توکن ربات فقط روی همین گوشی می‌ماند و طرف مقابل برای استفاده از پک به توکن نیاز ندارد.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        OutlinedTextField(
                                            value = tokenDraft,
                                            onValueChange = { tokenDraft = it },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("توکن ربات تلگرام") },
                                            placeholder = { Text("123456:ABC...") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = { onSetTelegramBotToken(tokenDraft.trim()) },
                                                enabled = tokenDraft.trim() != telegramBotToken.trim()
                                            ) { Text("ذخیره توکن") }
                                            if (telegramBotToken.isNotBlank()) {
                                                TextButton(onClick = {
                                                    tokenDraft = ""
                                                    onSetTelegramBotToken("")
                                                }) { Text("پاک کردن") }
                                            }
                                        }
                                        if (telegramBotToken.isNotBlank()) {
                                            Text(
                                                "توکن ذخیره شده ✓",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        HorizontalDivider()
                                        Text(
                                            "افزودن پک تلگرام",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        OutlinedTextField(
                                            value = telegramPackDraft,
                                            onValueChange = { telegramPackDraft = it },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("لینک یا نام پک") },
                                            placeholder = { Text("t.me/addstickers/PackName") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(16.dp),
                                            enabled = !stickerImportAction.isLoading
                                        )
                                        Button(
                                            onClick = {
                                                val pack = telegramPackDraft.trim()
                                                if (pack.isNotEmpty()) onImportTelegramPack(pack)
                                            },
                                            enabled = telegramPackDraft.isNotBlank() &&
                                                telegramBotToken.isNotBlank() && !stickerImportAction.isLoading
                                        ) {
                                            Text(if (stickerImportAction.isLoading) "در حال دریافت…" else "افزودن پک")
                                        }
                                        if (telegramBotToken.isBlank()) {
                                            Text(
                                                "برای افزودن پک، ابتدا توکن ربات را ذخیره کن.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        stickerImportAction.message?.let {
                                            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                        }
                                        stickerImportAction.error?.let {
                                            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                        }
                                        HorizontalDivider()
                                        Text(
                                            "پک‌های ذخیره‌شده",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        if (telegramStickerPacks.isEmpty()) {
                                            Text(
                                                "هنوز پکی به کتابخانه اضافه نشده است.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        } else {
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                telegramStickerPacks.forEachIndexed { index, pack ->
                                                    Row(
                                                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(Modifier.weight(1f)) {
                                                            Text(pack.title, style = MaterialTheme.typography.bodyMedium)
                                                            Text(
                                                                "${pack.stickerCount} استیکر · کتابخانهٔ مشترک",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        }
                                                        IconButton(onClick = { pendingDeleteStickerPack = pack }) {
                                                            Icon(
                                                                Icons.Outlined.Delete,
                                                                contentDescription = "حذف پک ${pack.title}",
                                                                tint = MaterialTheme.colorScheme.error
                                                            )
                                                        }
                                                    }
                                                    if (index < telegramStickerPacks.lastIndex) HorizontalDivider()
                                                }
                                            }
                                        }
                                    }
                                }
                                pendingDeleteStickerPack?.let { pack ->
                                    AlertDialog(
                                        onDismissRequest = { pendingDeleteStickerPack = null },
                                        title = { Text("حذف پک استیکر") },
                                        text = { Text("پک «${pack.title}» و فایل‌هایش از کتابخانهٔ هر دو گوشی حذف می‌شود.") },
                                        confirmButton = {
                                            TextButton(onClick = {
                                                onDeleteTelegramPack(pack.name)
                                                pendingDeleteStickerPack = null
                                            }) { Text("حذف") }
                                        },
                                        dismissButton = {
                                            TextButton(onClick = { pendingDeleteStickerPack = null }) { Text("انصراف") }
                                        }
                                    )
                                }
                            }
                        }
                    }
                    SettingsSection.APPEARANCE -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Settings, title = "ظاهر")
                                AppearanceSettingsCard(
                                    palette = palette,
                                    themeMode = themeMode,
                                    dynamicColor = dynamicColor,
                                    onSetPalette = onSetPalette,
                                    onSetThemeMode = onSetThemeMode,
                                    onSetDynamicColor = onSetDynamicColor
                                )
                                Spacer(Modifier.height(12.dp))
                                WidgetAccentSettingsCard(
                                    accent = widgetAccent,
                                    onSetAccent = onSetWidgetAccent
                                )
                                Spacer(Modifier.height(12.dp))
                                ChatBackgroundSettingsCard()
                                Spacer(Modifier.height(12.dp))
                                ChatFontSizeSettingsCard()
                                Spacer(Modifier.height(12.dp))
                                PersonalizationSettingsCard()
                            }
                        }

                        item { OSSectionSpacer() }
                    }

                    SettingsSection.HOST_AI -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Settings, title = "هوش مصنوعی میزبان")
                                HostAiSettingsCard(
                                    role = role,
                                    state = aiModelState,
                                    onSelectModel = onSelectAiModel,
                                    onImport = onImportAiModel,
                                    onDelete = onDeleteAiModel,
                                    onRefresh = onRefreshAiModel
                                )
                            }
                        }
                        item { OSSectionSpacer() }
                    }
                    SettingsSection.SMS_TEMPLATES -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Sms, title = "قالب پیامک بانکی")
                                var showSmsTemplates by remember { mutableStateOf(false) }
                                val templateCount = remember(showSmsTemplates) {
                                    SmsTemplateStore.list(context).size
                                }
                                Card(
                                    Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(26.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                                    )
                                ) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text(
                                            "قالب‌ها مشخص می‌کنند پیامک بانکی چطور خوانده شود: مبلغ، مانده، کارت، تاریخ، ساعت، کد پیگیری و پذیرنده. " +
                                                "الگوها فقط روی همین گوشی ذخیره می‌شوند و متن پیامک جایی ارسال نمی‌شود.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            "تعداد قالب‌های ذخیره‌شده: $templateCount",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Button(
                                            onClick = { showSmsTemplates = true },
                                            modifier = Modifier.fillMaxWidth()
                                        ) { Text("مدیریت قالب‌های پیامک") }
                                    }
                                }
                                if (showSmsTemplates) {
                                    SmsTemplatesDialog(onDismiss = { showSmsTemplates = false })
                                }
                                Spacer(Modifier.height(12.dp))
                            }
                        }
                    }
                    SettingsSection.DEVICE_SECURITY -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Lock, title = "دستگاه و امنیت")
                                AppLockSettingsCard()
                                Spacer(Modifier.height(12.dp))
                                Card(
                                    Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(26.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                                    )
                                ) {
                                    Column(Modifier.padding(18.dp)) {
                                        Text(
                                            "شناسه این دستگاه",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            identity.deviceId.take(16) + "…",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                        HorizontalDivider(Modifier.padding(vertical = 14.dp))
                                        Text(
                                            "بازنشانی، جفت‌سازی و داده‌های همگام‌سازی این گوشی را پاک می‌کند. روی دستگاه مقابل تأثیری ندارد.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        TextButton(
                                            onClick = onReset,
                                            modifier = Modifier.padding(top = 8.dp)
                                        ) {
                                            Text("بازنشانی این دستگاه", color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(OSSpacing.xxxl)) }
            }
        }
    }

}


private enum class SettingsSection(val title: String, val icon: ImageVector) {
    NOTIFICATIONS("اعلان‌ها", Icons.Outlined.Notifications),
    CATEGORIES("دسته‌بندی‌ها", Icons.Outlined.Category),
    SMS_TEMPLATES("قالب پیامک", Icons.Outlined.Sms),
    CONNECTION("اتصال و همگام‌سازی", Icons.Outlined.Wifi),
    PAIRING("جفت‌سازی امن", Icons.Outlined.Lock),
    TELEGRAM_STICKERS("استیکر تلگرام", Icons.Outlined.Share),
    APPEARANCE("ظاهر و شخصی‌سازی", Icons.Outlined.Settings),
    HOST_AI("هوش مصنوعی میزبان", Icons.Outlined.Settings),
    DEVICE_SECURITY("دستگاه و امنیت", Icons.Outlined.Info)
}

@Composable
private fun SettingsHomeScreen(
    role: DeviceRole,
    isPaired: Boolean,
    notificationStatus: String,
    pendingSyncChanges: Int,
    telegramPackCount: Int,
    onOpenSection: (SettingsSection) -> Unit
) {
    val sections = SettingsSection.values()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            OSLargeTitle(
                title = "تنظیمات",
                subtitle = if (isPaired) "کنترل اتصال، اعلان‌ها و ظاهر فضای مشترک"
                else "اتصال امن و شخصی‌سازی دستگاه"
            )
        }
        item { OSSectionSpacer() }
        item {
            OSGroupedSection(
                title = "موضوعات تنظیمات",
                footer = "برای مشاهده یا تغییر گزینه‌ها، یکی از بخش‌ها را باز کنید."
            ) {
                sections.forEachIndexed { index, section ->
                    val summary = when (section) {
                        SettingsSection.NOTIFICATIONS -> notificationStatus
                        SettingsSection.CATEGORIES -> "هزینه، خرید و درآمد"
                        SettingsSection.CONNECTION -> if (pendingSyncChanges > 0) {
                            "$pendingSyncChanges تغییر در صف همگام‌سازی"
                        } else "وضعیت اتصال، باتری، سرور و پشتیبان"
                        SettingsSection.PAIRING -> if (isPaired) {
                            "اتصال امن برقرار است"
                        } else "اتصال امن با دستگاه دیگر"
                        SettingsSection.TELEGRAM_STICKERS -> if (telegramPackCount > 0) {
                            "$telegramPackCount پک در کتابخانهٔ مشترک"
                        } else "افزودن و مدیریت پک‌های مشترک"
                        SettingsSection.APPEARANCE -> "فونت چت، پالت رنگ و حالت نمایش"
                        SettingsSection.HOST_AI -> if (role == DeviceRole.HOST) "وضعیت مدل روی میزبان" else "مدل روی گوشی میزبان اجرا می‌شود"
                        SettingsSection.DEVICE_SECURITY -> "شناسه و بازنشانی امن دستگاه"
                        SettingsSection.SMS_TEMPLATES -> "خواندن خودکار پیامک بانکی"
                    }
                    OSGroupRow(
                        title = section.title,
                        subtitle = summary,
                        leading = section.icon,
                        trailingText = "‹",
                        showDivider = index < sections.lastIndex,
                        onClick = { onOpenSection(section) }
                    )
                }
            }
        }
        item { Spacer(Modifier.height(OSSpacing.xxxl)) }
    }
}

@Composable
private fun SettingsDetailHeader(
    section: SettingsSection,
    onBack: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = OSSpacing.screenHorizontal, vertical = OSSpacing.xs),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "بازگشت"
                )
            }
            Column(Modifier.weight(1f).padding(start = OSSpacing.xs)) {
                Text(
                    "تنظیمات",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    section.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        HorizontalDivider(Modifier.padding(horizontal = OSSpacing.screenHorizontal))
    }
}

@Composable
private fun ChatBackgroundSettingsCard() {
    val context = LocalContext.current
    val prefs = remember(context) { AppPreferences(context.applicationContext) }
    val scope = rememberCoroutineScope()
    val selected by prefs.chatBackground.collectAsState(initial = ChatBackgroundStyle.NONE)
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("پس‌زمینه گفتگو", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "پس‌زمینه‌های متحرک فقط در صفحه گفتگو نمایش داده می‌شوند و با «کاهش انیمیشن» آرام‌تر می‌شوند.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            // Two rows of chips for readability
            val styles = ChatBackgroundStyle.entries
            styles.chunked(3).forEach { row ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { style ->
                        FilterChip(
                            selected = selected == style,
                            onClick = { scope.launch { prefs.setChatBackground(style) } },
                            label = { Text(style.persianLabel) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    // pad incomplete last row
                    repeat(3 - row.size) {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
            Text(
                selected.description,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}


@Composable
private fun ChatFontSizeSettingsCard() {
    val context = LocalContext.current
    val prefs = remember(context) { AppPreferences(context.applicationContext) }
    val scope = rememberCoroutineScope()
    val chatFontScale by prefs.chatFontScale.collectAsState(initial = 1.0f)
    val baseSp = 14.5f
    val sampleSp = (baseSp * chatFontScale).sp
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("اندازه فونت چت", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "فقط متن پیام‌های گفتگو را بزرگ یا کوچک می‌کند؛ بقیه برنامه تغییر نمی‌کند.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("اندازه", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.weight(1f))
                Text(
                    when {
                        chatFontScale < 0.90f -> "کوچک"
                        chatFontScale < 1.10f -> "متوسط"
                        chatFontScale < 1.30f -> "بزرگ"
                        else -> "خیلی بزرگ"
                    } + " · ${(chatFontScale * 100).toInt()}٪",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Slider(
                value = chatFontScale,
                onValueChange = { value -> scope.launch { prefs.setChatFontScale(value) } },
                valueRange = 0.80f..1.60f,
                steps = 15
            )
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    0.85f to "کوچک",
                    1.0f to "متوسط",
                    1.25f to "بزرگ",
                    1.50f to "خیلی بزرگ"
                ).forEach { (scale, label) ->
                    FilterChip(
                        selected = kotlin.math.abs(chatFontScale - scale) < 0.05f,
                        onClick = { scope.launch { prefs.setChatFontScale(scale) } },
                        label = { Text(label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("نمونه پیام", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(
                        "سلام، این اندازه متن در گفتگو است.",
                        fontSize = sampleSp,
                        lineHeight = (sampleSp.value * 1.35f).sp
                    )
                }
            }
            TextButton(
                onClick = { scope.launch { prefs.setChatFontScale(1.0f) } },
                modifier = Modifier.align(Alignment.End)
            ) { Text("بازگردانی پیش‌فرض") }
        }
    }
}


@Composable
private fun HostAiSettingsCard(
    role: DeviceRole,
    state: AiModelState,
    onSelectModel: (String) -> Unit,
    onImport: (android.net.Uri, String?) -> Unit = { _, _ -> },
    onDelete: () -> Unit,
    onRefresh: () -> Unit
) {
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImport(uri, null)
        }
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("مدل زبانی روی گوشی میزبان", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "مدل GGUF را از حافظهٔ گوشی انتخاب کنید؛ موتور بومی به‌صورت محافظت‌شده روی همین گوشی میزبان اجرا می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (role != DeviceRole.HOST) {
                Text(
                    "این گوشی همراه است. واردکردن و اجرای مدل فقط روی گوشی میزبان انجام می‌شود.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                return@Column
            }
            Text("وضعیت: " + when (state.status) {
                AiModelStatus.NONE -> "نصب‌نشده"
                AiModelStatus.DOWNLOADING ->
                    if (state.message.contains("حافظه") || state.message.contains("کپی")) "در حال خواندن از حافظه"
                    else "در حال آماده‌سازی مدل"
                AiModelStatus.READY -> "آماده · موتور بومی (JNI)"
                AiModelStatus.RUNTIME_MISSING -> "فایل مدل هست؛ کتابخانه بومی لود نشد (NDK/ABI)"
                AiModelStatus.ERROR -> "خطا"
            }, style = MaterialTheme.typography.labelLarge)
            if (state.message.isNotBlank()) {
                Text(state.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (state.status == AiModelStatus.DOWNLOADING) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                Text(
                    "${(state.progress * 100).toInt()}٪",
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Text("انتخاب مدل پیشنهادی", style = MaterialTheme.typography.labelLarge)
            AiModelCatalog.ALL.forEach { spec ->
                FilterChip(
                    selected = state.selectedModelId == spec.id,
                    onClick = { onSelectModel(spec.id) },
                    label = {
                        Text("${spec.displayName} · ${spec.parameterSize} ${spec.quantLabel}")
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(spec.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
                        Text("از حافظهٔ دستگاه", style = MaterialTheme.typography.labelLarge)
            Text(
                "فایل .gguf را از Downloads یا هر پوشه‌ای انتخاب کنید. یک‌بار در حافظهٔ برنامه کپی می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = {
                    AppLockSession.suppressRelock(300_000L); importLauncher.launch(arrayOf("*/*", "application/octet-stream"))
                },
                enabled = state.status != AiModelStatus.DOWNLOADING,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("انتخاب فایل GGUF از حافظه")
            }
            OutlinedButton(
                onClick = onRefresh,
                enabled = state.status != AiModelStatus.DOWNLOADING,
                modifier = Modifier.fillMaxWidth()
            ) { Text("بررسی وضعیت مدل") }
            if (state.localPath != null) {
                Text("مسیر: ${state.localPath}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onDelete) { Text("حذف مدل از این گوشی") }
            }
            Text(
                "موتور: ${state.engineLabel} · ${com.ourspace.app.core.ai.HostLlmRuntime.backendLabel()}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            com.ourspace.app.core.ai.HostLlmRuntime.probeDiagnostic()?.takeIf { it.isNotBlank() }?.let { reason ->
                Text(
                    reason,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun PersonalizationSettingsCard() {
    val context = LocalContext.current
    val prefs = androidx.compose.runtime.remember(context) { AppPreferences(context.applicationContext) }
    val scope = rememberCoroutineScope()
    val fontScale by prefs.fontScale.collectAsState(initial = 1.0f)
    val fontFamily by prefs.fontFamily.collectAsState(initial = AppFontFamily.SANS)
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("شخصی‌سازی نوشته‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("اندازه و سبک نوشته‌ها در سراسر برنامه اعمال می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("اندازه فونت", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.weight(1f))
                Text("${(fontScale * 100).toInt()}٪", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            Slider(
                value = fontScale,
                onValueChange = { value -> scope.launch { prefs.setFontScale(value) } },
                valueRange = 0.85f..1.35f,
                steps = 9
            )
            Text(
                "نمونه نوشته فارسی — فضای مشترک شما ۱۲۳",
                fontSize = (16f * fontScale).sp,
                fontFamily = fontFamily.toComposeFontFamily()
            )
            Text("فونت برنامه (۱۰ فونت)", style = MaterialTheme.typography.labelLarge)
            Text(
                "فونت انتخابی روی کل برنامه اعمال می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AppFontFamily.entries.chunked(2).forEach { rowFonts ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowFonts.forEach { family ->
                            FilterChip(
                                selected = fontFamily == family,
                                onClick = { scope.launch { prefs.setFontFamily(family) } },
                                label = {
                                    Text(
                                        family.persianLabel,
                                        fontFamily = family.toComposeFontFamily(),
                                        maxLines = 1
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (rowFonts.size == 1) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 4.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("بازگردانی ظاهر پیش‌فرض", style = MaterialTheme.typography.bodyLarge)
                    Text("فونت، اندازه نوشته، رنگ و حالت نمایش", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = {
                    scope.launch {
                        prefs.setFontScale(1.0f)
                        prefs.setFontFamily(AppFontFamily.SANS)
                    }
                }) { Text("بازگردانی") }
            }
        }
    }
}

@Composable
private fun SectionCaption(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 10.dp, top = 4.dp)
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
private fun WidgetAccentSettingsCard(
    accent: WidgetAccent,
    onSetAccent: (WidgetAccent) -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("رنگ ویجت‌ها", style = MaterialTheme.typography.labelLarge)
            Text(
                "پس‌زمینه ویجت‌های صفحهٔ اصلی گوشی را انتخاب کنید. بعد از تغییر، ویجت‌ها به‌روز می‌شوند.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                WidgetAccent.entries.forEach { item ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(if (accent == item) 40.dp else 34.dp)
                                .background(Color(item.swatchArgb), CircleShape)
                                .clickable { onSetAccent(item) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (accent == item) {
                                Text("✓", color = Color.White, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
            Text(
                accent.persianLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

@Composable
private fun AppearanceSettingsCard(
    palette: AppPalette,
    themeMode: AppThemeMode,
    dynamicColor: Boolean,
    onSetPalette: (AppPalette) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit,
    onSetDynamicColor: (Boolean) -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(
                "ظاهر و رنگ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Material You یا پالت اختصاصی — برای اندروید ۱۲+",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
            )

            // Live preview strip from active ColorScheme
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .height(44.dp)
            ) {
                listOf(
                    MaterialTheme.colorScheme.primary,
                    MaterialTheme.colorScheme.secondary,
                    MaterialTheme.colorScheme.tertiary,
                    MaterialTheme.colorScheme.primaryContainer,
                    MaterialTheme.colorScheme.secondaryContainer,
                    MaterialTheme.colorScheme.tertiaryContainer
                ).forEach { c ->
                    Box(Modifier.weight(1f).fillMaxSize().background(c))
                }
            }
            Text(
                if (dynamicColor) "پالت پویا از والپیپر دستگاه"
                else "پالت فعال: ${palette.persianLabel}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )

            // Mode cards: Material You vs Custom
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppearanceModeTile(
                    title = "Material You",
                    subtitle = "والپیپر سیستم",
                    selected = dynamicColor,
                    accent = MaterialTheme.colorScheme.primary,
                    onClick = { onSetDynamicColor(true) },
                    modifier = Modifier.weight(1f)
                )
                AppearanceModeTile(
                    title = "پالت ما",
                    subtitle = "رنگ اختصاصی",
                    selected = !dynamicColor,
                    accent = palettePreviewColor(palette),
                    onClick = { onSetDynamicColor(false) },
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                "پالت اختصاصی",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 20.dp)
            )
            Text(
                if (dynamicColor) "با انتخاب یک رنگ، حالت پالت اختصاصی فعال می‌شود."
                else "رنگ دکمه‌ها، کارت‌ها و پس‌زمینه با این پالت هماهنگ می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AppPalette.entries.forEach { item ->
                    val selected = !dynamicColor && palette == item
                    val swatch = palettePreviewColor(item)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(72.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { onSetPalette(item) }
                            .padding(vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .shadow(
                                    elevation = if (selected) 10.dp else 2.dp,
                                    shape = CircleShape,
                                    ambientColor = swatch.copy(alpha = 0.45f),
                                    spotColor = swatch.copy(alpha = 0.35f)
                                )
                                .border(
                                    width = if (selected) 3.dp else 0.dp,
                                    brush = Brush.linearGradient(
                                        listOf(swatch, swatch.copy(alpha = 0.55f))
                                    ),
                                    shape = CircleShape
                                )
                                .padding(if (selected) 3.dp else 0.dp)
                                .background(
                                    brush = Brush.linearGradient(
                                        listOf(swatch, swatch.copy(alpha = 0.75f))
                                    ),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) {
                                Text("✓", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                            }
                        }
                        Text(
                            item.persianLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }

            Text(
                "حالت نمایش",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 20.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.65f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AppThemeMode.entries.forEach { mode ->
                    val selected = themeMode == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary
                                else Color.Transparent
                            )
                            .clickable { onSetThemeMode(mode) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            mode.persianLabel,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppearanceModeTile(
    title: String,
    subtitle: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) {
        accent.copy(alpha = 0.16f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.55f)
    }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) accent else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(18.dp)
            )
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        Box(
            Modifier
                .size(10.dp)
                .background(accent, CircleShape)
        )
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 10.dp)
        )
        Text(
            subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

/** رنگ نمایشی دایرهٔ انتخاب پالت (هماهنگ با primary پالت‌ها) */
private fun palettePreviewColor(palette: AppPalette): Color = when (palette) {
    AppPalette.ROSE -> Color(0xFFE85D8C)
    AppPalette.OCEAN -> Color(0xFF2BB0C7)
    AppPalette.FOREST -> Color(0xFF6BBF59)
    AppPalette.SUNSET -> Color(0xFFFF8A5C)
    AppPalette.LAVENDER -> Color(0xFFB794F6)
    AppPalette.MIDNIGHT -> Color(0xFF5B7C99)
    AppPalette.HONEY -> Color(0xFFE8B84A)
}



@Composable
private fun AppLockSettingsCard() {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val prefs = remember(context) { AppPreferences(context) }
    val enabled by prefs.appLockEnabled.collectAsState(initial = false)
    val scope = rememberCoroutineScope()
    var statusHint by remember { mutableStateOf<String?>(null) }
    val canAuth = remember(activity) { activity?.let { AppLock.canAuthenticate(it) } ?: false }

    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "قفل ورود به برنامه",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                "با روشن کردن این گزینه، هنگام باز شدن برنامه و بعد از خروج به پس‌زمینه، ورود با اثر انگشت، چهره یا پین قفل صفحهٔ گوشی لازم است.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .toggleable(
                        value = enabled,
                        role = Role.Switch,
                        onValueChange = { wantEnable ->
                            if (activity == null) {
                                statusHint = "فعالیت برنامه در دسترس نیست."
                                return@toggleable
                            }
                            if (wantEnable) {
                                if (!AppLock.canAuthenticate(activity)) {
                                    statusHint = AppLock.statusMessage(activity)
                                    return@toggleable
                                }
                                // تأیید هویت قبل از فعال‌سازی
                                AppLock.authenticate(
                                    activity = activity,
                                    title = "فعال‌سازی قفل برنامه",
                                    subtitle = "برای روشن کردن قفل، یک‌بار هویت خود را تأیید کنید",
                                    onSuccess = {
                                        scope.launch { prefs.setAppLockEnabled(true) }
                                        statusHint = "قفل برنامه فعال شد."
                                    },
                                    onError = { msg -> statusHint = msg }
                                )
                            } else {
                                // برای خاموش کردن هم تأیید
                                AppLock.authenticate(
                                    activity = activity,
                                    title = "خاموش کردن قفل",
                                    subtitle = "برای غیرفعال کردن قفل، هویت خود را تأیید کنید",
                                    onSuccess = {
                                        scope.launch { prefs.setAppLockEnabled(false) }
                                        statusHint = "قفل برنامه خاموش شد."
                                    },
                                    onError = { msg -> statusHint = msg }
                                )
                            }
                        }
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (enabled) "قفل فعال است" else "قفل خاموش است",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        if (canAuth)
                            "اثر انگشت، چهره یا پین قفل صفحه"
                        else
                            "ابتدا در تنظیمات گوشی پین یا اثر انگشت بگذارید",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = enabled, onCheckedChange = null)
            }
            if (!statusHint.isNullOrBlank()) {
                Text(
                    statusHint!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun NotificationPreferenceRow(
    category: NotificationCategory,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    showDivider: Boolean
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .toggleable(
                    value = checked,
                    role = Role.Switch,
                    onValueChange = onCheckedChange
                )
                .padding(horizontal = OSSpacing.md, vertical = OSSpacing.sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    category.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    category.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            Spacer(Modifier.size(8.dp))
            Switch(checked = checked, onCheckedChange = null)
        }
        if (showDivider) {
            HorizontalDivider(
                modifier = Modifier.padding(start = OSSpacing.md),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
                thickness = 0.6.dp
            )
        }
    }
}


private fun formatLeadHours(hours: Int): String = when {
    hours <= 0 -> "نزدیک موعد"
    hours < 24 -> "${PersianDateFormatter.toPersianDigits(hours)} ساعت قبل"
    hours % 24 == 0 -> "${PersianDateFormatter.toPersianDigits(hours / 24)} روز قبل"
    else -> "${PersianDateFormatter.toPersianDigits(hours)} ساعت قبل"
}
