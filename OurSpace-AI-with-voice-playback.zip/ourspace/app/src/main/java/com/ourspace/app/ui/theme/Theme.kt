package com.ourspace.app.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontWeight
import com.ourspace.app.R

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

private data class PaletteColors(
    val primary: Color,
    val primaryContainer: Color,
    val secondary: Color,
    val secondaryContainer: Color,
    val tertiary: Color,
    val tertiaryContainer: Color,
    val darkPrimary: Color,
    val darkContainer: Color,
    val darkSecondary: Color,
    val darkSecondaryContainer: Color,
    val darkTertiary: Color,
    val darkTertiaryContainer: Color
)

private fun paletteColors(palette: AppPalette): PaletteColors = when (palette) {
    AppPalette.ROSE -> PaletteColors(
        primary = Color(0xFF8B3A6B),
        primaryContainer = Color(0xFFFFD9EC),
        secondary = Color(0xFF9C4F72),
        secondaryContainer = Color(0xFFFFE4F0),
        tertiary = Color(0xFFE07A5F),
        tertiaryContainer = Color(0xFFFFDBCF),
        darkPrimary = Color(0xFFFFB0D6),
        darkContainer = Color(0xFF6B2A50),
        darkSecondary = Color(0xFFF5B8D0),
        darkSecondaryContainer = Color(0xFF5A3044),
        darkTertiary = Color(0xFFFFB59A),
        darkTertiaryContainer = Color(0xFF6B3A2A)
    )
    AppPalette.OCEAN -> PaletteColors(
        primary = Color(0xFF006B70),
        primaryContainer = Color(0xFF9CF1F4),
        secondary = Color(0xFF3A6A72),
        secondaryContainer = Color(0xFFD0EEF2),
        tertiary = Color(0xFF4D5FAD),
        tertiaryContainer = Color(0xFFDDE1FF),
        darkPrimary = Color(0xFF70DCE1),
        darkContainer = Color(0xFF004F53),
        darkSecondary = Color(0xFFA0CDD2),
        darkSecondaryContainer = Color(0xFF2A4A50),
        darkTertiary = Color(0xFFBAC3FF),
        darkTertiaryContainer = Color(0xFF3A4578)
    )
    AppPalette.FOREST -> PaletteColors(
        primary = Color(0xFF386A20),
        primaryContainer = Color(0xFFB9F397),
        secondary = Color(0xFF52634A),
        secondaryContainer = Color(0xFFD8E8CE),
        tertiary = Color(0xFF006A60),
        tertiaryContainer = Color(0xFF9EF2E6),
        darkPrimary = Color(0xFF9ED67D),
        darkContainer = Color(0xFF205107),
        darkSecondary = Color(0xFFB9CCAD),
        darkSecondaryContainer = Color(0xFF3A4A34),
        darkTertiary = Color(0xFF75D8CC),
        darkTertiaryContainer = Color(0xFF004D46)
    )
    AppPalette.SUNSET -> PaletteColors(
        primary = Color(0xFF9B4424),
        primaryContainer = Color(0xFFFFDBCF),
        secondary = Color(0xFF7D5260),
        secondaryContainer = Color(0xFFFFD9E4),
        tertiary = Color(0xFF74558F),
        tertiaryContainer = Color(0xFFEFDBFF),
        darkPrimary = Color(0xFFFFB59C),
        darkContainer = Color(0xFF78300F),
        darkSecondary = Color(0xFFEEB8C8),
        darkSecondaryContainer = Color(0xFF5A3544),
        darkTertiary = Color(0xFFDFBBFA),
        darkTertiaryContainer = Color(0xFF4A3A60)
    )
    AppPalette.LAVENDER -> PaletteColors(
        primary = Color(0xFF6B4FA0),
        primaryContainer = Color(0xFFEADDFF),
        secondary = Color(0xFF7A5A8C),
        secondaryContainer = Color(0xFFF5D9FF),
        tertiary = Color(0xFF9A5B7A),
        tertiaryContainer = Color(0xFFFFD9E8),
        darkPrimary = Color(0xFFD0BCFF),
        darkContainer = Color(0xFF4A3570),
        darkSecondary = Color(0xFFE0B8F0),
        darkSecondaryContainer = Color(0xFF4A3458),
        darkTertiary = Color(0xFFFFB0D0),
        darkTertiaryContainer = Color(0xFF5A3048)
    )
    AppPalette.MIDNIGHT -> PaletteColors(
        primary = Color(0xFF3D5A80),
        primaryContainer = Color(0xFFD6E3FF),
        secondary = Color(0xFF5C6B8A),
        secondaryContainer = Color(0xFFDCE3F5),
        tertiary = Color(0xFF6A5A9A),
        tertiaryContainer = Color(0xFFE8DEFF),
        darkPrimary = Color(0xFFA8C7FF),
        darkContainer = Color(0xFF254060),
        darkSecondary = Color(0xFFB8C5E0),
        darkSecondaryContainer = Color(0xFF3A4560),
        darkTertiary = Color(0xFFCDBDFF),
        darkTertiaryContainer = Color(0xFF453868)
    )
    AppPalette.HONEY -> PaletteColors(
        primary = Color(0xFF8B6914),
        primaryContainer = Color(0xFFFFE08A),
        secondary = Color(0xFF7A6540),
        secondaryContainer = Color(0xFFF5E6C8),
        tertiary = Color(0xFFA05A2A),
        tertiaryContainer = Color(0xFFFFDBCF),
        darkPrimary = Color(0xFFE8C547),
        darkContainer = Color(0xFF5A4508),
        darkSecondary = Color(0xFFD4C4A0),
        darkSecondaryContainer = Color(0xFF4A4030),
        darkTertiary = Color(0xFFFFB59A),
        darkTertiaryContainer = Color(0xFF6B3A20)
    )
}

/** Soft blend: tint neutrals with palette hue while keeping contrast (Material 3 tonal). */
private fun Color.blend(other: Color, amount: Float): Color {
    val t = amount.coerceIn(0f, 1f)
    return Color(
        red = red + (other.red - red) * t,
        green = green + (other.green - green) * t,
        blue = blue + (other.blue - blue) * t,
        alpha = alpha
    )
}

private fun lightColors(palette: AppPalette) = paletteColors(palette).let { c ->
    val paper = Color(0xFFFFFBFE).blend(c.primaryContainer, 0.22f)
    val bg = Color(0xFFF7F4F8).blend(c.primaryContainer, 0.28f)
    val variant = Color(0xFFF0E8F0).blend(c.secondaryContainer, 0.35f)
    lightColorScheme(
        primary = c.primary,
        onPrimary = Color.White,
        primaryContainer = c.primaryContainer,
        onPrimaryContainer = Color(0xFF2A1020).blend(c.primary, 0.15f),
        secondary = c.secondary,
        onSecondary = Color.White,
        secondaryContainer = c.secondaryContainer,
        onSecondaryContainer = Color(0xFF2A1520).blend(c.secondary, 0.12f),
        tertiary = c.tertiary,
        onTertiary = Color.White,
        tertiaryContainer = c.tertiaryContainer,
        onTertiaryContainer = Color(0xFF2A1510).blend(c.tertiary, 0.12f),
        background = bg,
        onBackground = Color(0xFF1A1418),
        surface = paper,
        onSurface = Color(0xFF1A1418),
        surfaceVariant = variant,
        onSurfaceVariant = Color(0xFF564F5A).blend(c.primary, 0.08f),
        surfaceContainerLowest = Color(0xFFFFFFFF),
        surfaceContainerLow = paper.blend(Color.White, 0.35f),
        surfaceContainer = paper.blend(c.primaryContainer, 0.12f),
        surfaceContainerHigh = variant.blend(c.primaryContainer, 0.10f),
        surfaceContainerHighest = variant.blend(c.secondaryContainer, 0.18f),
        surfaceTint = c.primary,
        outline = Color(0xFF7E7279).blend(c.primary, 0.12f),
        outlineVariant = Color(0xFFD4C0C7).blend(c.primaryContainer, 0.25f),
        inverseSurface = Color(0xFF32262B).blend(c.primary, 0.15f),
        inverseOnSurface = Color(0xFFFCEEF2),
        inversePrimary = c.darkPrimary,
        error = Color(0xFFBA1A1A),
        onError = Color.White,
        errorContainer = Color(0xFFFFDAD6),
        onErrorContainer = Color(0xFF410002)
    )
}

private fun darkColors(palette: AppPalette) = paletteColors(palette).let { c ->
    val bg = Color(0xFF0E0E16).blend(c.darkContainer, 0.22f)
    val surface = Color(0xFF16151E).blend(c.darkContainer, 0.28f)
    val variant = Color(0xFF2A2733).blend(c.darkContainer, 0.20f)
    darkColorScheme(
        primary = c.darkPrimary,
        onPrimary = Color(0xFF1A1014),
        primaryContainer = c.darkContainer,
        onPrimaryContainer = Color(0xFFFFF0F6),
        secondary = c.darkSecondary,
        onSecondary = Color(0xFF1A1014),
        secondaryContainer = c.darkSecondaryContainer,
        onSecondaryContainer = Color(0xFFFFF0F6),
        tertiary = c.darkTertiary,
        onTertiary = Color(0xFF1A1014),
        tertiaryContainer = c.darkTertiaryContainer,
        onTertiaryContainer = Color(0xFFFFF2EC),
        background = bg,
        onBackground = Color(0xFFF8F6F9),
        surface = surface,
        onSurface = Color(0xFFF8F6F9),
        surfaceVariant = variant,
        onSurfaceVariant = Color(0xFFDCD8DF),
        surfaceContainerLowest = Color(0xFF0A0A12).blend(c.darkContainer, 0.12f),
        surfaceContainerLow = surface.blend(Color.Black, 0.08f),
        surfaceContainer = surface.blend(c.darkContainer, 0.12f),
        surfaceContainerHigh = variant.blend(c.darkContainer, 0.10f),
        surfaceContainerHighest = variant.blend(c.darkSecondaryContainer, 0.18f),
        surfaceTint = c.darkPrimary,
        outline = Color(0xFFC4BBC4).blend(c.darkPrimary, 0.12f),
        outlineVariant = Color(0xFF524C56).blend(c.darkContainer, 0.2f),
        inverseSurface = Color(0xFFF5E8ED),
        inverseOnSurface = Color(0xFF2A2228),
        inversePrimary = c.primary,
        error = Color(0xFFFFB4AB),
        onError = Color(0xFF690005),
        errorContainer = Color(0xFF93000A),
        onErrorContainer = Color(0xFFFFDAD6)
    )
}

private val OurSpaceTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 36.sp,
        lineHeight = 44.sp,
        letterSpacing = (-0.4).sp
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 38.sp,
        letterSpacing = (-0.25).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 34.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 25.sp,
        letterSpacing = 0.05.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 27.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 23.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 19.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.3.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.3.sp
    )
)

private val OurSpaceShapes = Shapes(
    extraSmall = RoundedCornerShape(16.dp),
    small = RoundedCornerShape(20.dp),
    medium = RoundedCornerShape(26.dp),
    large = RoundedCornerShape(32.dp),
    extraLarge = RoundedCornerShape(40.dp)
)


private val FontVazirmatn = FontFamily(Font(R.font.vazirmatn_regular, FontWeight.Normal))
private val FontSahel = FontFamily(Font(R.font.sahel_regular, FontWeight.Normal))
private val FontSamim = FontFamily(Font(R.font.samim_regular, FontWeight.Normal))
private val FontTanha = FontFamily(Font(R.font.tanha_regular, FontWeight.Normal))
private val FontParastoo = FontFamily(Font(R.font.parastoo_regular, FontWeight.Normal))
private val FontShabnam = FontFamily(Font(R.font.shabnam_regular, FontWeight.Normal))
private val FontGandom = FontFamily(Font(R.font.gandom_regular, FontWeight.Normal))

fun AppFontFamily.toComposeFontFamily(): FontFamily = when (this) {
    AppFontFamily.SANS -> FontFamily.SansSerif
    AppFontFamily.SERIF -> FontFamily.Serif
    AppFontFamily.MONO -> FontFamily.Monospace
    AppFontFamily.VAZIRMATN -> FontVazirmatn
    AppFontFamily.SAHEL -> FontSahel
    AppFontFamily.SAMIM -> FontSamim
    AppFontFamily.TANHA -> FontTanha
    AppFontFamily.PARASTOO -> FontParastoo
    AppFontFamily.SHABNAM -> FontShabnam
    AppFontFamily.GANDOM -> FontGandom
}

@Composable
fun OurSpaceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    palette: AppPalette = AppPalette.ROSE,
    /** true = Material You از والپیپر؛ false = پالت ثابت انتخابی */
    dynamicColor: Boolean = true,
    fontScale: Float = 1.0f,
    fontFamily: AppFontFamily = AppFontFamily.SANS,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor -> if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> darkColors(palette)
        else -> lightColors(palette)
    }
    val selectedFont = fontFamily.toComposeFontFamily()
    fun scaled(style: TextStyle): TextStyle = style.copy(
        fontFamily = selectedFont,
        fontSize = style.fontSize * fontScale.coerceIn(0.85f, 1.35f),
        lineHeight = if (style.lineHeight.value > 0f) style.lineHeight * fontScale.coerceIn(0.85f, 1.35f) else style.lineHeight
    )
    val typography = OurSpaceTypography.copy(
        displayLarge = scaled(OurSpaceTypography.displayLarge), displayMedium = scaled(OurSpaceTypography.displayMedium),
        displaySmall = scaled(OurSpaceTypography.displaySmall), headlineLarge = scaled(OurSpaceTypography.headlineLarge),
        headlineMedium = scaled(OurSpaceTypography.headlineMedium), headlineSmall = scaled(OurSpaceTypography.headlineSmall),
        titleLarge = scaled(OurSpaceTypography.titleLarge), titleMedium = scaled(OurSpaceTypography.titleMedium),
        titleSmall = scaled(OurSpaceTypography.titleSmall), bodyLarge = scaled(OurSpaceTypography.bodyLarge),
        bodyMedium = scaled(OurSpaceTypography.bodyMedium), bodySmall = scaled(OurSpaceTypography.bodySmall),
        labelLarge = scaled(OurSpaceTypography.labelLarge), labelMedium = scaled(OurSpaceTypography.labelMedium),
        labelSmall = scaled(OurSpaceTypography.labelSmall)
    )

    // Android 12+: transparent system bars + light/dark icon contrast from scheme luminance
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            // شفاف‌سازی نوار سیستم هنوز روی همهٔ نسخه‌های هدف کار می‌کند؛ مهاجرت کامل به
            // edge-to-edge (WindowCompat.setDecorFitsSystemWindows) تغییر چیدمان سراسری است
            // و باید جداگانه با تست روی گوشی انجام شود.
            @Suppress("DEPRECATION")
            run {
                window.statusBarColor = android.graphics.Color.TRANSPARENT
                window.navigationBarColor = android.graphics.Color.TRANSPARENT
            }
            // Contrast icons against the actual surface (dynamic or static)
            val lightIcons = colorScheme.background.luminance() > 0.5f
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = lightIcons
                isAppearanceLightNavigationBars = lightIcons
            }
            // Avoid legacy contrast scrim on gesture nav (API 29+)
            window.isNavigationBarContrastEnforced = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = OurSpaceShapes,
        content = content
    )
}
