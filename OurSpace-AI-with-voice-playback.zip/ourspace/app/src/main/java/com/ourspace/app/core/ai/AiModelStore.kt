package com.ourspace.app.core.ai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

enum class AiModelStatus {
    NONE,
    DOWNLOADING,
    READY,
    ERROR,
    RUNTIME_MISSING
}

data class AiModelState(
    val status: AiModelStatus = AiModelStatus.NONE,
    val selectedModelId: String = AiModelCatalog.RECOMMENDED.id,
    val progress: Float = 0f,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 0L,
    val localPath: String? = null,
    val message: String = "",
    val engineLabel: String = "rules-v1"
)

/**
 * Host-side model file storage under app private files.
 * Supports download OR import from device storage (no network).
 */
class AiModelStore(private val context: Context) {

    private val root: File
        get() = File(context.filesDir, "ai_models").also { it.mkdirs() }

    private val metaFile: File
        get() = File(root, "model_meta.json")

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<AiModelState> = _state.asStateFlow()

    fun refresh() {
        _state.value = readState()
    }

    fun modelFile(spec: AiModelSpec = AiModelCatalog.byId(_state.value.selectedModelId)): File =
        File(root, spec.fileName)

    fun isReady(): Boolean = _state.value.status == AiModelStatus.READY ||
        _state.value.status == AiModelStatus.RUNTIME_MISSING

    fun hasModelFile(): Boolean {
        val path = _state.value.localPath
        val f = if (!path.isNullOrBlank()) File(path) else modelFile()
        return f.exists() && f.length() > 1_000_000L
    }

    private fun readState(): AiModelState {
        val meta = runCatching {
            if (!metaFile.exists()) return@runCatching null
            JSONObject(metaFile.readText())
        }.getOrNull()
        val selectedId = meta?.optString("selectedModelId").orEmpty()
            .ifBlank { AiModelCatalog.RECOMMENDED.id }
        val spec = AiModelCatalog.byId(selectedId)
        val file = File(root, spec.fileName)
        val path = meta?.optString("localPath")?.takeIf { it.isNotBlank() } ?: file.absolutePath
        val f = File(path)
        return when {
            f.exists() && f.length() > 1_000_000L -> {
                val runtime = HostLlmRuntime.isNativeAvailable()
                val backend = HostLlmRuntime.backendLabel()
                val readyMsg = when (HostLlmRuntime.backendKind()) {
                    2 -> "مدل آماده · استنتاج واقعی llama.cpp"
                    1 -> "مدل آماده · پل بومی (بدون llama.cpp در این بیلد)"
                    else -> "مدل روی دیسک است."
                }
                val source = meta?.optString("source").orEmpty()
                val srcLabel = when (source) {
                    "import" -> " · از حافظه"
                    "download" -> " · دانلود"
                    else -> ""
                }
                AiModelState(
                    status = if (runtime) AiModelStatus.READY else AiModelStatus.RUNTIME_MISSING,
                    selectedModelId = selectedId,
                    localPath = f.absolutePath,
                    message = readyMsg + srcLabel + " · " + GgufSupport.describe(f),
                    engineLabel = if (runtime) backend else "rules+model-file"
                )
            }
            else -> AiModelState(
                status = AiModelStatus.NONE,
                selectedModelId = selectedId,
                message = "مدلی روی این گوشی نصب نشده است. می‌توانید از حافظه انتخاب کنید یا دانلود کنید.",
                engineLabel = "rules-v1"
            )
        }
    }

    suspend fun selectModel(modelId: String) = withContext(Dispatchers.IO) {
        val spec = AiModelCatalog.byId(modelId)
        writeMeta(selectedModelId = spec.id, localPath = modelFile(spec).absolutePath)
        refresh()
    }

    suspend fun markDownloading(progress: Float, downloaded: Long, total: Long) {
        _state.value = _state.value.copy(
            status = AiModelStatus.DOWNLOADING,
            progress = progress.coerceIn(0f, 1f),
            bytesDownloaded = downloaded,
            totalBytes = total,
            message = "در حال دانلود…"
        )
    }

    suspend fun markError(message: String) {
        _state.value = _state.value.copy(
            status = AiModelStatus.ERROR,
            progress = 0f,
            message = message
        )
    }

    suspend fun markInstalled(file: File, modelId: String) = withContext(Dispatchers.IO) {
        writeMeta(selectedModelId = modelId, localPath = file.absolutePath, sha256 = sha256(file), source = "download")
        val loaded = runCatching {
            HostLlmRuntime.ensureModelLoaded(file.absolutePath, context)
        }.getOrDefault(false)
        refresh()
        if (!loaded) surfaceLoadError()
    }

    /** Show the native/memory-guard refusal reason in model settings after refresh(). */
    private fun surfaceLoadError() {
        HostLlmRuntime.lastLoadError?.let { err ->
            _state.value = _state.value.copy(message = err)
        }
    }

    /**
     * Import a GGUF already on the device (no download).
     * Copies into app private storage so native llama can open a real path.
     */
    suspend fun importFromUri(uri: Uri, displayName: String? = null): Boolean = withContext(Dispatchers.IO) {
        try {
            _state.value = _state.value.copy(
                status = AiModelStatus.DOWNLOADING,
                progress = 0f,
                message = "در حال خواندن فایل از حافظه…"
            )
            val resolver = context.contentResolver
            val nameHint = displayName?.takeIf { it.isNotBlank() }
                ?: uri.lastPathSegment?.substringAfterLast('/')
                ?: "imported.gguf"
            val safeName = nameHint.map { ch -> if (ch.isLetterOrDigit() || ch == '.' || ch == '_' || ch == '-') ch else '_' }.joinToString("").let {
                if (it.endsWith(".gguf", ignoreCase = true)) it else "$it.gguf"
            }
            val dest = File(root, "imported_$safeName")
            val total = runCatching {
                resolver.openAssetFileDescriptor(uri, "r")?.use { it.length }?.takeIf { it > 0 }
            }.getOrNull() ?: -1L

            resolver.openInputStream(uri)?.use { input ->
                FileOutputStream(dest).use { output ->
                    val buf = ByteArray(1024 * 256)
                    var copied = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        output.write(buf, 0, n)
                        copied += n
                        if (total > 0) {
                            val p = (copied.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                            _state.value = _state.value.copy(
                                status = AiModelStatus.DOWNLOADING,
                                progress = p,
                                bytesDownloaded = copied,
                                totalBytes = total,
                                message = "کپی از حافظه… ${(p * 100).toInt()}٪"
                            )
                        } else if (copied % (8L * 1024L * 1024L) < buf.size) {
                            _state.value = _state.value.copy(
                                status = AiModelStatus.DOWNLOADING,
                                bytesDownloaded = copied,
                                message = "کپی از حافظه… ${copied / (1024 * 1024)} مگابایت"
                            )
                        }
                    }
                    output.fd.sync()
                }
            } ?: run {
                markError("نتوانستم فایل را از حافظه باز کنم.")
                return@withContext false
            }

            if (!GgufSupport.isValidGguf(dest)) {
                dest.delete()
                markError("فایل انتخاب‌شده GGUF معتبر نیست.")
                return@withContext false
            }

            val modelId = "local-import"
            writeMeta(
                selectedModelId = modelId,
                localPath = dest.absolutePath,
                sha256 = sha256(dest),
                source = "import"
            )
            val loaded = runCatching {
                HostLlmRuntime.ensureModelLoaded(dest.absolutePath, context)
            }.getOrDefault(false)
            refresh()
            if (!loaded) surfaceLoadError()
            true
        } catch (t: Throwable) {
            markError("خطا در خواندن از حافظه: ${t.message ?: t.javaClass.simpleName}")
            false
        }
    }

    /**
     * Use a file that already exists on accessible filesystem path (no copy if already under our dir).
     */
    suspend fun importFromPath(absolutePath: String): Boolean = withContext(Dispatchers.IO) {
        val src = File(absolutePath)
        if (!src.exists() || !src.canRead()) {
            markError("مسیر قابل خواندن نیست.")
            return@withContext false
        }
        if (!GgufSupport.isValidGguf(src)) {
            markError("فایل GGUF معتبر نیست.")
            return@withContext false
        }
        val dest = if (src.absolutePath.startsWith(root.absolutePath)) {
            src
        } else {
            val destFile = File(root, "imported_${src.name}")
            _state.value = _state.value.copy(status = AiModelStatus.DOWNLOADING, message = "در حال کپی…")
            src.copyTo(destFile, overwrite = true)
            destFile
        }
        writeMeta(
            selectedModelId = "local-import",
            localPath = dest.absolutePath,
            sha256 = sha256(dest),
            source = "import"
        )
        val loaded = runCatching {
            HostLlmRuntime.ensureModelLoaded(dest.absolutePath, context)
        }.getOrDefault(false)
        refresh()
        if (!loaded) surfaceLoadError()
        true
    }

    suspend fun deleteModel() = withContext(Dispatchers.IO) {
        val path = _state.value.localPath
        if (!path.isNullOrBlank()) {
            runCatching { File(path).delete() }
        }
        val spec = AiModelCatalog.byId(_state.value.selectedModelId)
        runCatching { modelFile(spec).delete() }
        runCatching { metaFile.delete() }
        runCatching { HostLlmRuntime.unload() }
        refresh()
    }

    private fun writeMeta(
        selectedModelId: String,
        localPath: String,
        sha256: String? = null,
        source: String? = null
    ) {
        val json = JSONObject()
            .put("selectedModelId", selectedModelId)
            .put("localPath", localPath)
            .put("updatedAt", System.currentTimeMillis())
        if (sha256 != null) json.put("sha256", sha256)
        if (source != null) json.put("source", source)
        metaFile.writeText(json.toString())
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(8192)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                digest.update(buf, 0, n)
            }
        }
        return digest.digest().joinToString("") { b -> "%02x".format(b) }
    }
}
