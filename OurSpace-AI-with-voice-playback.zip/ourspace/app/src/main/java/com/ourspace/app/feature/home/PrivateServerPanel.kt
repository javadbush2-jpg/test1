package com.ourspace.app.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.ui.AppViewModel

@Composable
fun PrivateServerPanel(
    config: RelayConfig,
    action: AppViewModel.RelayActionState,
    onSave: (Boolean, String, String) -> Unit
) {
    var endpoint by remember(config.endpoint) {
        mutableStateOf(config.endpoint.ifBlank { com.ourspace.app.core.relay.RelayConfig.DEFAULT_ENDPOINT })
    }
    val accessToken = com.ourspace.app.core.relay.RelayConfig.DEFAULT_ACCESS_TOKEN
    var enabled by remember(config.enabled) { mutableStateOf(config.enabled) }

    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("سرور شخصی من", fontWeight = FontWeight.Black)
            Text(
                "کلید مشترک از قبل در برنامه تعریف شده و با سرور هماهنگ است؛ نیازی به کپی‌کردن یا واردکردن آن نیست. " +
                    "هر دو گوشی باید از همین کلید استفاده کنند.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
            )

            OutlinedTextField(
                value = endpoint,
                onValueChange = { endpoint = it },
                label = { Text("آدرس سرور") },
                placeholder = { Text(com.ourspace.app.core.relay.RelayConfig.DEFAULT_ENDPOINT) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = accessToken,
                onValueChange = {},
                label = { Text("کلید مشترک خانه (از پیش تعریف‌شده)") },
                readOnly = true,
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )

            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Switch(checked = enabled, onCheckedChange = { enabled = it })
                Text(
                    if (enabled) "فعال" else "غیرفعال",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onSave(enabled, endpoint.trim(), accessToken.trim()) },
                    enabled = !action.isSaving,
                    modifier = Modifier.weight(1f)
                ) { Text(if (action.isSaving) "در حال بررسی…" else "ذخیره و آزمایش") }
                OutlinedButton(
                    onClick = {
                        endpoint = ""
                        enabled = false
                        onSave(false, "", accessToken)
                    },
                    enabled = !action.isSaving,
                    modifier = Modifier.weight(1f)
                ) { Text("پاک کردن") }
            }

            action.error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            action.message?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}
