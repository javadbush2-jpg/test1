package com.ourspace.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.ourspace.app.MainActivity
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.R
import com.ourspace.app.core.database.EventEntity
import com.ourspace.app.core.database.ShoppingItemEntity
import com.ourspace.app.core.database.TaskEntity
import com.ourspace.app.core.time.PersianDateFormatter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private object ExtraWidgetSupport {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun refresh(context: Context, provider: Class<out AppWidgetProvider>) {
        val appContext = context.applicationContext
        val manager = AppWidgetManager.getInstance(appContext)
        val ids = manager.getAppWidgetIds(ComponentName(appContext, provider))
        if (ids.isEmpty()) return
        scope.launch {
            ids.forEach { id ->
                runCatching {
                    val views = when (provider) {
                        OurSpaceTasksWidgetProvider::class.java -> tasksViews(appContext)
                        OurSpaceShoppingWidgetProvider::class.java -> shoppingViews(appContext)
                        else -> calendarViews(appContext)
                    }
                    manager.updateAppWidget(id, views)
                }
            }
        }
    }

    fun onRefresh(context: Context, intent: Intent, provider: Class<out AppWidgetProvider>) {
        if (intent.action == ACTION_REFRESH) refresh(context, provider)
    }

    private fun rootViews(context: Context, layout: Int, rootId: Int, refreshId: Int, requestCode: Int): RemoteViews {
        val views = RemoteViews(context.packageName, layout)
        WidgetStyle.applyBackground(views, rootId, context)
        val openIntent = PendingIntent.getActivity(
            context, requestCode,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(rootId, openIntent)
        val refreshIntent = PendingIntent.getBroadcast(
            context, requestCode + 100, Intent(context, when (layout) {
                R.layout.widget_tasks -> OurSpaceTasksWidgetProvider::class.java
                R.layout.widget_shopping -> OurSpaceShoppingWidgetProvider::class.java
                else -> OurSpaceCalendarWidgetProvider::class.java
            }).setAction(ACTION_REFRESH),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(refreshId, refreshIntent)
        return views
    }

    private suspend fun tasksViews(context: Context): RemoteViews {
        val views = rootViews(context, R.layout.widget_tasks, R.id.tasks_widget_root, R.id.tasks_widget_refresh, 201)
        val app = context.applicationContext as? OurSpaceApplication
        val tasks = runCatching {
            app?.database?.taskDao()?.getAllOnce().orEmpty()
                .filter { !it.isDeleted && !it.isCompleted }
                .sortedWith(compareByDescending<TaskEntity> { it.priority }.thenBy { it.dueAt ?: Long.MAX_VALUE }.thenByDescending { it.createdAt })
        }.getOrDefault(emptyList())
        views.setTextViewText(R.id.tasks_widget_count, "${PersianDateFormatter.toPersianDigits(tasks.size)} باز")
        val ids = listOf(R.id.tasks_widget_row1, R.id.tasks_widget_row2, R.id.tasks_widget_row3)
        ids.forEachIndexed { index, id ->
            val task = tasks.getOrNull(index)
            views.setTextViewText(id, task?.let { "□ ${it.title}" } ?: if (index == 0 && tasks.isEmpty()) "🎉 کاری باقی نمانده" else "")
        }
        return views
    }

    private suspend fun shoppingViews(context: Context): RemoteViews {
        val views = rootViews(context, R.layout.widget_shopping, R.id.shopping_widget_root, R.id.shopping_widget_refresh, 202)
        val app = context.applicationContext as? OurSpaceApplication
        val items = runCatching {
            app?.database?.shoppingDao()?.getAllOnce().orEmpty()
                .filter { !it.isDeleted && !it.isChecked }
                .sortedBy { it.createdAt }
        }.getOrDefault(emptyList())
        views.setTextViewText(R.id.shopping_widget_count, "${PersianDateFormatter.toPersianDigits(items.size)} مورد")
        val ids = listOf(R.id.shopping_widget_row1, R.id.shopping_widget_row2, R.id.shopping_widget_row3, R.id.shopping_widget_row4)
        ids.forEachIndexed { index, id ->
            val item: ShoppingItemEntity? = items.getOrNull(index)
            views.setTextViewText(id, item?.let { "○ ${it.title} · ${it.quantity}" } ?: if (index == 0 && items.isEmpty()) "🛍 فهرست خرید خالی است" else "")
        }
        return views
    }

    private suspend fun calendarViews(context: Context): RemoteViews {
        val views = rootViews(context, R.layout.widget_calendar, R.id.calendar_widget_root, R.id.calendar_widget_refresh, 203)
        val app = context.applicationContext as? OurSpaceApplication
        val now = System.currentTimeMillis()
        val events = runCatching {
            app?.database?.eventDao()?.getAllOnce().orEmpty()
                .filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt >= now - 60_000L }
                .sortedBy { it.startAt }
        }.getOrDefault(emptyList())
        val ids = listOf(R.id.calendar_widget_row1, R.id.calendar_widget_row2, R.id.calendar_widget_row3)
        ids.forEachIndexed { index, id ->
            val event: EventEntity? = events.getOrNull(index)
            val label = when {
                event != null -> "📅 ${event.title}\n${PersianDateFormatter.formatDateTime(event.startAt)}"
                index == 0 && events.isEmpty() -> "🌿 قرار آینده‌ای ثبت نشده"
                else -> ""
            }
            views.setTextViewText(id, label)
        }
        return views
    }

    const val ACTION_REFRESH = "com.ourspace.app.widget.ACTION_REFRESH_EXTRA"
}

class OurSpaceTasksWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = ExtraWidgetSupport.refresh(context, javaClass)
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        ExtraWidgetSupport.onRefresh(context, intent, OurSpaceTasksWidgetProvider::class.java)
    }
    companion object { fun requestUpdate(context: Context) = ExtraWidgetSupport.refresh(context, OurSpaceTasksWidgetProvider::class.java) }
}

class OurSpaceShoppingWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = ExtraWidgetSupport.refresh(context, javaClass)
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        ExtraWidgetSupport.onRefresh(context, intent, OurSpaceShoppingWidgetProvider::class.java)
    }
    companion object { fun requestUpdate(context: Context) = ExtraWidgetSupport.refresh(context, OurSpaceShoppingWidgetProvider::class.java) }
}

class OurSpaceCalendarWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = ExtraWidgetSupport.refresh(context, javaClass)
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        ExtraWidgetSupport.onRefresh(context, intent, OurSpaceCalendarWidgetProvider::class.java)
    }
    companion object { fun requestUpdate(context: Context) = ExtraWidgetSupport.refresh(context, OurSpaceCalendarWidgetProvider::class.java) }
}
