package com.ourspace.app.core.security

import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * قفل ورود با اثر انگشت / چهره / پین یا الگوی قفل صفحهٔ گوشی.
 */
object AppLock {

    /** BIOMETRIC + پین/الگوی دستگاه */
    private val authenticators: Int =
        BIOMETRIC_STRONG or BIOMETRIC_WEAK or DEVICE_CREDENTIAL

    fun canAuthenticate(activity: FragmentActivity): Boolean {
        val manager = BiometricManager.from(activity)
        val result = manager.canAuthenticate(authenticators)
        return result == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun statusMessage(activity: FragmentActivity): String {
        return when (BiometricManager.from(activity).canAuthenticate(authenticators)) {
            BiometricManager.BIOMETRIC_SUCCESS ->
                "اثر انگشت، چهره یا پین قفل صفحه در دسترس است."
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ->
                "ابتدا در تنظیمات گوشی پین، الگو یا اثر انگشت تعریف کنید."
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE,
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
                "می‌توانید از پین یا الگوی قفل صفحه استفاده کنید؛ سخت‌افزار زیست‌سنجی در دسترس نیست."
            BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED ->
                "این دستگاه از احراز هویت پشتیبانی نمی‌کند."
            else ->
                "احراز هویت دستگاه در دسترس نیست."
        }
    }

    /**
     * نمایش دیالوگ سیستم برای باز کردن قفل.
     * در صورت موفقیت [onSuccess]، در صورت انصراف/خطا [onError] فراخوانی می‌شود.
     */
    fun authenticate(
        activity: FragmentActivity,
        title: String = "باز کردن OurSpace",
        subtitle: String = "با اثر انگشت، چهره یا پین گوشی تأیید کنید",
        onSuccess: () -> Unit,
        onError: (String) -> Unit = {}
    ) {
        if (!canAuthenticate(activity)) {
            // اگر فقط پین ثبت نشده باشد نمی‌توان قفل کرد
            onError(statusMessage(activity))
            return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    // کاربر انصراف داد یا خطای سیستم
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_CANCELED
                    ) {
                        onError(errString.toString())
                    }
                }

                override fun onAuthenticationFailed() {
                    // تلاش ناموفق؛ دیالوگ باز می‌ماند تا کاربر دوباره امتحان کند
                }
            }
        )
        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
        // از Android 11 به بعد setNegativeButtonText با DEVICE_CREDENTIAL سازگار نیست
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setAllowedAuthenticators(authenticators)
        } else {
            @Suppress("DEPRECATION")
            builder.setDeviceCredentialAllowed(true)
        }
        prompt.authenticate(builder.build())
    }
}
