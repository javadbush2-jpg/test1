package com.ourspace.app.core.reminder

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.ourspace.app.core.database.HabitEntity
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Schedules clock-based daily habit/medicine reminders. Text-only schedules remain informational. */
object HabitReminderScheduler {
    private const val PREFIX = "ourspace_habit_reminder_"

    fun scheduleAll(context: Context) {
        val app = context.applicationContext
        val db = (app as? com.ourspace.app.OurSpaceApplication)?.database ?: return
        // Read on the app scope rather than blocking the main thread.
        com.ourspace.app.core.reminder.ReminderSchedulingScope.launch {
            val habits = runCatching { db.habitDao().getAllOnce() }.getOrDefault(emptyList())
            habits.forEach { schedule(app, it) }
        }
    }

    fun schedule(context: Context, habit: HabitEntity) {
        val workName = PREFIX + habit.id
        val clock = parseClock(habit.scheduleNote)
        if (habit.isDeleted || clock == null) {
            WorkManager.getInstance(context).cancelUniqueWork(workName)
            return
        }
        val now = System.currentTimeMillis()
        val next = nextReminderAt(habit, clock, now)
        val clockToken = "%02d:%02d".format(clock.first, clock.second)
        val request = OneTimeWorkRequestBuilder<HabitReminderWorker>()
            .setInputData(Data.Builder()
                .putString(HabitReminderWorker.KEY_HABIT_ID, habit.id)
                .putString(HabitReminderWorker.KEY_SCHEDULED_CLOCK, clockToken)
                .build())
            .setInitialDelay((next - now).coerceAtLeast(1_000L), TimeUnit.MILLISECONDS)
            .addTag(workName)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(workName, ExistingWorkPolicy.REPLACE, request)
    }

    /** Next local clock that matches frequency / selected weekdays (search up to 14 days). */
    private fun nextReminderAt(habit: HabitEntity, clock: Pair<Int, Int>, now: Long): Long {
        val activeDays = activeWeekDays(habit)
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, clock.first)
            set(Calendar.MINUTE, clock.second)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        // TIMES_PER_WEEK has no fixed days — keep daily clock reminder.
        if (activeDays == null) {
            if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
            return cal.timeInMillis
        }
        repeat(14) {
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            if (dow in activeDays && cal.timeInMillis > now) {
                return cal.timeInMillis
            }
            cal.add(Calendar.DAY_OF_YEAR, 1)
            cal.set(Calendar.HOUR_OF_DAY, clock.first)
            cal.set(Calendar.MINUTE, clock.second)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    /** null = every day (or times-per-week without fixed days). */
    private fun activeWeekDays(habit: HabitEntity): Set<Int>? {
        return when (habit.frequency.uppercase()) {
            "DAILY", "TIMES_PER_WEEK" -> null
            "WEEKDAYS" -> setOf(
                Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY,
                Calendar.TUESDAY, Calendar.WEDNESDAY
            )
            "WEEKENDS" -> setOf(Calendar.THURSDAY, Calendar.FRIDAY)
            "CUSTOM_DAYS" -> {
                val parsed = habit.weekDays.split(',')
                    .mapNotNull { it.trim().toIntOrNull() }
                    .filter { it in Calendar.SUNDAY..Calendar.SATURDAY }
                    .toSet()
                parsed.ifEmpty { null }
            }
            else -> null
        }
    }

    internal fun parseClock(raw: String): Pair<Int, Int>? {
        val normalized = buildString {
            raw.forEach { ch -> append(when (ch) {
                in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
                in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
                else -> ch
            }) }
        }
        val match = Regex("(\\d{1,2})\\s*:\\s*(\\d{2})").find(normalized) ?: return null
        val hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: return null
        return if (hour in 0..23 && minute in 0..59) hour to minute else null
    }
}
