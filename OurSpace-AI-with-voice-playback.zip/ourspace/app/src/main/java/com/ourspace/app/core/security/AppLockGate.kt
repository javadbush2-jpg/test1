package com.ourspace.app.core.security

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ourspace.app.core.preferences.AppPreferences

/**
 * اگر قفل برنامه روشن باشد، تا احراز هویت موفق روی محتوا پوشش قفل گذاشته می‌شود.
 *
 * نکات مهم:
 * - محتوا همیشه در composition می‌ماند تا Activity Result (مثل انتخاب عکس) از بین نرود.
 * - با ON_STOP به‌طور پیش‌فرض قفل می‌شود، مگر [AppLockSession.suppressRelock] فعال باشد
 *   (برای گالری، انتخاب فایل، و Intentهای کوتاه سیستمی).
 */
@Composable
fun AppLockGate(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val prefs = remember(context) { AppPreferences(context) }
    val lockEnabled by prefs.appLockEnabled.collectAsState(initial = false)
    var unlocked by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(lockEnabled) {
        if (!lockEnabled) {
            unlocked = true
            errorMessage = null
        } else {
            // فقط وقتی قفل تازه روشن شده، دوباره قفل کن — نه در هر recomposition
            unlocked = false
        }
    }

    DisposableEffect(lifecycleOwner, lockEnabled) {
        val observer = LifecycleEventObserver { _, event ->
            if (!lockEnabled) return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_STOP -> {
                    // اگر برای انتخاب عکس/فایل suppress شده، قفل نکن
                    if (!AppLockSession.shouldSuppressRelock()) {
                        unlocked = false
                    }
                }
                Lifecycle.Event.ON_RESUME -> {
                    // بعد از بازگشت از گالری، suppress را تمام کن تا خروج بعدی قفل شود
                    // (کمی تأخیر تا Activity Result اول پردازش شود)
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // تلاش خودکار برای باز کردن قفل
    LaunchedEffect(lockEnabled, unlocked, activity) {
        if (lockEnabled && !unlocked && activity != null) {
            AppLock.authenticate(
                activity = activity,
                onSuccess = {
                    unlocked = true
                    errorMessage = null
                },
                onError = { msg -> errorMessage = msg }
            )
        }
    }

    // محتوا همیشه زنده می‌ماند؛ قفل فقط روی آن لایه می‌شود
    Box(Modifier.fillMaxSize()) {
        content()
        if (lockEnabled && !unlocked) {
            AppLockScreen(
                errorMessage = errorMessage,
                onUnlockClick = {
                    if (activity == null) {
                        errorMessage = "فعالیت برنامه در دسترس نیست."
                        return@AppLockScreen
                    }
                    AppLock.authenticate(
                        activity = activity,
                        onSuccess = {
                            unlocked = true
                            errorMessage = null
                        },
                        onError = { msg -> errorMessage = msg }
                    )
                }
            )
        }
    }
}

@Composable
private fun AppLockScreen(
    errorMessage: String?,
    onUnlockClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Outlined.Lock,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Text(
                "OurSpace قفل است",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black
            )
            Text(
                "برای ورود، اثر انگشت، چهره یا پین قفل صفحهٔ گوشی را وارد کنید.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (!errorMessage.isNullOrBlank()) {
                Text(
                    errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onUnlockClick) {
                Text("باز کردن قفل")
            }
            TextButton(onClick = onUnlockClick) {
                Text("تلاش دوباره")
            }
        }
    }
}
