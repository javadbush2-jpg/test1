package com.ourspace.app.feature.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.material3.TextButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import android.view.HapticFeedbackConstants
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.core.database.AttachmentEntity
import com.ourspace.app.core.finance.SmsPendingBus
import com.ourspace.app.core.database.CoupleProfileEntity
import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.LocationShareEntity
import com.ourspace.app.core.database.SharedPlaceEntity
import com.ourspace.app.core.preferences.SectionAttentionStore
import com.ourspace.app.core.sync.GameMessageProtocol
import com.ourspace.app.core.database.HabitEntity
import com.ourspace.app.core.database.WatchlistItemEntity
import com.ourspace.app.core.database.BookItemEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import com.ourspace.app.core.database.EventEntity
import com.ourspace.app.core.database.FinanceBudgetEntity
import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.database.RecurringTransactionEntity
import com.ourspace.app.core.database.SharedDebtEntity
import com.ourspace.app.core.database.MemoryEntity
import com.ourspace.app.core.database.MessageEntity
import com.ourspace.app.core.database.MoodCheckInEntity
import com.ourspace.app.core.database.ShoppingItemEntity
import com.ourspace.app.core.database.SpecialDateEntity
import com.ourspace.app.core.database.TaskEntity
import com.ourspace.app.core.database.TelegramStickerEntity
import com.ourspace.app.core.pairing.PairingStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.sync.SyncClient
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.feature.chat.ChatScreen
import com.ourspace.app.feature.ai.AiChatScreen
import com.ourspace.app.core.navigation.AppDeepLink
import com.ourspace.app.core.ai.AiProtocol
import com.ourspace.app.feature.finance.FinanceScreen
import com.ourspace.app.feature.planner.PlannerScreen
import com.ourspace.app.feature.location.LocationMapScreen
import com.ourspace.app.feature.relationship.RelationshipScreen
import com.ourspace.app.feature.games.GamesScreen
import com.ourspace.app.feature.settings.SettingsScreen
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.AppViewModel
import com.ourspace.app.ui.components.AmbientBackground
import com.ourspace.app.ui.components.ConnectionStatusBar
import com.ourspace.app.ui.components.GlowCard
import com.ourspace.app.ui.components.FloatingMotion
import com.ourspace.app.ui.design.OSGroupedSection
import com.ourspace.app.ui.design.OSGroupRow
import com.ourspace.app.ui.design.OSIconButton
import com.ourspace.app.ui.design.OSLargeTitle
import com.ourspace.app.ui.design.OSMetricTile
import com.ourspace.app.ui.design.OSSectionSpacer
import com.ourspace.app.ui.design.OSSpacing
import com.ourspace.app.ui.components.GradientHero
import com.ourspace.app.ui.components.MotionCard
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode
import com.ourspace.app.ui.theme.WidgetAccent
import com.ourspace.app.ui.theme.SeasonalAccent

private data class Destination(val label: String, val icon: ImageVector, val selectedIcon: ImageVector = icon)

private val destinations = listOf(
    Destination("خانه", Icons.Outlined.Home, Icons.Filled.Home),
    Destination("برنامه‌ها", Icons.Outlined.DateRange, Icons.Filled.DateRange),
    Destination("تقویم", Icons.Outlined.CalendarMonth, Icons.Filled.CalendarMonth),
    Destination("گفتگو", Icons.Outlined.Email, Icons.Filled.Email),
    Destination("مالی", Icons.Outlined.Star, Icons.Filled.Star),
    Destination("نقشه", Icons.Outlined.Place, Icons.Filled.Place),
    Destination("ما", Icons.Outlined.FavoriteBorder, Icons.Filled.Favorite),
    Destination("بازی‌ها", Icons.Outlined.SportsEsports, Icons.Filled.SportsEsports),
    Destination("هوشمند", Icons.Outlined.Psychology, Icons.Filled.Psychology),
    Destination("تنظیمات", Icons.Outlined.Settings, Icons.Filled.Settings)
)

@Suppress("LongParameterList")
private fun syncQueueLabel(total: Int, unsent: Int, awaitingAck: Int): String {
    if (total <= 0) return ""
    val parts = mutableListOf<String>()
    if (unsent > 0) parts += "${com.ourspace.app.core.time.PersianDateFormatter.toPersianDigits(unsent)} در انتظار ارسال"
    if (awaitingAck > 0) parts += "${com.ourspace.app.core.time.PersianDateFormatter.toPersianDigits(awaitingAck)} منتظر تأیید همراه"
    return if (parts.isNotEmpty()) parts.joinToString(" · ")
    else "${com.ourspace.app.core.time.PersianDateFormatter.toPersianDigits(total)} تغییر در صف"
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MainShell(
    role: DeviceRole,
    identity: DeviceIdentityManager.DeviceIdentity,
    pairingSnapshot: PairingStore.Snapshot,
    pairingAction: AppViewModel.PairingActionState,
    syncState: AppViewModel.SyncState,
    relayConfig: RelayConfig,
    relayAction: AppViewModel.RelayActionState,
    backupAction: AppViewModel.BackupActionState = AppViewModel.BackupActionState(),
    onBackupNow: () -> Unit = {},
    onRestoreBackup: () -> Unit = {},
    pendingSyncChanges: Int,
    pendingSyncUnsent: Int = 0,
    pendingSyncAwaitingAck: Int = 0,
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    shoppingItems: List<ShoppingItemEntity>,
    messages: List<MessageEntity>,
    gameMessages: List<MessageEntity>,
    attachments: List<AttachmentEntity>,
    attachmentAction: AppViewModel.AttachmentActionState,
    chatAction: AppViewModel.ChatActionState = AppViewModel.ChatActionState(),
    stickerImportAction: AppViewModel.StickerImportActionState = AppViewModel.StickerImportActionState(),
    telegramStickerPacks: List<com.ourspace.app.core.database.TelegramStickerPackEntity> = emptyList(),
    onImportTelegramPack: (String) -> Unit = {},
    onDeleteTelegramPack: (String) -> Unit = {},
    onObserveTelegramStickers: (String) -> Flow<List<TelegramStickerEntity>> = { emptyFlow() },
    onSendTelegramSticker: (String, String?) -> Unit = { _, _ -> },
    peerTyping: Boolean = false,
    peerLastSeenAt: Long = 0L,
    pendingSendIds: Set<String> = emptySet(),
    financialAccounts: List<FinancialAccountEntity>,
    financeTransactions: List<FinanceTransactionEntity>,
    financeBudgets: List<FinanceBudgetEntity>,
    sharedDebts: List<SharedDebtEntity>,
    recurringTransactions: List<RecurringTransactionEntity>,
    memories: List<MemoryEntity>,
    moodCheckIns: List<MoodCheckInEntity>,
    specialDates: List<SpecialDateEntity>,
    cycleLogs: List<CycleLogEntity>,
    cycleSettings: CycleSettingsEntity?,
    locationShares: List<LocationShareEntity>,
    locationSharingEnabled: Boolean,
    locationAction: AppViewModel.LocationActionState,
    coupleProfile: CoupleProfileEntity?,
    palette: AppPalette,
    themeMode: AppThemeMode,
    dynamicColor: Boolean,
    widgetAccent: WidgetAccent = WidgetAccent.ROSE,
    onAddTask: (String, Int, String, Long?) -> Unit,
    onAddTimedTask: (String, Int, String, Long?, Int) -> Unit = { title, priority, assignee, dueAt, _ -> onAddTask(title, priority, assignee, dueAt) },
    onToggleTask: (TaskEntity) -> Unit,
    onUpdateTaskSchedule: (TaskEntity, Long, Int) -> Unit = { _, _, _ -> },
    onUpdateTask: (TaskEntity, String, Int, String, Long?, Int) -> Unit = { _, _, _, _, _, _ -> },
    onDeleteTask: (TaskEntity) -> Unit,
    onAddEvent: (String, Long) -> Unit,
    onAddTimedEvent: (String, Long, Int) -> Unit = { title, at, _ -> onAddEvent(title, at) },
    onAddWorkScheduleEvents: (List<EventEntity>) -> Unit = { items -> items.forEach { onAddTimedEvent(it.title, it.startAt, (((it.endAt ?: it.startAt) - it.startAt) / 60_000L).toInt()) } },
    onUpdateEvent: (EventEntity, String, Long) -> Unit = { _, _, _ -> },
    onUpdateEventSchedule: (EventEntity, Long, Long) -> Unit = { _, _, _ -> },
    onDeleteEvent: (EventEntity) -> Unit,
    onAddShopping: (String, String, String, Boolean) -> Unit,
    onToggleShopping: (ShoppingItemEntity) -> Unit,
    onDeleteShopping: (ShoppingItemEntity) -> Unit,
    onClearCheckedShopping: () -> Unit,
    heartAction: AppViewModel.HeartActionState,
    onSendHeartPulse: () -> Unit,
    sharedPlaces: List<SharedPlaceEntity>,
    onAddSharedPlace: (String, String, Double, Double, String) -> Unit,
    onDeleteSharedPlace: (SharedPlaceEntity) -> Unit,
    habits: List<HabitEntity> = emptyList(),
    watchlistItems: List<WatchlistItemEntity> = emptyList(),
    bookItems: List<BookItemEntity> = emptyList(),
    foodItems: List<com.ourspace.app.core.database.FoodItemEntity> = emptyList(),
    onAddHabit: (
        title: String,
        kind: String,
        scheduleNote: String,
        note: String,
        frequency: String,
        timesPerWeek: Int,
        timesPerDay: Int,
        weekDays: String,
        priority: String
    ) -> Unit = { _, _, _, _, _, _, _, _, _ -> },
    onToggleHabitDoneToday: (HabitEntity) -> Unit = {},
    onDeleteHabit: (HabitEntity) -> Unit = {},
    onAddWatchlistItem: (String, String, String, Int, Int) -> Unit = { _, _, _, _, _ -> },
    onUpdateWatchlistItem: (WatchlistItemEntity, String, String, String, String, Int, Int, Int) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onAdjustWatchlistWatchedEpisodes: (WatchlistItemEntity, Int) -> Unit = { _, _ -> },
    onCycleWatchlistStatus: (WatchlistItemEntity) -> Unit = {},
    onDeleteWatchlistItem: (WatchlistItemEntity) -> Unit = {},
    onAddBookItem: (String, String, String, Int) -> Unit = { _, _, _, _ -> },
    onUpdateBookItem: (BookItemEntity, String, String, String, String, Int, Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onAdjustBookReadPages: (BookItemEntity, Int) -> Unit = { _, _ -> },
    onCycleBookStatus: (BookItemEntity) -> Unit = {},
    onDeleteBookItem: (BookItemEntity) -> Unit = {},
    onAddFoodItem: (String, String) -> Unit = { _, _ -> },
    onToggleFoodFavorite: (com.ourspace.app.core.database.FoodItemEntity) -> Unit = {},
    onDeleteFoodItem: (com.ourspace.app.core.database.FoodItemEntity) -> Unit = {},
    onSendMessage: suspend (String, String?) -> Boolean,
    onRequestAiSuggestion: (String) -> Unit = {},
    onRequestAiFreeChat: (String, List<Pair<String, String>>) -> Unit = { _, _ -> },
    aiBusy: Boolean = false,
    aiLastError: String? = null,
    aiChatSuggestion: AiProtocol.Suggestion? = null,
    aiModelStatusLabel: String = "",
    onClearAiChat: () -> Unit = {},
    aiSuggestionText: String? = null,
    aiAlternatives: List<String> = emptyList(),
    aiError: String? = null,
    onClearAiSuggestion: () -> Unit = {},
    onSendGameMessage: suspend (String) -> Boolean,
    onSendVoiceMessage: (ByteArray, Int, String?) -> Unit = { _, _, _ -> },
    onSendAttachment: (String, String?) -> Unit,
    onSaveAttachment: (String, String) -> Unit,
    onLoadAttachment: suspend (String) -> AttachmentEntity? = { null },
    onDeleteAttachment: (AttachmentEntity) -> Unit,
    onEditMessage: (MessageEntity, String) -> Unit,
    onDeleteMessage: (MessageEntity) -> Unit,
    onReactMessage: (MessageEntity, String) -> Unit,
    onMarkVisibleChatMessagesRead: (List<String>) -> Unit = {},
    onTyping: (Boolean) -> Unit = {},
    onStampDeliveries: () -> Unit = {},
    onShareTaskToChat: (TaskEntity) -> Unit = {},
    onShareEventToChat: (EventEntity) -> Unit = {},
    onShareDebtToChat: (SharedDebtEntity) -> Unit = {},
    onShareMemoryToChat: (MemoryEntity) -> Unit = {},
    onShareLocationToChat: (LocationShareEntity) -> Unit = {},
    onSearchChatMessages: suspend (String) -> List<MessageEntity> = { emptyList() },
    onFindChatMessage: suspend (String) -> MessageEntity? = { null },
    onLoadOlderChatMessages: suspend (MessageEntity) -> Int,
    onAddFinancialAccount: (String, String, Long, Int) -> Unit,
    onCorrectFinancialAccountBalance: (FinancialAccountEntity, Long) -> Unit,
    onAddFinanceTransaction: (String, String?, String, Long, String, String) -> Unit,
    onAddFinanceTransactionAt: (String, String?, String, Long, String, String, Long, String) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onDeleteFinanceTransaction: (FinanceTransactionEntity) -> Unit,
    onSetFinanceBudget: (String, String, Long) -> Unit,
    onAddSharedDebt: (String, Long, String, String, Long?) -> Unit,
    onToggleDebtSettled: (SharedDebtEntity) -> Unit,
    onDeleteSharedDebt: (SharedDebtEntity) -> Unit,
    onAddRecurringTransaction: (String, String?, String, Long, String, String, String, Long) -> Unit,
    onToggleRecurringTransaction: (RecurringTransactionEntity) -> Unit,
    onDeleteRecurringTransaction: (RecurringTransactionEntity) -> Unit,
    onAddMemory: (String, String, String, Long) -> Unit,
    onUpdateMemory: (MemoryEntity, String, String, String, Long) -> Unit = { _, _, _, _, _ -> },
    onAddMemoryAttachment: (String, String, Int) -> Unit,
    onRotateMemoryAttachment: (String, Int) -> Unit = { _, _ -> },
    onToggleMemoryFavorite: (MemoryEntity) -> Unit,
    onDeleteMemory: (MemoryEntity) -> Unit,
    onSetDailyMood: (String, String) -> Unit,
    onSetMoodForDay: (String, String, String) -> Unit = { _, _, _ -> },
    onAddSpecialDate: (String, String, Long, Boolean) -> Unit,
    onUpdateSpecialDate: (SpecialDateEntity, String, String, Long, Boolean) -> Unit,
    onDeleteSpecialDate: (SpecialDateEntity) -> Unit,
    onStartPeriod: (Long, String, String) -> Unit,
    onEndPeriod: (CycleLogEntity, Long) -> Unit,
    onDeleteCycleLog: (CycleLogEntity) -> Unit,
    onUpdateCycleSettings: (Int, Int, Boolean) -> Unit,
    onToggleLocationSharing: (Boolean) -> Unit,
    onRefreshLocation: () -> Unit,
    onRefreshPartnerLocation: () -> Unit = {},
    onRequestLocationPermission: () -> Unit,
    hasLocationPermission: Boolean,
    onSaveCoupleProfile: (String, String, Long?) -> Unit,
    onSetPalette: (AppPalette) -> Unit,
    aiModelState: com.ourspace.app.core.ai.AiModelState = com.ourspace.app.core.ai.AiModelState(),
    onSelectAiModel: (String) -> Unit = {},
    onImportAiModel: (android.net.Uri, String?) -> Unit = { _, _ -> },
    onDeleteAiModel: () -> Unit = {},
    onRefreshAiModel: () -> Unit = {},
    onSetThemeMode: (AppThemeMode) -> Unit,
    onSetDynamicColor: (Boolean) -> Unit,
    onSetWidgetAccent: (WidgetAccent) -> Unit = {},
    telegramBotToken: String = "",
    onSetTelegramBotToken: (String) -> Unit = {},
    onApprovePairing: () -> Unit,
    onRejectPairing: () -> Unit,
    onCheckPairing: () -> Unit,
    onCancelPairing: () -> Unit,
    onRevokeTrust: () -> Unit,
    onSync: () -> Unit,
    onSaveRelayConfig: (Boolean, String, String) -> Unit,
    diagnostics: List<String> = emptyList(),
    syncHealth: com.ourspace.app.core.webrtc.ConnectionDiagnostics.Health = com.ourspace.app.core.webrtc.ConnectionDiagnostics.Health(),
    onRunConnectionTest: () -> Unit = {},
    onClearDiagnostics: () -> Unit = {},
    onPairPayload: (String) -> Unit,
    onScanCompanionReply: (String) -> Unit,
    onScanApproval: (String) -> Unit,
    onPairWithPin: (String) -> Unit = {},
    onGenerateHostPin: () -> Unit = {},
    onReset: () -> Unit
) {
    var selected by remember { mutableIntStateOf(0) }
    var deepLink by remember { mutableStateOf<AppDeepLink?>(null) }
    // لمس اعلان تراکنش پیامکی → مستقیم به تب مالی برو؛ دیالوگ دسته‌بندی را خود FinanceScreen باز می‌کند.
    LaunchedEffect(Unit) {
        SmsPendingBus.openRequest.collect { pendingId ->
            if (!pendingId.isNullOrBlank()) selected = AppDeepLink.SECTION_FINANCE
        }
    }
    val haptics = LocalHapticFeedback.current
    val menuView = LocalView.current
    val context = LocalContext.current
    // تشخیص مطمئن باز/بسته بودن کیبورد برای Compose (با edge-to-edge)
    val isImeVisible = WindowInsets.isImeVisible
    val attentionStore = remember { SectionAttentionStore(context) }
    val sectionSeen by attentionStore.seenAt.collectAsState()
    val unreadMessages = remember(messages, identity.deviceId) {
        messages.count {
            !GameMessageProtocol.isProtocolMessage(it.text) && it.senderDeviceId != identity.deviceId && it.readAt == null
        }
    }
    val sectionDots = remember(
        sectionSeen, tasks, events, shoppingItems, messages, unreadMessages,
        financialAccounts, financeTransactions, financeBudgets, sharedDebts, recurringTransactions,
        memories, moodCheckIns, specialDates, cycleLogs, cycleSettings,
        locationShares, sharedPlaces, coupleProfile, habits, watchlistItems, bookItems, attachments
    ) {
        computeSectionAttentionDots(
            seen = sectionSeen,
            tasks = tasks,
            events = events,
            shoppingItems = shoppingItems,
            messages = messages,
            unreadMessages = unreadMessages,
            financialAccounts = financialAccounts,
            financeTransactions = financeTransactions,
            financeBudgets = financeBudgets,
            sharedDebts = sharedDebts,
            recurringTransactions = recurringTransactions,
            memories = memories,
            moodCheckIns = moodCheckIns,
            specialDates = specialDates,
            cycleLogs = cycleLogs,
            cycleSettings = cycleSettings,
            locationShares = locationShares,
            sharedPlaces = sharedPlaces,
            coupleProfile = coupleProfile,
            habits = habits,
            watchlistItems = watchlistItems,
            bookItems = bookItems,
            attachments = attachments
        )
    }
    // اولین اجرا: همه بخش‌ها را «دیده‌شده» علامت بزن تا فقط تغییرات بعدی دایره بگیرند
    LaunchedEffect(Unit) {
        if (sectionSeen.isEmpty()) {
            val now = System.currentTimeMillis()
            for (i in 0 until SectionAttentionStore.SECTION_COUNT) {
                attentionStore.markSeen(i, now)
            }
        }
    }
    // با باز شدن هر تب، نشانگر همان بخش پاک می‌شود
    LaunchedEffect(selected) {
        // Opening the tab clears its attention dot, but does not mark every message read.
        // Read receipts are committed only for message rows actually visible in ChatScreen.
        attentionStore.markSeen(selected)
    }
    // وقتی داخل همان تب هستیم و داده عوض می‌شود، نشانگر دوباره روشن نشود
    LaunchedEffect(
        selected, tasks, events, shoppingItems, messages, financialAccounts, financeTransactions,
        financeBudgets, sharedDebts, recurringTransactions, memories, moodCheckIns, specialDates,
        cycleLogs, locationShares, sharedPlaces, coupleProfile, habits, watchlistItems, bookItems, attachments
    ) {
        attentionStore.touchOpenSection(selected)
    }
    val heartPulse = rememberInfiniteTransition(label = "top-heart")
    val heartBeatScale by heartPulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(tween(520), RepeatMode.Reverse),
        label = "heart-beat"
    )
    AmbientBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .shadow(
                                        elevation = 6.dp,
                                        shape = RoundedCornerShape(14.dp),
                                        ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.28f),
                                        spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                                    )
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(
                                                MaterialTheme.colorScheme.primary,
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.92f),
                                                MaterialTheme.colorScheme.tertiary
                                            )
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Filled.Favorite,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(21.dp)
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                            Text(
                                "OurSpace",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                letterSpacing = (-0.4).sp
                            )
                            ConnectionStatusBar(compact = true, modifier = Modifier.padding(top = 2.dp))
                            if (pendingSyncChanges > 0) {
                                Text(
                                    syncQueueLabel(pendingSyncChanges, pendingSyncUnsent, pendingSyncAwaitingAck),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(top = 1.dp)
                                )
                            }
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                onSendHeartPulse()
                            },
                            enabled = !heartAction.isSending && pairingSnapshot.trustedPeer != null
                        ) {
                            Icon(
                                Icons.Filled.Favorite,
                                contentDescription = "به یادتم",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.graphicsLayer {
                                    scaleX = heartBeatScale
                                    scaleY = heartBeatScale
                                }
                            )
                        }
                        IconButton(onClick = onSync) {
                            BadgedBox(
                                badge = {
                                    if (syncState.error != null) Badge(containerColor = MaterialTheme.colorScheme.error)
                                }
                            ) { Icon(Icons.Outlined.Notifications, "همگام‌سازی و اعلان‌ها") }
                        }
                    }
                )
            },
            bottomBar = {
                // فقط وقتی در گفتگو کیبورد باز است مخفی می‌شود تا باکس تایپ بچسبد به کیبورد؛
                // با بسته شدن کیبورد (isImeVisible=false) نوار فوراً برمی‌گردد.
                if (!(selected == 3 && isImeVisible)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    // Premium floating nav shell with soft border glow
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                brush = Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.32f),
                                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.14f),
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.20f)
                                    )
                                ),
                                shape = RoundedCornerShape(30.dp)
                            ),
                        shape = RoundedCornerShape(30.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.98f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 20.dp)
                    ) {
                        // Scrollable so all tabs stay tappable on narrow screens.
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            destinations.forEachIndexed { index, destination ->
                                val isSelected = selected == index
                                val iconScale by animateFloatAsState(
                                    targetValue = if (isSelected) 1.14f else 1f,
                                    animationSpec = com.ourspace.app.ui.design.OSMotion.navIndicator,
                                    label = "nav-icon-scale-$index"
                                )
                                val tint = if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f)
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .widthIn(min = 66.dp)
                                        .heightIn(min = 58.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .clickable {
                                            // Soft tick on every bottom-nav tap (chat, settings, …)
                                            menuView.performHapticFeedback(
                                                HapticFeedbackConstants.CLOCK_TICK
                                            )
                                            selected = index
                                        }
                                        .background(
                                            if (isSelected) {
                                                Brush.verticalGradient(
                                                    listOf(
                                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                                                    )
                                                )
                                            } else {
                                                Brush.verticalGradient(
                                                    listOf(Color.Transparent, Color.Transparent)
                                                )
                                            },
                                            RoundedCornerShape(20.dp)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                ) {
                                    val showDot = !isSelected && (sectionDots[index] == true)
                                    if (index == SectionAttentionStore.CHAT && unreadMessages > 0 && !isSelected) {
                                        BadgedBox(
                                            badge = {
                                                Badge {
                                                    Text(PersianDateFormatter.toPersianDigits(unreadMessages.coerceAtMost(99)))
                                                }
                                            }
                                        ) {
                                            Icon(if (isSelected) destination.selectedIcon else destination.icon, destination.label, tint = tint, modifier = Modifier.size(24.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale })
                                        }
                                    } else if (showDot) {
                                        BadgedBox(
                                            badge = {
                                                // دایره ساده برای تغییر جدید در بخش
                                                Badge(
                                                    containerColor = MaterialTheme.colorScheme.error,
                                                    content = {}
                                                )
                                            }
                                        ) {
                                            Icon(if (isSelected) destination.selectedIcon else destination.icon, destination.label, tint = tint, modifier = Modifier.size(24.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale })
                                        }
                                    } else {
                                        Icon(if (isSelected) destination.selectedIcon else destination.icon, destination.label, tint = tint, modifier = Modifier.size(24.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale })
                                    }
                                    Text(
                                        destination.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = tint,
                                        maxLines = 1
                                    )
                                    // Soft glowing pill under the selected tab
                                    if (isSelected) {
                                        Spacer(Modifier.height(4.dp))
                                        Canvas(Modifier.width(22.dp).height(3.5.dp)) {
                                            drawRoundRect(
                                                brush = Brush.horizontalGradient(
                                                    listOf(
                                                        tint.copy(alpha = 0.25f),
                                                        tint,
                                                        tint.copy(alpha = 0.25f)
                                                    )
                                                ),
                                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height)
                                            )
                                        }
                                    } else {
                                        Spacer(Modifier.height(7.5.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                } // end if (!(selected == 3 && isImeVisible))
            },
            floatingActionButton = {
                AnimatedVisibility(
                    visible = selected == 0,
                    enter = fadeIn(tween(220)) + scaleIn(initialScale = 0.7f, animationSpec = tween(280)),
                    exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.7f, animationSpec = tween(150))
                ) {
                    FloatingActionButton(
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            selected = 1
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        shape = RoundedCornerShape(22.dp),
                        elevation = FloatingActionButtonDefaults.elevation(10.dp)
                    ) { Icon(Icons.Default.Add, "افزودن") }
                }
            }
        ) { padding ->
            Box(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .pointerInput(selected, isImeVisible) {
                        // تب «ما» پیمایش داخلی خودش را دارد؛ ژست آن را RelationshipScreen مدیریت می‌کند.
                        if (!isImeVisible && selected != 6) {
                            val swipeThresholdPx = 64.dp.toPx()
                            var horizontalDrag = 0f
                            detectHorizontalDragGestures(
                                onHorizontalDrag = { change, dragAmount ->
                                    horizontalDrag += dragAmount
                                    change.consume()
                                },
                                onDragEnd = {
                                    val drag = horizontalDrag
                                    horizontalDrag = 0f
                                    val nextSection = when {
                                        drag <= -swipeThresholdPx -> (selected - 1).coerceAtLeast(0)
                                        drag >= swipeThresholdPx -> (selected + 1).coerceAtMost(destinations.lastIndex)
                                        else -> selected
                                    }
                                    if (nextSection != selected) {
                                        menuView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                        selected = nextSection
                                    }
                                },
                                onDragCancel = { horizontalDrag = 0f }
                            )
                        }
                    }
            ) {
                AnimatedContent(
                    targetState = selected,
                    transitionSpec = {
                        val forward = targetState < initialState
                        // Keep the same directional fade/slide navigation, but avoid scaling the
                        // entire incoming/outgoing screen and shorten overlap between heavy screens.
                        val enter = (
                            fadeIn(tween(180)) +
                                slideInHorizontally(tween(210)) { full -> if (forward) full / 7 else -full / 7 }
                        )
                        val exit = (
                            fadeOut(tween(120)) +
                                slideOutHorizontally(tween(160)) { full -> if (forward) -full / 12 else full / 12 }
                        )
                        enter togetherWith exit
                    },
                    label = "main-navigation"
                ) { destinationIndex ->
                    when (destinationIndex) {
                        0 -> HomeDashboard(
                            role = role,
                            identity = identity,
                            pairingSnapshot = pairingSnapshot,
                            syncState = syncState,
                            pendingSyncChanges = pendingSyncChanges,
                            pendingSyncUnsent = pendingSyncUnsent,
                            pendingSyncAwaitingAck = pendingSyncAwaitingAck,
                            tasks = tasks,
                            events = events,
                            shoppingItems = shoppingItems,
                            financeTransactions = financeTransactions,
                            moodCheckIns = moodCheckIns,
                            coupleProfile = coupleProfile,
                            specialDates = specialDates,
                            messages = messages,
                            memories = memories,
                            habits = habits,
                            sharedDebts = sharedDebts,
                            watchlistItems = watchlistItems,
                            bookItems = bookItems,
                            foodItems = foodItems,
                            financialAccounts = financialAccounts,
                            onSync = onSync,
                            onOpenPlanner = { selected = 1 },
                            onOpenDeepLink = { link -> deepLink = link; selected = link.section },
                            onOpenCalendar = { selected = 2 },
                            onOpenChat = { selected = 3 },
                            onOpenFinance = { selected = 4 },
                            onOpenMap = { selected = 5 },
                            onOpenUs = { selected = 6 },
                            onOpenGames = { selected = 7 },
                            onOpenSettings = { selected = 9 },
                            isPaired = pairingSnapshot.trustedPeer != null,
                            heartAction = heartAction,
                            onSendHeartPulse = onSendHeartPulse
                        )
                        1 -> PlannerScreen(
                            focusItemId = deepLink?.takeIf { it.section == 1 }?.itemId,
                            focusCategory = deepLink?.takeIf { it.section == 1 }?.category,
                            onFocusConsumed = { if (deepLink?.section == 1) deepLink = null },

                            tasks = tasks,
                            events = events,
                            shoppingItems = shoppingItems,
                            specialDates = specialDates,
                            cycleLogs = cycleLogs,
                            cycleSettings = cycleSettings,
                            habits = habits,
                            onAddTask = onAddTimedTask,
                            onToggleTask = onToggleTask,
                            onUpdateTask = onUpdateTask,
                            onDeleteTask = onDeleteTask,
                            onShareTaskToChat = { task -> onShareTaskToChat(task); selected = 3 },
                            onShareEventToChat = { event -> onShareEventToChat(event); selected = 3 },
                            onAddEvent = onAddEvent,
                            onAddWorkScheduleEvents = onAddWorkScheduleEvents,
                            onUpdateEvent = onUpdateEvent,
                            onDeleteEvent = onDeleteEvent,
                            onAddShopping = onAddShopping,
                            onToggleShopping = onToggleShopping,
                            onDeleteShopping = onDeleteShopping,
                            onClearCheckedShopping = onClearCheckedShopping,
                            onAddHabit = onAddHabit,
                            onToggleHabitDoneToday = onToggleHabitDoneToday,
                            onDeleteHabit = onDeleteHabit
                        )
                        2 -> CalendarScreen(
                            focusDayKey = deepLink?.takeIf { it.section == 2 }?.dayKey,
                            focusItemId = deepLink?.takeIf { it.section == 2 }?.itemId,
                            onFocusConsumed = { if (deepLink?.section == 2) deepLink = null },

                            tasks = tasks,
                            events = events,
                            shoppingItems = shoppingItems,
                            messages = messages,
                            financeTransactions = financeTransactions,
                            financialAccounts = financialAccounts,
                            onAddFinanceTransactionAt = onAddFinanceTransactionAt,
                            sharedDebts = sharedDebts,
                            recurringTransactions = recurringTransactions,
                            habits = habits,
                            memories = memories,
                            attachments = attachments,
                            moodCheckIns = moodCheckIns,
                            specialDates = specialDates,
                            cycleLogs = cycleLogs,
                            cycleSettings = cycleSettings,
                            onAddTask = onAddTask,
                            onAddTimedTask = onAddTimedTask,
                            onUpdateTaskSchedule = onUpdateTaskSchedule,
                            onToggleTask = onToggleTask,
                            onDeleteTask = onDeleteTask,
                            onAddEvent = onAddEvent,
                            onAddTimedEvent = onAddTimedEvent,
                            onUpdateEventSchedule = onUpdateEventSchedule,
                            onDeleteEvent = onDeleteEvent,
                            onAddHabit = onAddHabit,
                            onAddMemory = onAddMemory,
                            onToggleMemoryFavorite = onToggleMemoryFavorite,
                            onDeleteMemory = onDeleteMemory,
                            onAddSpecialDate = onAddSpecialDate,
                            onSetDailyMood = onSetMoodForDay,
                            onToggleShopping = onToggleShopping,
                            onOpenPlanner = { selected = 1 },
                            onOpenFinance = { selected = 4 },
                            onOpenChat = { selected = 3 },
                            onOpenMemories = { selected = 6 }
                        )
                        3 -> ChatScreen(
                            focusMessageId = deepLink?.takeIf { it.section == 3 }?.itemId,
                            onFocusConsumed = { if (deepLink?.section == 3) deepLink = null },
                            onOpenDeepLink = { link -> deepLink = link; selected = link.section },

                            ownDeviceId = identity.deviceId,
                            isPaired = pairingSnapshot.trustedPeer != null,
                            messages = messages,
                            attachments = attachments,
                            syncState = syncState,
                            attachmentAction = attachmentAction,
                            chatAction = chatAction,
                            peerTyping = peerTyping,
                            peerLastSeenAt = peerLastSeenAt,
                            pendingSendIds = pendingSendIds,
                            onSend = onSendMessage,
                            onSendAttachment = onSendAttachment,
                            onSendVoiceMessage = onSendVoiceMessage,
                            onSaveAttachment = onSaveAttachment,
                            onLoadAttachment = onLoadAttachment,
                            onEdit = onEditMessage,
                            onDelete = onDeleteMessage,
                            onReact = onReactMessage,
                            onMarkVisibleRead = onMarkVisibleChatMessagesRead,
                            onTyping = onTyping,
                            onStampDeliveries = onStampDeliveries,
                            onSearchMessages = onSearchChatMessages,
                            onFindMessage = onFindChatMessage,
                            onLoadOlder = onLoadOlderChatMessages,
                            onSync = onSync,
                            telegramStickerPacks = telegramStickerPacks,
                            onDeleteTelegramPack = onDeleteTelegramPack,
                            onObserveTelegramStickers = onObserveTelegramStickers,
                            onSendTelegramSticker = onSendTelegramSticker,
                            onRequestAiSuggestion = onRequestAiSuggestion,
                            aiSuggestionText = aiSuggestionText,
                            aiAlternatives = aiAlternatives,
                            aiBusy = aiBusy,
                            aiError = aiError,
                            onClearAiSuggestion = onClearAiSuggestion
                        )
                        4 -> FinanceScreen(
                            focusItemId = deepLink?.takeIf { it.section == 4 }?.itemId,
                            focusCategory = deepLink?.takeIf { it.section == 4 }?.category,
                            focusTab = deepLink?.takeIf { it.section == 4 }?.financeTab,
                            onFocusConsumed = { if (deepLink?.section == 4) deepLink = null },

                            ownDeviceId = identity.deviceId,
                            accounts = financialAccounts,
                            transactions = financeTransactions,
                            budgets = financeBudgets,
                            debts = sharedDebts,
                            recurringTransactions = recurringTransactions,
                            shoppingItems = shoppingItems,
                            onAddAccount = onAddFinancialAccount,
                            onCorrectAccountBalance = onCorrectFinancialAccountBalance,
                            onAddTransaction = onAddFinanceTransaction,
                            onAddTransactionAt = onAddFinanceTransactionAt,
                            onDeleteTransaction = onDeleteFinanceTransaction,
                            onSetBudget = onSetFinanceBudget,
                            onAddDebt = onAddSharedDebt,
                            onToggleDebtSettled = onToggleDebtSettled,
                            onDeleteDebt = onDeleteSharedDebt,
                            onShareDebtToChat = { debt -> onShareDebtToChat(debt); selected = 3 },
                            onAddRecurring = onAddRecurringTransaction,
                            onToggleRecurring = onToggleRecurringTransaction,
                            onDeleteRecurring = onDeleteRecurringTransaction,
                            onAddShopping = onAddShopping,
                            onToggleShopping = onToggleShopping,
                            onDeleteShopping = onDeleteShopping,
                            onClearCheckedShopping = onClearCheckedShopping
                        )
                        5 -> LocationMapScreen(
                            ownDeviceId = identity.deviceId,
                            isPaired = pairingSnapshot.trustedPeer != null,
                            sharingEnabled = locationSharingEnabled,
                            hasPermission = hasLocationPermission,
                            isUpdating = locationAction.isUpdating,
                            statusMessage = locationAction.message,
                            statusError = locationAction.error,
                            locations = locationShares,
                            sharedPlaces = sharedPlaces,
                            onToggleSharing = onToggleLocationSharing,
                            onRequestPermission = onRequestLocationPermission,
                            onRefreshNow = onRefreshLocation,
                            onRefreshPartnerLocation = onRefreshPartnerLocation,
                            onShareLocationToChat = { loc -> onShareLocationToChat(loc); selected = 3 },
                            onAddPlace = onAddSharedPlace,
                            onDeletePlace = onDeleteSharedPlace
                        )
                        6 -> RelationshipScreen(
                            focusItemId = deepLink?.takeIf { it.section == 6 }?.itemId,
                            focusCategory = deepLink?.takeIf { it.section == 6 }?.category,
                            focusTab = deepLink?.takeIf { it.section == 6 }?.usTab,
                            isImeVisible = isImeVisible,
                            onFocusConsumed = { if (deepLink?.section == 6) deepLink = null },

                            role = role,
                            ownDeviceId = identity.deviceId,
                            profile = coupleProfile,
                            memories = memories,
                            attachments = attachments,
                            attachmentAction = attachmentAction,
                            moodCheckIns = moodCheckIns,
                            specialDates = specialDates,
                            cycleLogs = cycleLogs,
                            cycleSettings = cycleSettings,
                            palette = palette,
                            themeMode = themeMode,
                            dynamicColor = dynamicColor,
                            watchlistItems = watchlistItems,
                            bookItems = bookItems,
                            foodItems = foodItems,
                            onAddWatchlistItem = onAddWatchlistItem,
                            onUpdateWatchlistItem = onUpdateWatchlistItem,
                            onAdjustWatchlistWatchedEpisodes = onAdjustWatchlistWatchedEpisodes,
                            onCycleWatchlistStatus = onCycleWatchlistStatus,
                            onDeleteWatchlistItem = onDeleteWatchlistItem,
                            onAddBookItem = onAddBookItem,
                            onUpdateBookItem = onUpdateBookItem,
                            onAdjustBookReadPages = onAdjustBookReadPages,
                            onCycleBookStatus = onCycleBookStatus,
                            onDeleteBookItem = onDeleteBookItem,
                            onAddFoodItem = onAddFoodItem,
                            onToggleFoodFavorite = onToggleFoodFavorite,
                            onDeleteFoodItem = onDeleteFoodItem,
                            onAddMemory = onAddMemory,
                            onUpdateMemory = onUpdateMemory,
                            onAddMemoryAttachment = onAddMemoryAttachment,
                            onRotateMemoryAttachment = onRotateMemoryAttachment,
                            onSaveAttachment = onSaveAttachment,
                            onLoadAttachment = onLoadAttachment,
                            onDeleteAttachment = onDeleteAttachment,
                            onToggleMemoryFavorite = onToggleMemoryFavorite,
                            onDeleteMemory = onDeleteMemory,
                            onShareMemoryToChat = { memory -> onShareMemoryToChat(memory); selected = 3 },
                            onSetMood = onSetDailyMood,
                            onAddSpecialDate = onAddSpecialDate,
                            onUpdateSpecialDate = onUpdateSpecialDate,
                            onDeleteSpecialDate = onDeleteSpecialDate,
                            onStartPeriod = onStartPeriod,
                            onEndPeriod = onEndPeriod,
                            onDeleteCycleLog = onDeleteCycleLog,
                            onUpdateCycleSettings = onUpdateCycleSettings,
                            onSaveProfile = onSaveCoupleProfile,
                            onSetPalette = onSetPalette,
                            onSetThemeMode = onSetThemeMode,
                            onSetDynamicColor = onSetDynamicColor,
                            onReset = onReset
                        )
                        7 -> GamesScreen(
                            gameMessages = gameMessages,
                            ownDeviceId = identity.deviceId,
                            isPaired = pairingSnapshot.trustedPeer != null,
                            onSendGameMessage = onSendGameMessage,
                            onSync = onSync
                        )
                        8 -> AiChatScreen(
                            isHost = role == com.ourspace.app.model.DeviceRole.HOST,
                            isPaired = pairingSnapshot.trustedPeer != null,
                            busy = aiBusy,
                            lastError = aiLastError,
                            latestSuggestion = aiChatSuggestion,
                            modelStatusLabel = aiModelStatusLabel,
                            onSend = onRequestAiFreeChat,
                            onClearError = onClearAiChat,
                            onOpenSettings = { selected = 9 }
                        )
                        else -> SettingsScreen(
                            role = role,
                            aiModelState = aiModelState,
                            onSelectAiModel = onSelectAiModel,
                            onImportAiModel = onImportAiModel,
                            onDeleteAiModel = onDeleteAiModel,
                            onRefreshAiModel = onRefreshAiModel,
                            identity = identity,
                            pairingSnapshot = pairingSnapshot,
                            pairingAction = pairingAction,
                            syncState = syncState,
                            relayConfig = relayConfig,
                            relayAction = relayAction,
                            backupAction = backupAction,
                            onBackupNow = onBackupNow,
                            onRestoreBackup = onRestoreBackup,
                            pendingSyncChanges = pendingSyncChanges,
                            pendingSyncUnsent = pendingSyncUnsent,
                            pendingSyncAwaitingAck = pendingSyncAwaitingAck,
                            diagnostics = diagnostics,
                            syncHealth = syncHealth,
                            palette = palette,
                            themeMode = themeMode,
                            dynamicColor = dynamicColor,
                            widgetAccent = widgetAccent,
                            onSaveRelayConfig = onSaveRelayConfig,
                            onRunConnectionTest = onRunConnectionTest,
                            onClearDiagnostics = onClearDiagnostics,
                            onApprovePairing = onApprovePairing,
                            onRejectPairing = onRejectPairing,
                            onCheckPairing = onCheckPairing,
                            onCancelPairing = onCancelPairing,
                            onRevokeTrust = onRevokeTrust,
                            onSync = onSync,
                            onPairPayload = onPairPayload,
                            onScanCompanionReply = onScanCompanionReply,
                            onScanApproval = onScanApproval,
                            onPairWithPin = onPairWithPin,
                            onGenerateHostPin = onGenerateHostPin,
                            onSetPalette = onSetPalette,
                            onSetThemeMode = onSetThemeMode,
                            onSetDynamicColor = onSetDynamicColor,
                            onSetWidgetAccent = onSetWidgetAccent,
                            onReset = onReset,
                            telegramBotToken = telegramBotToken,
                            onSetTelegramBotToken = onSetTelegramBotToken,
                            stickerImportAction = stickerImportAction,
                            onImportTelegramPack = onImportTelegramPack,
                            telegramStickerPacks = telegramStickerPacks,
                            onDeleteTelegramPack = onDeleteTelegramPack
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeDashboard(
    role: DeviceRole,
    identity: DeviceIdentityManager.DeviceIdentity,
    pairingSnapshot: PairingStore.Snapshot,
    syncState: AppViewModel.SyncState,
    pendingSyncChanges: Int,
    pendingSyncUnsent: Int = 0,
    pendingSyncAwaitingAck: Int = 0,
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    shoppingItems: List<ShoppingItemEntity>,
    financeTransactions: List<FinanceTransactionEntity>,
    moodCheckIns: List<MoodCheckInEntity>,
    coupleProfile: CoupleProfileEntity?,
    specialDates: List<SpecialDateEntity>,
    messages: List<MessageEntity> = emptyList(),
    memories: List<MemoryEntity> = emptyList(),
    habits: List<HabitEntity> = emptyList(),
    sharedDebts: List<SharedDebtEntity> = emptyList(),
    watchlistItems: List<WatchlistItemEntity> = emptyList(),
    bookItems: List<BookItemEntity> = emptyList(),
    foodItems: List<com.ourspace.app.core.database.FoodItemEntity> = emptyList(),
    financialAccounts: List<FinancialAccountEntity> = emptyList(),
    onSync: () -> Unit,
    onOpenPlanner: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenChat: () -> Unit = {},
    onOpenFinance: () -> Unit,
    onOpenMap: () -> Unit = {},
    onOpenUs: () -> Unit,
    onOpenDeepLink: (AppDeepLink) -> Unit = {},
    onOpenGames: () -> Unit = {},
    onOpenSettings: () -> Unit,
    isPaired: Boolean = false,
    heartAction: AppViewModel.HeartActionState = AppViewModel.HeartActionState(),
    onSendHeartPulse: () -> Unit = {}
) {
    var clockNow by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            clockNow = System.currentTimeMillis()
        }
    }
    val openTasks = remember(tasks) { tasks.count { !it.isCompleted && !it.isDeleted } }
    val overdueTasks = remember(tasks, clockNow) {
        tasks.count { !it.isCompleted && !it.isDeleted && it.dueAt != null && it.dueAt < clockNow }
    }
    val openShopping = remember(shoppingItems) { shoppingItems.count { !it.isChecked && !it.isDeleted } }
    val visibleEvents = remember(events) {
        events.filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") }
    }
    val currentEvent = remember(visibleEvents, clockNow) {
        visibleEvents
            .filter { it.startAt <= clockNow && it.endAt != null && it.endAt > clockNow }
            .minByOrNull { it.endAt ?: Long.MAX_VALUE }
    }
    val nextEvent = remember(visibleEvents, clockNow) {
        visibleEvents.filter { it.startAt >= clockNow }.minByOrNull { it.startAt }
    }
    val featuredEvent = currentEvent ?: nextEvent
    val currentMonth = PersianDateFormatter.jalaliMonthKey(clockNow)
    val monthlyExpense = remember(financeTransactions, currentMonth) {
        financeTransactions
            .filter { it.kind == "EXPENSE" && !it.isDeleted && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == currentMonth }
            .sumOf { it.amount }
    }
    val todayKey = PersianDateFormatter.jalaliDayKey(clockNow)
    val partnerMood = remember(moodCheckIns, todayKey, identity.deviceId) {
        moodCheckIns
            .filter { it.dayKey == todayKey && it.deviceId != identity.deviceId && !it.isDeleted }
            .maxByOrNull { it.updatedAt }
    }
    val ownMood = remember(moodCheckIns, todayKey, identity.deviceId) {
        moodCheckIns
            .filter { it.dayKey == todayKey && it.deviceId == identity.deviceId && !it.isDeleted }
            .maxByOrNull { it.updatedAt }
    }
    val daysTogether = remember(coupleProfile?.relationshipStartedAt, todayKey) {
        coupleProfile?.relationshipStartedAt?.let { start -> PersianDateFormatter.daysTogether(start) }
    }
    val upcomingSpecial = remember(specialDates, todayKey) {
        specialDates
            .filter { !it.isDeleted }
            .mapNotNull { sd ->
                val days = daysUntilNextOccurrence(sd.occurredAt, sd.repeatYearly)
                if (days in 0..14) sd to days else null
            }
            .minByOrNull { it.second }
    }
    val seasonal = remember(specialDates, todayKey) { SeasonalAccent.current(specialDates) }

    val partnerName = coupleProfile?.let {
                    if (role == DeviceRole.HOST) it.secondPersonName.ifBlank { "همراه" }
                    else it.firstPersonName.ifBlank { "همراه" }
                }
    val greetingSubtitle = PersianDateFormatter.todayLabel()

    var searchQuery by remember { mutableStateOf("") }
    var searchHits by remember { mutableStateOf<List<GlobalSearchHit>>(emptyList()) }
    LaunchedEffect(
        searchQuery, tasks, events, shoppingItems, messages, financeTransactions,
        memories, specialDates, habits, sharedDebts, watchlistItems, bookItems, financialAccounts
    ) {
        if (searchQuery.length < 2) {
            searchHits = emptyList()
            return@LaunchedEffect
        }
        // Debounce keystrokes and scan large histories off the UI thread to keep typing responsive.
        delay(120L)
        val query = searchQuery
        val hits = withContext(Dispatchers.Default) {
            buildGlobalSearchHits(
                query = query,
                tasks = tasks,
                events = events,
                shoppingItems = shoppingItems,
                messages = messages,
                financeTransactions = financeTransactions,
                memories = memories,
                specialDates = specialDates,
                habits = habits,
                sharedDebts = sharedDebts,
                watchlistItems = watchlistItems,
                bookItems = bookItems,
                financialAccounts = financialAccounts
            )
        }
        searchHits = hits
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            OSLargeTitle(
                title = "خانه",
                subtitle = greetingSubtitle,
                trailing = {
                    if (isPaired) {
                        OSIconButton(
                            icon = Icons.Filled.Favorite,
                            contentDescription = "به یادتم",
                            onClick = onSendHeartPulse,
                            tint = MaterialTheme.colorScheme.error,
                            size = 48.dp,
                            iconSize = 28.dp
                        )
                    }
                }
            )
        }

        item {
            GlobalSearchField(
                query = searchQuery,
                onQueryChange = { searchQuery = it.take(80) },
                onClear = { searchQuery = "" },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = OSSpacing.screenHorizontal, vertical = 6.dp)
            )
        }

        if (searchQuery.trim().length >= 2) {
            item {
                Text(
                    if (searchHits.isEmpty()) "نتیجه‌ای پیدا نشد"
                    else "${PersianDateFormatter.toPersianDigits(searchHits.size)} نتیجه",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = OSSpacing.screenHorizontal, vertical = 4.dp)
                )
            }
            items(searchHits, key = { "gsearch-${it.section}-${it.id}-${it.category}" }) { hit ->
                GlobalSearchResultRow(
                    hit = hit,
                    onClick = {
                        onOpenDeepLink(
                            AppDeepLink(
                                section = hit.section,
                                itemId = hit.id,
                                category = hit.category,
                                dayKey = hit.dayKey,
                                financeTab = hit.financeTab,
                                usTab = hit.usTab
                            )
                        )
                        searchQuery = ""
                    },
                    modifier = Modifier.padding(horizontal = OSSpacing.screenHorizontal, vertical = 3.dp)
                )
            }
            item { Spacer(Modifier.height(OSSpacing.xxl)) }
        } else {
        item {
            WelcomeHero(
                openTasks = openTasks,
                nextEvent = featuredEvent,
                daysTogether = daysTogether,
                partnerName = partnerName,
                partnerMoodCode = partnerMood?.mood,
                ownMoodCode = ownMood?.mood
            )
        }

        item {
            // Daily glance — one-screen snapshot of the shared day
            GlowCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = OSSpacing.screenHorizontal, vertical = 8.dp),
                cornerRadius = 22.dp
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "نگاه روزانه",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(Modifier.height(10.dp))
                    val moodLine = buildString {
                        append("حال شما: ")
                        append(ownMood?.mood?.let { moodLabelFa(it) } ?: "ثبت نشده")
                        append("  ·  حال ")
                        append(partnerName ?: "همراه")
                        append(": ")
                        append(partnerMood?.mood?.let { moodLabelFa(it) } ?: if (!isPaired) "هنوز متصل نیست" else "ثبت نشده یا هنوز همگام نشده")
                    }
                    Text(moodLine, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        featuredEvent?.let {
                            val kind = when {
                                currentEvent != null -> "در حال برگزاری"
                                it.title.contains("شیفت", ignoreCase = true) || it.title.contains("کار اداری", ignoreCase = true) -> "شیفت کاری بعدی"
                                else -> "قرار بعدی"
                            }
                            "$kind: ${it.title} — ${PersianDateFormatter.formatDateTime(if (currentEvent != null) currentEvent.startAt else it.startAt)}"
                        } ?: "قرار آینده‌ای ثبت نشده است",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "کارهای باز: ${PersianDateFormatter.toPersianDigits(openTasks)}  ·  عقب‌افتاده: ${PersianDateFormatter.toPersianDigits(overdueTasks)}  ·  خرید: ${PersianDateFormatter.toPersianDigits(openShopping)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "همگام‌سازی: " + when {
                            syncState.error != null -> "ناموفق — ${syncState.error}"
                            syncState.isSyncing -> "در حال انجام"
                            syncState.lastSyncAt != null -> "آخرین همگام‌سازی ${PersianDateFormatter.relativeTime(syncState.lastSyncAt, clockNow)}"
                            !isPaired -> "گوشی‌ها متصل نیستند"
                            pendingSyncChanges > 0 -> "${PersianDateFormatter.toPersianDigits(pendingSyncChanges)} تغییر در انتظار ارسال"
                            else -> "هنوز تأیید تازه‌ای ثبت نشده"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (syncState.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "هزینه این ماه: ${PersianDateFormatter.formatMoney(monthlyExpense)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    upcomingSpecial?.let { (sd, days) ->
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "یادآوری: ${sd.title} — ${if (days == 0) "امروز" else "${PersianDateFormatter.toPersianDigits(days)} روز دیگر"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                }
            }
        }

        seasonal?.let { accent ->
            item {
                Card(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = OSSpacing.screenHorizontal, vertical = 6.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = accent.orbA.copy(alpha = 0.28f))
                ) {
                    Text(
                        "✨ ${accent.label}",
                        modifier = Modifier.padding(14.dp),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }
        }

        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = OSSpacing.screenHorizontal),
                horizontalArrangement = Arrangement.spacedBy(OSSpacing.sm)
            ) {
                OSMetricTile(
                    label = "کار باز",
                    value = PersianDateFormatter.toPersianDigits(openTasks),
                    modifier = Modifier.weight(1f),
                    onClick = onOpenPlanner
                )
                OSMetricTile(
                    label = "خرید",
                    value = PersianDateFormatter.toPersianDigits(openShopping),
                    modifier = Modifier.weight(1f),
                    onClick = onOpenPlanner
                )
                OSMetricTile(
                    label = "هزینه ماه",
                    value = formatCompactMoneyExact(monthlyExpense),
                    modifier = Modifier.weight(1f),
                    onClick = onOpenFinance
                )
            }
        }

        item { OSSectionSpacer() }

        item {
            OSGroupedSection(title = "امروز") {
                OSGroupRow(
                    title = featuredEvent?.let { if (currentEvent != null) "در حال برگزاری: ${it.title}" else it.title } ?: "بدون قرار آینده",
                    subtitle = featuredEvent?.let { PersianDateFormatter.formatDateTime(if (currentEvent != null) currentEvent.startAt else it.startAt) }
                        ?: "از تقویم یک قرار اضافه کنید",
                    leading = Icons.Outlined.DateRange,
                    showDivider = true,
                    onClick = onOpenCalendar
                )
                if (overdueTasks > 0) {
                    OSGroupRow(
                        title = "${PersianDateFormatter.toPersianDigits(overdueTasks)} کار عقب‌افتاده",
                        subtitle = "برای بررسی کارهای عقب‌افتاده لمس کنید",
                        leading = Icons.Outlined.Notifications,
                        leadingTint = MaterialTheme.colorScheme.error,
                        showDivider = true,
                        onClick = onOpenPlanner
                    )
                }
                OSGroupRow(
                    title = "حال من",
                    subtitle = ownMood?.mood?.let { moodLabel(it) } ?: "هنوز ثبت نشده",
                    leading = Icons.Outlined.FavoriteBorder,
                    showDivider = true,
                    onClick = onOpenUs
                )
                OSGroupRow(
                    title = if (!partnerName.isNullOrBlank()) "حال $partnerName" else "حال همراه",
                    subtitle = partnerMood?.mood?.let { moodLabel(it) } ?: "هنوز به‌روز نشده",
                    leading = Icons.Filled.Favorite,
                    leadingTint = MaterialTheme.colorScheme.error,
                    showDivider = upcomingSpecial != null,
                    onClick = onOpenUs
                )
                if (upcomingSpecial != null) {
                    val days = upcomingSpecial.second
                    OSGroupRow(
                        title = upcomingSpecial.first.title,
                        subtitle = when {
                            days <= 0 -> "امروز"
                            days == 1 -> "فردا"
                            else -> "${PersianDateFormatter.toPersianDigits(days)} روز دیگر"
                        },
                        leading = Icons.Outlined.Star,
                        showDivider = false,
                        onClick = onOpenUs
                    )
                }
            }
        }

        if (pendingSyncChanges > 0 || syncState.isSyncing || syncState.error != null || heartAction.message != null || heartAction.error != null) {
            item { OSSectionSpacer() }
            item {
                OSGroupedSection(title = "وضعیت") {
                    if (heartAction.message != null || heartAction.error != null) {
                        OSGroupRow(
                            title = heartAction.message ?: heartAction.error ?: "",
                            leading = Icons.Filled.Favorite,
                            leadingTint = MaterialTheme.colorScheme.error,
                            showDivider = pendingSyncChanges > 0 || syncState.isSyncing || syncState.error != null,
                            onClick = onSendHeartPulse
                        )
                    }
                    if (pendingSyncChanges > 0 || syncState.isSyncing || syncState.error != null) {
                        OSGroupRow(
                            title = when {
                                syncState.error != null -> "همگام‌سازی ناموفق"
                                syncState.isSyncing -> "در حال همگام‌سازی…"
                                else -> "${syncQueueLabel(pendingSyncChanges, pendingSyncUnsent, pendingSyncAwaitingAck)}"
                            },
                            subtitle = syncState.error ?: syncState.message,
                            leading = Icons.Outlined.Notifications,
                            showDivider = false,
                            onClick = onSync
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(OSSpacing.xxxl)) }
        } // else: not searching
    }
}


private data class GlobalSearchHit(
    val id: String,
    val section: Int,
    val category: String,
    val title: String,
    val subtitle: String,
    val emoji: String,
    val dayKey: String? = null,
    val usTab: Int? = null,
    val financeTab: Int? = null
)

private fun normalizeSearch(text: String): String {
    if (text.isBlank()) return ""
    val persianDigits = charArrayOf('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹')
    val arabicDigits = charArrayOf('٠','١','٢','٣','٤','٥','٦','٧','٨','٩')
    return buildString(text.length) {
        for (ch in text.trim().lowercase()) {
            when (ch) {
                in persianDigits -> append(persianDigits.indexOf(ch))
                in arabicDigits -> append(arabicDigits.indexOf(ch))
                else -> append(ch)
            }
        }
    }
}

private fun buildGlobalSearchHits(
    query: String,
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    shoppingItems: List<ShoppingItemEntity>,
    messages: List<MessageEntity>,
    financeTransactions: List<FinanceTransactionEntity>,
    memories: List<MemoryEntity>,
    specialDates: List<SpecialDateEntity>,
    habits: List<HabitEntity>,
    sharedDebts: List<SharedDebtEntity>,
    watchlistItems: List<WatchlistItemEntity>,
    bookItems: List<BookItemEntity>,
    financialAccounts: List<FinancialAccountEntity>
): List<GlobalSearchHit> {
    val q = normalizeSearch(query)
    if (q.length < 2) return emptyList()
    fun match(vararg parts: String?): Boolean =
        parts.any { p -> !p.isNullOrBlank() && normalizeSearch(p).contains(q) }

    val hits = ArrayList<GlobalSearchHit>(32)

    tasks.asSequence().filter { !it.isDeleted && match(it.title, it.note) }.take(8).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 1, category = "task",
            title = it.title,
            subtitle = if (it.isCompleted) "انجام‌شده · برنامه‌ها" else "باز · برنامه‌ها",
            emoji = "✅"
        )
    }
    shoppingItems.asSequence().filter { !it.isDeleted && match(it.title, it.category) }.take(6).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 4, category = "خرید",
            title = it.title,
            subtitle = if (it.isChecked) "خریداری‌شده · مالی" else "لیست خرید · مالی",
            emoji = "🛒"
        )
    }
    habits.asSequence().filter { !it.isDeleted && match(it.title, it.note, it.scheduleNote) }.take(6).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 1, category = "habit",
            title = it.title,
            subtitle = "عادت · برنامه‌ها",
            emoji = "🔁"
        )
    }
    events.asSequence().filter {
        !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && match(it.title, it.details)
    }.take(8).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 2, category = "قرار",
            title = it.title,
            subtitle = "تقویم · ${PersianDateFormatter.formatDate(it.startAt)}",
            emoji = "📅"
        )
    }
    messages.asSequence().filter {
        !it.isDeleted &&
            !GameMessageProtocol.isProtocolMessage(it.text) &&
            match(it.text)
    }.take(8).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 3, category = "message",
            title = it.text.take(80),
            subtitle = "گفتگو · ${PersianDateFormatter.formatDate(it.createdAt)}",
            emoji = "💬"
        )
    }
    financialAccounts.asSequence().filter { !it.isDeleted && !it.isArchived && match(it.name) }.take(4).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 4, category = "حساب",
            title = it.name,
            subtitle = "مالی · حساب",
            emoji = "🏦"
        )
    }
    financeTransactions.asSequence().filter { !it.isDeleted && match(it.category, it.note) }.take(6).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 4, category = "تراکنش",
            title = it.category.ifBlank { "تراکنش" },
            subtitle = "مالی · ${PersianDateFormatter.formatDate(it.occurredAt)}",
            emoji = "💳"
        )
    }
    sharedDebts.asSequence().filter { !it.isDeleted && match(it.title, it.note) }.take(4).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 4, category = "بدهی",
            title = it.title,
            subtitle = "مالی · بدهی",
            emoji = "🤝"
        )
    }
    memories.asSequence().filter { !it.isDeleted && match(it.title, it.note) }.take(6).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 6, category = "memory", usTab = 0,
            title = it.title.ifBlank { "خاطره" },
            subtitle = "ما · ${PersianDateFormatter.formatDate(it.occurredAt)}",
            emoji = "📷"
        )
    }
    specialDates.asSequence().filter { !it.isDeleted && match(it.title, it.note) }.take(4).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 6, category = "مناسبت",
            title = it.title,
            subtitle = "ما · مناسبت",
            emoji = "🎉"
        )
    }
    watchlistItems.asSequence().filter { !it.isDeleted && match(it.title, it.note) }.take(6).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 6, category = "watchlist", usTab = 1,
            title = it.title,
            subtitle = "ما · باهم ببینیم",
            emoji = if (it.mediaType == "SERIES") "📺" else "🎬"
        )
    }
    bookItems.asSequence().filter { !it.isDeleted && match(it.title, it.author, it.note) }.take(6).forEach {
        hits += GlobalSearchHit(
            id = it.id, section = 6, category = "book", usTab = 2,
            title = it.title,
            subtitle = if (it.author.isNotBlank()) "ما · ${it.author}" else "ما · کتاب",
            emoji = "📚"
        )
    }
    return hits.take(40)
}

@Composable
private fun GlobalSearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier,
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        placeholder = { Text("جستجوی سراسری: کار، پیام، خاطره، فیلم…") },
        leadingIcon = {
            Icon(Icons.Outlined.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        trailingIcon = {
            if (query.isNotBlank()) {
                IconButton(onClick = onClear) {
                    Icon(Icons.Outlined.Close, contentDescription = "پاک کردن")
                }
            }
        }
    )
}

@Composable
private fun GlobalSearchResultRow(
    hit: GlobalSearchHit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(hit.emoji, style = MaterialTheme.typography.titleLarge)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    hit.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${hit.category} · ${hit.subtitle}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                "برو ›",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}


private fun isLowEnergyMood(code: String?): Boolean {
    if (code.isNullOrBlank()) return false
    return code.uppercase() in setOf(
        "SAD", "STRESSED", "ANGRY", "ANXIOUS", "TIRED", "SICK", "LONELY", "DOWN"
    )
}

private fun careSuggestions(code: String?, forPartner: Boolean, partnerName: String?): List<String> {
    val name = partnerName?.takeIf { it.isNotBlank() } ?: "همراهت"
    val c = code?.uppercase().orEmpty()
    return when {
        c in setOf("SAD", "DOWN", "LONELY") -> if (forPartner) listOf(
            "یک پیام کوتاه و گرم برای $name بفرست",
            "بپرس امروز چه چیزی اذیتش کرده، بدون عجله",
            "اگر می‌توانی یک کار کوچک از روی دوشش بردار"
        ) else listOf(
            "به خودت استراحت کوتاه بده",
            "احساست را با یک جمله صادقانه بنویس",
            "اگر لازم است از همراهت کمک بخواه"
        )
        c in setOf("STRESSED", "ANXIOUS") -> if (forPartner) listOf(
            "فشار نیاور؛ فقط بگو کنارت هستی",
            "پیشنهاد یک پیاده‌روی یا استراحت کوتاه",
            "کمک برای تقسیم کارها"
        ) else listOf(
            "لیست کارها را کوچک‌تر کن",
            "۵ دقیقه نفس عمیق",
            "یک کار غیرضروری را عقب بینداز"
        )
        c in setOf("TIRED", "SICK") -> if (forPartner) listOf(
            "پیشنهاد استراحت و مراقبت",
            "کارهای خانه را سبک کن",
            "پیام حمایت بدون انتظار جواب سریع"
        ) else listOf(
            "امروز سبک برنامه‌ریزی کن",
            "آب و استراحت را جدی بگیر",
            "از همراهت بخواه کمکت کند"
        )
        else -> if (forPartner) listOf(
            "یک پیام محبت‌آمیز بفرست",
            "برای یک قرار کوچک برنامه‌ریزی کن"
        ) else listOf(
            "یک کار کوچک لذت‌بخش برای خودت",
            "با همراهت چک‌این کوتاه داشته باش"
        )
    }
}

@Composable
private fun WelcomeHero(
    openTasks: Int,
    nextEvent: EventEntity?,
    daysTogether: Int?,
    partnerName: String?,
    partnerMoodCode: String?,
    ownMoodCode: String?
) {
    val partnerLabel = partnerMoodCode?.let { moodLabel(it) }
    val ownLabel = ownMoodCode?.let { moodLabel(it) }
    val partnerNeedsCare = isLowEnergyMood(partnerMoodCode)
    val selfNeedsCare = isLowEnergyMood(ownMoodCode)
    val tidyLine = if (openTasks == 0) {
        "امروز همه‌چیز مرتب است ✨"
    } else {
        "${PersianDateFormatter.toPersianDigits(openTasks)} کار منتظر شماست"
    }
    val careTitle = when {
        partnerNeedsCare && !partnerName.isNullOrBlank() ->
            "$partnerName امروز ${partnerLabel ?: "دلگیر"} به نظر می‌رسد"
        partnerNeedsCare ->
            "همراهت امروز نیاز به توجه بیشتری دارد"
        selfNeedsCare ->
            "امروز به خودت هم کمی مهربانی قرض بده"
        else -> null
    }
    val suggestions = when {
        partnerNeedsCare -> careSuggestions(partnerMoodCode, forPartner = true, partnerName = partnerName)
        selfNeedsCare -> careSuggestions(ownMoodCode, forPartner = false, partnerName = null)
        else -> emptyList()
    }

    GradientHero {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "امروز، ${PersianDateFormatter.todayLabel()}",
                color = Color.White.copy(alpha = 0.90f),
                style = MaterialTheme.typography.labelLarge
            )
            FloatingMotion {
                Text(
                    when {
                        partnerNeedsCare || selfNeedsCare -> "🤍"
                        else -> "✨"
                    },
                    style = MaterialTheme.typography.titleLarge
                )
            }
        }
        if (daysTogether != null && daysTogether >= 0) {
            Text(
                "${PersianDateFormatter.toPersianDigits(daysTogether)} روز با هم",
                color = Color.White,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 10.dp)
            )
            Text(
                tidyLine,
                color = Color.White.copy(alpha = 0.94f),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        } else {
            Text(
                tidyLine,
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Mood / next event line
        val moodLine = when {
            partnerLabel != null && !partnerName.isNullOrBlank() && ownLabel != null ->
                "حال $partnerName: $partnerLabel  ·  حال شما: $ownLabel"
            partnerLabel != null && !partnerName.isNullOrBlank() ->
                "حال امروز $partnerName: $partnerLabel"
            ownLabel != null ->
                "حال امروز شما: $ownLabel"
            nextEvent != null ->
                "قرار بعدی: ${nextEvent.title}"
            else ->
                "برای باهم‌بودن یک برنامه کوچک بسازید."
        }
        Text(
            moodLine,
            color = Color.White.copy(alpha = 0.92f),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 14.dp)
        )

        // Care suggestions when someone is low
        if (careTitle != null) {
            Text(
                careTitle,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
        if (suggestions.isNotEmpty()) {
            Column(
                Modifier
                    .padding(top = 8.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    "پیشنهادهای کوچک:",
                    color = Color.White.copy(alpha = 0.88f),
                    style = MaterialTheme.typography.labelLarge
                )
                suggestions.take(4).forEach { tip ->
                    Text(
                        "• $tip",
                        color = Color.White.copy(alpha = 0.90f),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else if (openTasks == 0 && !partnerNeedsCare && !selfNeedsCare) {
            Text(
                "یک پیام کوتاه یا یک قرار کوچک می‌تواند امروز را گرم‌تر کند.",
                color = Color.White.copy(alpha = 0.86f),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

@Composable
private fun SyncStatusCard(
    pending: Int,
    isSyncing: Boolean,
    isRelayPending: Boolean,
    transport: SyncClient.Transport?,
    message: String?,
    error: String?,
    onSync: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (error != null) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.primaryContainer.copy(alpha = .75f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                when {
                    isSyncing -> "در حال همگام‌سازی…"
                    pending > 0 -> "${PersianDateFormatter.toPersianDigits(pending)} تغییر در صف"
                    else -> "وضعیت همگام‌سازی"
                },
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
            val detail = error ?: message ?: when (transport) {
                SyncClient.Transport.RELAY -> "آخرین مسیر: سرور شخصی (لینوکس)"
                null -> "با زدن دکمه، تغییرات همگام می‌شوند."
            }
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
            Button(
                onClick = onSync,
                enabled = !isSyncing,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) {
                Text(if (isSyncing) "لطفاً صبر کنید…" else "همگام‌سازی اکنون")
            }
        }
    }
}

@Composable
private fun MoodSnapshotCard(
    title: String,
    mood: String?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .6f)
        )
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
            Text(
                mood?.let { moodLabel(it) } ?: "هنوز ثبت نشده",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun UpcomingSpecialCard(title: String, daysUntil: Int, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = .12f)
        )
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("مناسبت نزدیک", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                Text(
                    when (daysUntil) {
                        0 -> "امروز"
                        1 -> "فردا"
                        else -> "${PersianDateFormatter.toPersianDigits(daysUntil)} روز دیگر"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text("مشاهده ›", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
    }
}

private fun moodLabel(mood: String): String = when (mood.uppercase()) {
    "LOVE", "LOVED", "HAPPY" -> "خوشحال و عاشقانه 💛"
    "CALM", "OK" -> "آرام 🙂"
    "EXCITED" -> "هیجان‌زده 🤩"
    "GRATEFUL" -> "قدردان 🙏"
    "TIRED" -> "خسته 😴"
    "SAD" -> "دلگیر 💙"
    "STRESSED" -> "پراسترس 😣"
    "ANGRY" -> "عصبانی 😠"
    "ANXIOUS" -> "نگران 😟"
    "SICK" -> "ناخوش 🤒"
    else -> mood
}

/** Days until next occurrence. Shared Jalali-aware date logic also powers reminders. */
private fun daysUntilNextOccurrence(occurredAt: Long, repeatYearly: Boolean): Int =
    PersianDateFormatter.nextSpecialDateOccurrence(occurredAt, repeatYearly)?.daysUntil ?: Int.MAX_VALUE

private fun formatCompactMoneyExact(amount: Long): String {
    val grouped = java.text.NumberFormat.getIntegerInstance(java.util.Locale.US).format(amount.coerceAtLeast(0))
    return PersianDateFormatter.toPersianDigits(grouped)
}

@Composable
private fun ServiceStatusCard(role: DeviceRole) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .55f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = .12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Build, null, tint = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(
                    if (role == DeviceRole.HOST) "میزبان روی این گوشی فعال است"
                    else "هویت میزبان ذخیره شده",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (role == DeviceRole.HOST) "دیتابیس رمزگذاری‌شده • پورت ۸۷۶۵"
                    else "اتصال دوطرفه امن آماده است",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            Box(
                Modifier
                    .size(12.dp)
                    .background(Color(0xFF2E7D32), CircleShape)
                    .border(2.dp, Color(0xFF2E7D32).copy(alpha = .25f), CircleShape)
            )
        }
    }
}

@Composable
private fun FinanceInsightCard(monthlyExpense: Long, onClick: () -> Unit) {
    MotionCard(onClick = onClick, modifier = Modifier.fillMaxWidth(), cornerRadius = 24) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .85f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(52.dp)
                        .background(
                            Brush.linearGradient(
                                if (MaterialTheme.colorScheme.background.luminance() < 0.5f) {
                                    listOf(
                                        MaterialTheme.colorScheme.primaryContainer,
                                        MaterialTheme.colorScheme.tertiaryContainer
                                    )
                                } else {
                                    listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            ),
                            RoundedCornerShape(18.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("◎", color = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) MaterialTheme.colorScheme.onPrimaryContainer else Color.White, style = MaterialTheme.typography.headlineSmall)
                }
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(
                        "هزینه این ماه",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        PersianDateFormatter.formatMoney(monthlyExpense),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    "مدیریت ›",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    MotionCard(onClick = onClick, modifier = modifier, cornerRadius = 22) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Box(
                    Modifier
                        .size(40.dp)
                        .background(
                            MaterialTheme.colorScheme.primary.copy(alpha = .12f),
                            RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text(
                    title,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun ThinkingOfYouCard(
    isPaired: Boolean,
    isSending: Boolean,
    message: String?,
    error: String?,
    onSend: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = .55f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("به یادتم 💗", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                Text(
                    when {
                        !isPaired -> "بعد از جفت‌سازی، یک تپش قلب برای طرف مقابل بفرستید."
                        error != null -> error
                        message != null -> message
                        else -> "با لمس قلب، برای طرف مقابل نوتیف و ویبرهٔ تپش قلب می‌رود."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            IconButton(
                onClick = onSend,
                enabled = isPaired && !isSending,
                modifier = Modifier.size(84.dp)
            ) {
                Icon(
                    Icons.Filled.Favorite,
                    contentDescription = "ارسال تپش قلب",
                    tint = if (isPaired) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(56.dp)
                )
            }
        }
    }
}


private fun moodLabelFa(value: String): String = when (value.uppercase()) {
    "LOVE" -> "عاشقانه"
    "HAPPY" -> "خوشحال"
    "CALM" -> "آرام"
    "SAD" -> "غمگین"
    "ANXIOUS" -> "نگران"
    else -> value
}

// One-pass maximum avoids allocating intermediate List<Long> objects on database updates.
private inline fun <T> maxUpdatedTimestamp(
    items: List<T>,
    crossinline include: (T) -> Boolean = { true },
    crossinline timestamp: (T) -> Long
): Long {
    var found = false
    var latest = 0L
    for (item in items) {
        if (!include(item)) continue
        val value = timestamp(item)
        if (!found || value > latest) {
            latest = value
            found = true
        }
    }
    return if (found) latest else 0L
}

/** آخرین زمان به‌روزرسانی رکوردهای هر تب را با آخرین بازدید مقایسه می‌کند. */
private fun computeSectionAttentionDots(
    seen: Map<Int, Long>,
    tasks: List<com.ourspace.app.core.database.TaskEntity>,
    events: List<com.ourspace.app.core.database.EventEntity>,
    shoppingItems: List<com.ourspace.app.core.database.ShoppingItemEntity>,
    messages: List<com.ourspace.app.core.database.MessageEntity>,
    unreadMessages: Int,
    financialAccounts: List<com.ourspace.app.core.database.FinancialAccountEntity>,
    financeTransactions: List<com.ourspace.app.core.database.FinanceTransactionEntity>,
    financeBudgets: List<com.ourspace.app.core.database.FinanceBudgetEntity>,
    sharedDebts: List<com.ourspace.app.core.database.SharedDebtEntity>,
    recurringTransactions: List<com.ourspace.app.core.database.RecurringTransactionEntity>,
    memories: List<com.ourspace.app.core.database.MemoryEntity>,
    moodCheckIns: List<com.ourspace.app.core.database.MoodCheckInEntity>,
    specialDates: List<com.ourspace.app.core.database.SpecialDateEntity>,
    cycleLogs: List<com.ourspace.app.core.database.CycleLogEntity>,
    cycleSettings: CycleSettingsEntity?,
    locationShares: List<LocationShareEntity>,
    sharedPlaces: List<SharedPlaceEntity>,
    coupleProfile: CoupleProfileEntity?,
    habits: List<com.ourspace.app.core.database.HabitEntity>,
    watchlistItems: List<com.ourspace.app.core.database.WatchlistItemEntity>,
    bookItems: List<com.ourspace.app.core.database.BookItemEntity> = emptyList(),
    attachments: List<AttachmentEntity>
): Map<Int, Boolean> {
    fun newer(seenAt: Long, vararg stamps: Long): Boolean =
        stamps.any { it > seenAt }

    val plannerSeen = seen[SectionAttentionStore.PLANNER] ?: 0L
    val calendarSeen = seen[SectionAttentionStore.CALENDAR] ?: 0L
    val chatSeen = seen[SectionAttentionStore.CHAT] ?: 0L
    val financeSeen = seen[SectionAttentionStore.FINANCE] ?: 0L
    val mapSeen = seen[SectionAttentionStore.MAP] ?: 0L
    val usSeen = seen[SectionAttentionStore.US] ?: 0L
    val homeSeen = seen[SectionAttentionStore.HOME] ?: 0L

    val plannerStamp = maxOf(
        maxUpdatedTimestamp(tasks) { it.updatedAt },
        maxUpdatedTimestamp(events) { it.updatedAt },
        maxUpdatedTimestamp(shoppingItems) { it.updatedAt },
        maxUpdatedTimestamp(habits) { it.updatedAt }
    )
    val calendarStamp = maxOf(
        maxUpdatedTimestamp(events) { it.updatedAt },
        maxUpdatedTimestamp(specialDates) { it.updatedAt },
        maxUpdatedTimestamp(cycleLogs) { it.updatedAt },
        cycleSettings?.updatedAt ?: 0L,
        maxUpdatedTimestamp(tasks, include = { it.dueAt?.let { due -> due > 0L } == true }) { it.updatedAt },
        maxUpdatedTimestamp(financeTransactions) { it.updatedAt },
        maxUpdatedTimestamp(moodCheckIns) { it.updatedAt }
    )
    val chatStamp = maxOf(
        maxUpdatedTimestamp(messages, include = { !GameMessageProtocol.isProtocolMessage(it.text) }) { it.updatedAt },
        maxUpdatedTimestamp(attachments) { it.updatedAt }
    )
    val financeStamp = maxOf(
        maxUpdatedTimestamp(financialAccounts) { it.updatedAt },
        maxUpdatedTimestamp(financeTransactions) { it.updatedAt },
        maxUpdatedTimestamp(financeBudgets) { it.updatedAt },
        maxUpdatedTimestamp(sharedDebts) { it.updatedAt },
        maxUpdatedTimestamp(recurringTransactions) { it.updatedAt }
    )
    val mapStamp = maxOf(
        maxUpdatedTimestamp(locationShares) { it.updatedAt },
        maxUpdatedTimestamp(sharedPlaces) { it.updatedAt }
    )
    val usStamp = maxOf(
        maxUpdatedTimestamp(memories) { it.updatedAt },
        maxUpdatedTimestamp(moodCheckIns) { it.updatedAt },
        maxUpdatedTimestamp(specialDates) { it.updatedAt },
        maxUpdatedTimestamp(watchlistItems) { it.updatedAt },
        maxUpdatedTimestamp(bookItems) { it.updatedAt },
        coupleProfile?.updatedAt ?: 0L,
        maxUpdatedTimestamp(habits) { it.updatedAt }
    )
    val homeStamp = maxOf(plannerStamp, calendarStamp, chatStamp, financeStamp, mapStamp, usStamp)

    return mapOf(
        SectionAttentionStore.HOME to newer(homeSeen, homeStamp),
        SectionAttentionStore.PLANNER to newer(plannerSeen, plannerStamp),
        SectionAttentionStore.CALENDAR to newer(calendarSeen, calendarStamp),
        SectionAttentionStore.CHAT to (unreadMessages > 0 || newer(chatSeen, chatStamp)),
        SectionAttentionStore.FINANCE to newer(financeSeen, financeStamp),
        SectionAttentionStore.MAP to newer(mapSeen, mapStamp),
        SectionAttentionStore.US to newer(usSeen, usStamp),
        SectionAttentionStore.GAMES to false,
        SectionAttentionStore.SETTINGS to false
    )
}
