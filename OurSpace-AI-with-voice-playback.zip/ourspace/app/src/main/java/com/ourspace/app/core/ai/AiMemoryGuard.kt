package com.ourspace.app.core.ai

import android.app.ActivityManager
import android.content.Context
import android.util.Log
import java.io.File

/**
 * Pre-flight memory/size checks before handing a multi-GB GGUF to native llama.
 *
 * The native layer has its own /proc/meminfo guard, but deciding here lets the UI
 * show a clear Persian reason and prevents doomed loads that Realme/ColorOS-style
 * aggressive low-memory killers would otherwise end by killing the whole process.
 */
object AiMemoryGuard {
    private const val TAG = "AiMemoryGuard"
    private const val MB = 1024L * 1024L
    private const val GB = 1024L * MB

    /** Keep in sync with HARD_MODEL_CAP_BYTES in ourspace_llm.cpp. */
    private const val HARD_MODEL_CAP_BYTES = 5L * GB

    /** Headroom for KV cache, compute buffers and the rest of the app. */
    private const val MMAP_HEADROOM = 2L * GB

    /** Below this available RAM, even a small model is risky. */
    private const val MIN_AVAILABLE_BYTES = 1_200L * MB

    /** 7B-class files start around 4 GB; they need a high-RAM device. */
    private const val LARGE_MODEL_BYTES = 4_000L * MB
    private const val LARGE_MODEL_REQUIRED_TOTAL_RAM = 10L * GB

    data class Check(val allowed: Boolean, val reason: String? = null)

    fun evaluate(context: Context, file: File): Check {
        if (!file.exists()) {
            return Check(false, "فایل مدل پیدا نشد.")
        }
        val size = file.length()
        if (size <= 0L) {
            return Check(false, "فایل مدل خالی یا ناخوانا است.")
        }
        if (size > HARD_MODEL_CAP_BYTES) {
            return Check(
                false,
                "این مدل برای اجرای روی گوشی بسیار بزرگ است (بیش از ۵ گیگابایت). مدل سبک‌تر ۳B را انتخاب کنید."
            )
        }

        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        if (am == null) {
            Log.w(TAG, "ActivityManager unavailable; allowing load without memory heuristic")
            return Check(true)
        }
        val info = ActivityManager.MemoryInfo().also(am::getMemoryInfo)

        if (info.lowMemory || info.availMem < MIN_AVAILABLE_BYTES) {
            return Check(
                false,
                "حافظهٔ آزاد گوشی کم است. چند برنامهٔ باز را ببندید و دوباره تلاش کنید."
            )
        }
        if (size > info.availMem + MMAP_HEADROOM) {
            return Check(
                false,
                "این مدل با حافظهٔ آزاد فعلی سازگار نیست و باعث بسته‌شدن برنامه می‌شود. مدل سبک‌تر ۳B را امتحان کنید."
            )
        }
        if (size >= LARGE_MODEL_BYTES && info.totalMem < LARGE_MODEL_REQUIRED_TOTAL_RAM) {
            return Check(
                false,
                "مدل ۷B روی گوشی‌های با رم کمتر از ۱۰–۱۲ گیگ باعث بسته‌شدن برنامه می‌شود؛ مدل ۳B را انتخاب کنید."
            )
        }
        return Check(true)
    }
}
