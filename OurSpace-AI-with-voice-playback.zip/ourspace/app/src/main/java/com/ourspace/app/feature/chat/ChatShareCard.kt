package com.ourspace.app.feature.chat

import org.json.JSONObject

/**
 * Structured share cards embedded in chat messages.
 * Wire format: `OS_CARD|v1|<TYPE>|<json-payload>`
 * Unknown clients still see a readable Persian fallback line in [displayFallback].
 */
object ChatShareCard {
    const val PREFIX = "OS_CARD|v1|"

    enum class Type(val wire: String, val emoji: String, val label: String) {
        TASK("TASK", "✅", "کار"),
        EVENT("EVENT", "📅", "قرار"),
        DEBT("DEBT", "🤝", "بدهی"),
        MEMORY("MEMORY", "📷", "خاطره"),
        LOCATION("LOCATION", "📍", "موقعیت");

        companion object {
            fun fromWire(value: String): Type? = entries.firstOrNull { it.wire == value }
        }
    }

    data class Card(
        val type: Type,
        val id: String,
        val title: String,
        val subtitle: String? = null,
        val meta: Map<String, String> = emptyMap()
    )

    fun encode(type: Type, id: String, title: String, subtitle: String? = null, extra: Map<String, Any?> = emptyMap()): String {
        val payload = JSONObject()
            .put("id", id.take(80))
            .put("title", title.take(200))
        if (!subtitle.isNullOrBlank()) payload.put("subtitle", subtitle.take(200))
        extra.forEach { (k, v) ->
            when (v) {
                null -> Unit
                is Number -> payload.put(k, v)
                is Boolean -> payload.put(k, v)
                else -> payload.put(k, v.toString().take(200))
            }
        }
        val fallback = buildString {
            append(type.emoji)
            append(' ')
            append(type.label)
            append(" · ")
            append(title.take(120))
            if (!subtitle.isNullOrBlank()) {
                append(" · ")
                append(subtitle.take(80))
            }
        }
        // Human-readable line first so search/preview stay useful, then machine payload.
        return "$fallback\n$PREFIX${type.wire}|${payload}"
    }

    fun parse(text: String): Card? {
        val marker = text.indexOf(PREFIX)
        if (marker < 0) return null
        val rest = text.substring(marker + PREFIX.length)
        val pipe = rest.indexOf('|')
        if (pipe <= 0) return null
        val type = Type.fromWire(rest.substring(0, pipe)) ?: return null
        val json = runCatching { JSONObject(rest.substring(pipe + 1)) }.getOrNull() ?: return null
        val id = json.optString("id").ifBlank { return null }
        val title = json.optString("title").ifBlank { type.label }
        val subtitle = json.optString("subtitle").takeIf { it.isNotBlank() }
        val meta = mutableMapOf<String, String>()
        json.keys().forEach { key ->
            if (key != "id" && key != "title" && key != "subtitle") {
                meta[key] = json.opt(key)?.toString().orEmpty()
            }
        }
        return Card(type, id, title, subtitle, meta)
    }

    fun isShareCard(text: String): Boolean = text.contains(PREFIX)
}
