package com.ourspace.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.ui.theme.ChatBackgroundStyle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * لایهٔ پس‌زمینهٔ متحرک گفتگو — پشت لیست پیام‌ها.
 * با «کاهش انیمیشن» حرکت تقریباً ثابت می‌شود.
 */
@Composable
fun ChatBackgroundLayer(
    style: ChatBackgroundStyle,
    reduceMotion: Boolean,
    modifier: Modifier = Modifier
) {
    when (style) {
        ChatBackgroundStyle.NONE -> ChatPlainBackground(modifier)
        ChatBackgroundStyle.MESH -> {
            Box(modifier.fillMaxSize()) {
                LivingAmbientMesh(
                    modifier = Modifier.fillMaxSize(),
                    intensity = if (reduceMotion) 0.5f else 0.9f
                )
                // وینیت نرم برای خوانایی حباب پیام
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.10f)
                            ),
                            center = Offset(size.width * 0.5f, size.height * 0.35f),
                            radius = size.minDimension * 1.15f
                        )
                    )
                }
            }
        }
        ChatBackgroundStyle.STARS -> ChatStarsBackground(modifier, reduceMotion)
        ChatBackgroundStyle.WAVES -> ChatWavesBackground(modifier, reduceMotion)
        ChatBackgroundStyle.HEARTS -> ChatHeartsBackground(modifier, reduceMotion)
        ChatBackgroundStyle.AURORA -> ChatAuroraBackground(modifier, reduceMotion)
    }
}

@Composable
fun ChatBackgroundFromPrefs(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember(context) { AppPreferences(context.applicationContext) }
    val style by prefs.chatBackground.collectAsState(initial = ChatBackgroundStyle.NONE)
    val reduce by prefs.reduceAnimations.collectAsState(initial = false)
    ChatBackgroundLayer(style = style, reduceMotion = reduce, modifier = modifier)
}

@Composable
private fun ChatPlainBackground(modifier: Modifier) {
    val top = MaterialTheme.colorScheme.surface
    val mid = MaterialTheme.colorScheme.surfaceContainerLowest
    val bottom = MaterialTheme.colorScheme.background
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(top, mid, bottom)
                )
            )
    )
}

/* ───────────────── ستاره‌ها ───────────────── */

private data class StarSpec(
    val x: Float,
    val y: Float,
    val radius: Float,
    val phase: Float,
    val speed: Float,
    val colorIndex: Int,
    val glow: Boolean
)

@Composable
private fun ChatStarsBackground(modifier: Modifier, reduceMotion: Boolean) {
    // آسمان شب طبیعی — رنگ‌های ملایم، نه نئون
    val nightTop = Color(0xFF0A0E1A)
    val nightMid = Color(0xFF12182B)
    val nightBottom = Color(0xFF1A1528)
    val starPalette = remember {
        listOf(
            Color(0xFFF5F7FF), // سفید سرد
            Color(0xFFFFF8F0), // سفید گرم
            Color(0xFFE8EEFF), // آبی بسیار کم‌رنگ
            Color(0xFFFFF0E8), // هلویی خیلی ملایم
            Color(0xFFEDE4FF), // یاسی خیلی ملایم
            Color(0xFFFFF5E0), // کرم طلایی کم‌رنگ
            Color(0xFFE0F2FF), // آبی آسمانی کم‌رنگ
            Color(0xFFFFE8F0)  // صورتی خیلی کم‌رنگ
        )
    }

    val stars = remember {
        // بیشتر ستاره‌های ریز و کم‌نور؛ تعداد کمی کمی درشت‌تر
        List(160) {
            val layer = Random.nextFloat() // 0..1 عمق
            StarSpec(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                radius = when {
                    layer > 0.92f -> 1.8f + Random.nextFloat() * 1.4f // چند ستاره برجسته
                    layer > 0.7f -> 1.1f + Random.nextFloat() * 0.9f
                    else -> 0.6f + Random.nextFloat() * 0.7f
                },
                phase = Random.nextFloat() * (2f * PI.toFloat()),
                speed = 0.25f + Random.nextFloat() * 0.9f,
                colorIndex = Random.nextInt(starPalette.size),
                glow = layer > 0.88f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "chat-stars")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 180_000 else 28_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "stars-phase"
    )
    val shoot by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 120_000 else 18_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shooting-star"
    )

    Canvas(modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(nightTop, nightMid, nightBottom)
            )
        )
        // مه بسیار ملایم گوشه‌ها (طبیعی، نه رنگی تند)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF2A1F4A).copy(alpha = 0.14f), Color.Transparent),
                center = Offset(size.width * 0.2f, size.height * 0.15f),
                radius = size.minDimension * 0.5f
            ),
            radius = size.minDimension * 0.5f,
            center = Offset(size.width * 0.2f, size.height * 0.15f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF1A2A40).copy(alpha = 0.12f), Color.Transparent),
                center = Offset(size.width * 0.85f, size.height * 0.7f),
                radius = size.minDimension * 0.45f
            ),
            radius = size.minDimension * 0.45f,
            center = Offset(size.width * 0.85f, size.height * 0.7f)
        )

        val w = size.width
        val h = size.height
        stars.forEach { star ->
            // چشمک آرام و محدود — نه چشمک تند
            val twinkle = if (reduceMotion) {
                0.7f
            } else {
                0.55f + 0.35f * (0.5f + 0.5f * sin((t * star.speed + star.phase).toDouble()).toFloat())
            }
            val base = starPalette[star.colorIndex % starPalette.size]
            val alpha = (0.35f + twinkle * 0.5f).coerceIn(0.25f, 0.92f)
            val c = Offset(star.x * w, star.y * h)

            if (star.glow) {
                drawCircle(
                    color = base.copy(alpha = alpha * 0.18f),
                    radius = star.radius * 3.2f,
                    center = c
                )
            }
            drawCircle(
                color = base.copy(alpha = alpha),
                radius = star.radius,
                center = c
            )
            // هسته خیلی کوچک و کم‌نور فقط برای ستاره‌های کمی بزرگ‌تر
            if (star.radius > 1.5f) {
                drawCircle(
                    color = Color.White.copy(alpha = alpha * 0.35f),
                    radius = star.radius * 0.28f,
                    center = c
                )
            }
        }

        // شهاب کم‌رنگ و نادر
        if (!reduceMotion && shoot in 0.05f..0.18f) {
            val progress = ((shoot - 0.05f) / 0.13f).coerceIn(0f, 1f)
            val sx = w * (0.15f + progress * 0.55f)
            val sy = h * (0.1f + progress * 0.28f)
            val len = 36f + progress * 28f
            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.55f * (1f - progress * 0.4f)),
                        Color.White.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    start = Offset(sx, sy),
                    end = Offset(sx - len, sy + len * 0.4f)
                ),
                start = Offset(sx, sy),
                end = Offset(sx - len, sy + len * 0.4f),
                strokeWidth = 1.4f
            )
        }
    }
}

/* ───────────────── موج‌ها ───────────────── */

@Composable
private fun ChatWavesBackground(modifier: Modifier, reduceMotion: Boolean) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val surface = MaterialTheme.colorScheme.surface
    val bg = MaterialTheme.colorScheme.background

    val transition = rememberInfiniteTransition(label = "chat-waves")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 90_000 else 10_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waves-phase"
    )
    val t2 by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 100_000 else 14_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waves-phase-2"
    )

    Canvas(modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    surface,
                    primary.copy(alpha = 0.08f),
                    bg
                )
            )
        )
        val w = size.width
        val h = size.height

        val layers = listOf(
            WaveLayer(primary.copy(alpha = 0.18f), 0.55f, 22f, 1.0f, 0f, t),
            WaveLayer(secondary.copy(alpha = 0.15f), 0.68f, 16f, 1.25f, 1.2f, t2),
            WaveLayer(tertiary.copy(alpha = 0.12f), 0.80f, 12f, 0.85f, 2.4f, t),
            WaveLayer(primary.copy(alpha = 0.10f), 0.90f, 8f, 1.5f, 0.6f, t2)
        )
        layers.forEach { layer ->
            val path = Path()
            val baseY = h * layer.baseY
            path.moveTo(0f, h)
            path.lineTo(0f, baseY)
            val steps = 48
            for (i in 0..steps) {
                val frac = i / steps.toFloat()
                val x = w * frac
                val phase = layer.time * layer.speed + layer.offset + frac * 2.4f * PI.toFloat()
                val y = baseY + sin(phase.toDouble()).toFloat() * layer.amplitude +
                    cos((phase * 0.55f).toDouble()).toFloat() * layer.amplitude * 0.25f
                path.lineTo(x, y)
            }
            path.lineTo(w, h)
            path.close()
            drawPath(
                path,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        layer.color,
                        layer.color.copy(alpha = layer.color.alpha * 0.35f)
                    ),
                    startY = baseY - layer.amplitude,
                    endY = h
                )
            )
        }

        // ذرات کف روی موج
        if (!reduceMotion) {
            for (i in 0 until 18) {
                val px = ((i * 97 + t * 40) % w + w) % w
                val py = h * (0.62f + 0.3f * ((i % 5) / 5f)) +
                    sin((t + i).toDouble()).toFloat() * 10f
                drawCircle(
                    color = Color.White.copy(alpha = 0.18f),
                    radius = 2f + (i % 3),
                    center = Offset(px, py)
                )
            }
        }
    }
}

private data class WaveLayer(
    val color: Color,
    val baseY: Float,
    val amplitude: Float,
    val speed: Float,
    val offset: Float,
    val time: Float
)

/* ───────────────── قلب‌ها ───────────────── */

@Composable
private fun ChatHeartsBackground(modifier: Modifier, reduceMotion: Boolean) {
    val surface = MaterialTheme.colorScheme.background
    val primary = MaterialTheme.colorScheme.primary
    val palette = remember {
        listOf(
            Color(0xFFE91E63),
            Color(0xFFF06292),
            Color(0xFFEC407A),
            Color(0xFFEF5350),
            Color(0xFFFF7043),
            Color(0xFFAB47BC),
            Color(0xFF7E57C2),
            Color(0xFF5C6BC0),
            Color(0xFF42A5F5),
            Color(0xFF26C6DA),
            Color(0xFF66BB6A),
            Color(0xFFFFCA28),
            Color(0xFFFFA726),
            Color(0xFF8D6E63)
        )
    }
    val hearts = remember {
        List(56) {
            HeartSpec(
                x = Random.nextFloat(),
                startY = Random.nextFloat(),
                size = 6f + Random.nextFloat() * 22f,
                phase = Random.nextFloat() * (2f * PI.toFloat()),
                speed = 0.2f + Random.nextFloat() * 0.9f,
                drift = (Random.nextFloat() - 0.5f) * 0.14f,
                colorIndex = Random.nextInt(palette.size),
                rotate = (Random.nextFloat() - 0.5f) * 0.35f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "chat-hearts")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 100_000 else 13_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "hearts-phase"
    )
    val breathe by transition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 40_000 else 4_200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hearts-breathe"
    )

    Canvas(modifier.fillMaxSize()) {
        // پس‌زمینهٔ ملایم عاشقانه
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    surface,
                    primary.copy(alpha = 0.06f),
                    surface
                )
            )
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFF80AB).copy(alpha = 0.10f), Color.Transparent),
                center = Offset(size.width * 0.7f, size.height * 0.25f),
                radius = size.minDimension * 0.55f
            ),
            radius = size.minDimension * 0.55f,
            center = Offset(size.width * 0.7f, size.height * 0.25f)
        )

        val w = size.width
        val h = size.height
        hearts.forEach { heart ->
            val floatY = if (reduceMotion) {
                heart.startY
            } else {
                ((heart.startY + (t * heart.speed * 0.09f) % 1.25f) % 1.25f) - 0.12f
            }
            val x = (heart.x + sin((t + heart.phase).toDouble()).toFloat() * heart.drift)
                .coerceIn(0.02f, 0.98f)
            val alpha = if (floatY < -0.05f || floatY > 1.05f) {
                0f
            } else {
                0.18f + 0.32f * (0.5f + 0.5f * sin((t * 1.4f + heart.phase).toDouble()).toFloat())
            }
            if (alpha <= 0.02f) return@forEach
            val base = palette[heart.colorIndex % palette.size]
            val s = heart.size * (if (reduceMotion) 1f else breathe)
            val c = Offset(x * w, floatY * h)
            // هاله
            drawHeart(c, s * 1.35f, base.copy(alpha = alpha * 0.22f), heart.rotate * t * 0.15f)
            drawHeart(c, s, base.copy(alpha = alpha), heart.rotate * 0.5f)
        }
    }
}

private data class HeartSpec(
    val x: Float,
    val startY: Float,
    val size: Float,
    val phase: Float,
    val speed: Float,
    val drift: Float,
    val colorIndex: Int,
    val rotate: Float
)

private fun DrawScope.drawHeart(
    center: Offset,
    size: Float,
    color: Color,
    tilt: Float = 0f
) {
    val path = Path()
    val s = size
    // مسیر کلاسیک قلب
    path.moveTo(center.x, center.y + s * 0.3f)
    path.cubicTo(
        center.x - s * 0.15f, center.y + s * 0.05f,
        center.x - s * 0.55f, center.y - s * 0.25f,
        center.x - s * 0.55f, center.y - s * 0.05f
    )
    path.cubicTo(
        center.x - s * 0.55f, center.y - s * 0.45f,
        center.x - s * 0.1f, center.y - s * 0.55f,
        center.x, center.y - s * 0.22f
    )
    path.cubicTo(
        center.x + s * 0.1f, center.y - s * 0.55f,
        center.x + s * 0.55f, center.y - s * 0.45f,
        center.x + s * 0.55f, center.y - s * 0.05f
    )
    path.cubicTo(
        center.x + s * 0.55f, center.y - s * 0.25f,
        center.x + s * 0.15f, center.y + s * 0.05f,
        center.x, center.y + s * 0.3f
    )
    path.close()
    // tilt ساده با جابه‌جایی جزئی افقی (بدون matrix برای سبکی)
    if (tilt != 0f) {
        // نادیده برای سادگی — رنگ و اندازه کافی‌اند
    }
    drawPath(path, color = color)
}

/* ───────────────── شفق ───────────────── */

@Composable
private fun ChatAuroraBackground(modifier: Modifier, reduceMotion: Boolean) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val night = Color(0xFF071018)

    val transition = rememberInfiniteTransition(label = "chat-aurora")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 80_000 else 18_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "aurora-phase"
    )
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 90_000 else 22_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "aurora-drift"
    )

    Canvas(modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    night,
                    Color(0xFF0D1B2A),
                    Color(0xFF1B2838)
                )
            )
        )

        val w = size.width
        val h = size.height

        // حباب‌های نور پس‌زمینه
        val blobs = listOf(
            Triple(primary, Offset(w * (0.2f + 0.1f * sin(t.toDouble()).toFloat()), h * 0.25f), 0.14f),
            Triple(secondary, Offset(w * (0.75f + 0.08f * cos(t.toDouble()).toFloat()), h * 0.4f), 0.12f),
            Triple(tertiary, Offset(w * 0.5f, h * (0.55f + 0.05f * sin((t + 1).toDouble()).toFloat())), 0.10f)
        )
        blobs.forEach { (c, center, alpha) ->
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c.copy(alpha = alpha), Color.Transparent),
                    center = center,
                    radius = size.minDimension * 0.55f
                ),
                radius = size.minDimension * 0.55f,
                center = center
            )
        }

        val bands = listOf(
            AuroraBand(Color(0xFF69F0AE), 0.22f, 0.32f, 0.85f, 0f),
            AuroraBand(primary, 0.30f, 0.28f, 1.1f, 1.2f),
            AuroraBand(secondary, 0.42f, 0.24f, 0.7f, 2.5f),
            AuroraBand(tertiary, 0.55f, 0.20f, 1.0f, 0.8f),
            AuroraBand(Color(0xFF82B1FF), 0.38f, 0.18f, 0.95f, 3.1f)
        )
        bands.forEach { band ->
            val path = Path()
            val midY = h * band.centerY + sin((t * 0.3f + band.phase).toDouble()).toFloat() * h * 0.03f
            val steps = 56
            for (i in 0..steps) {
                val frac = i / steps.toFloat()
                val x = w * ((frac + drift * 0.15f * band.speed) % 1.15f - 0.05f)
                val wave = sin((t * band.speed + band.phase + frac * 4.2f).toDouble()).toFloat()
                val y = midY + wave * h * band.amplitude * 0.12f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            for (i in steps downTo 0) {
                val frac = i / steps.toFloat()
                val x = w * ((frac + drift * 0.15f * band.speed) % 1.15f - 0.05f)
                val wave = sin((t * band.speed + band.phase + frac * 4.2f + 0.5f).toDouble()).toFloat()
                val y = midY + wave * h * band.amplitude * 0.12f + h * 0.10f
                path.lineTo(x, y)
            }
            path.close()
            drawPath(
                path,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        band.color.copy(alpha = 0.28f),
                        band.color.copy(alpha = 0.08f),
                        Color.Transparent
                    )
                )
            )
            // خط درخشان لبه بالا
            val edge = Path()
            for (i in 0..steps) {
                val frac = i / steps.toFloat()
                val x = w * ((frac + drift * 0.15f * band.speed) % 1.15f - 0.05f)
                val wave = sin((t * band.speed + band.phase + frac * 4.2f).toDouble()).toFloat()
                val y = midY + wave * h * band.amplitude * 0.12f
                if (i == 0) edge.moveTo(x, y) else edge.lineTo(x, y)
            }
            drawPath(
                edge,
                color = band.color.copy(alpha = 0.35f),
                style = Stroke(width = 2.2f)
            )
        }
    }
}

private data class AuroraBand(
    val color: Color,
    val centerY: Float,
    val amplitude: Float,
    val speed: Float,
    val phase: Float
)
