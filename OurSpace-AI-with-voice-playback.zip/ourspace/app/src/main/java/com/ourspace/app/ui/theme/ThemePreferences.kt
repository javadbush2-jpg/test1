package com.ourspace.app.ui.theme

enum class AppPalette(val persistedName: String, val persianLabel: String) {
    ROSE("rose", "رز عاشقانه"),
    OCEAN("ocean", "اقیانوس آرام"),
    FOREST("forest", "جنگل زنده"),
    SUNSET("sunset", "غروب گرم"),
    LAVENDER("lavender", "اسطوخودوس"),
    MIDNIGHT("midnight", "نیمه‌شب"),
    HONEY("honey", "عسل طلایی");

    companion object {
        fun fromPersistedName(value: String?): AppPalette =
            entries.firstOrNull { it.persistedName == value } ?: ROSE
    }
}

enum class AppThemeMode(val persistedName: String, val persianLabel: String) {
    SYSTEM("system", "خودکار"),
    LIGHT("light", "روشن"),
    DARK("dark", "تاریک");

    companion object {
        fun fromPersistedName(value: String?): AppThemeMode =
            entries.firstOrNull { it.persistedName == value } ?: SYSTEM
    }
}


enum class AppFontFamily(val persistedName: String, val persianLabel: String) {
    SANS("sans", "ساده (سیستم)"),
    SERIF("serif", "کلاسیک (سیستم)"),
    MONO("mono", "تک‌فاصله"),
    VAZIRMATN("vazirmatn", "وزیرمتن"),
    SAHEL("sahel", "ساحل"),
    SAMIM("samim", "صمیم"),
    TANHA("tanha", "تنها"),
    PARASTOO("parastoo", "پرستو"),
    SHABNAM("shabnam", "شبنم"),
    GANDOM("gandom", "گندم");

    companion object {
        fun fromPersistedName(value: String?): AppFontFamily =
            entries.firstOrNull { it.persistedName == value } ?: SANS
    }
}

/**
 * Animated / static backgrounds exclusive to the chat conversation surface.
 * Chosen in Settings → ظاهر and applied only behind the message list.
 */
enum class ChatBackgroundStyle(
    val persistedName: String,
    val persianLabel: String,
    val description: String
) {
    NONE("none", "ساده", "رنگ پیش‌فرض تم بدون حرکت"),
    MESH("mesh", "ابر نرم", "حباب‌های رنگی آرام و شناور"),
    STARS("stars", "ستاره‌ها", "آسمان شب با چشمک نرم"),
    WAVES("waves", "موج‌ها", "موج‌های آرام اقیانوسی"),
    HEARTS("hearts", "قلب‌ها", "قلب‌های کوچک شناور عاشقانه"),
    AURORA("aurora", "شفق قطبی", "نورهای رنگی نرم و موج‌دار");

    companion object {
        fun fromPersistedName(value: String?): ChatBackgroundStyle =
            entries.firstOrNull { it.persistedName == value } ?: NONE
    }
}


/**
 * رنگ پس‌زمینه ویجت‌های صفحهٔ اصلی (جدا از تم پویای داخل اپ).
 */
enum class WidgetAccent(
    val persistedName: String,
    val persianLabel: String,
    val swatchArgb: Long
) {
    ROSE("rose", "رز", 0xFFE85D8C),
    OCEAN("ocean", "اقیانوس", 0xFF2BB0C7),
    FOREST("forest", "جنگل", 0xFF6BBF59),
    SUNSET("sunset", "غروب", 0xFFFF8A5C),
    LAVENDER("lavender", "اسطوخودوس", 0xFFB794F6),
    MIDNIGHT("midnight", "نیمه‌شب", 0xFF5B7C99),
    HONEY("honey", "عسل", 0xFFE8B84A),
    SLATE("slate", "سنگی", 0xFF90A4AE);

    companion object {
        fun fromPersistedName(value: String?): WidgetAccent =
            entries.firstOrNull { it.persistedName == value } ?: ROSE
    }
}
