package com.ourspace.app.core.finance

import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.time.PersianDateFormatter

object FinanceCalculator {
    data class PeriodTotals(val income: Long, val expense: Long)

    fun accountBalance(
        account: FinancialAccountEntity,
        transactions: List<FinanceTransactionEntity>
    ): Long = try {
        account.openingBalance + transactions.asSequence()
            .filter { !it.isDeleted && (it.accountId == account.id || it.targetAccountId == account.id) }
            .sumOf { transaction ->
                val amount = transaction.amount.coerceAtLeast(0L)
                when {
                    transaction.kind.equals("TRANSFER", true) && transaction.targetAccountId == account.id -> amount
                    transaction.kind.equals("INCOME", true) && transaction.accountId == account.id -> amount
                    transaction.accountId == account.id -> -amount
                    else -> 0L
                }
            }
    } catch (_: Exception) {
        account.openingBalance
    }

    fun totalBalance(
        accounts: List<FinancialAccountEntity>,
        transactions: List<FinanceTransactionEntity>
    ): Long = try {
        accounts.asSequence()
            .filter { !it.isDeleted && !it.isArchived }
            .sumOf { accountBalance(it, transactions) }
    } catch (_: Exception) {
        0L
    }

    fun periodTotals(
        transactions: List<FinanceTransactionEntity>,
        periodKey: String
    ): PeriodTotals {
        return try {
            val periodTransactions = transactions.filter {
                !it.isDeleted && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey
            }
            PeriodTotals(
                income = periodTransactions.filter { it.kind.equals("INCOME", true) }.sumOf { it.amount.coerceAtLeast(0L) },
                expense = periodTransactions.filter { it.kind.equals("EXPENSE", true) }.sumOf { it.amount.coerceAtLeast(0L) }
            )
        } catch (_: Exception) {
            PeriodTotals(0L, 0L)
        }
    }

    fun categoryExpense(
        transactions: List<FinanceTransactionEntity>,
        periodKey: String,
        category: String
    ): Long = try {
        transactions.asSequence()
            .filter {
                !it.isDeleted &&
                    it.kind.equals("EXPENSE", true) &&
                    it.category == category &&
                    PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey
            }
            .sumOf { it.amount.coerceAtLeast(0L) }
    } catch (_: Exception) {
        0L
    }
}
