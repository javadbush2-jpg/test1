package com.ourspace.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.ourspace.app.MainActivity
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.R
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.sync.CompanionSyncWorker
import com.ourspace.app.core.time.PersianDateFormatter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class OurSpaceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val appContext = context.applicationContext
        scope.launch {
            appWidgetIds.forEach { id ->
                runCatching {
                    val views = buildViews(appContext)
                    appWidgetManager.updateAppWidget(id, views)
                }
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH, AppWidgetManager.ACTION_APPWIDGET_UPDATE -> {
                requestUpdate(context)
            }
            ACTION_SEND_HEART -> {
                val appContext = context.applicationContext
                scope.launch {
                    runCatching {
                        val app = appContext as OurSpaceApplication
                        val deviceId = DeviceIdentityManager().getOrCreateIdentity().deviceId
                        app.repository.sendHeartPulse(deviceId)
                        OurSpaceNotificationCenter(appContext).playHeartbeatVibration()
                        CompanionSyncWorker.runSoon(appContext)
                    }
                    requestUpdate(appContext)
                }
            }
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.ourspace.app.widget.ACTION_REFRESH"
        const val ACTION_SEND_HEART = "com.ourspace.app.widget.ACTION_SEND_HEART"

        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        fun requestUpdate(context: Context) {
            val appContext = context.applicationContext
            val manager = AppWidgetManager.getInstance(appContext)
            val ids = manager.getAppWidgetIds(
                ComponentName(appContext, OurSpaceWidgetProvider::class.java)
            )
            if (ids.isEmpty()) return
            scope.launch {
                ids.forEach { id ->
                    runCatching {
                        val views = buildViews(appContext)
                        manager.updateAppWidget(id, views)
                    }
                }
            }
        }

        private suspend fun buildViews(context: Context): RemoteViews {
            val app = context.applicationContext as? OurSpaceApplication
            val views = RemoteViews(context.packageName, R.layout.widget_ourspace)
            WidgetStyle.applyBackground(views, R.id.widget_root, context)

            val openApp = PendingIntent.getActivity(
                context,
                10,
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openApp)

            val heartIntent = Intent(context, OurSpaceWidgetProvider::class.java).apply {
                action = ACTION_SEND_HEART
            }
            val heartPending = PendingIntent.getBroadcast(
                context,
                11,
                heartIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_heart, heartPending)

            if (app == null) {
                views.setTextViewText(R.id.widget_subtitle, "OurSpace")
                views.setTextViewText(R.id.widget_tasks_value, "—")
                views.setTextViewText(R.id.widget_shopping_value, "—")
                views.setTextViewText(R.id.widget_mood_line, "حال امروز: —")
                views.setTextViewText(R.id.widget_next_event, context.getString(R.string.widget_no_event))
                views.setTextViewText(R.id.widget_footer, context.getString(R.string.widget_tap_open))
                return views
            }

            val db = app.database
            val tasks = db.taskDao().getAllOnce().filter { !it.isDeleted && !it.isCompleted }
            val shopping = db.shoppingDao().getAllOnce().filter { !it.isDeleted && !it.isChecked }
            val events = db.eventDao().getAllOnce()
                .filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt >= System.currentTimeMillis() - 3_600_000L }
                .sortedBy { it.startAt }
            val profile = db.coupleProfileDao().getOnce()
            val daysTogether = profile?.relationshipStartedAt?.let { start ->
                PersianDateFormatter.daysTogether(start)
            }

            val subtitle = when {
                daysTogether != null -> "${PersianDateFormatter.toPersianDigits(daysTogether)} روز با هم"
                else -> "فضای خصوصی دونفره"
            }
            views.setTextViewText(R.id.widget_subtitle, subtitle)
            views.setTextViewText(
                R.id.widget_tasks_value,
                PersianDateFormatter.toPersianDigits(tasks.size)
            )
            views.setTextViewText(
                R.id.widget_shopping_value,
                PersianDateFormatter.toPersianDigits(shopping.size)
            )

            val todayKey = PersianDateFormatter.currentJalaliDayKey()
            val moods = db.moodCheckInDao().getAllOnce().filter { !it.isDeleted && it.dayKey == todayKey }
            val moodText = if (moods.isEmpty()) {
                "حال امروز هنوز ثبت نشده"
            } else {
                val labels = moods.take(2).joinToString(" · ") { m ->
                    val label = when (m.mood.uppercase()) {
                        "GREAT" -> "عالی"
                        "HAPPY" -> "خوشحال"
                        "LOVED" -> "عاشقانه"
                        "CALM" -> "آرام"
                        "TIRED" -> "خسته"
                        "SAD" -> "دلگیر"
                        else -> m.mood
                    }
                    label
                }
                "حال امروز: $labels"
            }
            views.setTextViewText(R.id.widget_mood_line, moodText)

            val next = events.firstOrNull()
            val nextText = if (next != null) {
                "قرار بعدی: ${next.title} • ${PersianDateFormatter.formatDateTime(next.startAt)}"
            } else {
                context.getString(R.string.widget_no_event)
            }
            views.setTextViewText(R.id.widget_next_event, nextText)
            views.setTextViewText(
                R.id.widget_footer,
                "💗 قلب = به یادتم  •  ${context.getString(R.string.widget_tap_open)}"
            )
            return views
        }
    }
}
