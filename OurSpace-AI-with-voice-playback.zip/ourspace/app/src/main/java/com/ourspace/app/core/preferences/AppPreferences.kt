package com.ourspace.app.core.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.core.relay.RelayEndpointValidator
import com.ourspace.app.core.webrtc.WebRtcConfig
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode
import com.ourspace.app.ui.theme.WidgetAccent
import com.ourspace.app.ui.theme.AppFontFamily
import com.ourspace.app.ui.theme.ChatBackgroundStyle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ourSpaceDataStore by preferencesDataStore(name = "ourspace_settings")

class AppPreferences(private val context: Context) {
    private object Keys {
        val role = stringPreferencesKey("device_role")
        val trustedHostPayload = stringPreferencesKey("trusted_host_payload")
        val palette = stringPreferencesKey("theme_palette")
        val themeMode = stringPreferencesKey("theme_mode")
        val dynamicColor = booleanPreferencesKey("dynamic_color")
        val widgetAccent = stringPreferencesKey("widget_accent")
        val fontScale = floatPreferencesKey("font_scale")
        val chatFontScale = floatPreferencesKey("chat_font_scale")
        val aiModelUrl = stringPreferencesKey("ai_model_download_url")
        val aiModelId = stringPreferencesKey("ai_model_selected_id")
        val fontFamily = stringPreferencesKey("font_family")
        val chatBackground = stringPreferencesKey("chat_background_style")
        val compactUi = booleanPreferencesKey("compact_ui")
        val hapticsEnabled = booleanPreferencesKey("haptics_enabled")
        val reduceAnimations = booleanPreferencesKey("reduce_animations")
        val showCalendarWeekNumbers = booleanPreferencesKey("calendar_week_numbers")
        val appLockEnabled = booleanPreferencesKey("app_lock_enabled")
        val peerLastSeenAt = longPreferencesKey("peer_last_seen_at")
        val reminderHour = intPreferencesKey("daily_reminder_hour")
        val reminderMinute = intPreferencesKey("daily_reminder_minute")
        val calendarVisibleCategories = stringSetPreferencesKey("calendar_visible_categories")
        val relayEnabled = booleanPreferencesKey("relay_enabled")
        val relayEndpoint = stringPreferencesKey("relay_endpoint")
        val relayAccessToken = stringPreferencesKey("relay_access_token")
        val locationSharingEnabled = booleanPreferencesKey("location_sharing_enabled")
        val turnUrl = stringPreferencesKey("turn_url")
        val turnUsername = stringPreferencesKey("turn_username")
        val turnPassword = stringPreferencesKey("turn_password")
        val telegramBotToken = stringPreferencesKey("telegram_bot_token")
    }

    val role: Flow<DeviceRole?> = context.ourSpaceDataStore.data.map { preferences ->
        DeviceRole.fromPersistedName(preferences[Keys.role])
    }

    val trustedHostPayload: Flow<String?> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.trustedHostPayload]
    }

    val palette: Flow<AppPalette> = context.ourSpaceDataStore.data.map { preferences ->
        AppPalette.fromPersistedName(preferences[Keys.palette])
    }

    val themeMode: Flow<AppThemeMode> = context.ourSpaceDataStore.data.map { preferences ->
        AppThemeMode.fromPersistedName(preferences[Keys.themeMode])
    }

    /** true = Material You از والپیپر؛ false = پالت انتخابی کاربر */
    val dynamicColor: Flow<Boolean> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.dynamicColor] ?: true
    }

    val widgetAccent: Flow<WidgetAccent> = context.ourSpaceDataStore.data.map { preferences ->
        WidgetAccent.fromPersistedName(preferences[Keys.widgetAccent])
    }

    val fontScale: Flow<Float> = context.ourSpaceDataStore.data.map { preferences ->
        (preferences[Keys.fontScale] ?: 1.0f).coerceIn(0.85f, 1.35f)
    }

    /** مقیاس اختصاصی متن حباب‌های چت (مستقل از فونت سراسری) */
    val chatFontScale: Flow<Float> = context.ourSpaceDataStore.data.map { preferences ->
        (preferences[Keys.chatFontScale] ?: 1.0f).coerceIn(0.80f, 1.60f)
    }

    val aiModelUrl: Flow<String> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.aiModelUrl].orEmpty()
    }

    val aiModelId: Flow<String> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.aiModelId] ?: "os-chat-7b-q4"
    }

    val fontFamily: Flow<AppFontFamily> = context.ourSpaceDataStore.data.map { preferences ->
        AppFontFamily.fromPersistedName(preferences[Keys.fontFamily])
    }

    val chatBackground: Flow<ChatBackgroundStyle> = context.ourSpaceDataStore.data.map { preferences ->
        ChatBackgroundStyle.fromPersistedName(preferences[Keys.chatBackground])
    }

    val compactUi: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.compactUi] ?: false }
    val hapticsEnabled: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.hapticsEnabled] ?: true }
    val appLockEnabled: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.appLockEnabled] ?: false }
    val peerLastSeenAt: Flow<Long> = context.ourSpaceDataStore.data.map { it[Keys.peerLastSeenAt] ?: 0L }
    /** ساعت یادآوری روزانه (۰–۲۳)، پیش‌فرض ۹ صبح */
    val reminderHour: Flow<Int> = context.ourSpaceDataStore.data.map { (it[Keys.reminderHour] ?: 9).coerceIn(0, 23) }
    /** دقیقه یادآوری روزانه (۰–۵۹) */
    val reminderMinute: Flow<Int> = context.ourSpaceDataStore.data.map { (it[Keys.reminderMinute] ?: 0).coerceIn(0, 59) }
    val reduceAnimations: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.reduceAnimations] ?: false }
    val showCalendarWeekNumbers: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.showCalendarWeekNumbers] ?: false }

    /** دسته‌هایی که در تقویم نمایش داده می‌شوند؛ پیش‌فرض همه فعال‌اند. */
    val calendarVisibleCategories: Flow<Set<String>> = context.ourSpaceDataStore.data.map { prefs ->
        prefs[Keys.calendarVisibleCategories] ?: CalendarVisibilityCategory.ALL_IDS
    }


    val locationSharingEnabled: Flow<Boolean> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.locationSharingEnabled] ?: false
    }

    /** Optional self-hosted TURN relay; when set it is tried before the public ones. */
    val customTurn: Flow<WebRtcConfig.IceServerConfig?> = context.ourSpaceDataStore.data.map { preferences ->
        val url = preferences[Keys.turnUrl]?.trim().orEmpty()
        if (url.isBlank()) null else WebRtcConfig.IceServerConfig(
            url = url,
            username = preferences[Keys.turnUsername]?.takeIf { it.isNotBlank() },
            credential = preferences[Keys.turnPassword]?.takeIf { it.isNotBlank() }
        )
    }



    suspend fun currentCustomTurn(): WebRtcConfig.IceServerConfig? = customTurn.first()

    suspend fun setCustomTurn(url: String, username: String, password: String) {
        context.ourSpaceDataStore.edit { preferences ->
            preferences[Keys.turnUrl] = url.trim()
            preferences[Keys.turnUsername] = username.trim()
            preferences[Keys.turnPassword] = password.trim()
        }
    }

    val relayConfig: Flow<RelayConfig> = context.ourSpaceDataStore.data.map { preferences ->
        val storedEndpoint = preferences[Keys.relayEndpoint]?.trim().orEmpty()
        // Normalize old dashboard URLs too; migrate only the previous built-in HTTPS default.
        val normalizedStoredEndpoint = storedEndpoint.takeIf { it.isNotBlank() }?.let { saved ->
            runCatching { RelayEndpointValidator.normalize(saved) }.getOrDefault(saved)
        }.orEmpty()
        val endpoint = when {
            normalizedStoredEndpoint.isBlank() -> RelayConfig.DEFAULT_ENDPOINT
            normalizedStoredEndpoint.trimEnd('/').equals(RelayConfig.PREVIOUS_HTTPS_DEFAULT_ENDPOINT, ignoreCase = true) ->
                RelayConfig.DEFAULT_ENDPOINT
            else -> normalizedStoredEndpoint
        }
        val token = preferences[Keys.relayAccessToken]?.trim().orEmpty()
            .ifBlank { RelayConfig.DEFAULT_ACCESS_TOKEN }
        RelayConfig(
            // Default ON so first launch connects to the household server without setup.
            enabled = preferences[Keys.relayEnabled] ?: true,
            endpoint = endpoint,
            accessToken = token
        )
    }

    suspend fun setRole(role: DeviceRole, hostPayload: String? = null) {
        context.ourSpaceDataStore.edit { preferences ->
            preferences[Keys.role] = role.persistedName
            if (hostPayload != null) {
                preferences[Keys.trustedHostPayload] = hostPayload
            }
        }
    }

    suspend fun currentRole(): DeviceRole? = role.first()

    suspend fun setPalette(palette: AppPalette) {
        // انتخاب پالت سفارشی → خاموش کردن Material You
        context.ourSpaceDataStore.edit {
            it[Keys.palette] = palette.persistedName
            it[Keys.dynamicColor] = false
        }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.ourSpaceDataStore.edit { it[Keys.themeMode] = mode.persistedName }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.ourSpaceDataStore.edit { it[Keys.dynamicColor] = enabled }
    }

    suspend fun setWidgetAccent(accent: WidgetAccent) {
        context.ourSpaceDataStore.edit { it[Keys.widgetAccent] = accent.persistedName }
    }

    suspend fun currentWidgetAccent(): WidgetAccent = widgetAccent.first()

    suspend fun setFontScale(scale: Float) {
        context.ourSpaceDataStore.edit { it[Keys.fontScale] = scale.coerceIn(0.85f, 1.35f) }
    }
    suspend fun setChatFontScale(scale: Float) {
        context.ourSpaceDataStore.edit { it[Keys.chatFontScale] = scale.coerceIn(0.80f, 1.60f) }
    }
    suspend fun setAiModelUrl(url: String) {
        context.ourSpaceDataStore.edit { it[Keys.aiModelUrl] = url.trim() }
    }
    suspend fun setAiModelId(id: String) {
        context.ourSpaceDataStore.edit { it[Keys.aiModelId] = id }
    }
    suspend fun setFontFamily(family: AppFontFamily) {
        context.ourSpaceDataStore.edit { it[Keys.fontFamily] = family.persistedName }
    }
    suspend fun setChatBackground(style: ChatBackgroundStyle) {
        context.ourSpaceDataStore.edit { it[Keys.chatBackground] = style.persistedName }
    }
    suspend fun setCompactUi(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.compactUi] = enabled } }
    suspend fun setHapticsEnabled(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.hapticsEnabled] = enabled } }
    suspend fun setAppLockEnabled(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.appLockEnabled] = enabled } }
    suspend fun setPeerLastSeenAt(epochMs: Long) {
        if (epochMs <= 0L) return
        context.ourSpaceDataStore.edit { prefs ->
            val current = prefs[Keys.peerLastSeenAt] ?: 0L
            if (epochMs > current) prefs[Keys.peerLastSeenAt] = epochMs
        }
    }

    suspend fun setReminderTime(hour: Int, minute: Int) {
        context.ourSpaceDataStore.edit {
            it[Keys.reminderHour] = hour.coerceIn(0, 23)
            it[Keys.reminderMinute] = minute.coerceIn(0, 59)
        }
    }
    suspend fun setReduceAnimations(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.reduceAnimations] = enabled } }
    suspend fun setShowCalendarWeekNumbers(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.showCalendarWeekNumbers] = enabled } }

    suspend fun setCalendarVisibleCategories(categories: Set<String>) {
        context.ourSpaceDataStore.edit {
            it[Keys.calendarVisibleCategories] = categories.ifEmpty { CalendarVisibilityCategory.ALL_IDS }
        }
    }

    suspend fun setCalendarCategoryVisible(category: String, visible: Boolean) {
        context.ourSpaceDataStore.edit { prefs ->
            val current = (prefs[Keys.calendarVisibleCategories] ?: CalendarVisibilityCategory.ALL_IDS).toMutableSet()
            if (visible) current.add(category) else current.remove(category)
            prefs[Keys.calendarVisibleCategories] = current.ifEmpty { setOf(CalendarVisibilityCategory.TASKS.id) }
        }
    }


    suspend fun isLocationSharingEnabled(): Boolean = locationSharingEnabled.first()

    suspend fun setLocationSharingEnabled(enabled: Boolean) {
        context.ourSpaceDataStore.edit { it[Keys.locationSharingEnabled] = enabled }
    }

    suspend fun currentRelayConfig(): RelayConfig = relayConfig.first()


    val telegramBotToken: Flow<String> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.telegramBotToken].orEmpty()
    }

    suspend fun currentTelegramBotToken(): String = telegramBotToken.first()

    suspend fun setTelegramBotToken(token: String) {
        context.ourSpaceDataStore.edit { preferences ->
            val cleaned = token.trim()
            if (cleaned.isEmpty()) preferences.remove(Keys.telegramBotToken)
            else preferences[Keys.telegramBotToken] = cleaned
        }
    }

    suspend fun setRelayConfig(enabled: Boolean, endpoint: String, accessToken: String = "") {
        val normalized = if (endpoint.isBlank()) "" else RelayEndpointValidator.normalize(endpoint)
        val token = accessToken.trim()
        require(!enabled || normalized.isNotBlank()) { "آدرس سرور لازم است" }
        if (enabled) require(token.length in 16..128) { "کلید مشترک خانه لازم است (از کنسول سرور کپی کن)" }
        context.ourSpaceDataStore.edit { preferences ->
            preferences[Keys.relayEnabled] = enabled
            preferences[Keys.relayEndpoint] = normalized
            preferences[Keys.relayAccessToken] = token
        }
    }

    suspend fun reset() {
        context.ourSpaceDataStore.edit { it.clear() }
    }

    companion object {
    }
}


/** دسته‌های قابل نمایش در تقویم — کاربر می‌تواند هر کدام را روشن/خاموش کند. */
enum class CalendarVisibilityCategory(val id: String, val label: String) {
    TASKS("tasks", "کارها"),
    EVENTS("events", "قرارها و برنامه‌ها"),
    WORK_SHIFT("work_shift", "شیفت شغلی"),
    WORK_OFFICE("work_office", "ساعت اداری"),
    HABITS("habits", "عادات و یادآورها"),
    MEMORIES("memories", "خاطرات"),
    OCCASIONS("occasions", "مناسبت‌ها"),
    MOOD("mood", "حال‌وهوا"),
    FINANCE("finance", "امور مالی"),
    DEBTS("debts", "بدهی‌ها"),
    RECURRING("recurring", "پرداخت دوره‌ای"),
    CYCLE("cycle", "قاعدگی و پیش‌بینی");

    companion object {
        val ALL_IDS: Set<String> = entries.map { it.id }.toSet()
        fun fromId(id: String): CalendarVisibilityCategory? = entries.firstOrNull { it.id == id }
    }
}
