package com.ourspace.app.core.preferences

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Tracks the last time the user opened each bottom-nav section.
 * A section shows an attention dot while any of its records have
 * [updatedAt] greater than that last-seen timestamp.
 */
class SectionAttentionStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val _seenAt = MutableStateFlow(loadAll())
    val seenAt: StateFlow<Map<Int, Long>> = _seenAt.asStateFlow()

    fun lastSeen(section: Int): Long = _seenAt.value[section] ?: 0L

    fun markSeen(section: Int, at: Long = System.currentTimeMillis()) {
        prefs.edit().putLong(key(section), at).apply()
        _seenAt.value = _seenAt.value.toMutableMap().apply { put(section, at) }
    }

    /** Bump last-seen for the open tab so own live edits don't leave a sticky dot. */
    fun touchOpenSection(section: Int) {
        markSeen(section, System.currentTimeMillis())
    }

    private fun loadAll(): Map<Int, Long> {
        val previousSettingsSeen = prefs.getLong(key(LEGACY_SETTINGS), 0L)
        if (prefs.getLong(key(SETTINGS), 0L) == 0L && previousSettingsSeen > 0L) {
            prefs.edit().putLong(key(SETTINGS), previousSettingsSeen).apply()
        }
        val map = mutableMapOf<Int, Long>()
        for (i in 0 until SECTION_COUNT) {
            val v = prefs.getLong(key(i), 0L)
            if (v > 0L) map[i] = v
        }
        return map
    }

    private fun key(section: Int) = "seen_$section"

    companion object {
        private const val PREFS = "ourspace_section_attention"
        const val SECTION_COUNT = 9

        const val HOME = 0
        const val PLANNER = 1
        const val CALENDAR = 2
        const val CHAT = 3
        const val FINANCE = 4
        const val MAP = 5
        const val US = 6
        const val GAMES = 7
        private const val LEGACY_SETTINGS = 7
        const val SETTINGS = 8

        fun maxUpdated(vararg values: Long): Long = values.maxOrNull() ?: 0L

        fun maxOf(items: List<Long>): Long = items.maxOrNull() ?: 0L
    }
}
