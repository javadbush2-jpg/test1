package com.ourspace.app.core.attachment

import java.security.MessageDigest

object AttachmentIntegrity {
    fun sha256Hex(content: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(content)
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    fun verify(content: ByteArray, expectedSize: Long, expectedSha256: String): Boolean {
        if (content.size.toLong() != expectedSize || expectedSha256.length != 64) return false
        val actual = sha256Hex(content).toByteArray(Charsets.US_ASCII)
        val expected = expectedSha256.lowercase().toByteArray(Charsets.US_ASCII)
        return MessageDigest.isEqual(actual, expected)
    }
}
