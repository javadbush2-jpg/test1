package com.ourspace.app.feature.finance

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Sms
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.AlertDialog
import com.ourspace.app.ui.design.OSConfirmDialog
import com.ourspace.app.ui.design.OSFormDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.database.FinanceBudgetEntity
import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.finance.FinanceCalculator
import com.ourspace.app.core.finance.CategoryPreferences

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.ourspace.app.core.finance.SmsCandidate
import com.ourspace.app.core.finance.SmsTransactionImporter
import com.ourspace.app.core.finance.PendingSmsStore
import com.ourspace.app.core.finance.PendingSmsTransaction
import com.ourspace.app.core.finance.SmsPendingBus
import com.ourspace.app.core.finance.AutoSmsSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.launch
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.database.ShoppingItemEntity
import com.ourspace.app.core.database.RecurringTransactionEntity
import com.ourspace.app.core.database.SharedDebtEntity
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.ui.components.FloatingMotion
import com.ourspace.app.ui.components.PersianDatePickerDialog
import com.ourspace.app.ui.components.MotionCard

// دسته‌بندی‌ها از CategoryPreferences (مشترک هزینه و خرید)

@Composable
fun FinanceScreen(
    focusItemId: String? = null,
    focusCategory: String? = null,
    focusTab: Int? = null,
    onFocusConsumed: () -> Unit = {},
    ownDeviceId: String,
    accounts: List<FinancialAccountEntity>,
    transactions: List<FinanceTransactionEntity>,
    budgets: List<FinanceBudgetEntity>,
    debts: List<SharedDebtEntity>,
    recurringTransactions: List<RecurringTransactionEntity>,
    shoppingItems: List<ShoppingItemEntity> = emptyList(),
    onAddAccount: (String, String, Long, Int) -> Unit,
    onCorrectAccountBalance: (FinancialAccountEntity, Long) -> Unit,
    onAddTransaction: (String, String?, String, Long, String, String) -> Unit,
    onAddTransactionAt: (String, String?, String, Long, String, String, Long, String) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onDeleteTransaction: (FinanceTransactionEntity) -> Unit,
    onSetBudget: (String, String, Long) -> Unit,
    onAddDebt: (String, Long, String, String, Long?) -> Unit,
    onToggleDebtSettled: (SharedDebtEntity) -> Unit,
    onDeleteDebt: (SharedDebtEntity) -> Unit,
    onShareDebtToChat: (SharedDebtEntity) -> Unit = {},
    onAddRecurring: (String, String?, String, Long, String, String, String, Long) -> Unit,
    onToggleRecurring: (RecurringTransactionEntity) -> Unit,
    onDeleteRecurring: (RecurringTransactionEntity) -> Unit,
    onAddShopping: (String, String, String, Boolean) -> Unit = { _, _, _, _ -> },
    onToggleShopping: (ShoppingItemEntity) -> Unit = {},
    onDeleteShopping: (ShoppingItemEntity) -> Unit = {},
    onClearCheckedShopping: () -> Unit = {}
) {
    val haptics = LocalHapticFeedback.current
    var financeTab by remember { mutableIntStateOf(0) } // 0 مالی، ۱ گزارش، ۲ خرید
    var highlightId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(focusItemId, focusTab, focusCategory) {
        focusTab?.let { financeTab = it }
        if (!focusItemId.isNullOrBlank()) {
            highlightId = focusItemId
            onFocusConsumed()
            kotlinx.coroutines.delay(4000)
            if (highlightId == focusItemId) highlightId = null
        } else if (focusTab != null) {
            onFocusConsumed()
        }
    }
    var showAddShopping by remember { mutableStateOf(false) }
    var showSmsImport by remember { mutableStateOf(false) }
    var smsCandidates by remember { mutableStateOf<List<SmsCandidate>>(emptyList()) }
    var smsScanning by remember { mutableStateOf(false) }
    var smsError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    var categoryVersion by remember { mutableIntStateOf(0) }
    val expenseCategories = remember(categoryVersion) { CategoryPreferences.expenseCategories(context) }
    val incomeCategories = remember(categoryVersion) { CategoryPreferences.incomeCategories(context) }
    val shoppingCategories = expenseCategories
    val smsScope = rememberCoroutineScope()
    fun startSmsScan() {
        smsError = null
        smsScanning = true
        smsScope.launch {
            val found = withContext(Dispatchers.IO) {
                SmsTransactionImporter.scan(context, lookbackDays = 45, maxScan = 500)
            }
            smsCandidates = found
            smsScanning = false
            showSmsImport = true
            if (found.isEmpty()) {
                smsError = "پیامک بانکی جدیدی پیدا نشد (یا قبلاً وارد شده‌اند)."
            }
        }
    }
    val smsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startSmsScan()
        else smsError = "برای ورود از پیامک، مجوز خواندن پیامک لازم است."
    }
    fun requestSmsImport() {
        if (accounts.none { !it.isDeleted }) {
            smsError = "اول یک حساب مالی بسازید، بعد پیامک‌ها را وارد کنید."
            showSmsImport = true
            smsCandidates = emptyList()
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_SMS
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startSmsScan()
        else smsPermissionLauncher.launch(Manifest.permission.READ_SMS)
    }

    // --- دریافت خودکار پیامک بانکی → صف در انتظار دسته‌بندی ---
    val pendingSms by PendingSmsStore.observe(context).collectAsState()
    var showPendingCategorize by remember { mutableStateOf(false) }
    var autoSmsEnabled by remember { mutableStateOf(AutoSmsSettings.isEnabled(context)) }
    val smsAutoPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        // هر دو مجوز READ_SMS و RECEIVE_SMS لازم است؛ گیرنده بدون RECEIVE_SMS کار نمی‌کند.
        val granted = result.isNotEmpty() && result.values.all { it }
        autoSmsEnabled = granted
        AutoSmsSettings.setEnabled(context, granted)
        if (!granted) {
            smsError = "برای ثبت خودکار تراکنش، مجوز پیامک لازم است. پیامک‌های قبلی را می‌توانی از دکمهٔ «از پیامک» دستی وارد کنی."
        }
    }
    fun toggleAutoSms(enabled: Boolean) {
        if (!enabled) {
            AutoSmsSettings.setEnabled(context, false)
            autoSmsEnabled = false
            return
        }
        val perms = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)
        val allGranted = perms.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) {
            AutoSmsSettings.setEnabled(context, true)
            autoSmsEnabled = true
        } else {
            smsAutoPermissionLauncher.launch(perms)
        }
    }
    // اعلان پیامک → باز کردن دیالوگ دسته‌بندی
    LaunchedEffect(Unit) {
        SmsPendingBus.openRequest.collect { requestedId ->
            if (!requestedId.isNullOrBlank()) {
                SmsPendingBus.consume()
                if (PendingSmsStore.current(context).isNotEmpty()) {
                    showPendingCategorize = true
                }
            }
        }
    }

    val currentPeriod = PersianDateFormatter.currentJalaliMonthKey()
    val activeAccounts = remember(accounts) { accounts.filter { !it.isDeleted } }
    val reportAccounts = remember(accounts) { accounts.filter { !it.isDeleted && it.id.isNotBlank() } }
    val reportTransactions = remember(transactions) { transactions.filter { it.id.isNotBlank() } }
    val accountsById = remember(accounts) { accounts.associateBy { it.id } }
    val periodBudgets = remember(budgets, currentPeriod) { budgets.filter { it.periodKey == currentPeriod } }
    val activeTransactionsExist = remember(transactions) { transactions.any { !it.isDeleted } }
    val recentTransactions = remember(transactions) {
        transactions.filter { !it.isDeleted && it.id.isNotBlank() }
            .sortedByDescending { it.occurredAt }
            .take(100)
    }
    val totalBalance = remember(activeAccounts, transactions) {
        runCatching { FinanceCalculator.totalBalance(activeAccounts, transactions) }.getOrDefault(0L)
    }
    val periodTotals = remember(transactions, currentPeriod) {
        runCatching { FinanceCalculator.periodTotals(transactions, currentPeriod) }
            .getOrDefault(FinanceCalculator.PeriodTotals(0L, 0L))
    }
    val monthIncome = periodTotals.income
    val monthExpense = periodTotals.expense
    val openDebts = remember(debts) { debts.filter { it.settledAt == null } }
    val debtTotals = remember(openDebts, ownDeviceId) {
        var owedToMe = 0L
        var iOwe = 0L
        openDebts.forEach { debt ->
            if (debt.creditorDeviceId == ownDeviceId) owedToMe += debt.amount
            if (debt.debtorDeviceId == ownDeviceId) iOwe += debt.amount
        }
        owedToMe to iOwe
    }
    val owedToMe = debtTotals.first
    val iOwe = debtTotals.second
    var showAccountDialog by remember { mutableStateOf(false) }
    var showTransactionDialog by remember { mutableStateOf(false) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    var showDebtDialog by remember { mutableStateOf(false) }
    var showRecurringDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = financeTab == 0, onClick = { financeTab = 0 }, label = { Text("مالی") })
            FilterChip(selected = financeTab == 1, onClick = { financeTab = 1 }, label = { Text("گزارش") })
            FilterChip(selected = financeTab == 2, onClick = { financeTab = 2 }, label = { Text("خرید") })
        }
        if (financeTab == 2) {
            FinanceShoppingPanel(
                items = shoppingItems,
                onToggle = onToggleShopping,
                onDelete = onDeleteShopping,
                onClearChecked = onClearCheckedShopping,
                onAddClick = { showAddShopping = true }
            )
        } else if (financeTab == 1) {
            FinanceReportsPanel(
                accounts = reportAccounts,
                transactions = reportTransactions,
                budgets = budgets,
                currentPeriod = currentPeriod
            )
        } else {
        Box(Modifier.weight(1f).fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                FinanceHero(
                    totalBalance = totalBalance,
                    income = monthIncome,
                    expense = monthExpense
                )
            }
            item {
                FinanceFlowChart(transactions = transactions)
            }
            item {
                CategoryBreakdownCard(transactions = transactions, periodKey = currentPeriod)
            }
            item {
                BudgetAlertBanner(
                    budgets = periodBudgets,
                    transactions = transactions,
                    periodKey = currentPeriod
                )
            }
            item {
                AutoSmsControlCard(
                    enabled = autoSmsEnabled,
                    pendingCount = pendingSms.size,
                    onToggle = ::toggleAutoSms,
                    onReviewPending = { showPendingCategorize = true }
                )
            }
            item {
                QuickFinanceActions(
                    onAccount = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        showAccountDialog = true
                    },
                    onTransaction = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (accounts.isEmpty()) showAccountDialog = true else showTransactionDialog = true
                    },
                    onBudget = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        showBudgetDialog = true
                    },
                    onDebt = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        showDebtDialog = true
                    },
                    onRecurring = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (accounts.isEmpty()) showAccountDialog = true else showRecurringDialog = true
                    },
                    onSmsImport = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        requestSmsImport()
                    }
                )
            }
            item {
                SectionHeader("حساب‌های مشترک", "${PersianDateFormatter.toPersianDigits(accounts.size)} حساب")
            }
            if (accounts.isEmpty()) {
                item { EmptyAccounts(onClick = { showAccountDialog = true }) }
            } else {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(accounts, key = { it.id }) { account ->
                            val accountBalance = runCatching { FinanceCalculator.accountBalance(account, transactions) }.getOrDefault(account.openingBalance)
                            AccountCard(
                                account = account,
                                balance = accountBalance,
                                onCorrectBalance = { target -> onCorrectAccountBalance(account, target) }
                            )
                        }
                    }
                }
            }
            item {
                SectionHeader(
                    "حساب دونفره",
                    if (openDebts.isEmpty()) "بدهی بازی ندارید"
                    else "طلب من ${PersianDateFormatter.formatMoney(owedToMe)} • بدهی من ${PersianDateFormatter.formatMoney(iOwe)}"
                )
            }
            if (debts.isEmpty()) {
                item { EmptyFinanceFeature("هنوز بدهی دونفره‌ای ثبت نشده است.", "ثبت بدهی", onClick = { showDebtDialog = true }) }
            } else {
                items(debts.take(30), key = { "debt-${it.id}" }) { debt ->
                    DebtCard(
                        debt = debt,
                        ownDeviceId = ownDeviceId,
                        onToggleSettled = { onToggleDebtSettled(debt) },
                        onDelete = { runCatching { onDeleteDebt(debt) } },
                        onShare = { onShareDebtToChat(debt) }
                    )
                }
            }
            item {
                SectionHeader("تراکنش‌های تکرارشونده", if (recurringTransactions.isEmpty()) "پرداخت خودکار ثبت نشده" else "زمان‌بندی بر پایه تقویم شمسی")
            }
            if (recurringTransactions.isEmpty()) {
                item {
                    EmptyFinanceFeature(
                        "حقوق، اجاره یا هزینه‌های ثابت را زمان‌بندی کنید.",
                        "زمان‌بندی جدید",
                        onClick = { if (accounts.isEmpty()) showAccountDialog = true else showRecurringDialog = true }
                    )
                }
            } else {
                items(recurringTransactions.take(30), key = { "recurring-${it.id}" }) { rule ->
                    RecurringCard(
                        rule = rule,
                        accountName = accountsById[rule.accountId]?.name ?: "حساب حذف‌شده",
                        onToggle = { onToggleRecurring(rule) },
                        onDelete = { runCatching { onDeleteRecurring(rule) } }
                    )
                }
            }
            item {
                SectionHeader("بودجه این ماه", PersianDateFormatter.currentJalaliMonthLabel())
            }
            if (periodBudgets.isEmpty()) {
                item { EmptyBudget(onClick = { showBudgetDialog = true }) }
            } else {
                items(periodBudgets, key = { it.id }) { budget ->
                    val spent = FinanceCalculator.categoryExpense(transactions, currentPeriod, budget.category)
                    BudgetCard(budget, spent)
                }
            }
            item {
                SectionHeader(
                    "تراکنش‌های اخیر",
                    if (!activeTransactionsExist) "بدون تراکنش" else "آخرین تغییرات"
                )
            }
            if (!activeTransactionsExist) {
                item {
                    EmptyTransactions(
                        onClick = {
                            if (accounts.isEmpty()) showAccountDialog = true
                            else showTransactionDialog = true
                        }
                    )
                }
            } else {
                items(
                    items = recentTransactions,
                    key = { "tx-${it.id}" }
                ) { transaction ->
                    key(transaction.id) {
                        val safeName = accountsById[transaction.accountId]?.name
                            ?: "حساب حذف‌شده"
                        val safeTarget = transaction.targetAccountId
                            ?.takeIf { it.isNotBlank() }
                            ?.let { id -> accountsById[id]?.name }
                        val canDelete = runCatching { !transaction.isSmsLocked }.getOrDefault(true)
                        TransactionCard(
                            transaction = transaction,
                            accountName = safeName,
                            targetAccountName = safeTarget,
                            onDelete = if (canDelete) {
                                { runCatching { onDeleteTransaction(transaction) }; Unit }
                            } else null
                        )
                    }
                }
            }
        }
            if (accounts.isNotEmpty()) {
                FloatingActionButton(
                    onClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        showTransactionDialog = true
                    },
                    modifier = Modifier.align(Alignment.BottomStart).padding(20.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Icon(Icons.Default.Add, "تراکنش جدید", tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        } // Box
        } // else financeTab 0
    if (showAddShopping) {
        FinanceAddShoppingDialog(
            existingItems = shoppingItems,
            onDismiss = { showAddShopping = false },
            onAdd = { title, qty, cat, rec ->
                onAddShopping(title, qty, cat, rec)
                showAddShopping = false
            }
        )
    }
    if (showSmsImport) {
        SmsImportReviewDialog(
            candidates = smsCandidates,
            accounts = activeAccounts,
            scanning = smsScanning,
            errorMessage = smsError,
            onDismiss = { showSmsImport = false; smsError = null },
            onImport = { selected, accountId ->
                selected.forEach { row ->
                    onAddTransactionAt(
                        accountId,
                        null,
                        row.kind,
                        row.amount,
                        row.category,
                        row.note,
                        row.dateMillis,
                        "SMS"
                    )
                }
                SmsTransactionImporter.markImported(context, selected.map { it.smsId })
                showSmsImport = false
                smsCandidates = emptyList()
            }
        )
    }
    if (showPendingCategorize && pendingSms.isNotEmpty()) {
        SmsCategorizeDialog(
            items = pendingSms,
            accounts = reportAccounts,
            expenseCategories = expenseCategories,
            incomeCategories = incomeCategories,
            onDismiss = { showPendingCategorize = false },
            onConfirm = { item, category, accountId ->
                onAddTransactionAt(
                    accountId,
                    null,
                    item.kind,
                    item.amount,
                    category,
                    item.note,
                    item.dateMillis,
                    "SMS"
                )
                smsScope.launch(Dispatchers.IO) {
                    SmsTransactionImporter.markImported(context, listOf(item.smsKey))
                    PendingSmsStore.remove(context, item.id)
                }
            },
            onSkip = { item ->
                smsScope.launch(Dispatchers.IO) {
                    SmsTransactionImporter.markImported(context, listOf(item.smsKey))
                    PendingSmsStore.remove(context, item.id)
                }
            }
        )
    }
    if (showAccountDialog) {
        AddAccountDialog(
            onDismiss = { showAccountDialog = false },
            onSave = { name, type, opening, color ->
                onAddAccount(name, type, opening, color)
                showAccountDialog = false
            }
        )
    }
    if (showTransactionDialog && accounts.isNotEmpty()) {
        AddTransactionDialog(
            accounts = accounts,
            onDismiss = { showTransactionDialog = false },
            onSave = { accountId, targetAccountId, kind, amount, category, note ->
                onAddTransaction(accountId, targetAccountId, kind, amount, category, note)
                showTransactionDialog = false
            }
        )
    }
    if (showBudgetDialog) {
        AddBudgetDialog(
            periodKey = currentPeriod,
            onDismiss = { showBudgetDialog = false },
            onSave = { category, amount ->
                onSetBudget(category, currentPeriod, amount)
                showBudgetDialog = false
            }
        )
    }
    if (showDebtDialog) {
        AddDebtDialog(
            onDismiss = { showDebtDialog = false },
            onSave = { title, amount, direction, note, dueAt ->
                onAddDebt(title, amount, direction, note, dueAt)
                showDebtDialog = false
            }
        )
    }
    if (showRecurringDialog && accounts.isNotEmpty()) {
        AddRecurringDialog(
            accounts = accounts,
            onDismiss = { showRecurringDialog = false },
            onSave = { accountId, targetId, kind, amount, category, note, interval, firstRunAt ->
                onAddRecurring(accountId, targetId, kind, amount, category, note, interval, firstRunAt)
                showRecurringDialog = false
            }
        )
    }
    } // Column
} // FinanceScreen

@Composable
private fun FinanceHero(totalBalance: Long, income: Long, expense: Long) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val gradient = Brush.linearGradient(
        if (dark) listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer)
        else listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
    )
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(gradient).padding(22.dp)
    ) {
        Box(
            Modifier.size(140.dp).align(Alignment.TopStart).background(Color.White.copy(alpha = .08f), CircleShape)
        )
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("دارایی مشترک", color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .90f) else Color.White.copy(alpha = .88f), style = MaterialTheme.typography.labelLarge)
                    AnimatedContent(
                        targetState = totalBalance,
                        transitionSpec = { (fadeIn() + scaleIn(initialScale = .92f)).togetherWith(fadeOut()) },
                        label = "balance"
                    ) { balance ->
                        Text(
                            PersianDateFormatter.formatMoney(balance),
                            color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
                FloatingMotion {
                    Box(
                        Modifier.size(52.dp).background(Color.White.copy(alpha = .16f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text("✦", color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White, style = MaterialTheme.typography.headlineSmall) }
                }
            }
            Row(Modifier.padding(top = 24.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FinanceMetric("درآمد ماه", income, Color(0xFFB9F6CA), Modifier.weight(1f))
                FinanceMetric("هزینه ماه", expense, Color(0xFFFFCDD2), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FinanceMetric(title: String, amount: Long, accent: Color, modifier: Modifier) {
    Column(
        modifier.background(Color.Black.copy(alpha = .12f), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Text(title, color = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .88f) else Color.White.copy(alpha = .80f), style = MaterialTheme.typography.labelSmall)
        Text(PersianDateFormatter.formatMoney(amount), color = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) accent.copy(alpha = .98f) else accent, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun QuickFinanceActions(
    onAccount: () -> Unit,
    onTransaction: () -> Unit,
    onBudget: () -> Unit,
    onDebt: () -> Unit,
    onRecurring: () -> Unit,
    onSmsImport: () -> Unit = {}
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("دسترسی سریع", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FinanceQuickAction("حساب", Icons.Outlined.AccountBalanceWallet, Modifier.weight(1f), onAccount)
            FinanceQuickAction("تراکنش", Icons.AutoMirrored.Outlined.ReceiptLong, Modifier.weight(1f), onTransaction)
            FinanceQuickAction("بودجه", Icons.Outlined.PieChart, Modifier.weight(1f), onBudget)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FinanceQuickAction("بدهی دونفره", Icons.Outlined.SwapHoriz, Modifier.weight(1f), onDebt)
            FinanceQuickAction("تکرارشونده", Icons.Outlined.Repeat, Modifier.weight(1f), onRecurring)
            FinanceQuickAction("از پیامک", Icons.Outlined.Sms, Modifier.weight(1f), onSmsImport)
        }
    }
}

@Composable
private fun FinanceQuickAction(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Box(
                Modifier.size(42.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary)
            }
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun SectionHeader(title: String, caption: String) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.Bottom) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        Text(caption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun AccountCard(
    account: FinancialAccountEntity,
    balance: Long,
    onCorrectBalance: (Long) -> Unit
) {
    val colors = listOf(
        Color(0xFF7B3F68), Color(0xFF006D77), Color(0xFF386A20),
        Color(0xFF9B4424), Color(0xFF4D5FAD), Color(0xFF6B5778)
    )
    val color = colors[account.colorSeed.mod(colors.size).let { if (it < 0) it + colors.size else it }]
    var showCorrectionDialog by remember(account.id) { mutableStateOf(false) }
    Card(
        modifier = Modifier.width(230.dp),
        shape = RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(Color.White.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
                    Text(if (account.type == "CARD") "▣" else if (account.type == "SAVINGS") "◇" else "●", color = Color.White)
                }
                Text(account.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp).weight(1f), maxLines = 1)
                IconButton(onClick = { showCorrectionDialog = true }) {
                    Icon(Icons.Outlined.Edit, contentDescription = "اصلاح موجودی", tint = Color.White)
                }
            }
            Text("موجودی", color = Color.White.copy(alpha = .7f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 20.dp))
            Text(PersianDateFormatter.formatMoney(balance), color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
        }
    }
    if (showCorrectionDialog) {
        CorrectAccountBalanceDialog(
            accountName = account.name,
            currentBalance = balance,
            onDismiss = { showCorrectionDialog = false },
            onSave = onCorrectBalance
        )
    }

}

@Composable
private fun CorrectAccountBalanceDialog(
    accountName: String,
    currentBalance: Long,
    onDismiss: () -> Unit,
    onSave: (Long) -> Unit
) {
    var amount by remember(currentBalance) { mutableStateOf(currentBalance.toString()) }
    OSFormDialog(
        title = "اصلاح موجودی حساب",
        subtitle = "موجودی واقعی «$accountName» را وارد کنید. این اصلاح تراکنش جدید ایجاد نمی‌کند و فقط مانده حساب را با موجودی واقعی هماهنگ می‌کند.",
        emoji = "💰",
        onDismiss = onDismiss,
        onConfirm = { onSave(parseAmount(amount)); onDismiss() },
        confirmLabel = "ثبت اصلاح",
        confirmEnabled = amount.isNotBlank()
    ) {
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = sanitizeAmountInput(it).take(18) },
            label = { Text("موجودی واقعی به تومان") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
    }
}

@Composable
private fun BudgetCard(budget: FinanceBudgetEntity, spent: Long) {
    val progress = (spent.toFloat() / budget.monthlyLimit.coerceAtLeast(1)).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(progress, label = "budget-progress")
    Card(
        Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(17.dp)) {
            Row {
                Text(categoryEmoji(budget.category), modifier = Modifier.padding(end = 8.dp))
                Text(budget.category, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    "${PersianDateFormatter.formatMoney(spent)} از ${PersianDateFormatter.formatMoney(budget.monthlyLimit)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(8.dp).clip(CircleShape),
                color = if (progress >= .9f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surface
            )
        }
    }
}

@Composable
private fun TransactionCard(
    transaction: FinanceTransactionEntity,
    accountName: String,
    targetAccountName: String?,
    onDelete: (() -> Unit)?
) {
    val kind = transaction.kind.ifBlank { "EXPENSE" }
    val isIncome = kind.equals("INCOME", ignoreCase = true)
    val isTransfer = kind.equals("TRANSFER", ignoreCase = true)
    val category = transaction.category.takeIf { it.isNotBlank() } ?: "سایر"
    val note = transaction.note
    val amount = transaction.amount.coerceAtLeast(0L)
    val whenText = runCatching {
        PersianDateFormatter.formatDateTime(transaction.occurredAt.coerceAtLeast(0L))
    }.getOrElse { "—" }
    val moneyText = runCatching {
        PersianDateFormatter.formatMoney(amount)
    }.getOrElse { amount.toString() }
    var confirmDelete by remember(transaction.id) { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        when {
                            isTransfer -> MaterialTheme.colorScheme.primaryContainer
                            isIncome -> Color(0xFFD8F5DF)
                            else -> MaterialTheme.colorScheme.errorContainer
                        },
                        RoundedCornerShape(18.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    runCatching { categoryEmoji(category) }.getOrDefault("◉"),
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    buildString {
                        append(category)
                        if (transaction.isSmsLocked) append(" · قفل پیامک")
                    },
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val subtitle = buildList {
                    add(
                        if (isTransfer) {
                            "از $accountName به ${targetAccountName ?: "حساب مقصد"}"
                        } else {
                            accountName
                        }
                    )
                    if (transaction.isSmsLocked) {
                        add("مبلغ قابل ویرایش/حذف نیست")
                    } else if (note.isNotBlank()) {
                        add(note)
                    }
                }.joinToString(" • ")
                if (subtitle.isNotBlank()) {
                    Text(
                        subtitle,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    whenText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    (when {
                        isTransfer -> "↔ "
                        isIncome -> "+"
                        else -> "−"
                    }) + moneyText,
                    color = when {
                        isTransfer -> MaterialTheme.colorScheme.primary
                        isIncome -> Color(0xFF237A3B)
                        else -> MaterialTheme.colorScheme.error
                    },
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                if (onDelete != null) {
                    IconButton(
                        onClick = { confirmDelete = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            Icons.Outlined.Delete,
                            contentDescription = "حذف تراکنش",
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                    }
                } else if (transaction.isSmsLocked) {
                    Text(
                        "پیامک",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
    }

    if (confirmDelete && onDelete != null) {
        // دیالوگ ساده Material تا از کرش OSConfirmDialog جلوگیری شود
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف تراکنش؟") },
            text = { Text("این تراکنش از لیست حذف شود؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmDelete = false
                        runCatching { onDelete.invoke() }
                    }
                ) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("انصراف") }
            }
        )
    }
}

@Composable
private fun EmptyAccounts(onClick: () -> Unit) = EmptyFinanceCard(
    title = "اولین حساب را بسازید",
    body = "کارت بانکی، پول نقد یا پس‌انداز مشترک را اضافه کنید.",
    action = "افزودن حساب",
    onClick = onClick
)

@Composable
private fun EmptyBudget(onClick: () -> Unit) = EmptyFinanceCard(
    title = "بودجه‌ای برای این ماه ندارید",
    body = "برای هر دسته سقف مشخص کنید تا روند هزینه‌ها دیده شود.",
    action = "تنظیم بودجه",
    onClick = onClick
)

@Composable
private fun EmptyTransactions(onClick: () -> Unit) = EmptyFinanceCard(
    title = "هنوز تراکنشی ثبت نشده",
    body = "درآمد و هزینه‌های مشترک از اینجا قابل پیگیری هستند.",
    action = "ثبت اولین تراکنش",
    onClick = onClick
)

@Composable
private fun EmptyFinanceCard(title: String, body: String, action: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .78f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).background(
                    MaterialTheme.colorScheme.surface.copy(alpha = .85f),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Text("✦", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(title, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                Text(
                    body,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Text("‹", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun EmptyFinanceFeature(body: String, action: String, onClick: () -> Unit) = EmptyFinanceCard(
    title = action,
    body = body,
    action = action,
    onClick = onClick
)

@Composable
private fun DebtCard(
    debt: SharedDebtEntity,
    ownDeviceId: String,
    onToggleSettled: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit = {}
) {
    val isCreditor = debt.creditorDeviceId == ownDeviceId
    val settled = debt.settledAt != null
    Card(
        Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (settled) MaterialTheme.colorScheme.surfaceVariant
            else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .68f)
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(debt.title, fontWeight = FontWeight.Black)
                    Text(
                        if (settled) "تسویه‌شده" else if (isCreditor) "من طلبکارم" else "من بدهکارم",
                        color = if (settled) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                Text(PersianDateFormatter.formatMoney(debt.amount), fontWeight = FontWeight.Black)
                IconButton(onClick = onShare, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Outlined.Share, "اشتراک در چت", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Outlined.Delete, "حذف بدهی", modifier = Modifier.size(18.dp))
                }
            }
            if (debt.note.isNotBlank()) Text(debt.note, style = MaterialTheme.typography.bodySmall)
            debt.dueAt?.let {
                Text("سررسید: ${runCatching { PersianDateFormatter.formatDate(it) }.getOrDefault("—")}", style = MaterialTheme.typography.labelSmall)
            }
            OutlinedButton(onClick = onToggleSettled, modifier = Modifier.fillMaxWidth()) {
                Text(if (settled) "بازگرداندن به بدهی باز" else "علامت‌گذاری به‌عنوان تسویه‌شده")
            }
        }
    }
}

@Composable
private fun RecurringCard(
    rule: RecurringTransactionEntity,
    accountName: String,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val intervalLabel = when (rule.interval) {
        "WEEKLY" -> "هفتگی"
        "YEARLY" -> "سالانه"
        else -> "ماهانه شمسی"
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("↻", style = MaterialTheme.typography.titleLarge) }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text("${rule.category} • $accountName", fontWeight = FontWeight.Bold)
                Text(
                    "$intervalLabel • اجرای بعدی ${runCatching { PersianDateFormatter.formatDate(rule.nextRunAt) }.getOrDefault("—")}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(PersianDateFormatter.formatMoney(rule.amount), color = MaterialTheme.colorScheme.primary)
            }
            TextButton(onClick = onToggle) { Text(if (rule.isActive) "توقف" else "فعال‌سازی") }
            IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Outlined.Delete, "حذف زمان‌بندی", modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun AddDebtDialog(
    onDismiss: () -> Unit,
    onSave: (String, Long, String, String, Long?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("OWED_TO_ME") }
    var note by remember { mutableStateOf("") }
    var dueAt by remember { mutableStateOf<Long?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }
    OSFormDialog(
        title = "بدهی دونفره جدید",
        emoji = "🤝",
        onDismiss = onDismiss,
        onConfirm = { onSave(title, parseAmount(amount), direction, note, dueAt) },
        confirmLabel = "ثبت بدهی",
        confirmEnabled = title.isNotBlank() && parseAmount(amount) > 0
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(direction == "OWED_TO_ME", { direction = "OWED_TO_ME" }, label = { Text("من طلبکارم") })
            FilterChip(direction == "I_OWE", { direction = "I_OWE" }, label = { Text("من بدهکارم") })
        }
        OutlinedTextField(title, { title = it.take(200) }, label = { Text("عنوان") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            amount,
            { amount = sanitizeAmountInput(it) },
            label = { Text("مبلغ به تومان") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(note, { note = it.take(1_000) }, label = { Text("یادداشت اختیاری") }, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
            Text(dueAt?.let { "سررسید: ${PersianDateFormatter.formatDate(it)}" } ?: "انتخاب سررسید اختیاری")
        }
        if (dueAt != null) TextButton(onClick = { dueAt = null }) { Text("حذف سررسید") }
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "انتخاب سررسید شمسی",
            initialEpochMillis = dueAt ?: System.currentTimeMillis(),
            onDismiss = { showDatePicker = false },
            onConfirm = { dueAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun AddRecurringDialog(
    accounts: List<FinancialAccountEntity>,
    onDismiss: () -> Unit,
    onSave: (String, String?, String, Long, String, String, String, Long) -> Unit
) {
    val expenseCategories = CategoryPreferences.expenseCategories(LocalContext.current)
    val incomeCategories = CategoryPreferences.incomeCategories(LocalContext.current)

    var accountId by remember { mutableStateOf(accounts.first().id) }
    var kind by remember { mutableStateOf("EXPENSE") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(expenseCategories.firstOrNull() ?: "سایر") }
    var note by remember { mutableStateOf("") }
    var interval by remember { mutableStateOf("MONTHLY") }
    var firstRunAt by remember { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val categories = if (kind == "INCOME") incomeCategories else expenseCategories
    OSFormDialog(
        title = "تراکنش تکرارشونده",
        emoji = "🔄",
        onDismiss = onDismiss,
        onConfirm = { onSave(accountId, null, kind, parseAmount(amount), category, note, interval, firstRunAt) },
        confirmLabel = "ذخیره زمان‌بندی",
        confirmEnabled = parseAmount(amount) > 0
    ) {
LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        FilterChip(kind == "EXPENSE", { kind = "EXPENSE"; category = expenseCategories.firstOrNull() ?: "سایر" }, label = { Text("هزینه") })
                        FilterChip(kind == "INCOME", { kind = "INCOME"; category = incomeCategories.firstOrNull() ?: "سایر" }, label = { Text("درآمد") })
                    }
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(accounts, key = { it.id }) { account ->
                            FilterChip(accountId == account.id, { accountId = account.id }, label = { Text(account.name) })
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        amount,
                        { amount = sanitizeAmountInput(it) },
                        label = { Text("مبلغ به تومان") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(categories) { item ->
                            FilterChip(category == item, { category = item }, label = { Text(item) })
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("WEEKLY" to "هفتگی", "MONTHLY" to "ماهانه", "YEARLY" to "سالانه").forEach { option ->
                            FilterChip(interval == option.first, { interval = option.first }, label = { Text(option.second) })
                        }
                    }
                }
                item {
                    OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("اولین اجرا: ${PersianDateFormatter.formatDate(firstRunAt)}")
                    }
                }
                item { OutlinedTextField(note, { note = it.take(1_000) }, label = { Text("یادداشت اختیاری") }, modifier = Modifier.fillMaxWidth()) }
            }
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "اولین اجرای تراکنش",
            initialEpochMillis = firstRunAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { firstRunAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun AddAccountDialog(onDismiss: () -> Unit, onSave: (String, String, Long, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var opening by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("CARD") }
    var color by remember { mutableStateOf(0) }
    OSFormDialog(
        title = "حساب جدید",
        emoji = "🏦",
        onDismiss = onDismiss,
        onConfirm = { onSave(name.trim(), type, parseAmount(opening), color) },
        confirmLabel = "ساخت حساب",
        confirmEnabled = name.isNotBlank()
    ) {
OutlinedTextField(name, { name = it.take(120) }, label = { Text("نام حساب") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(
                    opening,
                    { opening = sanitizeAmountInput(it) },
                    label = { Text("موجودی اولیه به تومان") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Text("نوع حساب", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("CARD" to "کارت", "CASH" to "نقدی", "SAVINGS" to "پس‌انداز").forEach { item ->
                        FilterChip(selected = type == item.first, onClick = { type = item.first }, label = { Text(item.second) })
                    }
                }
                Text("رنگ کارت", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(0xFF7B3F68, 0xFF006D77, 0xFF386A20, 0xFF9B4424, 0xFF4D5FAD, 0xFF6B5778).forEachIndexed { index, value ->
                        Box(
                            Modifier.size(if (color == index) 34.dp else 30.dp)
                                .background(Color(value), CircleShape)
                                .clickable { color = index }
                        )
                    }
                }
    }
}

@Composable
private fun AddTransactionDialog(
    accounts: List<FinancialAccountEntity>,
    onDismiss: () -> Unit,
    onSave: (String, String?, String, Long, String, String) -> Unit
) {
    val expenseCategories = CategoryPreferences.expenseCategories(LocalContext.current)
    val incomeCategories = CategoryPreferences.incomeCategories(LocalContext.current)

    val safeAccounts = remember(accounts) { accounts.filter { !it.isDeleted } }
    // همهٔ stateها قبل از هر return تا ترتیب Hook ثابت بماند
    var selectedAccount by remember {
        mutableStateOf(safeAccounts.firstOrNull()?.id.orEmpty())
    }
    var selectedTarget by remember {
        mutableStateOf<String?>(safeAccounts.getOrNull(1)?.id)
    }
    var kind by remember { mutableStateOf("EXPENSE") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(expenseCategories.firstOrNull() ?: "سایر") }
    var note by remember { mutableStateOf("") }
    LaunchedEffect(kind) {
        val list = when (kind) {
            "INCOME" -> incomeCategories
            "TRANSFER" -> listOf("انتقال")
            else -> expenseCategories
        }
        if (category !in list) category = list.firstOrNull() ?: "سایر"
    }
    LaunchedEffect(safeAccounts) {
        if (safeAccounts.isEmpty()) {
            onDismiss()
            return@LaunchedEffect
        }
        if (safeAccounts.none { it.id == selectedAccount }) {
            selectedAccount = safeAccounts.first().id
        }
        if (selectedTarget != null && safeAccounts.none { it.id == selectedTarget }) {
            selectedTarget = safeAccounts.firstOrNull { it.id != selectedAccount }?.id
        }
    }
    if (safeAccounts.isEmpty()) {
        return
    }
    val categories = when (kind) {
        "INCOME" -> incomeCategories
        "TRANSFER" -> listOf("انتقال")
        else -> expenseCategories
    }
    val parsed = parseAmount(amount)
    val transferOk = kind != "TRANSFER" || (selectedTarget != null && selectedTarget != selectedAccount)
    OSFormDialog(
        title = "تراکنش جدید",
        emoji = "💳",
        onDismiss = onDismiss,
        onConfirm = {
            if (parsed > 0 && transferOk) {
                onSave(selectedAccount, selectedTarget, kind, parsed, category.ifBlank { "سایر" }, note)
            }
        },
        confirmLabel = "ثبت تراکنش",
        confirmEnabled = parsed > 0 && transferOk
    ) {
        // OSFormDialog already wraps content in a bounded (56% screen height),
        // vertically scrollable Column. Nesting another verticalScroll here made the
        // inner Column measure with infinite max-height constraints and crashed the app
        // ("Vertically scrollable component was measured with an infinity maximum
        // height constraints") the moment the transaction dialog opened.
        Column(
            Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = kind == "EXPENSE",
                    onClick = { kind = "EXPENSE"; category = expenseCategories.firstOrNull() ?: "سایر" },
                    label = { Text("هزینه") }
                )
                FilterChip(
                    selected = kind == "INCOME",
                    onClick = { kind = "INCOME"; category = incomeCategories.firstOrNull() ?: "سایر" },
                    label = { Text("درآمد") }
                )
                FilterChip(
                    selected = kind == "TRANSFER",
                    enabled = safeAccounts.size > 1,
                    onClick = {
                        kind = "TRANSFER"
                        category = "انتقال"
                        selectedTarget = safeAccounts.firstOrNull { it.id != selectedAccount }?.id
                    },
                    label = { Text("انتقال") }
                )
            }
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = sanitizeAmountInput(it) },
                label = { Text("مبلغ به تومان") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Text("حساب", style = MaterialTheme.typography.labelLarge)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                safeAccounts.forEach { account ->
                    FilterChip(
                        selected = selectedAccount == account.id,
                        onClick = {
                            selectedAccount = account.id
                            if (selectedTarget == account.id) {
                                selectedTarget = safeAccounts.firstOrNull { it.id != account.id }?.id
                            }
                        },
                        label = { Text(account.name) }
                    )
                }
            }
            if (kind == "TRANSFER") {
                Text("حساب مقصد", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    safeAccounts.filter { it.id != selectedAccount }.forEach { account ->
                        FilterChip(
                            selected = selectedTarget == account.id,
                            onClick = { selectedTarget = account.id },
                            label = { Text(account.name) }
                        )
                    }
                }
            }
            if (kind != "TRANSFER") {
                Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { item ->
                        FilterChip(
                            selected = category == item,
                            onClick = { category = item },
                            label = { Text("${categoryEmoji(item)} $item") }
                        )
                    }
                }
            }
            OutlinedTextField(
                value = note,
                onValueChange = { note = it.take(500) },
                label = { Text("یادداشت اختیاری") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )
        }
    }
}

@Composable
private fun AddBudgetDialog(periodKey: String, onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    val expenseCategories = CategoryPreferences.expenseCategories(LocalContext.current)

    var category by remember { mutableStateOf(expenseCategories.firstOrNull() ?: "سایر") }
    var amount by remember { mutableStateOf("") }
    OSFormDialog(
        title = "بودجه ${PersianDateFormatter.currentJalaliMonthLabel()}",
        emoji = "📊",
        onDismiss = onDismiss,
        onConfirm = { onSave(category, parseAmount(amount)) },
        confirmLabel = "ذخیره بودجه",
        confirmEnabled = parseAmount(amount) > 0
    ) {
Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(expenseCategories) { item ->
                        FilterChip(selected = category == item, onClick = { category = item }, label = { Text("${categoryEmoji(item)} $item") })
                    }
                }
                OutlinedTextField(
                    amount,
                    { amount = sanitizeAmountInput(it) },
                    label = { Text("سقف ماهانه به تومان") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Text("شناسه دوره: ${PersianDateFormatter.toPersianDigits(periodKey)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
    }
}

private fun categoryEmoji(category: String): String = when (category.trim()) {
    "خوراک" -> "🍽️"
    "خانه" -> "🏠"
    "رفت‌وآمد" -> "🚕"
    "تفریح" -> "🎬"
    "سلامت" -> "💊"
    "هدیه" -> "🎁"
    "حقوق" -> "💼"
    "پاداش" -> "✨"
    "فروش" -> "🏷️"
    "انتقال" -> "↔️"
    else -> "◉"
}

private fun sanitizeAmountInput(value: String): String = value.mapNotNull { char ->
    when (char) {
        in '0'..'9' -> char
        in '۰'..'۹' -> ('0'.code + (char.code - '۰'.code)).toChar()
        else -> null
    }
}.joinToString("").take(15)

private fun parseAmount(value: String): Long = sanitizeAmountInput(value).toLongOrNull() ?: 0L


@Composable
private fun FinanceFlowChart(transactions: List<FinanceTransactionEntity>) {
    val months = remember(transactions) {
        val keys = mutableListOf<String>()
        repeat(6) { i ->
            val c = java.util.Calendar.getInstance()
            c.add(java.util.Calendar.MONTH, -(5 - i))
            keys += PersianDateFormatter.jalaliMonthKey(c.timeInMillis)
        }
        keys.distinct()
    }
    val flows = remember(transactions, months) {
        months.map { key ->
            val monthRows = transactions.filter { !it.isDeleted && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == key }
            Triple(
                key,
                monthRows.filter { it.kind == "INCOME" }.sumOf { it.amount },
                monthRows.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
            )
        }
    }
    val maxVal = flows.maxOfOrNull { maxOf(it.second, it.third) }?.coerceAtLeast(1L) ?: 1L
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("نمودار تراکنش‌ها", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("مقایسه درآمد و هزینه در ۶ ماه اخیر", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FinanceLegendDot("درآمد", MaterialTheme.colorScheme.primary)
                    FinanceLegendDot("هزینه", MaterialTheme.colorScheme.error)
                }
            }
            val primaryColor = MaterialTheme.colorScheme.primary
            val errorColor = MaterialTheme.colorScheme.error
            Canvas(Modifier.fillMaxWidth().height(170.dp).padding(top = 14.dp)) {
                val n = flows.size.coerceAtLeast(1)
                val groupGap = size.width * 0.055f
                val groupWidth = (size.width - groupGap * (n + 1)) / n
                val barGap = 4.dp.toPx()
                val barWidth = (groupWidth - barGap) / 2f
                flows.forEachIndexed { index, (_, income, expense) ->
                    val x = groupGap + index * (groupWidth + groupGap)
                    val incomeH = income.toFloat() / maxVal * size.height * .82f
                    val expenseH = expense.toFloat() / maxVal * size.height * .82f
                    drawRoundRect(
                        color = primaryColor,
                        topLeft = Offset(x, size.height - incomeH),
                        size = Size(barWidth, incomeH),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                    )
                    drawRoundRect(
                        color = errorColor,
                        topLeft = Offset(x + barWidth + barGap, size.height - expenseH),
                        size = Size(barWidth, expenseH),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                flows.forEach { (key, _, _) ->
                    Text(key.takeLast(2).let { PersianDateFormatter.toPersianDigits(it.toIntOrNull() ?: 0) }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun FinanceLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun CategoryBreakdownCard(
    transactions: List<FinanceTransactionEntity>,
    periodKey: String
) {
    val rows = remember(transactions, periodKey) {
        transactions
            .filter { !it.isDeleted && it.kind == "EXPENSE" && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey }
            .groupBy { it.category.ifBlank { "سایر" } }
            .map { (cat, list) -> cat to list.sumOf { it.amount } }
            .sortedByDescending { it.second }
            .take(6)
    }
    if (rows.isEmpty()) return
    val max = rows.first().second.coerceAtLeast(1L)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("هزینه بر اساس دسته (این ماه)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            rows.forEach { (cat, amount) ->
                Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(cat, style = MaterialTheme.typography.bodyMedium)
                        Text(PersianDateFormatter.formatMoney(amount), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    }
                    LinearProgressIndicator(
                        progress = { (amount.toFloat() / max.toFloat()).coerceIn(0.05f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun BudgetAlertBanner(
    budgets: List<FinanceBudgetEntity>,
    transactions: List<FinanceTransactionEntity>,
    periodKey: String
) {
    val alerts = remember(budgets, transactions, periodKey) {
        budgets.mapNotNull { budget ->
            val spent = transactions
                .filter {
                    it.kind == "EXPENSE" &&
                        it.category == budget.category &&
                        PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey &&
                        !it.isDeleted
                }
                .sumOf { it.amount }
            if (budget.monthlyLimit <= 0L) return@mapNotNull null
            val percent = ((spent * 100) / budget.monthlyLimit).toInt()
            if (percent >= 80) budget.category to percent else null
        }
    }
    if (alerts.isEmpty()) return
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = .7f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("هشدار بودجه ماهانه", fontWeight = FontWeight.Bold)
            alerts.forEach { (cat, percent) ->
                Text(
                    "«$cat» به ${PersianDateFormatter.toPersianDigits(percent)}٪ سقف رسیده است.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}




@Composable
private fun AutoSmsControlCard(
    enabled: Boolean,
    pendingCount: Int,
    onToggle: (Boolean) -> Unit,
    onReviewPending: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "ثبت خودکار از پیامک بانکی",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "با رسیدن پیام برداشت/واریز، تراکنش خودکار آماده می‌شود و فقط دسته‌بندی را انتخاب می‌کنید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = enabled, onCheckedChange = onToggle)
            }
            if (pendingCount > 0) {
                HorizontalDivider()
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Outlined.Sms,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        "${PersianDateFormatter.toPersianDigits(pendingCount)} تراکنش پیامکی در انتظار دسته‌بندی",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = onReviewPending) { Text("بررسی") }
                }
            }
        }
    }
}

/**
 * دیالوگ دسته‌بندی تراکنش‌های استخراج‌شده از پیامک. مبلغ، نوع و حساب از قبل آماده است؛
 * کاربر فقط دسته‌بندی را انتخاب و ثبت می‌کند. موارد تأیید/ردشده از صف حذف و مورد بعدی نشان داده می‌شود.
 */
@Composable
private fun SmsCategorizeDialog(
    items: List<PendingSmsTransaction>,
    accounts: List<FinancialAccountEntity>,
    expenseCategories: List<String>,
    incomeCategories: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (PendingSmsTransaction, String, String) -> Unit,
    onSkip: (PendingSmsTransaction) -> Unit
) {
    // همیشه اولین مورد صف؛ با حذف آن، مورد بعدی خودبه‌خود جایگزین می‌شود.
    val item = items.first()
    val categories = if (item.kind == "INCOME") incomeCategories else expenseCategories
    var category by remember(item.id) {
        mutableStateOf(
            item.suggestedCategory.takeIf { it in categories }
                ?: categories.firstOrNull().orEmpty()
        )
    }
    var accountId by remember(item.id) {
        mutableStateOf(
            accounts.firstOrNull { acc ->
                item.bankLabel.isNotBlank() && acc.name.contains(item.bankLabel, ignoreCase = true)
            }?.id ?: accounts.firstOrNull()?.id.orEmpty()
        )
    }
    // جلوگیری از ثبت دوباره با ضربه‌های پشت‌سرهم تا صف تازه شود.
    var busy by remember(item.id) { mutableStateOf(false) }
    val kindFa = if (item.kind == "INCOME") "واریز" else "برداشت"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("دسته‌بندی تراکنش پیامکی", fontWeight = FontWeight.Bold)
                Text(
                    "${PersianDateFormatter.toPersianDigits(items.size)} تراکنش در صف",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "${PersianDateFormatter.formatMoney(item.amount)} تومان · $kindFa",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                val meta = listOfNotNull(
                    item.bankLabel.takeIf { it.isNotBlank() },
                    PersianDateFormatter.formatDate(item.dateMillis).takeIf { it.isNotBlank() }
                ).joinToString(" · ")
                if (meta.isNotBlank()) {
                    Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (item.body.isNotBlank()) {
                    Text(
                        item.body,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 4
                    )
                }
                if (accounts.size > 1) {
                    Text("حساب", style = MaterialTheme.typography.labelLarge)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        accounts.forEach { account ->
                            FilterChip(
                                selected = accountId == account.id,
                                onClick = { accountId = account.id },
                                label = { Text(account.name) }
                            )
                        }
                    }
                } else if (accounts.firstOrNull() != null) {
                    Text(
                        "حساب: ${accounts.first().name}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text("${categoryEmoji(cat)} $cat") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && accountId.isNotBlank(),
                onClick = {
                    if (busy) return@Button
                    busy = true
                    onConfirm(item, category.ifBlank { "سایر" }, accountId)
                }
            ) { Text("ثبت تراکنش") }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(
                    enabled = !busy,
                    onClick = {
                        if (busy) return@TextButton
                        busy = true
                        onSkip(item)
                    }
                ) { Text("رد کردن") }
                TextButton(onClick = onDismiss) { Text("بستن") }
            }
        }
    )
}

@Composable
private fun SmsImportReviewDialog(
    candidates: List<SmsCandidate>,
    accounts: List<FinancialAccountEntity>,
    scanning: Boolean,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onImport: (List<SmsImportRow>, String) -> Unit
) {
    val expenseCategories = CategoryPreferences.expenseCategories(LocalContext.current)
    val incomeCategories = CategoryPreferences.incomeCategories(LocalContext.current)

    data class EditableSms(
        val smsId: String,
        val amount: Long,
        val dateMillis: Long,
        val body: String,
        val note: String,
        val kind: String,
        val category: String,
        val selected: Boolean
    )

    var rows by remember(candidates) {
        mutableStateOf(
            candidates.map { c ->
                EditableSms(
                    smsId = c.smsId,
                    amount = c.parsed.amount,
                    dateMillis = c.dateMillis.takeIf { it > 0L } ?: System.currentTimeMillis(),
                    body = c.body,
                    note = c.parsed.note,
                    kind = c.parsed.kind,
                    category = c.parsed.category,
                    selected = true
                )
            }
        )
    }
    var accountId by remember(accounts) {
        mutableStateOf(accounts.firstOrNull()?.id.orEmpty())
    }
    val selectedCount = rows.count { it.selected }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ورود تراکنش از پیامک", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
            ) {
                Text(
                    "نوع و دسته‌بندی هر مورد را خودتان تأیید یا اصلاح کنید. پیامک‌ها فقط روی همین گوشی خوانده می‌شوند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (scanning) {
                    Text("در حال بررسی پیامک‌ها…", modifier = Modifier.padding(top = 12.dp))
                }
                if (errorMessage != null && rows.isEmpty()) {
                    Text(errorMessage, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                }
                if (accounts.isNotEmpty()) {
                    Text("حساب مقصد", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 10.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        accounts.forEach { account ->
                            FilterChip(
                                selected = accountId == account.id,
                                onClick = { accountId = account.id },
                                label = { Text(account.name) }
                            )
                        }
                    }
                }
                if (rows.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(onClick = {
                            rows = rows.map { it.copy(selected = true) }
                        }) { Text("همه") }
                        TextButton(onClick = {
                            rows = rows.map { it.copy(selected = false) }
                        }) { Text("هیچ‌کدام") }
                    }
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        items(rows, key = { it.smsId }) { item ->
                            val categories = if (item.kind == "INCOME") incomeCategories else expenseCategories
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (item.selected)
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                    else MaterialTheme.colorScheme.surfaceContainerLow
                                )
                            ) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = item.selected,
                                            onCheckedChange = { checked ->
                                                rows = rows.map {
                                                    if (it.smsId == item.smsId) it.copy(selected = checked) else it
                                                }
                                            }
                                        )
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                PersianDateFormatter.formatMoney(item.amount),
                                                fontWeight = FontWeight.Black
                                            )
                                            Text(
                                                "مبلغ از پیامک — قابل تغییر نیست",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.error
                                            )
                                            Text(
                                                PersianDateFormatter.formatDateTime(item.dateMillis),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        item.body.replace("\n", " ").take(110),
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text("نوع تراکنش", style = MaterialTheme.typography.labelMedium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        FilterChip(
                                            selected = item.kind == "EXPENSE",
                                            onClick = {
                                                rows = rows.map {
                                                    if (it.smsId != item.smsId) it
                                                    else it.copy(
                                                        kind = "EXPENSE",
                                                        category = if (it.category in expenseCategories) it.category
                                                        else expenseCategories.first()
                                                    )
                                                }
                                            },
                                            label = { Text("هزینه") }
                                        )
                                        FilterChip(
                                            selected = item.kind == "INCOME",
                                            onClick = {
                                                rows = rows.map {
                                                    if (it.smsId != item.smsId) it
                                                    else it.copy(
                                                        kind = "INCOME",
                                                        category = if (it.category in incomeCategories) it.category
                                                        else incomeCategories.first()
                                                    )
                                                }
                                            },
                                            label = { Text("درآمد") }
                                        )
                                    }
                                    Text("دسته‌بندی", style = MaterialTheme.typography.labelMedium)
                                    Row(
                                        Modifier.horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        categories.forEach { cat ->
                                            FilterChip(
                                                selected = item.category == cat,
                                                onClick = {
                                                    rows = rows.map {
                                                        if (it.smsId == item.smsId) it.copy(category = cat) else it
                                                    }
                                                },
                                                label = { Text("${categoryEmoji(cat)} $cat") }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val chosen = rows.filter { it.selected }.map {
                        SmsImportRow(
                            smsId = it.smsId,
                            amount = it.amount,
                            kind = it.kind,
                            category = it.category,
                            note = it.note,
                            dateMillis = it.dateMillis
                        )
                    }
                    if (chosen.isNotEmpty() && accountId.isNotBlank()) {
                        onImport(chosen, accountId)
                    }
                },
                enabled = selectedCount > 0 && accountId.isNotBlank() && !scanning
            ) {
                Text("ثبت " + PersianDateFormatter.toPersianDigits(selectedCount) + " مورد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("بستن") }
        }
    )
}

/** ردیف تأییدشده برای ورود از پیامک */
private data class SmsImportRow(
    val smsId: String,
    val amount: Long,
    val kind: String,
    val category: String,
    val note: String,
    val dateMillis: Long
)


@Composable
private fun FinanceReportsPanel(
    accounts: List<FinancialAccountEntity>,
    transactions: List<FinanceTransactionEntity>,
    budgets: List<FinanceBudgetEntity>,
    currentPeriod: String
) {
    var rangeMonths by remember { mutableIntStateOf(6) } // 1, 3, 6
    val active = remember(transactions) { transactions.filter { !it.isDeleted } }
    val periodKeys = remember(rangeMonths) {
        (0 until rangeMonths).map { i ->
            val c = java.util.Calendar.getInstance()
            c.add(java.util.Calendar.MONTH, -(rangeMonths - 1 - i))
            PersianDateFormatter.jalaliMonthKey(c.timeInMillis)
        }.distinct()
    }
    val rangeTx = remember(active, periodKeys) {
        active.filter { PersianDateFormatter.jalaliMonthKey(it.occurredAt) in periodKeys }
    }
    val incomeTotal = rangeTx.filter { it.kind == "INCOME" }.sumOf { it.amount }
    val expenseTotal = rangeTx.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
    val net = incomeTotal - expenseTotal
    val monthTotals = remember(active, currentPeriod) {
        FinanceCalculator.periodTotals(active, currentPeriod)
    }
    val categoryRows = remember(rangeTx) {
        rangeTx.filter { it.kind == "EXPENSE" }
            .groupBy { it.category.ifBlank { "سایر" } }
            .map { (cat, list) -> cat to list.sumOf { it.amount } }
            .sortedByDescending { it.second }
    }
    val monthlyBars = remember(active, periodKeys) {
        periodKeys.map { key ->
            val rows = active.filter { PersianDateFormatter.jalaliMonthKey(it.occurredAt) == key }
            Triple(
                key,
                rows.filter { it.kind == "INCOME" }.sumOf { it.amount },
                rows.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
            )
        }
    }
    val dailyExpense = remember(active, currentPeriod) {
        active.filter {
            it.kind == "EXPENSE" && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == currentPeriod
        }.groupBy {
            PersianDateFormatter.jalaliDate(it.occurredAt).day
        }.map { (day, list) -> day to list.sumOf { t -> t.amount } }
            .sortedBy { it.first }
    }
    val topExpenses = remember(rangeTx) {
        rangeTx.filter { it.kind == "EXPENSE" }
            .sortedByDescending { it.amount }
            .take(8)
    }
    val accountBalances = remember(accounts, active) {
        accounts.map { acc ->
            acc.name to FinanceCalculator.accountBalance(acc, active)
        }.sortedByDescending { it.second }
    }
    val budgetRows = remember(budgets, active, currentPeriod) {
        budgets.filter { it.periodKey == currentPeriod && !it.isDeleted }.map { b ->
            val spent = FinanceCalculator.categoryExpense(active, currentPeriod, b.category)
            Triple(b.category, spent, b.monthlyLimit)
        }
    }

    val primary = MaterialTheme.colorScheme.primary
    val error = MaterialTheme.colorScheme.error
    val tertiary = MaterialTheme.colorScheme.tertiary
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("گزارش‌های تفصیلی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(
                "تحلیل درآمد، هزینه و روند ماهانه",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1 to "این ماه", 3 to "۳ ماه", 6 to "۶ ماه").forEach { (m, label) ->
                    FilterChip(
                        selected = rangeMonths == m,
                        onClick = { rangeMonths = m },
                        label = { Text(label) }
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ReportStatCard(
                    title = "درآمد",
                    value = PersianDateFormatter.formatMoney(incomeTotal),
                    color = primary,
                    modifier = Modifier.weight(1f)
                )
                ReportStatCard(
                    title = "هزینه",
                    value = PersianDateFormatter.formatMoney(expenseTotal),
                    color = error,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            ReportStatCard(
                title = if (net >= 0) "مانده مثبت دوره" else "کسری دوره",
                value = PersianDateFormatter.formatMoney(kotlin.math.abs(net)),
                color = if (net >= 0) tertiary else error,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("سهم درآمد و هزینه", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "این ماه: درآمد ${PersianDateFormatter.formatMoney(monthTotals.income)} · هزینه ${PersianDateFormatter.formatMoney(monthTotals.expense)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val totalPie = (incomeTotal + expenseTotal).coerceAtLeast(1L)
                    Canvas(Modifier.fillMaxWidth().height(180.dp).padding(top = 12.dp)) {
                        val stroke = 28.dp.toPx()
                        val r = (size.minDimension - stroke) / 2f
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val incomeSweep = 360f * (incomeTotal.toFloat() / totalPie)
                        val expenseSweep = 360f * (expenseTotal.toFloat() / totalPie)
                        drawCircle(color = surfaceVariant, radius = r, center = c, style = Stroke(width = stroke))
                        if (incomeTotal > 0) {
                            drawArc(
                                color = primary,
                                startAngle = -90f,
                                sweepAngle = incomeSweep,
                                useCenter = false,
                                topLeft = Offset(c.x - r, c.y - r),
                                size = Size(r * 2, r * 2),
                                style = Stroke(width = stroke, cap = StrokeCap.Round)
                            )
                        }
                        if (expenseTotal > 0) {
                            drawArc(
                                color = error,
                                startAngle = -90f + incomeSweep,
                                sweepAngle = expenseSweep,
                                useCenter = false,
                                topLeft = Offset(c.x - r, c.y - r),
                                size = Size(r * 2, r * 2),
                                style = Stroke(width = stroke, cap = StrokeCap.Round)
                            )
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        FinanceLegendDot("درآمد", primary)
                        FinanceLegendDot("هزینه", error)
                    }
                }
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("مقایسه ماهانه", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("درآمد در برابر هزینه", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val maxVal = monthlyBars.maxOfOrNull { maxOf(it.second, it.third) }?.coerceAtLeast(1L) ?: 1L
                    Canvas(Modifier.fillMaxWidth().height(180.dp).padding(top = 12.dp)) {
                        val n = monthlyBars.size.coerceAtLeast(1)
                        val gap = size.width * 0.04f
                        val groupW = (size.width - gap * (n + 1)) / n
                        val barGap = 3.dp.toPx()
                        val barW = ((groupW - barGap) / 2f).coerceAtLeast(4f)
                        monthlyBars.forEachIndexed { index, (_, inc, exp) ->
                            val x0 = gap + index * (groupW + gap)
                            val ih = (inc.toFloat() / maxVal) * (size.height * 0.85f)
                            val eh = (exp.toFloat() / maxVal) * (size.height * 0.85f)
                            drawRoundRect(
                                color = primary,
                                topLeft = Offset(x0, size.height - ih),
                                size = Size(barW, ih.coerceAtLeast(2f)),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = error,
                                topLeft = Offset(x0 + barW + barGap, size.height - eh),
                                size = Size(barW, eh.coerceAtLeast(2f)),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        monthlyBars.forEach { (key, _, _) ->
                            Text(
                                key.takeLast(5),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("هزینه به تفکیک دسته", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    if (categoryRows.isEmpty()) {
                        Text("در این بازه هزینه‌ای نیست", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        val maxCat = categoryRows.first().second.coerceAtLeast(1L)
                        categoryRows.take(10).forEach { (cat, amount) ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${categoryEmoji(cat)} $cat", style = MaterialTheme.typography.bodyMedium)
                                    Text(PersianDateFormatter.formatMoney(amount), fontWeight = FontWeight.SemiBold)
                                }
                                val frac = (amount.toFloat() / maxCat).coerceIn(0.02f, 1f)
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Box(
                                        Modifier
                                            .fillMaxWidth(frac)
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.85f))
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        if (dailyExpense.isNotEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("روند روزانه هزینه (این ماه)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        val maxDay = dailyExpense.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
                        Canvas(Modifier.fillMaxWidth().height(140.dp).padding(top = 12.dp)) {
                            if (dailyExpense.size == 1) {
                                val y = size.height * (1f - dailyExpense[0].second.toFloat() / maxDay)
                                drawCircle(error, radius = 6.dp.toPx(), center = Offset(size.width / 2f, y))
                            } else {
                                val step = size.width / (dailyExpense.size - 1).coerceAtLeast(1)
                                val points = dailyExpense.mapIndexed { i, (_, amt) ->
                                    Offset(
                                        i * step,
                                        size.height * (1f - (amt.toFloat() / maxDay).coerceIn(0f, 1f))
                                    )
                                }
                                for (i in 0 until points.lastIndex) {
                                    drawLine(
                                        color = error.copy(alpha = 0.85f),
                                        start = points[i],
                                        end = points[i + 1],
                                        strokeWidth = 3.dp.toPx(),
                                        cap = StrokeCap.Round
                                    )
                                }
                                points.forEach { p ->
                                    drawCircle(error, radius = 4.dp.toPx(), center = p)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (budgetRows.isNotEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("وضعیت بودجه این ماه", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        budgetRows.forEach { (cat, spent, limit) ->
                            val pct = if (limit > 0) (spent * 100 / limit).toInt().coerceAtMost(999) else 0
                            Column {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(cat)
                                    Text(
                                        "${PersianDateFormatter.toPersianDigits(pct)}٪ · ${PersianDateFormatter.formatMoney(spent)} / ${PersianDateFormatter.formatMoney(limit)}",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { (spent.toFloat() / limit.toFloat().coerceAtLeast(1f)).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                    color = if (pct >= 100) error else if (pct >= 80) tertiary else primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
        if (accountBalances.isNotEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("موجودی حساب‌ها", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        accountBalances.forEach { (name, bal) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name)
                                Text(
                                    PersianDateFormatter.formatMoney(bal),
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (bal >= 0) primary else error
                                )
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("بزرگ‌ترین هزینه‌ها", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    if (topExpenses.isEmpty()) {
                        Text("موردی نیست", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        topExpenses.forEach { tx ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(categoryEmoji(tx.category), modifier = Modifier.padding(end = 8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(tx.category, fontWeight = FontWeight.Medium)
                                    Text(
                                        PersianDateFormatter.formatDate(tx.occurredAt) +
                                            if (tx.note.isNotBlank()) " · ${tx.note.take(30)}" else "",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    "−" + PersianDateFormatter.formatMoney(tx.amount),
                                    color = error,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportStatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = color)
            Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }
}

@Composable
private fun FinanceShoppingPanel(
    items: List<ShoppingItemEntity>,
    onToggle: (ShoppingItemEntity) -> Unit,
    onDelete: (ShoppingItemEntity) -> Unit,
    onClearChecked: () -> Unit,
    onAddClick: () -> Unit
) {
    var itemToDelete by remember { mutableStateOf<ShoppingItemEntity?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    val visible = items.filterNot { it.isDeleted }
    val checkedCount = visible.count { it.isChecked }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (checkedCount > 0) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${PersianDateFormatter.toPersianDigits(checkedCount)} مورد خریداری‌شده",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { confirmClear = true }) { Text("پاک‌سازی خریداری‌شده‌ها") }
                }
            }
            if (visible.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Outlined.ShoppingCart, null, modifier = Modifier.size(56.dp))
                    Text("فهرست خرید خالی است", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
                    Text("اقلام موردنیاز را اینجا اضافه کنید.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visible, key = { it.id }) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onToggle(item) },
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = item.isChecked, onCheckedChange = { onToggle(item) })
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        item.title,
                                        fontWeight = FontWeight.SemiBold,
                                        textDecoration = if (item.isChecked) TextDecoration.LineThrough else null
                                    )
                                    Text(
                                        "${item.quantity} · ${item.category}" + if (item.isRecurring) " · تکرارشونده" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { itemToDelete = item }) {
                                    Icon(Icons.Outlined.Delete, contentDescription = "حذف")
                                }
                            }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = onAddClick,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) { Icon(Icons.Default.Add, "افزودن خرید") }
    }
    itemToDelete?.let { item ->
        OSConfirmDialog(
            title = "حذف از خرید؟",
            message = "«${item.title}» حذف شود؟",
            confirmLabel = "حذف",
            destructive = true,
            onConfirm = { onDelete(item); itemToDelete = null },
            onDismiss = { itemToDelete = null }
        )
    }
    if (confirmClear) {
        OSConfirmDialog(
            title = "پاک‌سازی خریداری‌شده‌ها؟",
            message = "موارد تیک‌خورده از فهرست حذف می‌شوند.",
            confirmLabel = "پاک‌سازی",
            destructive = true,
            onConfirm = { onClearChecked(); confirmClear = false },
            onDismiss = { confirmClear = false }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FinanceAddShoppingDialog(
    existingItems: List<ShoppingItemEntity>,
    onDismiss: () -> Unit,
    onAdd: (String, String, String, Boolean) -> Unit
) {
    val shoppingCategories = CategoryPreferences.shoppingCategories(LocalContext.current)

    var title by remember { mutableStateOf("") }
    var quantity by remember { mutableIntStateOf(1) }
    var category by remember { mutableStateOf("خانه") }
    var recurring by remember { mutableStateOf(false) }
    OSFormDialog(
        title = "افزودن به خرید",
        emoji = "🛒",
        onDismiss = onDismiss,
        onConfirm = {
            if (title.isNotBlank()) {
                onAdd(
                    title.trim(),
                    "${PersianDateFormatter.toPersianDigits(quantity)} عدد",
                    category,
                    recurring
                )
            }
        },
        confirmLabel = "ثبت",
        confirmEnabled = title.isNotBlank()
    ) {
        OutlinedTextField(
            value = title,
            onValueChange = { title = it.take(80) },
            label = { Text("نام کالا") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("تعداد", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (quantity > 1) quantity-- }) { Text("−") }
            Text(
                PersianDateFormatter.toPersianDigits(quantity),
                modifier = Modifier.padding(horizontal = 20.dp),
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { if (quantity < 99) quantity++ }) { Text("+") }
        }
        Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            shoppingCategories.forEach { value ->
                FilterChip(
                    selected = category == value,
                    onClick = { category = value },
                    label = { Text(value) }
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = recurring, onCheckedChange = { recurring = it })
            Text("تکرارشونده", style = MaterialTheme.typography.bodySmall)
        }
    }
}


