package com.ourspace.app.core.reminder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.time.PersianDateFormatter

class HabitReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as? OurSpaceApplication ?: return Result.success()
        val id = inputData.getString(KEY_HABIT_ID) ?: return Result.failure()
        val scheduledClock = inputData.getString(KEY_SCHEDULED_CLOCK)
        val habit = runCatching { app.database.habitDao().findById(id) }.getOrNull()
            ?: return Result.success()
        if (habit.isDeleted) return Result.success()

        // A delayed worker from an older schedule must never notify after the time was edited.
        val currentClock = HabitReminderScheduler.parseClock(habit.scheduleNote)
        val currentToken = currentClock?.let { "%02d:%02d".format(it.first, it.second) }
        if (currentClock == null || (scheduledClock != null && scheduledClock != currentToken)) {
            HabitReminderScheduler.schedule(applicationContext, habit)
            return Result.success()
        }

        val today = PersianDateFormatter.currentJalaliDayKey()
        val perDay = habit.timesPerDay.coerceIn(1, 10)
        val todayCount = if (habit.lastCompletedDayKey == today) habit.completionsToday else 0
        val alreadyDone = habit.kind.equals("HABIT", true) && todayCount >= perDay
        val prefs = applicationContext.getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
        val dedupeKey = "${habit.kind}:${habit.id}"
        val alreadyNotified = prefs.getString(dedupeKey, null) == today
        val notifications = OurSpaceNotificationCenter(applicationContext)
        if (!alreadyDone && !alreadyNotified && notifications.canPostReminders()) {
            notifications.showHabitOrMedicineReminder(habit.kind, habit.id)
            prefs.edit().putString(dedupeKey, today).apply()
        }
        // Always arrange the next local-time occurrence. WorkManager may be delayed by Doze/OEM policy.
        HabitReminderScheduler.schedule(applicationContext, habit)
        return Result.success()
    }

    companion object {
        const val KEY_HABIT_ID = "habit_id"
        const val KEY_SCHEDULED_CLOCK = "scheduled_clock"
        private const val DEDUP_PREFS = "ourspace_notification_dedupe"
    }
}
