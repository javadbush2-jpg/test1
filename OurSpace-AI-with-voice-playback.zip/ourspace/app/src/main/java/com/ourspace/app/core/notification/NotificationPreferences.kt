package com.ourspace.app.core.notification

import android.content.Context

/** A per-device choice for each kind of user-facing OurSpace notification. */
enum class NotificationCategory(
    val key: String,
    val title: String,
    val description: String,
    val defaultEnabled: Boolean
) {
    CHAT_MESSAGES(
        key = "chat_messages",
        title = "پیام جدید گفتگو",
        description = "وقتی پیام تازه‌ای در گفتگوی خصوصی می‌رسد",
        defaultEnabled = true
    ),
    HEART_PULSES(
        key = "heart_pulses",
        title = "قلب «به یادتم»",
        description = "وقتی همراه برای شما تپش قلب می‌فرستد یا آن را تأیید می‌کند",
        defaultEnabled = true
    ),
    SHARED_DATA_UPDATES(
        key = "shared_data_updates",
        title = "تغییر اطلاعات مشترک",
        description = "وقتی داده‌های مشترک از گوشی مقابل به‌روز می‌شوند",
        defaultEnabled = false
    ),
    SYNC_STATUS(
        key = "sync_status",
        title = "وضعیت همگام‌سازی",
        description = "اعلان دربارهٔ تغییرهای منتظر ارسال یا دریافت",
        defaultEnabled = false
    ),
    PARTNER_MOOD_UPDATES(
        key = "partner_mood_updates",
        title = "تغییر حال همراه",
        description = "وقتی حال روزانهٔ همراه به‌روز می‌شود",
        defaultEnabled = false
    ),
    REMINDERS(
        key = "reminders",
        title = "یادآوری‌ها",
        description = "عادت و دارو، کارها، قرار و مناسبت، حال روزانه، چرخه و خرید",
        defaultEnabled = false
    ),
    BUDGET_ALERTS(
        key = "budget_alerts",
        title = "هشدار بودجه",
        description = "وقتی هزینه به آستانهٔ بودجهٔ تعیین‌شده می‌رسد",
        defaultEnabled = false
    )
}

/** Stores notification choices locally; preferences are intentionally not synced between phones. */
object NotificationPreferenceStore {
    private const val PREFERENCES_NAME = "ourspace_notification_preferences"

    fun isEnabled(context: Context, category: NotificationCategory): Boolean =
        preferences(context).getBoolean(category.key, category.defaultEnabled)

    fun readAll(context: Context): Map<NotificationCategory, Boolean> =
        NotificationCategory.values().associateWith { isEnabled(context, it) }

    fun setEnabled(context: Context, category: NotificationCategory, enabled: Boolean) {
        preferences(context).edit().putBoolean(category.key, enabled).apply()
    }

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
}
