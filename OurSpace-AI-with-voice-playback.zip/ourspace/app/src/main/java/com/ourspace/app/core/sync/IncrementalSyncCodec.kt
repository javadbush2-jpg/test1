package com.ourspace.app.core.sync

import androidx.room.withTransaction
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.database.SyncAcknowledgementEntity
import com.ourspace.app.core.database.SyncChangeEntity
import com.ourspace.app.core.database.SyncVersionEntity
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.min

/**
 * Durable incremental synchronization codec.
 *
 * The database is the source of truth for delivery. A change moves through:
 * PENDING -> SENDING -> ACKED(delete). A stale SENDING row becomes eligible again.
 * Entity versions are stored separately so conflict resolution does not require changing
 * every business entity schema.
 */
class IncrementalSyncCodec(
    private val database: OurSpaceDatabase,
    private val localDeviceId: String = ""
) {
    data class PreparedRequest(
        val payload: JSONObject,
        val sentAcknowledgementIds: List<String>,
        val sentChangeCount: Int
    )

    data class RealtimePush(
        val payload: JSONObject,
        val changeIds: List<String>,
        val acknowledgementIds: List<String>,
        val messageId: String
    )

    data class AppliedResponse(
        val receivedChanges: Int,
        val acknowledgedLocalChanges: Int
    )

    /** True only when every incoming entity snapshot is a hidden game-protocol message. */
    fun isGameEventsOnlyDelta(delta: JSONObject): Boolean {
        val changes = delta.optJSONArray("changes") ?: return false
        if (changes.length() == 0) return false
        for (index in 0 until changes.length()) {
            val change = changes.optJSONObject(index) ?: return false
            if (change.optString("entityType") != "messages") return false
            val payload = change.optJSONObject("payload") ?: return false
            if (!GameMessageProtocol.isProtocolMessage(payload.optString("text"))) return false
        }
        return true
    }

    private val snapshotCodec = SyncSnapshotCodec(database)

    suspend fun exportEntityForRealtime(entityType: String, entityId: String): JSONObject? =
        snapshotCodec.exportEntity(entityType, entityId)

    /**
     * Claims only changes that are due. The claim is persisted before network transmission,
     * so process death cannot turn an already-sent item into an unknown state.
     */
    suspend fun prepareRealtimePush(
        messageId: String = UUID.randomUUID().toString(),
        maxDeltaBytes: Int = DEFAULT_MAX_DELTA_BYTES,
        maxChanges: Int = MAX_CHANGES
    ): RealtimePush? = database.withTransaction {
        val now = System.currentTimeMillis()
        val candidates = database.syncChangeDao().due(
            now = now,
            staleBefore = now - IN_FLIGHT_TIMEOUT_MS,
            limit = maxChanges
        )
        if (candidates.isEmpty()) return@withTransaction null

        val selected = ArrayList<SyncChangeEntity>()
        val changes = JSONArray()
        var bytes = 0
        // Only the newest eligible revision per entity is useful to transmit. Older PENDING
        // revisions are safely discarded because the payload is a current entity snapshot.
        val latestByEntity = candidates
            .groupBy { it.entityType to it.entityId }
            .values
            .mapNotNull { rows -> rows.maxByOrNull { it.changedAt } }
            // Chat text and heartbeats first; attachments stay on the dedicated chunk lane.
            .sortedByDescending { change ->
                when (change.entityType) {
                    "messages" -> 1_000
                    "heartPulses" -> 950
                    "tasks", "events", "shopping" -> 700
                    ATTACHMENT_TYPE -> 0
                    else -> 500
                }
            }
        for (change in latestByEntity) {
            // Attachments use the dedicated chunked relay transport. Leave their durable
            // change rows pending for RelayDuplexPoller instead of dropping the binary payload.
            if (change.entityType == ATTACHMENT_TYPE) continue
            val payload = snapshotCodec.exportEntity(change.entityType, change.entityId)
            if (payload == null) {
                database.syncChangeDao().deleteAcknowledged(listOf(change.changeId))
                continue
            }
            val item = JSONObject()
                .put("changeId", change.changeId)
                .put("entityType", change.entityType)
                .put("entityId", change.entityId)
                .put("changedAt", change.changedAt)
                .put("originDeviceId", localDeviceId)
                .put("payload", payload)
            val itemBytes = item.toString().toByteArray(Charsets.UTF_8).size
            if (change.entityType == ATTACHMENT_TYPE && itemBytes > maxDeltaBytes) continue
            if (itemBytes > maxDeltaBytes) {
                database.syncChangeDao().markRetry(
                    listOf(change.changeId), now, now + OVERSIZE_RETRY_MS
                )
                continue
            }
            if (changes.length() > 0 && bytes + itemBytes > maxDeltaBytes) break
            changes.put(item)
            selected += change
            bytes += itemBytes
        }
        val acknowledgementIds = database.syncAcknowledgementDao()
            .pending(MAX_ACKNOWLEDGEMENTS)
            .map { it.changeId }
        if (selected.isEmpty() && acknowledgementIds.isEmpty()) return@withTransaction null

        val attemptNow = System.currentTimeMillis()
        // Remove older unsent revisions for the selected entities. Never touch SENDING rows.
        selected.forEach { change ->
            database.syncChangeDao().coalescePending(change.entityType, change.entityId, change.changeId)
            // ردیف‌های قدیمی‌تر SENDING همان موجودیت را هم پاک کن تا صف گیر نکند
            database.syncChangeDao().deleteOlderForEntity(change.entityType, change.entityId, change.changeId)
        }
        // Persist the local version before network transmission so an equal-timestamp conflict
        // has a deterministic local origin/changeId even after process restart.
        selected.forEach { change ->
            database.syncVersionDao().upsert(
                SyncVersionEntity(
                    change.entityType, change.entityId, change.changedAt,
                    localDeviceId.ifBlank { "local" }, change.changeId, attemptNow
                )
            )
        }
        // Keep SENDING ineligible for a short window. Never call markSending with an empty list
        // (Room throws on empty IN (:ids) and that was blocking ACK-only pushes).
        // Stable transport id for the same set of changeIds so relay retries do not
        // flood the mailbox with duplicate 150KB+ envelopes every few seconds.
        val transportId = if (selected.isNotEmpty()) {
            stableTransportMessageId(selected.map { it.changeId })
        } else {
            messageId.ifBlank { java.util.UUID.randomUUID().toString().replace("-", "") }
        }
        if (selected.isNotEmpty()) {
            val retryAt = attemptNow + IN_FLIGHT_TIMEOUT_MS
            database.syncChangeDao().markSending(
                selected.map { it.changeId }, attemptNow, transportId, retryAt
            )
        }
        RealtimePush(
            payload = JSONObject()
                .put("protocol", DELTA_PROTOCOL)
                .put("schema", DELTA_SCHEMA)
                .put("changes", changes)
                .put("acknowledgements", JSONArray(acknowledgementIds)),
            changeIds = selected.map { it.changeId },
            acknowledgementIds = acknowledgementIds,
            messageId = transportId
        )
    }

    suspend fun claimSpecificChanges(changeIds: List<String>, messageId: String): Boolean = database.withTransaction {
        if (changeIds.isEmpty()) return@withTransaction false
        val now = System.currentTimeMillis()
        val current = changeIds.mapNotNull { database.syncChangeDao().find(it) }
        if (current.size != changeIds.size) return@withTransaction false
        database.syncChangeDao().markSending(
            changeIds, now, messageId, now + retryDelay(current.maxOf { it.attempts + 1 })
        )
        true
    }

    suspend fun markRealtimePushFailed(changeIds: List<String>) {
        val ids = changeIds.filter { it.isNotBlank() }.distinct()
        if (ids.isEmpty()) return
        val now = System.currentTimeMillis()
        database.syncChangeDao().markRetry(
            ids,
            now,
            now + RETRY_AFTER_SEND_FAILURE_MS
        )
    }

    suspend fun prepareRequest(maxDeltaBytes: Int = DEFAULT_MAX_DELTA_BYTES): PreparedRequest = database.withTransaction {
        val changes = database.syncChangeDao().pending(MAX_CHANGES)
        val acknowledgements = database.syncAcknowledgementDao().pending(MAX_ACKNOWLEDGEMENTS)
        val exportedChanges = exportChanges(changes, maxDeltaBytes)
        PreparedRequest(
            payload = JSONObject()
                .put("protocol", DELTA_PROTOCOL)
                .put("schema", DELTA_SCHEMA)
                .put("changes", exportedChanges)
                .put("acknowledgements", JSONArray(acknowledgements.map { it.changeId })),
            sentAcknowledgementIds = acknowledgements.map { it.changeId },
            sentChangeCount = exportedChanges.length()
        )
    }

    suspend fun handleHostRequest(request: JSONObject): JSONObject = database.withTransaction {
        validateDelta(request)
        val remoteAcknowledgements = request.getJSONArray("acknowledgements").stringList(MAX_ACKNOWLEDGEMENTS)
        if (remoteAcknowledgements.isNotEmpty()) {
            database.syncChangeDao().deleteAcknowledged(remoteAcknowledgements)
        }
        val appliedIds = applyChanges(request.getJSONArray("changes"))
        // پاسخ: آخرین نسخه هر موجودیت را بدون قفل SENDING برگردان.
        // ACK این‌ها با acknowledgements در push بعدی peer انجام می‌شود.
        // (قفل SENDING اینجا باعث صف «منتظر تأیید» بدون مسیر ACK تضمینی می‌شد.)
        val now = System.currentTimeMillis()
        val outgoing = database.syncChangeDao().due(
            now = now,
            staleBefore = now - IN_FLIGHT_TIMEOUT_MS,
            limit = MAX_CHANGES
        )
        val latestOutgoing = outgoing
            .groupBy { it.entityType to it.entityId }
            .values
            .mapNotNull { rows -> rows.maxByOrNull { it.changedAt } }
            .filter { it.entityType != ATTACHMENT_TYPE }
            .sortedByDescending { change ->
                when (change.entityType) {
                    "messages" -> 1_000
                    "heartPulses" -> 950
                    "tasks", "events", "shopping" -> 700
                    else -> 500
                }
            }
        val exportedChanges = exportChanges(latestOutgoing, DEFAULT_MAX_DELTA_BYTES)
        JSONObject()
            .put("protocol", DELTA_PROTOCOL)
            .put("schema", DELTA_SCHEMA)
            .put("changes", exportedChanges)
            .put("acknowledgedChanges", JSONArray(appliedIds))
    }

    suspend fun applyRealtimeChanges(changes: JSONArray): List<String> = database.withTransaction {
        applyChanges(changes)
    }

    suspend fun applyRealtimeAttachment(json: JSONObject, changeId: String? = null) = database.withTransaction {
        val miniSnapshot = JSONObject().put("schema", SNAPSHOT_SCHEMA)
            .put("generatedAt", System.currentTimeMillis())
            .put("attachments", JSONArray().put(json))
        val forceEqualKeys = setOf("attachments:${json.getString("id")}")
        snapshotCodec.mergeSnapshot(miniSnapshot, forceEqualKeys)
        changeId?.takeIf { it.isNotBlank() }?.let { database.syncChangeDao().deleteAcknowledged(listOf(it)) }
        if (changeId != null && localDeviceId.isNotBlank()) {
            database.syncVersionDao().upsert(
                SyncVersionEntity("attachments", json.getString("id"), json.optLong("updatedAt"), localDeviceId, changeId, System.currentTimeMillis())
            )
        }
    }

    suspend fun acknowledgeRealtimeChanges(changeIds: List<String>) {
        val ids = changeIds.filter { it.isNotBlank() }.distinct()
        if (ids.isNotEmpty()) {
            database.syncChangeDao().deleteAcknowledged(ids)
        }
    }

    /** Persist ACK ids so lost TYPE_CHANGE_ACK frames can be retried. */
    suspend fun enqueueAcknowledgements(changeIds: List<String>) {
        if (changeIds.isEmpty()) return
        val now = System.currentTimeMillis()
        database.syncAcknowledgementDao().upsertAll(
            changeIds.distinct().map { SyncAcknowledgementEntity(it, now) }
        )
    }

    suspend fun pendingAcknowledgementIds(limit: Int = MAX_ACKNOWLEDGEMENTS): List<String> =
        database.syncAcknowledgementDao().pending(limit).map { it.changeId }

    suspend fun clearSentAcknowledgements(changeIds: List<String>) {
        if (changeIds.isNotEmpty()) {
            database.syncAcknowledgementDao().deleteSent(changeIds)
        }
    }

    suspend fun applyCompanionResponse(
        response: JSONObject,
        sentAcknowledgementIds: List<String>
    ): AppliedResponse = database.withTransaction {
        validateDelta(response, responseMode = true)
        val acknowledgedChanges = response.getJSONArray("acknowledgedChanges").stringList(MAX_CHANGES)
        if (acknowledgedChanges.isNotEmpty()) {
            database.syncChangeDao().deleteAcknowledged(acknowledgedChanges)
        }
        val appliedIds = applyChanges(response.getJSONArray("changes"))
        if (appliedIds.isNotEmpty()) {
            val now = System.currentTimeMillis()
            database.syncAcknowledgementDao().upsertAll(appliedIds.map { SyncAcknowledgementEntity(it, now) })
        }
        if (sentAcknowledgementIds.isNotEmpty()) {
            database.syncAcknowledgementDao().deleteSent(sentAcknowledgementIds)
        }
        AppliedResponse(appliedIds.size, acknowledgedChanges.size)
    }

    private suspend fun exportChanges(changes: List<SyncChangeEntity>, maxDeltaBytes: Int): JSONArray {
        if (changes.isEmpty()) return JSONArray()
        val result = JSONArray()
        var encodedBytes = 0
        val staleChangeIds = ArrayList<String>()
        for (change in changes) {
            if (change.entityType == ATTACHMENT_TYPE) {
                // Binary data is delivered by the dedicated chunked relay lane.
                // Keep this row pending; deleting it here would silently lose images.
                continue
            }
            val payload = snapshotCodec.exportEntity(change.entityType, change.entityId)
            if (payload == null) { staleChangeIds += change.changeId; continue }
            val item = JSONObject()
                .put("changeId", change.changeId)
                .put("entityType", change.entityType)
                .put("entityId", change.entityId)
                .put("changedAt", change.changedAt)
                .put("originDeviceId", localDeviceId)
                .put("payload", payload)
            val itemBytes = item.toString().toByteArray(Charsets.UTF_8).size
            // Oversized non-attachment: skip. Oversized attachment: still skip if beyond hard cap.
            if (itemBytes > maxDeltaBytes) {
                if (change.entityType == ATTACHMENT_TYPE) {
                    // Leave PENDING so a future higher limit / compress can retry; do not block others.
                    continue
                }
                continue
            }
            // Attachments travel alone so one photo does not starve text changes.
            if (change.entityType == ATTACHMENT_TYPE && result.length() > 0) break
            if (result.length() > 0 && change.entityType == ATTACHMENT_TYPE) break
            if (result.length() > 0 && encodedBytes + itemBytes > maxDeltaBytes) break
            result.put(item)
            encodedBytes += itemBytes
            if (change.entityType == ATTACHMENT_TYPE) break
        }
        if (staleChangeIds.isNotEmpty()) database.syncChangeDao().deleteAcknowledged(staleChangeIds)
        return result
    }

    private suspend fun applyChanges(changes: JSONArray): List<String> {
        require(changes.length() <= MAX_CHANGES) { "Too many incremental changes" }
        if (changes.length() == 0) return emptyList()

        val grouped = ENTITY_TYPES.associateWith { JSONArray() }.toMutableMap()
        val appliedIds = ArrayList<String>(changes.length())
        val forceEqualKeys = mutableSetOf<String>()
        for (index in 0 until changes.length()) {
            // One bad item must not abort the whole batch (would leave the sender queue stuck).
            runCatching {
                val change = changes.getJSONObject(index)
                val changeId = change.getString("changeId").take(MAX_ID_LENGTH)
                val entityType = change.getString("entityType")
                val entityId = change.getString("entityId").take(MAX_ID_LENGTH)
                val originDeviceId = change.optString("originDeviceId").take(MAX_ID_LENGTH)
                require(changeId.isNotBlank() && entityType in ENTITY_TYPES && entityId.isNotBlank())
                val payload = change.getJSONObject("payload")
                require(payload.getString("id").take(MAX_ID_LENGTH) == entityId)
                val incomingUpdatedAt = payload.optLong("updatedAt", change.optLong("changedAt"))
                val localVersion = database.syncVersionDao().find(entityType, entityId)
                val localPayload = snapshotCodec.exportEntity(entityType, entityId)
                val localUpdatedAt = localPayload?.optLong("updatedAt", 0L) ?: 0L
                val localOrigin = localVersion?.originDeviceId ?: localDeviceId
                val localChangeId = localVersion?.changeId

                val incomingWins = when {
                    localChangeId == changeId -> false
                    incomingUpdatedAt > localUpdatedAt -> true
                    incomingUpdatedAt < localUpdatedAt -> false
                    else -> compareVersion(originDeviceId, changeId, localOrigin, localChangeId) > 0
                }

                if (incomingWins) {
                    if (incomingUpdatedAt == localUpdatedAt) forceEqualKeys += "$entityType:$entityId"
                    grouped.getValue(entityType).put(payload)
                    appliedIds += changeId
                    database.syncVersionDao().upsert(
                        SyncVersionEntity(entityType, entityId, incomingUpdatedAt, originDeviceId.ifBlank { "remote" }, changeId, System.currentTimeMillis())
                    )
                } else {
                    // Even a stale/duplicate change is safely delivered: ACK it so the sender does
                    // not retry an update that can no longer win the deterministic version ordering.
                    appliedIds += changeId
                }
            }.onFailure { error ->
                android.util.Log.w("IncrementalSyncCodec", "Skipping bad change at index $index", error)
                // Still surface the changeId for ACK when present so the peer can clear its outbox.
                changes.optJSONObject(index)?.optString("changeId")?.takeIf { it.isNotBlank() }?.let { appliedIds += it }
            }
        }

        val miniSnapshot = JSONObject().put("schema", SNAPSHOT_SCHEMA).put("generatedAt", System.currentTimeMillis())
        ENTITY_TYPES.forEach { type -> miniSnapshot.put(type, grouped.getValue(type)) }
        // Remote materialization must NEVER create a new local outbox item. The old trigger
        // behaviour was the main source of echo traffic, queue growth and delayed delivery.
        snapshotCodec.mergeSnapshot(miniSnapshot)
        database.syncChangeDao().deleteAcknowledged(appliedIds)
        return appliedIds
    }

    private fun compareVersion(
        incomingOrigin: String,
        incomingChangeId: String,
        localOrigin: String,
        localChangeId: String?
    ): Int {
        val originCmp = incomingOrigin.compareTo(localOrigin)
        if (originCmp != 0) return originCmp
        return incomingChangeId.compareTo(localChangeId.orEmpty())
    }

    private fun validateDelta(json: JSONObject, responseMode: Boolean = false) {
        require(json.optInt("protocol") == DELTA_PROTOCOL) { "Unsupported sync protocol" }
        require(json.optInt("schema") == DELTA_SCHEMA) { "Unsupported delta schema" }
        require(json.has("changes"))
        require(json.has(if (responseMode) "acknowledgedChanges" else "acknowledgements"))
    }

    private fun JSONArray.stringList(max: Int): List<String> {
        require(length() <= max) { "Too many acknowledgements" }
        return buildList(length()) {
            for (index in 0 until length()) {
                val value = getString(index)
                require(value.length in 1..MAX_ID_LENGTH)
                add(value)
            }
        }
    }

    private fun retryDelay(attempt: Int): Long {
        val exponent = min(attempt.coerceAtLeast(1) - 1, 6)
        return min(MAX_RETRY_DELAY_MS, BASE_RETRY_DELAY_MS * (1L shl exponent))
    }

    companion object {
        const val DELTA_PROTOCOL = 3
        /** Exposed so transport can reclaim SENDING rows on the same schedule. */
        // Shorter window → stuck SENDING clears faster and retries sooner.
        const val IN_FLIGHT_TIMEOUT_MS_PUBLIC = 20_000L
        private const val DELTA_SCHEMA = 1
        private const val SNAPSHOT_SCHEMA = 6
        private const val MAX_CHANGES = 80
        private const val DEFAULT_MAX_DELTA_BYTES = 28 * 1024 * 1024
        private const val ATTACHMENT_TYPE = "attachments"
        private const val MAX_ACKNOWLEDGEMENTS = 1_000
        private const val MAX_ID_LENGTH = 220
        private const val IN_FLIGHT_TIMEOUT_MS = 20_000L
        private const val BASE_RETRY_DELAY_MS = 150L
        private const val MAX_RETRY_DELAY_MS = 3_000L
        private const val OVERSIZE_RETRY_MS = 2_000L
        private const val RETRY_AFTER_SEND_FAILURE_MS = 120L

        fun stableTransportMessageId(changeIds: List<String>): String {
            val material = changeIds.sorted().joinToString("\n")
            val digest = java.security.MessageDigest.getInstance("SHA-256")
                .digest(material.toByteArray(Charsets.UTF_8))
            return digest.joinToString("") { b -> "%02x".format(b) }.take(32)
        }

        val ENTITY_TYPES = setOf(
            "tasks", "events", "shopping", "messages", "financialAccounts", "financeTransactions",
            "financeBudgets", "sharedDebts", "recurringTransactions", "memories", "moodCheckIns",
            "specialDates", "coupleProfile", "cycleLogs", "cycleSettings", "locationShares",
            "heartPulses", "sharedPlaces", "habits", "watchlistItems", "bookItems", "telegramStickerPacks",
            "telegramStickers", ATTACHMENT_TYPE
        )
    }
}
