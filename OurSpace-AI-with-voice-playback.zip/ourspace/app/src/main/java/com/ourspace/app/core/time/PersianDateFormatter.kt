package com.ourspace.app.core.time

import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

object PersianDateFormatter {
    data class JalaliDate(val year: Int, val month: Int, val day: Int)

    /** A calendar-aware occurrence of a saved date, measured in local calendar days. */
    data class DateOccurrence(val daysUntil: Int, val jalaliYear: Int, val epochMillis: Long)

    /**
     * Finds the next occurrence of a special date. Yearly dates follow the Jalali calendar,
     * not the Gregorian month/day. LocalDate arithmetic avoids 23/25-hour DST day errors.
     */
    fun nextSpecialDateOccurrence(occurredAt: Long, repeatYearly: Boolean, nowAt: Long = System.currentTimeMillis()): DateOccurrence? {
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(nowAt).atZone(zone).toLocalDate()
        val source = jalaliDate(occurredAt)
        val todayJalali = jalaliDate(nowAt)
        var targetYear = if (repeatYearly) todayJalali.year else source.year

        fun candidateFor(year: Int): Long = toEpochMillis(
            year, source.month, source.day.coerceAtMost(daysInJalaliMonth(year, source.month)), 12, 0
        )

        var targetAt = candidateFor(targetYear)
        var targetDate = Instant.ofEpochMilli(targetAt).atZone(zone).toLocalDate()
        if (repeatYearly && targetDate.isBefore(today)) {
            targetYear += 1
            targetAt = candidateFor(targetYear)
            targetDate = Instant.ofEpochMilli(targetAt).atZone(zone).toLocalDate()
        } else if (!repeatYearly && targetDate.isBefore(today)) {
            return null
        }

        val days = ChronoUnit.DAYS.between(today, targetDate).toInt()
        if (days < 0) return null
        return DateOccurrence(days, targetYear, targetAt)
    }

    private val months = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun jalaliDate(epochMillis: Long): JalaliDate {
        val calendar = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val (year, month, day) = gregorianToJalali(
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        return JalaliDate(year, month, day)
    }

    fun jalaliMonthName(month: Int): String = months[(month - 1).coerceIn(months.indices)]

    /** Calendar-day count for relationship duration, inclusive of the start day. */
    fun daysTogether(startAt: Long, nowAt: Long = System.currentTimeMillis()): Int {
        val startLocal = Calendar.getInstance().apply { timeInMillis = startAt }
        val nowLocal = Calendar.getInstance().apply { timeInMillis = nowAt }
        val utc = TimeZone.getTimeZone("UTC")
        val startDay = Calendar.getInstance(utc).apply {
            clear()
            set(startLocal.get(Calendar.YEAR), startLocal.get(Calendar.MONTH), startLocal.get(Calendar.DAY_OF_MONTH))
        }
        val nowDay = Calendar.getInstance(utc).apply {
            clear()
            set(nowLocal.get(Calendar.YEAR), nowLocal.get(Calendar.MONTH), nowLocal.get(Calendar.DAY_OF_MONTH))
        }
        if (nowDay.timeInMillis < startDay.timeInMillis) return 0
        return ((nowDay.timeInMillis - startDay.timeInMillis) / (24L * 60 * 60 * 1000)).toInt() + 1
    }

    fun daysInJalaliMonth(year: Int, month: Int): Int = when (month) {
        in 1..6 -> 31
        in 7..11 -> 30
        12 -> if (isJalaliLeapYear(year)) 30 else 29
        else -> throw IllegalArgumentException("Invalid Jalali month")
    }

    fun toEpochMillis(
        year: Int,
        month: Int,
        day: Int,
        hour: Int = 12,
        minute: Int = 0
    ): Long {
        require(month in 1..12 && day in 1..daysInJalaliMonth(year, month)) { "Invalid Jalali date" }
        val (gy, gm, gd) = jalaliToGregorian(year, month, day)
        return Calendar.getInstance().apply {
            set(Calendar.YEAR, gy)
            set(Calendar.MONTH, gm - 1)
            set(Calendar.DAY_OF_MONTH, gd)
            set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
            set(Calendar.MINUTE, minute.coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun advanceRecurringDate(
        epochMillis: Long,
        interval: String,
        anchorJalaliDay: Int = jalaliDate(epochMillis).day
    ): Long {
        if (interval == "WEEKLY") {
            return Calendar.getInstance().apply {
                timeInMillis = epochMillis
                add(Calendar.DAY_OF_YEAR, 7)
            }.timeInMillis
        }
        val source = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val jalali = jalaliDate(epochMillis)
        val monthOffset = if (interval == "YEARLY") 12 else 1
        val absoluteMonth = jalali.year * 12 + (jalali.month - 1) + monthOffset
        val targetYear = Math.floorDiv(absoluteMonth, 12)
        val targetMonth = Math.floorMod(absoluteMonth, 12) + 1
        val targetDay = anchorJalaliDay.coerceIn(1, daysInJalaliMonth(targetYear, targetMonth))
        return toEpochMillis(
            targetYear,
            targetMonth,
            targetDay,
            source.get(Calendar.HOUR_OF_DAY),
            source.get(Calendar.MINUTE)
        )
    }

    fun formatDate(epochMillis: Long): String {
        val date = jalaliDate(epochMillis)
        return "${toPersianDigits(date.day)} ${months[date.month.coerceIn(1, 12) - 1]} ${toPersianDigits(date.year)}"
    }

    fun formatDateTime(epochMillis: Long): String {
        val safeMillis = epochMillis.coerceIn(0L, 4102444800000L) // تا حدود 2100
        val calendar = Calendar.getInstance().apply { timeInMillis = safeMillis }
        val (year, month, day) = gregorianToJalali(
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        val safeMonth = month.coerceIn(1, 12)
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        return "${toPersianDigits(day)} ${months[safeMonth.coerceIn(1, 12) - 1]} ${toPersianDigits(year)}، " +
            "${toPersianDigits(hour).padStart(2, '۰')}:${toPersianDigits(minute).padStart(2, '۰')}"
    }

    fun relativeTime(epochMillis: Long, now: Long = System.currentTimeMillis()): String {
        val diff = now - epochMillis
        if (diff < 0) return formatDateTime(epochMillis)
        val minutes = diff / 60_000L
        val hours = diff / 3_600_000L
        val days = diff / 86_400_000L
        return when {
            minutes < 1 -> "همین الان"
            minutes < 60 -> "${toPersianDigits(minutes)} دقیقه پیش"
            hours < 24 -> "${toPersianDigits(hours)} ساعت پیش"
            days < 7 -> "${toPersianDigits(days)} روز پیش"
            else -> formatDateTime(epochMillis)
        }
    }

    fun formatTime(epochMillis: Long): String {
        val calendar = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val hour = toPersianDigits(calendar.get(Calendar.HOUR_OF_DAY)).padStart(2, '۰')
        val minute = toPersianDigits(calendar.get(Calendar.MINUTE)).padStart(2, '۰')
        return "$hour:$minute"
    }

    fun todayLabel(): String {
        val calendar = Calendar.getInstance()
        val (_, month, day) = gregorianToJalali(
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        return "${toPersianDigits(day)} ${months[month.coerceIn(1, 12) - 1]}"
    }

    fun currentJalaliDayKey(): String = jalaliDayKey(System.currentTimeMillis())

    fun jalaliDayKey(epochMillis: Long): String {
        val calendar = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val (year, month, day) = gregorianToJalali(
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        return "$year-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}"
    }

    fun currentJalaliMonthKey(): String = jalaliMonthKey(System.currentTimeMillis())

    fun jalaliMonthKey(epochMillis: Long): String {
        val safe = epochMillis.coerceIn(0L, 4102444800000L)
        return try {
            val calendar = Calendar.getInstance().apply { timeInMillis = safe }
            val (year, month, _) = gregorianToJalali(
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            val m = month.coerceIn(1, 12)
            "$year-${m.toString().padStart(2, '0')}"
        } catch (_: Exception) {
            "0000-01"
        }
    }

    fun currentJalaliMonthLabel(): String {
        val calendar = Calendar.getInstance()
        val (year, month, _) = gregorianToJalali(
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        return "${months[month.coerceIn(1, 12) - 1]} ${toPersianDigits(year)}"
    }

    fun formatMoney(amount: Long): String {
        val formatted = NumberFormat.getIntegerInstance(Locale.US).format(amount)
        return "${toPersianDigits(formatted)} تومان"
    }

    fun toPersianDigits(value: Any): String = value.toString().map { char ->
        if (char in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[char - '0'] else char
    }.joinToString("")

    internal fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val monthOffsets = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var adjustedYear = gy
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * adjustedYear) + ((gy2 + 3) / 4) -
            ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + monthOffsets[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return Triple(jy, jm, jd)
    }

    internal fun jalaliToGregorian(jyInput: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy = jyInput + 1595
        var days = -355668 + (365 * jy) + ((jy / 33) * 8) + (((jy % 33) + 3) / 4) + jd
        days += if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            gy += 100 * (--days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = gy % 4 == 0 && (gy % 100 != 0 || gy % 400 == 0)
        val gregorianMonthDays = intArrayOf(31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 1
        while (gm <= 12 && gd > gregorianMonthDays[gm - 1]) {
            gd -= gregorianMonthDays[gm - 1]
            gm++
        }
        return Triple(gy, gm, gd)
    }

    private fun isJalaliLeapYear(year: Int): Boolean {
        val start = jalaliToGregorian(year, 1, 1)
        val next = jalaliToGregorian(year + 1, 1, 1)
        val utc = TimeZone.getTimeZone("UTC")
        val startCalendar = Calendar.getInstance(utc).apply {
            clear()
            set(start.first, start.second - 1, start.third)
        }
        val nextCalendar = Calendar.getInstance(utc).apply {
            clear()
            set(next.first, next.second - 1, next.third)
        }
        val days = (nextCalendar.timeInMillis - startCalendar.timeInMillis) / (24L * 60 * 60 * 1000)
        return days == 366L
    }
}
