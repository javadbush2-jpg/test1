package com.ourspace.app.core.finance

import android.content.Context

/**
 * دسته‌بندی‌های مشترک هزینه و خرید + دسته‌بندی درآمد.
 * قابل ویرایش از تنظیمات.
 */
object CategoryPreferences {
    private const val PREFS = "ourspace_categories"
    private const val KEY_EXPENSE = "expense_categories"
    private const val KEY_INCOME = "income_categories"

    /** پیش‌فرض یکسان برای هزینه و خرید */
    val DEFAULT_EXPENSE = listOf(
        "خوراک", "میوه و سبزیجات", "گوشت و پروتئین", "لبنیات", "نان و غلات",
        "تنقلات", "نوشیدنی", "خانه", "لوازم خانه", "شوینده", "بهداشت", "آرایشی",
        "دارو و سلامت", "رفت‌وآمد", "تفریح", "پوشاک", "کودک", "حیوان خانگی",
        "لوازم‌التحریر", "دیجیتال", "هدیه", "سفر", "سایر"
    )

    val DEFAULT_INCOME = listOf(
        "حقوق", "پاداش", "فروش", "هدیه", "سایر"
    )

    fun expenseCategories(context: Context): List<String> =
        load(context, KEY_EXPENSE, DEFAULT_EXPENSE)

    /** همان لیست هزینه — برای خرید */
    fun shoppingCategories(context: Context): List<String> =
        expenseCategories(context)

    fun incomeCategories(context: Context): List<String> =
        load(context, KEY_INCOME, DEFAULT_INCOME)

    fun addExpenseCategory(context: Context, name: String): Boolean {
        val clean = name.trim().take(40)
        if (clean.isEmpty()) return false
        val current = expenseCategories(context).toMutableList()
        if (current.any { it.equals(clean, ignoreCase = true) }) return false
        // «سایر» همیشه آخر بماند
        current.removeAll { it == "سایر" }
        current.add(clean)
        if (current.none { it == "سایر" }) current.add("سایر")
        save(context, KEY_EXPENSE, current)
        return true
    }

    fun removeExpenseCategory(context: Context, name: String): Boolean {
        if (name == "سایر") return false
        val current = expenseCategories(context).toMutableList()
        val removed = current.removeAll { it == name }
        if (!removed) return false
        if (current.none { it == "سایر" }) current.add("سایر")
        if (current.isEmpty()) {
            save(context, KEY_EXPENSE, DEFAULT_EXPENSE)
        } else {
            save(context, KEY_EXPENSE, current)
        }
        return true
    }

    fun addIncomeCategory(context: Context, name: String): Boolean {
        val clean = name.trim().take(40)
        if (clean.isEmpty()) return false
        val current = incomeCategories(context).toMutableList()
        if (current.any { it.equals(clean, ignoreCase = true) }) return false
        current.removeAll { it == "سایر" }
        current.add(clean)
        if (current.none { it == "سایر" }) current.add("سایر")
        save(context, KEY_INCOME, current)
        return true
    }

    fun removeIncomeCategory(context: Context, name: String): Boolean {
        if (name == "سایر") return false
        val current = incomeCategories(context).toMutableList()
        val removed = current.removeAll { it == name }
        if (!removed) return false
        if (current.none { it == "سایر" }) current.add("سایر")
        if (current.isEmpty()) {
            save(context, KEY_INCOME, DEFAULT_INCOME)
        } else {
            save(context, KEY_INCOME, current)
        }
        return true
    }

    fun resetExpenseToDefault(context: Context) {
        save(context, KEY_EXPENSE, DEFAULT_EXPENSE)
    }

    fun resetIncomeToDefault(context: Context) {
        save(context, KEY_INCOME, DEFAULT_INCOME)
    }

    private fun load(context: Context, key: String, defaults: List<String>): List<String> {
        val raw = preferences(context).getString(key, null)
        if (raw.isNullOrBlank()) return defaults
        val parsed = raw.split('\u001F')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
        return if (parsed.isEmpty()) defaults else parsed
    }

    private fun save(context: Context, key: String, items: List<String>) {
        preferences(context).edit()
            .putString(key, items.joinToString("\u001F"))
            .apply()
    }

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
