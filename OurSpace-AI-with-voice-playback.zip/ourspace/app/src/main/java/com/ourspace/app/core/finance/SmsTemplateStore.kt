package com.ourspace.app.core.finance

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * قالب‌های سفارشی کاربر برای خواندن پیامک بانکی.
 *
 * الگوی مبلغ: متن ساده با {amount} برای محل عدد.
 * مثال: "مبلغ: {amount} ریال"
 */
data class UserSmsTemplate(
    val id: String = UUID.randomUUID().toString().replace("-", "").take(16),
    val name: String,
    /** بخشی از شماره/نام فرستنده — خالی = هر فرستنده */
    val senderContains: String = "",
    /** کلمات ضروری (با کاما جدا) — همه باید در متن باشند */
    val mustContain: String = "",
    /** الگوی مبلغ با {amount} */
    val amountPattern: String = "مبلغ {amount}",
    /** EXPENSE | INCOME | AUTO */
    val kind: String = "AUTO",
    val category: String = "سایر",
    /** اگر مبلغ به ریال است true */
    val amountIsRial: Boolean = true,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("senderContains", senderContains)
        .put("mustContain", mustContain)
        .put("amountPattern", amountPattern)
        .put("kind", kind)
        .put("category", category)
        .put("amountIsRial", amountIsRial)
        .put("enabled", enabled)
        .put("createdAt", createdAt)

    companion object {
        fun fromJson(o: JSONObject): UserSmsTemplate = UserSmsTemplate(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString().take(16) },
            name = o.optString("name").ifBlank { "قالب" },
            senderContains = o.optString("senderContains"),
            mustContain = o.optString("mustContain"),
            amountPattern = o.optString("amountPattern").ifBlank { "مبلغ {amount}" },
            kind = o.optString("kind").ifBlank { "AUTO" },
            category = o.optString("category").ifBlank { "سایر" },
            amountIsRial = o.optBoolean("amountIsRial", true),
            enabled = o.optBoolean("enabled", true),
            createdAt = o.optLong("createdAt", System.currentTimeMillis())
        )
    }
}

object SmsTemplateStore {
    private const val PREFS = "ourspace_sms_templates"
    private const val KEY = "templates_json"

    fun list(context: Context): List<UserSmsTemplate> {
        val raw = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    add(UserSmsTemplate.fromJson(arr.getJSONObject(i)))
                }
            }.sortedByDescending { it.createdAt }
        }.getOrDefault(emptyList())
    }

    fun saveAll(context: Context, items: List<UserSmsTemplate>) {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }

    fun upsert(context: Context, template: UserSmsTemplate) {
        val cur = list(context).toMutableList()
        val idx = cur.indexOfFirst { it.id == template.id }
        if (idx >= 0) cur[idx] = template else cur.add(0, template)
        saveAll(context, cur)
    }

    fun delete(context: Context, id: String) {
        saveAll(context, list(context).filterNot { it.id == id })
    }

    /**
     * تبدیل الگوی کاربر به Regex؛ {amount} → گروه عددی.
     */
    fun amountRegexFromPattern(pattern: String): Regex {
        val escaped = Regex.escape(pattern.trim().ifBlank { "مبلغ {amount}" })
            .replace("\\{amount\\}", """([\d٬,،\s\u066C\u060C]+)""")
        return Regex(escaped, RegexOption.IGNORE_CASE)
    }

    fun tryParse(context: Context, body: String, address: String): BankSmsParser.ParsedSmsTransaction? {
        val normalized = BankSmsParser.normalizeDigitsPublic(body)
        val addr = address.lowercase()
        for (tpl in list(context).filter { it.enabled }) {
            if (tpl.senderContains.isNotBlank()) {
                val hint = tpl.senderContains.trim().lowercase()
                if (!addr.contains(hint) && !normalized.lowercase().contains(hint)) continue
            }
            val must = tpl.mustContain.split(",", "،")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
            if (must.isNotEmpty() && must.any { !normalized.contains(it) && !body.contains(it) }) continue

            val match = amountRegexFromPattern(tpl.amountPattern).find(normalized)
                ?: amountRegexFromPattern(tpl.amountPattern).find(body)
                ?: continue
            var amount = BankSmsParser.parseNumberPublic(match.groupValues.getOrNull(1).orEmpty()) ?: continue
            if (amount <= 0L) continue
            if (tpl.amountIsRial && amount >= 10L) {
                // اگر خیلی بزرگ به نظر ریال است
                if (amount >= 1000L) amount = amount / 10L
            }
            val kind = when (tpl.kind.uppercase()) {
                "EXPENSE", "INCOME" -> tpl.kind.uppercase()
                else -> BankSmsParser.guessKindPublic(normalized)
            }
            return BankSmsParser.ParsedSmsTransaction(
                amount = amount,
                kind = kind,
                category = tpl.category.ifBlank { "سایر" },
                note = "قالب: ${tpl.name}",
                confidence = 0.96f,
                templateId = "user:${tpl.id}"
            )
        }
        return null
    }

    /** چند قالب نمونه برای شروع */
    fun seedDefaultsIfEmpty(context: Context) {
        if (list(context).isNotEmpty()) return
        saveAll(
            context,
            listOf(
                UserSmsTemplate(
                    name = "بانک مهر · واریز (+)",
                    senderContains = "mehr",
                    mustContain = "مانده",
                    amountPattern = "{amount}+",
                    kind = "INCOME",
                    category = "سایر",
                    amountIsRial = true
                ),
                UserSmsTemplate(
                    name = "بانک مهر · برداشت (−)",
                    senderContains = "mehr",
                    mustContain = "مانده",
                    amountPattern = "{amount}-",
                    kind = "EXPENSE",
                    category = "سایر",
                    amountIsRial = true
                ),
                UserSmsTemplate(
                    name = "برداشت عمومی",
                    mustContain = "برداشت",
                    amountPattern = "مبلغ {amount}",
                    kind = "EXPENSE",
                    category = "سایر",
                    amountIsRial = true
                ),
                UserSmsTemplate(
                    name = "واریز عمومی",
                    mustContain = "واریز",
                    amountPattern = "مبلغ {amount}",
                    kind = "INCOME",
                    category = "سایر",
                    amountIsRial = true
                )
            )
        )
    }
}
