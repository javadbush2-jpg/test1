package com.ourspace.app.core.finance

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * قالب‌های سفارشی کاربر برای خواندن پیامک بانکی.
 *
 * placeholderهای مجاز در الگو:
 *  - {amount}  : مبلغ تراکنش (الزامی) — گروه عددی
 *  - {balance} : موجودی/مانده — گروه عددی، فقط در یادداشت استخراج می‌شود
 *  - {card}    : شماره/بخش کارت (مثل ****6060) — در یادداشت استخراج می‌شود
 *
 * مثال: «مبلغ: {amount} ریال · مانده: {balance} · کارت {card}»
 */
data class UserSmsTemplate(
    val id: String = UUID.randomUUID().toString().replace("-", "").take(16),
    val name: String,
    /** بخشی از شماره/نام فرستنده — خالی = هر فرستنده */
    val senderContains: String = "",
    /** کلمات ضروری (با کاما جدا) */
    val mustContain: String = "",
    /** الگو با placeholderها؛ حداقل باید {amount} داشته باشد */
    val amountPattern: String = "مبلغ {amount}",
    /** EXPENSE | INCOME | AUTO */
    val kind: String = "AUTO",
    val category: String = "سایر",
    /** اگر مبلغ به ریال است true (تبدیل ÷۱۰ به تومان) */
    val amountIsRial: Boolean = true,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    /** نحوهٔ تطبیق کلمات ضروری: ALL = همه باید باشند، ANY = وجود هرکدام کافی است */
    val matchMode: String = "ALL",
    /** کلمات ردکننده (با کاما) — اگر هرکدام در متن باشد قالب رد می‌شود (مثل ناموفق، لغو) */
    val excludeContain: String = "",
    /** اولویت ارزیابی؛ عدد کوچک‌تر زودتر بررسی می‌شود */
    val priority: Int = 0,
    /** متن نمونهٔ همراه قالب برای آزمایش زنده در ویرایشگر */
    val sampleBody: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("senderContains", senderContains)
        .put("mustContain", mustContain)
        .put("amountPattern", amountPattern)
        .put("kind", kind)
        .put("category", category)
        .put("amountIsRial", amountIsRial)
        .put("enabled", enabled)
        .put("createdAt", createdAt)
        .put("matchMode", matchMode)
        .put("excludeContain", excludeContain)
        .put("priority", priority)
        .put("sampleBody", sampleBody)

    companion object {
        fun fromJson(o: JSONObject): UserSmsTemplate = UserSmsTemplate(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString().take(16) },
            name = o.optString("name").ifBlank { "قالب" },
            senderContains = o.optString("senderContains"),
            mustContain = o.optString("mustContain"),
            amountPattern = o.optString("amountPattern").ifBlank { "مبلغ {amount}" },
            kind = o.optString("kind").ifBlank { "AUTO" },
            category = o.optString("category").ifBlank { "سایر" },
            amountIsRial = o.optBoolean("amountIsRial", true),
            enabled = o.optBoolean("enabled", true),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            matchMode = o.optString("matchMode").ifBlank { "ALL" },
            excludeContain = o.optString("excludeContain"),
            priority = o.optInt("priority", 0),
            sampleBody = o.optString("sampleBody")
        )
    }
}

/**
 * نتیجهٔ بررسی یک قالب روی یک متن — هم برای پارس واقعی و هم برای عیب‌یابی رابط.
 */
data class TemplateDiagnostic(
    val templateId: String,
    val templateName: String,
    val matched: Boolean,
    val reason: String,
    val amount: Long? = null,
    val kind: String? = null,
    val extras: Map<String, String> = emptyMap()
)

object SmsTemplateStore {
    private const val PREFS = "ourspace_sms_templates"
    private const val KEY = "templates_json"

    private val PLACEHOLDER = Regex("""\{(amount|balance|card|[a-zA-Z_][a-zA-Z0-9_]*)\}""")
    private const val AMOUNT_TOKEN = "{amount}"

    fun list(context: Context): List<UserSmsTemplate> {
        val raw = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    add(UserSmsTemplate.fromJson(arr.getJSONObject(i)))
                }
            }.sortedWith(compareBy<UserSmsTemplate> { it.priority }.thenByDescending { it.createdAt })
        }.getOrDefault(emptyList())
    }

    fun saveAll(context: Context, items: List<UserSmsTemplate>) {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }

    fun upsert(context: Context, template: UserSmsTemplate) {
        val cur = list(context).toMutableList()
        val idx = cur.indexOfFirst { it.id == template.id }
        if (idx >= 0) cur[idx] = template else cur.add(0, template)
        saveAll(context, cur)
    }

    fun delete(context: Context, id: String) {
        saveAll(context, list(context).filterNot { it.id == id })
    }

    /**
     * جابه‌جایی قالب در ترتیب اولویت (قالب‌های بالایی زودتر ارزیابی می‌شوند).
         */
    fun move(context: Context, id: String, up: Boolean) {
        val cur = list(context)
        val idx = cur.indexOfFirst { it.id == id }
        val target = if (up) idx - 1 else idx + 1
        if (idx < 0 || target !in cur.indices) return
        val renumbered = cur.mapIndexed { i, t -> t.copy(priority = i) }.toMutableList()
        val tmp = renumbered[idx]
        renumbered[idx] = renumbered[target]
        renumbered[target] = tmp
        saveAll(context, renumbered)
    }

    /** افزودن قالب آماده؛ اگر قالبی با همین نام موجود باشد اضافه نمی‌شود. */
    fun addPreset(context: Context, preset: UserSmsTemplate): Boolean {
        val cur = list(context)
        if (cur.any { it.name == preset.name }) return false
        saveAll(context, cur + preset.copy(priority = cur.size))
        return true
    }

    internal data class PlaceholderMatch(
        val amountGroup: Int,
        val balanceGroup: Int?,
        val cardGroup: Int?
    )

    /**
     * تبدیل الگوی کاربر به Regex؛ بخش‌های ثابت escape و هر placeholder به یک گروه
     * ضبط تبدیل می‌شود. شمارهٔ گروه {amount} برای استخراج برگردانده می‌شود.
     */
    internal fun buildPattern(pattern: String): Pair<Regex, PlaceholderMatch> {
        val trimmed = pattern.trim().ifBlank { "مبلغ $AMOUNT_TOKEN" }
        val sb = StringBuilder()
        var amountGroup = -1
        var balanceGroup: Int? = null
        var cardGroup: Int? = null
        var group = 0
        var cursor = 0
        for (m in PLACEHOLDER.findAll(trimmed)) {
            sb.append(Regex.escape(trimmed.substring(cursor, m.range.first)))
            group += 1
            when (m.groupValues[1].lowercase()) {
                "amount" -> {
                    amountGroup = group
                    sb.append("""([\d\u066C\u060C,،\s]+)""")
                }
                "balance" -> {
                    balanceGroup = group
                    sb.append("""([\d\u066C\u060C,،\s]+)""")
                }
                "card" -> {
                    cardGroup = group
                    sb.append("""([0-9*＊xX\-–_ \u0640]+)""")
                }
                else -> {
                    // placeholder ناشناخته: هر توکن بدون فاصله
                    sb.append("""(\S+)""")
                }
            }
            cursor = m.range.last + 1
        }
        sb.append(Regex.escape(trimmed.substring(cursor)))
        if (amountGroup < 0) {
            // الگو بدون {amount}؛ کل عدد به‌عنوان گروه مبلغ در نظر گرفته می‌شود
            sb.setLength(0)
            sb.append(Regex.escape(trimmed))
            amountGroup = 0
        }
        return Regex(sb.toString(), RegexOption.IGNORE_CASE) to
            PlaceholderMatch(amountGroup, balanceGroup, cardGroup)
    }

    /** سازگاری با نسخهٔ قبل: فقط Regex الگوی مبلغ. */
    fun amountRegexFromPattern(pattern: String): Regex = buildPattern(pattern).first

    private fun splitWords(raw: String): List<String> =
        raw.split(",", "،").map { it.trim() }.filter { it.isNotEmpty() }

    private data class EvalOutcome(
        val ok: Boolean,
        val reason: String,
        val parsed: BankSmsParser.ParsedSmsTransaction? = null,
        val extras: Map<String, String> = emptyMap()
    )

    private fun evaluate(
        tpl: UserSmsTemplate,
        body: String,
        address: String
    ): EvalOutcome {
        if (!tpl.enabled) return EvalOutcome(false, "قالب خاموش است")
        val normalized = BankSmsParser.normalizeDigitsPublic(body)
        val addr = address.lowercase()

        if (tpl.senderContains.isNotBlank()) {
            val hint = tpl.senderContains.trim().lowercase()
            if (!addr.contains(hint) && !normalized.lowercase().contains(hint) &&
                !body.lowercase().contains(hint)
            ) {
                return EvalOutcome(false, "فرستنده شامل «${tpl.senderContains.trim()}» نیست")
            }
        }

        val excludes = splitWords(tpl.excludeContain)
        excludes.firstOrNull { normalized.contains(it) || body.contains(it) }?.let {
            return EvalOutcome(false, "کلمهٔ ردکنندهٔ «$it» در متن هست")
        }

        val must = splitWords(tpl.mustContain)
        if (must.isNotEmpty()) {
            val present = must.filter { normalized.contains(it) || body.contains(it) }
            val modeAny = tpl.matchMode.equals("ANY", ignoreCase = true)
            if (modeAny) {
                if (present.isEmpty()) {
                    return EvalOutcome(false, "هیچ‌یک از کلمات ضروری در متن نیست")
                }
            } else if (present.size != must.size) {
                val missing = (must - present.toSet()).firstOrNull().orEmpty()
                return EvalOutcome(false, "کلمهٔ ضروری «$missing» پیدا نشد")
            }
        }

        val (regex, mapping) = buildPattern(tpl.amountPattern)
        val match = regex.find(normalized) ?: regex.find(body)
            ?: return EvalOutcome(false, "الگو در متن پیدا نشد")
        if (mapping.amountGroup <= 0) {
            return EvalOutcome(false, "الگو فاقد $AMOUNT_TOKEN است")
        }
        val amountRaw = match.groupValues.getOrNull(mapping.amountGroup).orEmpty()
        var amount = BankSmsParser.parseNumberPublic(amountRaw)
            ?: return EvalOutcome(false, "عدد مبلغ قابل خواندن نیست")
        if (amount <= 0L) return EvalOutcome(false, "مبلغ باید بزرگ‌تر از صفر باشد")
        if (tpl.amountIsRial && amount >= 10L && amount >= 1000L) {
            amount /= 10L
        }

        val extras = mutableMapOf<String, String>()
        mapping.balanceGroup?.let { g ->
            match.groupValues.getOrNull(g)?.takeIf { it.isNotBlank() }?.let { raw ->
                BankSmsParser.parseNumberPublic(raw)?.let { extras["مانده"] = formatDigits(it.toString()) }
            }
        }
        mapping.cardGroup?.let { g ->
            match.groupValues.getOrNull(g)?.trim()?.takeIf { it.isNotBlank() }?.let {
                extras["کارت"] = it
            }
        }

        val kind = when (tpl.kind.uppercase()) {
            "EXPENSE", "INCOME" -> tpl.kind.uppercase()
            else -> BankSmsParser.guessKindPublic(normalized)
        }
        val note = buildString {
            append("قالب: ${tpl.name}")
            extras["کارت"]?.let { append(" · کارت: $it") }
            extras["مانده"]?.let { append(" · مانده: $it") }
        }.take(500)

        val parsed = BankSmsParser.ParsedSmsTransaction(
            amount = amount,
            kind = kind,
            category = tpl.category.ifBlank { "سایر" },
            note = note,
            confidence = 0.96f,
            templateId = "user:${tpl.id}"
        )
        return EvalOutcome(
            ok = true,
            reason = "تطبیق موفق",
            parsed = parsed,
            extras = extras
        )
    }

    fun tryParse(context: Context, body: String, address: String): BankSmsParser.ParsedSmsTransaction? {
        for (tpl in list(context).filter { it.enabled }) {
            val outcome = evaluate(tpl, body, address)
            if (outcome.ok) return outcome.parsed
        }
        return null
    }

    /** آزمایش یک قالب تنها روی متن (بدون نیاز به ذخیره) — برای آزمایش زندهٔ ویرایشگر. */
    fun testTemplate(tpl: UserSmsTemplate, body: String, address: String = ""): TemplateDiagnostic {
        if (body.isBlank()) {
            return TemplateDiagnostic(tpl.id, tpl.name, false, "متن نمونه خالی است")
        }
        val enabledTpl = if (tpl.enabled) tpl else tpl.copy(enabled = true)
        val outcome = evaluate(enabledTpl, body, address)
        return TemplateDiagnostic(
            templateId = tpl.id,
            templateName = tpl.name,
            matched = outcome.ok,
            reason = outcome.reason,
            amount = outcome.parsed?.amount,
            kind = outcome.parsed?.kind,
            extras = outcome.extras
        )
    }

    /** تحلیل متن با همهٔ قالب‌ها؛ دلیل موفقیت یا شکست هر قالب جداگانه گزارش می‌شود. */
    fun diagnoseAll(context: Context, body: String, address: String = ""): List<TemplateDiagnostic> =
        list(context).map { tpl ->
            val outcome = evaluate(tpl, body, address)
            TemplateDiagnostic(
                templateId = tpl.id,
                templateName = tpl.name,
                matched = outcome.ok,
                reason = outcome.reason,
                amount = outcome.parsed?.amount,
                kind = outcome.parsed?.kind,
                extras = outcome.extras
            )
        }

    private fun formatDigits(rawDigits: String): String =
        rawDigits.reversed().chunked(3).joinToString("٬").reversed()

    /** چند قالب نمونه برای شروع */
    fun seedDefaultsIfEmpty(context: Context) {
        if (list(context).isNotEmpty()) return
        saveAll(context, DEFAULT_SEEDS)
    }

    /**
     * گالری قالب‌های آمادهٔ بانک‌های پرکاربر؛ کاربر با یک لمس اضافه می‌کند.
     * نام‌ها یکتا هستند و افزودن تکراری جلوگیری می‌شود.
     */
    val PRESETS: List<UserSmsTemplate> = listOf(
        UserSmsTemplate(
            name = "ملت · برداشت",
            senderContains = "mellat",
            mustContain = "برداشت,خرید",
            excludeContain = "ناموفق,لغو,برگشت",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "ملت · واریز",
            senderContains = "mellat",
            mustContain = "واریز",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "INCOME"
        ),
        UserSmsTemplate(
            name = "ملی · برداشت",
            senderContains = "bmi",
            mustContain = "برداشت,خرید,پرداخت",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "سامان · برداشت",
            senderContains = "saman",
            mustContain = "برداشت,خرید,پرداخت",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "پاسارگاد · برداشت",
            senderContains = "pasargad",
            mustContain = "برداشت,خرید",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "بلوبانک · برداشت",
            senderContains = "blu",
            mustContain = "برداشت,خرید,پرداخت",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            matchMode = "ANY"
        ),
        UserSmsTemplate(
            name = "بلوبانک · واریز",
            senderContains = "blu",
            mustContain = "واریز",
            excludeContain = "ناموفق,لغو",
            amountPattern = "مبلغ {amount}",
            kind = "INCOME"
        ),
        UserSmsTemplate(
            name = "الگوی کامل با مانده و کارت",
            mustContain = "مبلغ",
            amountPattern = "مبلغ {amount} ریال · مانده: {balance} · کارت {card}",
            kind = "AUTO",
            sampleBody = "مبلغ 1,250,000 ریال · مانده: 8,400,000 · کارت ****6060"
        ),
        UserSmsTemplate(
            name = "نادیده‌گرفتن تراکنش ناموفق",
            mustContain = "مبلغ",
            excludeContain = "ناموفق,لغو,خطا,برگشت خورد",
            amountPattern = "مبلغ {amount}",
            kind = "AUTO"
        )
    )

    private val DEFAULT_SEEDS: List<UserSmsTemplate> = listOf(
        UserSmsTemplate(
            name = "بانک مهر · واریز (+)",
            senderContains = "mehr",
            mustContain = "مانده",
            amountPattern = "{amount}+",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "بانک مهر · برداشت (−)",
            senderContains = "mehr",
            mustContain = "مانده",
            amountPattern = "{amount}-",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "برداشت عمومی",
            mustContain = "برداشت",
            amountPattern = "مبلغ {amount}",
            kind = "EXPENSE",
            category = "سایر",
            amountIsRial = true
        ),
        UserSmsTemplate(
            name = "واریز عمومی",
            mustContain = "واریز",
            amountPattern = "مبلغ {amount}",
            kind = "INCOME",
            category = "سایر",
            amountIsRial = true
        )
    )
}
