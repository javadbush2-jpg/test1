package com.ourspace.app.widget

import android.content.Context
import android.widget.RemoteViews
import com.ourspace.app.R
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.ui.theme.WidgetAccent
import kotlinx.coroutines.runBlocking

object WidgetStyle {
    fun backgroundRes(accent: WidgetAccent): Int = when (accent) {
        WidgetAccent.ROSE -> R.drawable.widget_background_rose
        WidgetAccent.OCEAN -> R.drawable.widget_background_ocean
        WidgetAccent.FOREST -> R.drawable.widget_background_forest
        WidgetAccent.SUNSET -> R.drawable.widget_background_sunset
        WidgetAccent.LAVENDER -> R.drawable.widget_background_lavender
        WidgetAccent.MIDNIGHT -> R.drawable.widget_background_midnight
        WidgetAccent.HONEY -> R.drawable.widget_background_honey
        WidgetAccent.SLATE -> R.drawable.widget_background_slate
    }

    fun currentAccent(context: Context): WidgetAccent = runCatching {
        runBlocking { AppPreferences(context.applicationContext).currentWidgetAccent() }
    }.getOrDefault(WidgetAccent.ROSE)

    fun applyBackground(views: RemoteViews, rootId: Int, context: Context) {
        val res = backgroundRes(currentAccent(context))
        runCatching { views.setInt(rootId, "setBackgroundResource", res) }
    }

    /** به‌روزرسانی همه ویجت‌های OurSpace پس از تغییر رنگ در تنظیمات. */
    fun refreshAll(context: Context) {
        OurSpaceWidgetProvider.requestUpdate(context)
        OurSpaceTasksWidgetProvider.requestUpdate(context)
        OurSpaceShoppingWidgetProvider.requestUpdate(context)
        OurSpaceCalendarWidgetProvider.requestUpdate(context)
    }
}
