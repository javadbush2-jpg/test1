package com.ourspace.app.core.ai

import org.json.JSONArray
import org.json.JSONObject

/**
 * Phase-1 on-device / host-side "AI": deterministic, rule-based text suggestions.
 * Later phases can swap the body of [complete] for a real local LLM while keeping the same protocol.
 */
object LocalAiEngine {

    data class Result(
        val text: String,
        val alternatives: List<String> = emptyList(),
        val engine: String = "rules-v1"
    )

    fun complete(request: JSONObject): Result {
        val kind = request.optString("kind", "chat_suggestion").ifBlank { "chat_suggestion" }
        val draft = request.optString("draft").trim()
        val partnerMood = request.optString("partnerMood").uppercase()
        val ownMood = request.optString("ownMood").uppercase()
        val partnerName = request.optString("partnerName").ifBlank { "عزیزم" }
        return when (kind) {
            "free_chat" -> freeChat(request)
            "chat_suggestion", "rewrite" -> chatSuggestion(draft, partnerMood, ownMood, partnerName)
            "care_tip" -> careTip(partnerMood, ownMood, partnerName)
            else -> chatSuggestion(draft, partnerMood, ownMood, partnerName)
        }
    }

    private fun chatSuggestion(
        draft: String,
        partnerMood: String,
        ownMood: String,
        partnerName: String
    ): Result {
        if (draft.isNotBlank() && draft.length >= 4) {
            val soft = soften(draft)
            return Result(
                text = soft,
                alternatives = listOf(
                    "$soft 💛",
                    "بگذار ساده‌تر بگویم: $soft"
                )
            )
        }
        val primary = when {
            partnerMood in LOW -> listOf(
                "$partnerName، کنارت هستم. هر وقت خواستی حرف بزن، من اینجام.",
                "امروز سخت به نظر می‌رسد. مجبور نیستی تنها تحملش کنی.",
                "دوست دارم کمکت کنم. چه چیزی الان بیشتر اذیتت می‌کند؟"
            ).random()
            ownMood in LOW -> listOf(
                "امروز کمی درگیرم، ولی برام مهمی. اگر چیزی لازم داری بگو.",
                "حال خودم هم سنگین است؛ شاید با هم سبک‌ترش کنیم.",
                "الان انرژی‌ام کم است، اما دوست دارم صدایت را بشنوم."
            ).random()
            partnerMood in HIGH -> listOf(
                "از حال خوبت خوشحال شدم 💛",
                "چه عالی! دوست دارم بیشتر برام بگی چی خوشحالت کرده.",
                "انرژی مثبتت رسید. دلم می‌خواد امروز یک برنامه کوچک با هم داشته باشیم."
            ).random()
            else -> listOf(
                "سلام $partnerName، دلم برایت تنگ شده بود.",
                "یه پیام کوتاه از سمت من: امروز هم کنارت هستم.",
                "اگر الان وقت داری، دوست دارم بدونم روزت چطور گذشت."
            ).random()
        }
        val alts = when {
            partnerMood in LOW -> listOf(
                "لازم نیست جواب سریع بدهی؛ فقط بدان که هستم.",
                "اگر بخواهی، یک تماس کوتاه هم خوب است."
            )
            else -> listOf(
                "هر وقت آزاد شدی پیام بده.",
                "یک قرار کوچک امروز چطور است؟"
            )
        }
        return Result(text = primary, alternatives = alts)
    }

    private fun freeChat(request: JSONObject): Result {
        val message = request.optString("message").ifBlank { request.optString("draft") }.trim()
        if (message.isBlank()) {
            return Result(
                text = "سلام! من دستیار هوشمند OurSpace هستم. درباره رابطه، برنامه‌ها، حال‌وهوا یا نوشتن پیام بپرس.",
                engine = "rules-v1"
            )
        }
        val lower = message.lowercase()
        val text = when {
            listOf("سلام", "درود", "hi", "hello").any { lower.contains(it) } ->
                "سلام! خوش اومدی. بگو امروز چه کمکی ازم برمیاد — پیام به همراه، برنامه‌ریزی، یا فقط یک هم‌صحبتی کوتاه."
            listOf("حال", "خلسه", "ناراحت", "استرس", "خست").any { lower.contains(it) } ->
                "درکت می‌کنم که سنگین باشد. یک نفس عمیق، یک کار خیلی کوچک، و اگر خواستی یک پیام کوتاه صادقانه برای همراهت — بدون فشار برای توضیح کامل."
            listOf("پیام", "چت", "بنویس", "چی بگم").any { lower.contains(it) } ->
                "می‌تونی این را بفرستی: «امروز کمی درگیر بودم، ولی برام مهمی. اگر وقت داشتی دوست دارم بدونم روزت چطور بود.» اگر بخوای لحن گرم‌تر یا رسمی‌تر هم می‌سازم."
            listOf("قرار", "برنامه", "تقویم", "کار").any { lower.contains(it) } ->
                "یک بلوک ۳۰ دقیقه‌ای مشترک در تقویم بگذارید؛ عنوان ساده مثل «زمان ما» کافی است. کم‌تعهدتر از یک برنامه بزرگ است و بیشتر انجام می‌شود."
            listOf("پول", "مالی", "هزینه", "بودجه").any { lower.contains(it) } ->
                "برای شروع: سه دسته اصلی (خوراک، رفت‌وآمد، خانه) را در همین ماه سقف بگذارید و بقیه را «سایر» نگه دارید. از پیامک‌های بانکی فقط برای ثبت سریع استفاده کنید."
            else ->
                "پیشنهادم این است که درخواستت را یک‌جمله روشن‌تر بگویی: مثلاً «یک پیام دلگرم‌کننده بنویس» یا «برای قرار امشب ایده بده». تا همان لحظه دقیق‌تر کمکت کنم.\n\nدرباره «${message.take(80)}»: اگر مربوط به رابطه یا برنامه‌ریزی است، جزئیات بیشتری بده."
        }
        return Result(text = text, engine = "rules-v1")
    }

    private fun careTip(partnerMood: String, ownMood: String, partnerName: String): Result {
        val text = when {
            partnerMood in LOW -> "برای $partnerName: یک پیام کوتاه بفرست، فشار نیاور، و اگر می‌توانی یک کار کوچک از روی دوشش بردار."
            ownMood in LOW -> "اول به خودت کمی استراحت بده؛ بعد یک جمله صادقانه برای همراهت بنویس."
            else -> "یک پیام گرم و یک برنامه کوچک مشترک، امروز را نزدیک‌تر می‌کند."
        }
        return Result(text = text)
    }

    private fun soften(text: String): String {
        var t = text.trim()
        // خیلی ساده: لبه‌های تند را کمی ملایم کن
        t = t.replace(Regex("(?i)هیچوقت"), "گاهی")
        t = t.replace(Regex("(?i)همیشه"), "خیلی وقت‌ها")
        if (!t.endsWith(".") && !t.endsWith("؟") && !t.endsWith("!")) {
            t += "."
        }
        return t
    }

    private val LOW = setOf("SAD", "STRESSED", "ANGRY", "ANXIOUS", "TIRED", "SICK")
    private val HIGH = setOf("HAPPY", "LOVE", "LOVED", "GREAT", "EXCITED", "GRATEFUL", "CALM")

    fun toResponseJson(requestId: String, result: Result): JSONObject =
        JSONObject()
            .put("type", AiProtocol.TYPE_RESPONSE)
            .put("requestId", requestId)
            .put("sentAt", System.currentTimeMillis())
            .put("engine", result.engine)
            .put("text", result.text)
            .put("alternatives", JSONArray(result.alternatives))
}
