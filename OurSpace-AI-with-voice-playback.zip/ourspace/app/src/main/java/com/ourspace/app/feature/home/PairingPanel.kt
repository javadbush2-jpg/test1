package com.ourspace.app.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.AppViewModel

/**
 * Host generates a 4-digit code and tells the companion.
 * Companion types that code — no long strings, no QR.
 */
@Composable
fun PairingPanel(
    role: DeviceRole,
    identity: DeviceIdentityManager.DeviceIdentity,
    snapshot: PairingStore.Snapshot,
    action: AppViewModel.PairingActionState,
    syncState: AppViewModel.SyncState,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onCheckStatus: () -> Unit,
    onCancelOutgoing: () -> Unit,
    onRevokeTrust: () -> Unit,
    onSync: () -> Unit,
    onPairPayload: (String) -> Unit,
    onScanCompanionReply: (String) -> Unit,
    onScanApproval: (String) -> Unit,
    onPairWithPin: (String) -> Unit = {},
    onGenerateHostPin: () -> Unit = {}
) {
    var pin by remember { mutableStateOf("") }
    val paired = snapshot.trustedPeer != null
    val shownPin = action.hostPin

    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lock, contentDescription = null)
                Text("اتصال با کد ۴ رقمی", fontWeight = FontWeight.Black)
            }

            if (paired) {
                Text(
                    if (role == DeviceRole.HOST) "✓ میزبان آماده است؛ کد باید در گوشی همراه وارد شود" else "✓ کد ثبت شد؛ وضعیت اتصال در حال بررسی است",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                if (role == DeviceRole.HOST) {
                    if (shownPin != null) {
                        Text(
                            text = shownPin,
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            letterSpacing = 8.sp
                        )
                        Text(
                            "کد برای ۱۰ دقیقه معتبر است؛ اگر منقضی شد کد تازه بساز.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text("برای اتصال همراه، یک کد تازه بساز.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = onSync, enabled = !syncState.isSyncing, modifier = Modifier.weight(1f)) {
                        Text(if (syncState.isSyncing) "همگام…" else "همگام‌سازی الآن")
                    }
                    if (role == DeviceRole.HOST) {
                        OutlinedButton(onClick = onGenerateHostPin, enabled = !action.isLoading, modifier = Modifier.weight(1f)) {
                            Text("ساخت کد جدید")
                        }
                    }
                }
                OutlinedButton(onClick = onRevokeTrust, modifier = Modifier.fillMaxWidth()) { Text("قطع جفت") }
            } else if (role == DeviceRole.HOST) {
                Text(
                    "روی این گوشی «ساخت کد» را بزن. کد ۴ رقمی را به همراه بگو تا وارد کند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (shownPin != null) {
                    Text(
                        text = shownPin,
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        letterSpacing = 10.sp
                    )
                    Text(
                        "این کد را به همراه بگو",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Button(
                    onClick = onGenerateHostPin,
                    enabled = !action.isLoading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        when {
                            action.isLoading -> "…"
                            shownPin != null -> "ساخت کد جدید"
                            else -> "ساخت کد ۴ رقمی"
                        }
                    )
                }
            } else {
                Text(
                    "کد ۴ رقمی که روی گوشی میزبان نشان داده شده را اینجا وارد کن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(4) },
                    label = { Text("کد میزبان") },
                    placeholder = { Text("مثلاً 4821") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onPairWithPin(pin) },
                    enabled = pin.length == 4 && !action.isLoading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (action.isLoading) "در حال اتصال…" else "وصل شو")
                }
            }

            action.message?.let {
                Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            action.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            syncState.message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            syncState.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
