package com.ourspace.app.core.webrtc

import android.content.Context
import android.util.Log
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Mutex
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SessionDescription
import org.webrtc.SdpObserver

/**
 * Manages a single PeerConnection + reliable DataChannel for OurSpace sync.
 *
 * Roles:
 * - Companion creates an Offer (createOfferSignal).
 * - Host receives the Offer, produces an Answer (createAnswerSignal).
 * - Companion applies the Answer (applyRemoteAnswer).
 * - Once the DataChannel is open, both sides can send/receive UTF-8 JSON envelopes.
 *
 * Signaling payloads are exchanged out-of-band (QR / local); this manager applies ICE locally.
 * No manual offer/answer or QR exchange is required.
 */
class WebRtcPeerManager(context: Context) {

    enum class Role { HOST, COMPANION }
    enum class State { IDLE, GATHERING, WAITING_REMOTE, CONNECTING, OPEN, CLOSED, FAILED }

    interface Listener {
        fun onStateChanged(state: State)
        fun onMessage(text: String)
        fun onError(message: String)
    }

    private val appContext = context.applicationContext
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val state = AtomicReference(State.IDLE)
    private val factoryReady = AtomicBoolean(false)

    private var factory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var dataChannel: DataChannel? = null
    private var localRole: Role? = null

    private val pendingCandidates = mutableListOf<IceCandidate>()

    /** Optional self-hosted TURN server supplied by the user in settings. */
    @Volatile
    var customTurnServer: WebRtcConfig.IceServerConfig? = null

    /** Optional ICE/TURN servers from app settings. */
    @Volatile
    var dynamicIceServers: List<WebRtcConfig.IceServerConfig> = emptyList()
    private var gatherContinuation: CancellableContinuation<Unit>? = null

    private val pendingResponses = mutableMapOf<String, CancellableContinuation<String>>()
    private val responseMutex = Mutex()

    fun addListener(listener: Listener) {
        listeners += listener
    }

    fun removeListener(listener: Listener) {
        listeners -= listener
    }

    fun currentState(): State = state.get()

    fun isOpen(): Boolean = state.get() == State.OPEN && dataChannel?.state() == DataChannel.State.OPEN

    suspend fun createOfferSignal(): String = withContext(Dispatchers.Main) {
        ensureFactory()
        closeInternal()
        localRole = Role.COMPANION
        setState(State.GATHERING)

        val pc = createPeerConnection()
        peerConnection = pc

        val init = DataChannel.Init().apply {
            ordered = true
            negotiated = false
        }
        val channel = pc.createDataChannel(WebRtcConfig.DATA_CHANNEL_LABEL, init)
            ?: throw IllegalStateException("ساخت DataChannel ناموفق بود.")
        attachDataChannel(channel)

        val constraints = MediaConstraints()
        val sdp = createLocalDescription(pc, isOffer = true, constraints)
        setLocalDescription(pc, sdp)
        waitForIceGathering(pc)
        setState(State.WAITING_REMOTE)

        val candidates = synchronized(pendingCandidates) { pendingCandidates.toList() }
        require(candidates.isNotEmpty()) {
            "هیچ مسیر شبکه‌ای پیدا نشد. اینترنت گوشی را بررسی کنید و دوباره تلاش کنید."
        }
        val signal = WebRtcSignaling.Signal(
            type = WebRtcSignaling.Signal.Type.OFFER,
            sdp = pc.localDescription?.description
                ?: throw IllegalStateException("SDP محلی آماده نیست."),
            candidates = candidates.map {
                WebRtcSignaling.IceCandidatePayload(it.sdp, it.sdpMid, it.sdpMLineIndex)
            }
        )
        WebRtcSignaling.encode(signal)
    }

    suspend fun createAnswerSignal(remoteOfferPayload: String): String = withContext(Dispatchers.Main) {
        ensureFactory()
        closeInternal()
        localRole = Role.HOST
        setState(State.GATHERING)

        val remote = WebRtcSignaling.decode(remoteOfferPayload)
        require(remote.type == WebRtcSignaling.Signal.Type.OFFER) {
            "انتظار Offer بود."
        }

        val pc = createPeerConnection()
        peerConnection = pc

        val remoteSdp = SessionDescription(SessionDescription.Type.OFFER, remote.sdp)
        setRemoteDescription(pc, remoteSdp)
        for (c in remote.candidates) {
            pc.addIceCandidate(
                IceCandidate(c.sdpMid, c.sdpMLineIndex, c.candidate)
            )
        }

        val constraints = MediaConstraints()
        val answer = createLocalDescription(pc, isOffer = false, constraints)
        setLocalDescription(pc, answer)
        waitForIceGathering(pc)
        setState(State.CONNECTING)

        val candidates = synchronized(pendingCandidates) { pendingCandidates.toList() }
        val signal = WebRtcSignaling.Signal(
            type = WebRtcSignaling.Signal.Type.ANSWER,
            sdp = pc.localDescription?.description
                ?: throw IllegalStateException("SDP پاسخ آماده نیست."),
            candidates = candidates.map {
                WebRtcSignaling.IceCandidatePayload(it.sdp, it.sdpMid, it.sdpMLineIndex)
            }
        )
        WebRtcSignaling.encode(signal)
    }

    suspend fun applyRemoteAnswer(remoteAnswerPayload: String) = withContext(Dispatchers.Main) {
        val pc = peerConnection ?: throw IllegalStateException("PeerConnection وجود ندارد.")
        val remote = WebRtcSignaling.decode(remoteAnswerPayload)
        require(remote.type == WebRtcSignaling.Signal.Type.ANSWER) {
            "انتظار Answer بود."
        }
        setState(State.CONNECTING)
        val remoteSdp = SessionDescription(SessionDescription.Type.ANSWER, remote.sdp)
        setRemoteDescription(pc, remoteSdp)
        for (c in remote.candidates) {
            pc.addIceCandidate(
                IceCandidate(c.sdpMid, c.sdpMLineIndex, c.candidate)
            )
        }
    }

    /**
     * Sends an encrypted sync envelope and waits for the host encrypted response.
     * One outstanding request at a time is assumed on this DataChannel.
     */
    suspend fun sendRequest(requestJson: String, timeoutMs: Long = 20_000L): String {
        if (!isOpen()) {
            throw IllegalStateException("کانال WebRTC باز نیست. دوباره با QR وصل شوید.")
        }
        return sendAndWait(
            request = requestJson,
            timeoutMs = timeoutMs,
            isMatch = { text ->
                // Accept an explicit error too, otherwise a rejected request would hang
                // for the whole timeout before the user sees anything.
                text.contains("incremental_exchange_result") ||
                    text.contains("exchange_result") ||
                    text.contains("\"error\"")
            }
        )
    }

    /**
     * Sends a UTF-8 text message and optionally waits for a correlated response.
     * Correlation is done by the caller (requestId inside the JSON).
     */
    suspend fun send(text: String) {
        if (!isOpen()) throw IllegalStateException("کانال WebRTC باز نیست.")
        val bytes = text.toByteArray(StandardCharsets.UTF_8)
        require(bytes.size <= WebRtcConfig.MAX_MESSAGE_BYTES) {
            "پیام بیش از حد بزرگ است (${bytes.size} بایت)."
        }
        val buffer = DataChannel.Buffer(ByteBuffer.wrap(bytes), false)
        val ok = dataChannel?.send(buffer) ?: false
        if (!ok) throw IllegalStateException("ارسال روی DataChannel ناموفق بود.")
    }

    /**
     * Sends a request and suspends until a matching response arrives or timeout.
     * The response matcher is provided by the caller.
     */
    suspend fun sendAndWait(
        request: String,
        timeoutMs: Long = 30_000L,
        isMatch: (String) -> Boolean
    ): String = withTimeout(timeoutMs) {
        suspendCancellableCoroutine { cont ->
            val key = System.nanoTime().toString()
            // We register a one-shot listener that resumes when isMatch returns true.
            val listener = object : Listener {
                override fun onStateChanged(state: State) {
                    if (state == State.CLOSED || state == State.FAILED) {
                        cont.resumeWithException(IllegalStateException("اتصال WebRTC قطع شد."))
                        removeListener(this)
                    }
                }

                override fun onMessage(text: String) {
                    if (isMatch(text)) {
                        cont.resume(text)
                        removeListener(this)
                    }
                }

                override fun onError(message: String) {
                    cont.resumeWithException(IllegalStateException(message))
                    removeListener(this)
                }
            }
            addListener(listener)
            cont.invokeOnCancellation { removeListener(listener) }
            try {
                // Fire-and-forget send; response comes via onMessage.
                val bytes = request.toByteArray(StandardCharsets.UTF_8)
                val buffer = DataChannel.Buffer(ByteBuffer.wrap(bytes), false)
                if (dataChannel?.send(buffer) != true) {
                    removeListener(listener)
                    cont.resumeWithException(IllegalStateException("ارسال درخواست ناموفق بود."))
                }
            } catch (e: Exception) {
                removeListener(listener)
                cont.resumeWithException(e)
            }
        }
    }

    fun close() {
        closeInternal()
        setState(State.CLOSED)
    }

    private fun closeInternal() {
        try {
            dataChannel?.unregisterObserver()
            dataChannel?.close()
        } catch (_: Exception) {}
        dataChannel = null
        try {
            peerConnection?.close()
        } catch (_: Exception) {}
        peerConnection = null
        synchronized(pendingCandidates) { pendingCandidates.clear() }
        gatherContinuation?.cancel()
        gatherContinuation = null
    }

    private fun ensureFactory() {
        if (factoryReady.get()) return
        synchronized(this) {
            if (factoryReady.get()) return
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(appContext)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )
            factory = PeerConnectionFactory.builder()
                .setOptions(PeerConnectionFactory.Options())
                .createPeerConnectionFactory()
            factoryReady.set(true)
        }
    }

    private fun createPeerConnection(): PeerConnection {
        val stun = WebRtcConfig.STUN_SERVERS.map {
            PeerConnection.IceServer.builder(it).createIceServer()
        }
        // TURN relays make the connection work behind carrier-grade NAT, where plain
        // STUN hole punching can never succeed. Custom (self-hosted) TURN comes first.
        val turnConfigs = (listOfNotNull(customTurnServer) + dynamicIceServers +
            WebRtcConfig.DEFAULT_TURN_SERVERS).distinctBy { it.url }
        val turn = turnConfigs.map { config ->
            PeerConnection.IceServer.builder(config.url)
                .setUsername(config.username.orEmpty())
                .setPassword(config.credential.orEmpty())
                .createIceServer()
        }
        val rtcConfig = PeerConnection.RTCConfiguration(stun + turn).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_ONCE
            // Try every transport, including TURN over TCP/TLS on 443.
            iceTransportsType = PeerConnection.IceTransportsType.ALL
            tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.ENABLED
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            keyType = PeerConnection.KeyType.ECDSA
        }
        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(newState: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                ConnectionDiagnostics.log("وضعیت ICE: ${newState?.name}")
                when (newState) {
                    PeerConnection.IceConnectionState.CONNECTED,
                    PeerConnection.IceConnectionState.COMPLETED -> {
                        // DataChannel open callback is the real readiness signal.
                    }
                    PeerConnection.IceConnectionState.FAILED -> {
                        setState(State.FAILED)
                        notifyError("اتصال ICE ناموفق بود.")
                    }
                    PeerConnection.IceConnectionState.DISCONNECTED,
                    PeerConnection.IceConnectionState.CLOSED -> {
                        if (state.get() == State.OPEN) setState(State.CLOSED)
                    }
                    else -> {}
                }
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {
                if (newState == PeerConnection.IceGatheringState.COMPLETE) {
                    gatherContinuation?.resume(Unit)
                    gatherContinuation = null
                }
            }
            override fun onIceCandidate(candidate: IceCandidate?) {
                if (candidate == null) return
                // Collect while gathering; after setLocalDescription they are already in SDP
                // for many stacks, but we still keep them for the compact signal.
                synchronized(pendingCandidates) {
                    pendingCandidates.add(candidate)
                }
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: org.webrtc.MediaStream?) {}
            override fun onRemoveStream(stream: org.webrtc.MediaStream?) {}
            override fun onDataChannel(channel: DataChannel?) {
                // Host side receives the channel created by the companion.
                if (channel != null && localRole == Role.HOST) {
                    attachDataChannel(channel)
                }
            }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(
                receiver: org.webrtc.RtpReceiver?,
                mediaStreams: Array<out org.webrtc.MediaStream>?
            ) {}
        }
        return factory!!.createPeerConnection(rtcConfig, observer)
            ?: throw IllegalStateException("ساخت PeerConnection ناموفق بود.")
    }

    private fun attachDataChannel(channel: DataChannel) {
        dataChannel = channel
        channel.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previousAmount: Long) {}
            override fun onStateChange() {
                when (channel.state()) {
                    DataChannel.State.OPEN -> setState(State.OPEN)
                    DataChannel.State.CLOSING, DataChannel.State.CLOSED -> {
                        if (state.get() == State.OPEN) setState(State.CLOSED)
                    }
                    else -> {}
                }
            }
            override fun onMessage(buffer: DataChannel.Buffer?) {
                if (buffer == null) return
                val data = ByteArray(buffer.data.remaining())
                buffer.data.get(data)
                val text = String(data, StandardCharsets.UTF_8)
                listeners.forEach { it.onMessage(text) }
            }
        })
        if (channel.state() == DataChannel.State.OPEN) {
            setState(State.OPEN)
        }
    }

    private suspend fun createLocalDescription(
        pc: PeerConnection,
        isOffer: Boolean,
        constraints: MediaConstraints
    ): SessionDescription = suspendCancellableCoroutine { cont ->
        val observer = object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc != null) cont.resume(desc)
                else cont.resumeWithException(IllegalStateException("SDP خالی است."))
            }
            override fun onCreateFailure(error: String?) {
                cont.resumeWithException(IllegalStateException(error ?: "ایجاد SDP ناموفق"))
            }
        }
        if (isOffer) pc.createOffer(observer, constraints)
        else pc.createAnswer(observer, constraints)
    }

    private suspend fun setLocalDescription(
        pc: PeerConnection,
        sdp: SessionDescription
    ) = suspendCancellableCoroutine { cont ->
        pc.setLocalDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() { cont.resume(Unit) }
            override fun onSetFailure(error: String?) {
                cont.resumeWithException(
                    IllegalStateException(error ?: "تنظیم SDP محلی ناموفق بود.")
                )
            }
        }, sdp)
    }

    private suspend fun setRemoteDescription(
        pc: PeerConnection,
        sdp: SessionDescription
    ) = suspendCancellableCoroutine { cont ->
        pc.setRemoteDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() { cont.resume(Unit) }
            override fun onSetFailure(error: String?) {
                cont.resumeWithException(IllegalStateException(error ?: "تنظیم SDP دوردست ناموفق"))
            }
        }, sdp)
    }

    /**
     * Waits for ICE gathering, but never fails because of it: if some STUN servers are
     * unreachable (common on mobile networks) gathering may never report COMPLETE, so we
     * simply continue with the candidates collected so far.
     */
    private suspend fun waitForIceGathering(pc: PeerConnection) {
        if (pc.iceGatheringState() == PeerConnection.IceGatheringState.COMPLETE) return

        val started = System.currentTimeMillis()
        withTimeoutOrNull(WebRtcConfig.ICE_GATHER_TIMEOUT_MS) {
            while (pc.iceGatheringState() != PeerConnection.IceGatheringState.COMPLETE) {
                delay(200)
                val elapsed = System.currentTimeMillis() - started
                val candidates = synchronized(pendingCandidates) { pendingCandidates.toList() }

                // For cellular/NAT networks, a relay candidate is the useful signal that
                // Relay candidate found — no need to wait the full ICE timeout.
                val hasRelay = candidates.any {
                    it.sdp.contains(" typ relay ")
                }
                val hasAny = candidates.isNotEmpty()

                if (hasRelay && elapsed >= WebRtcConfig.ICE_GATHER_GOOD_ENOUGH_MS) break
                if (hasAny && elapsed >= WebRtcConfig.ICE_GATHER_GOOD_ENOUGH_MS) break
            }
        }
        gatherContinuation = null
    }

    private fun setState(newState: State) {
        val prev = state.getAndSet(newState)
        if (prev != newState) {
            Log.i(TAG, "WebRTC state: $prev → $newState")
            listeners.forEach { it.onStateChanged(newState) }
        }
    }

    private fun notifyError(message: String) {
        listeners.forEach { it.onError(message) }
    }

    private open class SdpObserverAdapter : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }

    companion object {
        private const val TAG = "OurSpaceWebRTC"
    }
}
