package com.ourspace.app.feature.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.finance.SmsTemplateStore
import com.ourspace.app.core.finance.TemplateDiagnostic
import com.ourspace.app.core.finance.UserSmsTemplate
import com.ourspace.app.core.time.PersianDateFormatter

@Composable
internal fun SmsTemplatesDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var templates by remember {
        mutableStateOf(
            SmsTemplateStore.list(context)
                .also { if (it.isEmpty()) SmsTemplateStore.seedDefaultsIfEmpty(context) }
                .let { SmsTemplateStore.list(context) }
        )
    }
    var editing by remember { mutableStateOf<UserSmsTemplate?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var testBody by remember { mutableStateOf("") }
    var diagnostics by remember { mutableStateOf<List<TemplateDiagnostic>?>(null) }
    var showPresets by remember { mutableStateOf(false) }

    fun reload() {
        templates = SmsTemplateStore.list(context)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("قالب‌های پیامک بانکی", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val activeCount = templates.count { it.enabled }
                Text(
                    "${templates.size} قالب · $activeCount فعال · ترتیب فهرست، اولویت بررسی است. " +
                        "متغیرها: {amount} مبلغ، {balance} مانده، {card} کارت، {account} حساب، {date} تاریخ، {time} ساعت، {ref} کد پیگیری، {merchant} پذیرنده.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                templates.forEachIndexed { index, tpl ->
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (tpl.enabled) MaterialTheme.colorScheme.surfaceContainerLow
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "${index + 1}.",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(tpl.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(
                                    if (tpl.enabled) "فعال" else "خاموش",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text("الگو: ${tpl.amountPattern}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                buildString {
                                    append(when (tpl.kind) { "EXPENSE" -> "هزینه"; "INCOME" -> "درآمد"; else -> "خودکار" })
                                    append(" · ").append(tpl.category)
                                    append(" · ").append(if (tpl.amountIsRial) "ریال↔تومان" else "تومان")
                                    append(" · ").append(if (tpl.matchMode == "ANY") "تطبیق هر کلمه" else "تطبیق همهٔ کلمات")
                                },
                                style = MaterialTheme.typography.labelSmall
                            )
                            if (tpl.senderContains.isNotBlank()) {
                                Text("فرستنده: ${tpl.senderContains}", style = MaterialTheme.typography.labelSmall)
                            }
                            if (tpl.mustContain.isNotBlank()) {
                                Text("کلمات ضروری: ${tpl.mustContain}", style = MaterialTheme.typography.labelSmall)
                            }
                            if (tpl.excludeContain.isNotBlank()) {
                                Text(
                                    "کلمات ردکننده: ${tpl.excludeContain}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = {
                                    editing = tpl
                                    showEditor = true
                                }) { Text("ویرایش") }
                                TextButton(onClick = {
                                    editing = tpl.copy(
                                        id = java.util.UUID.randomUUID().toString().replace("-", "").take(16),
                                        name = "${tpl.name} (کپی)"
                                    )
                                    showEditor = true
                                }) { Text("کپی") }
                                TextButton(
                                    enabled = index > 0,
                                    onClick = {
                                        SmsTemplateStore.move(context, tpl.id, up = true)
                                        reload()
                                    }
                                ) { Text("بالا") }
                                TextButton(
                                    enabled = index < templates.lastIndex,
                                    onClick = {
                                        SmsTemplateStore.move(context, tpl.id, up = false)
                                        reload()
                                    }
                                ) { Text("پایین") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = {
                                    SmsTemplateStore.upsert(context, tpl.copy(enabled = !tpl.enabled))
                                    reload()
                                }) { Text(if (tpl.enabled) "خاموش‌کردن" else "روشن‌کردن") }
                                TextButton(onClick = {
                                    SmsTemplateStore.delete(context, tpl.id)
                                    reload()
                                }) { Text("حذف") }
                            }
                        }
                    }
                }
                OutlinedButton(
                    onClick = {
                        editing = UserSmsTemplate(
                            name = "قالب جدید",
                            mustContain = "برداشت",
                            amountPattern = "مبلغ {amount}",
                            kind = "EXPENSE",
                            category = "سایر",
                            amountIsRial = true
                        )
                        showEditor = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ قالب جدید") }

                OutlinedButton(
                    onClick = { showPresets = !showPresets },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (showPresets) "بستن قالب‌های آماده" else "＋ افزودن از قالب‌های آمادهٔ بانک‌ها") }
                AnimatedVisibility(visible = showPresets) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(SmsTemplateStore.PRESETS) { preset ->
                            val exists = templates.any { it.name == preset.name }
                            FilterChip(
                                selected = false,
                                enabled = !exists,
                                onClick = {
                                    if (SmsTemplateStore.addPreset(context, preset)) reload()
                                },
                                label = { Text(if (exists) "✓ ${preset.name}" else preset.name) }
                            )
                        }
                    }
                }

                HorizontalDivider()
                Text("آزمایش پیشرفتهٔ قالب‌ها", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = testBody,
                    onValueChange = { testBody = it.take(2000) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("متن یک پیامک نمونه") },
                    minLines = 3
                )
                Button(
                    onClick = {
                        diagnostics = if (testBody.isBlank()) {
                            null
                        } else {
                            SmsTemplateStore.diagnoseAll(context, testBody, "")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = testBody.isNotBlank()
                ) { Text("تحلیل همهٔ قالب‌ها") }
                diagnostics?.let { rows ->
                    val matched = rows.firstOrNull { it.matched }
                    if (matched != null && matched.amount != null) {
                        val kindFa = if (matched.kind == "INCOME") "درآمد" else "هزینه"
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text("✓ قالب «${matched.templateName}» تطبیق کرد", fontWeight = FontWeight.Bold)
                                Text("$kindFa · ${PersianDateFormatter.formatMoney(matched.amount)} تومان")
                                matched.extras.forEach { (k, v) ->
                                    Text("$k: $v", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    } else {
                        Text(
                            "هیچ قالبی تطبیق نکرد؛ دلیل ردشدن در هر قالب پایین آمده است.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 170.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        rows.forEach { d ->
                            val amountPart = d.amount?.let {
                                " · ${PersianDateFormatter.formatMoney(it)} تومان"
                            }.orEmpty()
                            Text(
                                (if (d.matched) "✓ " else "✗ ") + d.templateName + " — " + d.reason + amountPart,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (d.matched) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("بستن") }
        }
    )

    if (showEditor && editing != null) {
        SmsTemplateEditorDialog(
            initial = editing!!,
            onDismiss = { showEditor = false; editing = null },
            onSave = { saved ->
                SmsTemplateStore.upsert(context, saved)
                reload()
                showEditor = false
                editing = null
            }
        )
    }
}

@Composable
internal fun SmsTemplateEditorDialog(
    initial: UserSmsTemplate,
    onDismiss: () -> Unit,
    onSave: (UserSmsTemplate) -> Unit
) {
    var name by remember(initial.id) { mutableStateOf(initial.name) }
    var sender by remember(initial.id) { mutableStateOf(initial.senderContains) }
    var must by remember(initial.id) { mutableStateOf(initial.mustContain) }
    var exclude by remember(initial.id) { mutableStateOf(initial.excludeContain) }
    var pattern by remember(initial.id) {
        mutableStateOf(TextFieldValue(initial.amountPattern, TextRange(initial.amountPattern.length)))
    }
    var kind by remember(initial.id) { mutableStateOf(initial.kind) }
    var category by remember(initial.id) { mutableStateOf(initial.category) }
    var isRial by remember(initial.id) { mutableStateOf(initial.amountIsRial) }
    var matchMode by remember(initial.id) { mutableStateOf(initial.matchMode.ifBlank { "ALL" }) }
    var sample by remember(initial.id) { mutableStateOf(initial.sampleBody) }

    val patternOk = pattern.text.contains("{amount}")

    fun insertToken(token: String) {
        val s = pattern.text
        val start = pattern.selection.start.coerceIn(0, s.length)
        val end = pattern.selection.end.coerceIn(0, s.length)
        val updated = s.replaceRange(start, end, token)
        pattern = TextFieldValue(updated, TextRange((start + token.length).coerceAtMost(updated.length)))
    }

    val liveTemplate = remember(name, sender, must, exclude, pattern.text, kind, category, isRial, matchMode) {
        initial.copy(
            name = name.ifBlank { "قالب" },
            senderContains = sender.trim(),
            mustContain = must.trim(),
            excludeContain = exclude.trim(),
            amountPattern = pattern.text,
            kind = kind,
            category = category.ifBlank { "سایر" },
            amountIsRial = isRial,
            matchMode = matchMode,
            enabled = true
        )
    }
    val liveDiagnostic = remember(liveTemplate, sample) {
        if (sample.isBlank()) null else SmsTemplateStore.testTemplate(liveTemplate, sample)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ویرایش قالب", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    name, { name = it.take(80) },
                    label = { Text("نام قالب") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    sender, { sender = it.take(80) },
                    label = { Text("فرستنده شامل (اختیاری)") },
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("مثال: mellat، bmi یا بخشی از شمارهٔ فرستنده") }
                )
                OutlinedTextField(
                    must, { must = it.take(200) },
                    label = { Text("کلمات ضروری (با کاما)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL" to "همهٔ کلمات", "ANY" to "هر کلمه").forEach { (k, label) ->
                        FilterChip(
                            selected = matchMode == k,
                            onClick = { matchMode = k },
                            label = { Text(label) }
                        )
                    }
                }
                OutlinedTextField(
                    exclude, { exclude = it.take(200) },
                    label = { Text("کلمات ردکننده (با کاما)") },
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("اگر هرکدام در پیامک باشد قالب رد می‌شود — مثال: ناموفق، لغو، خطا") }
                )
                OutlinedTextField(
                    value = pattern,
                    onValueChange = { pattern = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("الگو — حداقل شامل {amount}") },
                    isError = !patternOk,
                    supportingText = {
                        Text(
                            if (patternOk) "مثال: مبلغ {amount} ریال · مانده: {balance} · کارت {card} · ساعت {time} · پذیرنده {merchant}"
                            else "الگو باید شامل {amount} باشد"
                        )
                    }
                )
                Text("درج متغیر در محل کرسر", style = MaterialTheme.typography.labelMedium)
                SmsTemplateStore.PLACEHOLDER_DOCS.map { it.first }.chunked(4).forEach { rowTokens ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        rowTokens.forEach { token ->
                            OutlinedButton(
                                onClick = { insertToken(token) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) { Text(token, style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
                Text("واحد مبلغ", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = isRial, onClick = { isRial = true }, label = { Text("ریال (تبدیل به تومان)") })
                    FilterChip(selected = !isRial, onClick = { isRial = false }, label = { Text("تومان (بدون تبدیل)") })
                }
                Text("نوع تراکنش", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("EXPENSE" to "هزینه", "INCOME" to "درآمد", "AUTO" to "خودکار").forEach { (k, label) ->
                        FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(label) })
                    }
                }
                OutlinedTextField(
                    category, { category = it.take(40) },
                    label = { Text("دستهٔ پیش‌فرض") },
                    modifier = Modifier.fillMaxWidth()
                )
                HorizontalDivider()
                Text("آزمایش زندهٔ قالب", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    sample, { sample = it.take(2000) },
                    label = { Text("متن نمونهٔ پیامک") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                liveDiagnostic?.let { d ->
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (d.matched) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            if (d.matched && d.amount != null) {
                                val kindFa = if (d.kind == "INCOME") "درآمد" else "هزینه"
                                Text(
                                    "✓ ${PersianDateFormatter.formatMoney(d.amount)} تومان · $kindFa",
                                    fontWeight = FontWeight.Bold
                                )
                                d.extras.forEach { (k, v) ->
                                    Text("$k: $v", style = MaterialTheme.typography.labelSmall)
                                }
                            } else {
                                Text("✗ ${d.reason}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        initial.copy(
                            name = name.trim().ifBlank { "قالب" },
                            senderContains = sender.trim(),
                            mustContain = must.trim(),
                            excludeContain = exclude.trim(),
                            amountPattern = pattern.text.trim().ifBlank { "مبلغ {amount}" },
                            kind = kind,
                            category = category.trim().ifBlank { "سایر" },
                            amountIsRial = isRial,
                            matchMode = matchMode,
                            sampleBody = sample.trim()
                        )
                    )
                },
                enabled = name.isNotBlank() && patternOk
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
