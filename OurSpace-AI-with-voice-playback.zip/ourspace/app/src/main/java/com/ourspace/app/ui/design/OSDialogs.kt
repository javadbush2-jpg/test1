package com.ourspace.app.ui.design

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties

/**
 * Premium dialog system for OurSpace — soft, warm, couple-first.
 *
 * Design principles:
 * - Large rounded corners (xl / 32dp)
 * - Soft primary-tinted elevation, no harsh Material shadows
 * - Clear visual hierarchy: optional icon → title → body → actions
 * - Destructive actions use error color but stay calm (no screaming red)
 * - Consistent horizontal padding and button height with the rest of the app
 */

private val DialogShape = RoundedCornerShape(OSRadius.xl)
private val DialogMaxWidth = 360.dp

/**
 * Base styled AlertDialog shell used by all OS dialogs.
 * Prefer the higher-level helpers (OSConfirmDialog, OSFormDialog, …) over calling this directly.
 */
@Composable
fun OSAlertDialog(
    onDismissRequest: () -> Unit,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null,
    confirmButton: @Composable () -> Unit,
    dismissButton: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    properties: DialogProperties = DialogProperties(usePlatformDefaultWidth = false)
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        properties = properties,
        shape = DialogShape,
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 0.dp,
        icon = icon,
        title = title,
        text = text,
        confirmButton = confirmButton,
        dismissButton = dismissButton,
        modifier = Modifier
            .widthIn(max = DialogMaxWidth)
            .padding(horizontal = 20.dp)
            .shadow(
                elevation = OSElevation.floating,
                shape = DialogShape,
                ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.08f)
                    )
                ),
                shape = DialogShape
            )
    )
}

/**
 * Simple confirm / cancel dialog with optional icon and destructive styling.
 *
 * Example:
 * ```
 * OSConfirmDialog(
 *     title = "حذف الگو؟",
 *     message = "این عمل قابل بازگشت نیست.",
 *     confirmLabel = "حذف",
 *     destructive = true,
 *     onConfirm = { … },
 *     onDismiss = { … }
 * )
 * ```
 */
@Composable
fun OSConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    dismissLabel: String = "انصراف",
    destructive: Boolean = false,
    icon: ImageVector? = null,
    iconTint: Color? = null,
    emoji: String? = null
) {
    val dialogContentMaxHeight = (LocalConfiguration.current.screenHeightDp * 0.48f).coerceAtLeast(180f).dp
    OSAlertDialog(
        onDismissRequest = onDismiss,
        icon = when {
            emoji != null -> {
                {
                    Box(
                        Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(
                                if (destructive) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f)
                                else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.70f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(emoji, style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
            icon != null -> {
                {
                    Box(
                        Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(
                                if (destructive) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f)
                                else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.70f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = iconTint
                                ?: if (destructive) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
            else -> null
        },
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = dialogContentMaxHeight)
                    .verticalScroll(rememberScrollState())
            )
        },
        confirmButton = {
            if (destructive) {
                OSDestructiveButton(text = confirmLabel, onClick = onConfirm)
            } else {
                OSDialogPrimaryButton(text = confirmLabel, onClick = onConfirm)
            }
        },
        dismissButton = {
            OSDialogSecondaryButton(text = dismissLabel, onClick = onDismiss)
        }
    )
}

/**
 * Form-style dialog: title + custom content (fields, lists, …) + actions.
 * Use for any dialog that needs more than a simple message.
 */
@Composable
fun OSFormDialog(
    title: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    confirmLabel: String = "ذخیره",
    dismissLabel: String = "انصراف",
    confirmEnabled: Boolean = true,
    destructiveConfirm: Boolean = false,
    showDismissButton: Boolean = true,
    subtitle: String? = null,
    icon: ImageVector? = null,
    emoji: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val dialogContentMaxHeight = (LocalConfiguration.current.screenHeightDp * 0.56f).coerceAtLeast(220f).dp
    OSAlertDialog(
        onDismissRequest = onDismiss,
        icon = when {
            emoji != null -> {
                {
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.75f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(emoji, style = MaterialTheme.typography.headlineSmall)
                    }
                }
            }
            icon != null -> {
                {
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.75f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
            else -> null
        },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                if (!subtitle.isNullOrBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = dialogContentMaxHeight)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(OSSpacing.sm),
                content = content
            )
        },
        confirmButton = {
            if (destructiveConfirm) {
                OSDestructiveButton(text = confirmLabel, onClick = onConfirm, enabled = confirmEnabled)
            } else {
                OSDialogPrimaryButton(text = confirmLabel, onClick = onConfirm, enabled = confirmEnabled)
            }
        },
        dismissButton = if (showDismissButton) {
            {
                OSDialogSecondaryButton(text = dismissLabel, onClick = onDismiss)
            }
        } else null
    )
}

/**
 * Compact primary action used inside dialogs.
 */
@Composable
fun OSDialogPrimaryButton(
    text: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(OSRadius.md),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 0.dp),
        modifier = modifier.height(44.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Soft secondary / dismiss action for dialogs.
 */
@Composable
fun OSDialogSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TextButton(
        onClick = onClick,
        shape = RoundedCornerShape(OSRadius.md),
        colors = ButtonDefaults.textButtonColors(
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        modifier = modifier.height(44.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
    }
}

/**
 * Calm destructive confirm button (soft error, not alarming).
 */
@Composable
fun OSDestructiveButton(
    text: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(OSRadius.md),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 0.dp),
        modifier = modifier.height(44.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Full-screen style dialog content container for richer UIs (date picker, gallery, …).
 * Wraps content in the same soft surface + border language as OSAlertDialog.
 */
@Composable
fun OSDialogSurface(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .widthIn(max = DialogMaxWidth)
            .clip(DialogShape)
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.08f)
                    )
                ),
                shape = DialogShape
            )
            .padding(OSSpacing.lg),
        content = content
    )
}
