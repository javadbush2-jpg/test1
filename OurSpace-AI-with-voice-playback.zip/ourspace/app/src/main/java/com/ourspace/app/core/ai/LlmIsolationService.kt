package com.ourspace.app.core.ai

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * مرز ایزولاسیون موتور بومی هوش مصنوعی.
 *
 * چرا پروسهٔ جدا؟ کتابخانهٔ llama.cpp/ggml در بعضی شرایط (کمبود حافظه، معماری مدل
 * ناسازگار، assert داخلی) مستقیم abort()/SIGSEGV می‌زند؛ این سیگنال‌ها با try/catch
 * یا runCatching قابل مهار نیستند و کل پروسهٔ اپ را می‌کشند. با اجرای موتور در
 * سرویس پروسهٔ «:llm»، مرگ بومی فقط همان پروسه را می‌کشد و پروسهٔ رابط کاربری
 * سالم می‌ماند؛ کلاینت مرگ سرویس را تشخیص می‌دهد و موتور را برای این مدل غیرفعال
 * کرده و پاسخ قانون‌محمد را جایگزین می‌کند.
 *
 * ارتباط با Messenger (بدون نیاز به AIDL) و کاملاً درون‌برنامه‌ای (exported=false).
 */

// ---- پروتکل پیام‌ها (بین کلاینت پروسهٔ اصلی و سرویس پروسهٔ :llm) ----
internal const val MSG_PING = 1
internal const val MSG_LOAD = 2
internal const val MSG_COMPLETE = 3
internal const val MSG_UNLOAD = 4
internal const val MSG_CANCEL = 5

internal const val KEY_PATH = "path"
internal const val KEY_PROMPT = "prompt"
internal const val KEY_TEXT = "text"
internal const val KEY_ERROR = "error"

/**
 * سرویس میزبان موتور بومی؛ در پروسهٔ جداگانه اجرا می‌شود (android:process=":llm").
 * همهٔ فراخوانی‌های بومی روی یک HandlerThread سریال می‌شوند.
 */
class LlmIsolationService : Service() {

    private lateinit var workerThread: HandlerThread
    private lateinit var worker: Handler
    private val inbound: Messenger by lazy { Messenger(worker) }

    override fun onCreate() {
        super.onCreate()
        workerThread = HandlerThread("ourspace-llm-isolated").apply { start() }
        worker = object : Handler(workerThread.looper) {
            override fun handleMessage(msg: Message) {
                // پیام‌های یک‌طرفه (بدون replyTo) فقط قبل از بررسی پاسخ‌دهنده مدیریت شوند.
                if (msg.what == MSG_UNLOAD) {
                    runCatching { HostLlmRuntime.directUnload() }
                    return
                }
                if (msg.what == MSG_CANCEL) {
                    runCatching { HostLlmRuntime.directCancel() }
                    return
                }
                val replyTo = msg.replyTo ?: return

                val reply = Message.obtain().apply {
                    what = msg.what
                    arg1 = msg.arg1 // همان شناسهٔ ترتیبی درخواست
                    arg2 = 0
                }
                try {
                    when (msg.what) {
                        MSG_PING -> {
                            reply.arg2 = HostLlmRuntime.directBackendKind()
                        }
                        MSG_LOAD -> {
                            val path = msg.data?.getString(KEY_PATH).orEmpty()
                            val ok = HostLlmRuntime.directEnsureModelLoaded(path, applicationContext)
                            reply.arg2 = if (ok) 0 else -1
                            if (!ok) {
                                val err = HostLlmRuntime.directLastError()
                                if (!err.isNullOrBlank()) {
                                    reply.data = Bundle().apply { putString(KEY_ERROR, err) }
                                }
                            }
                        }
                        MSG_COMPLETE -> {
                            val prompt = msg.data?.getString(KEY_PROMPT).orEmpty()
                            val text = HostLlmRuntime.directCompleteText(prompt, msg.arg2)
                            if (text.isNullOrBlank()) {
                                reply.arg2 = 1
                            } else {
                                reply.arg2 = 0
                                reply.data = Bundle().apply { putString(KEY_TEXT, text) }
                            }
                        }
                        else -> return
                    }
                } catch (t: Throwable) {
                    // حتی اگر لایهٔ بومی به‌جای abort یک استثنا بیرون بیندازد، پاسخ خطا برمی‌گردد.
                    Log.w(TAG, "isolated service handler failure: ${t.message}")
                    reply.arg2 = -1
                    reply.data = Bundle().apply {
                        putString(KEY_ERROR, t.message ?: "native failure")
                    }
                }
                runCatching { replyTo.send(reply) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder = inbound.binder

    override fun onDestroy() {
        runCatching { workerThread.quitSafely() }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "LlmIsolationService"
    }
}

/**
 * کلاینت پروسهٔ اصلی: اتصال به سرویس ایزوله، فراخوانی همگامِ امن، تشخیص مرگ
 * پروسهٔ بومی و گیت ضدِ کرش‌لوپ (تا وقتی مدل عوض نشده دیگر سراغ بومی نمی‌رود).
 */
object LlmServiceClient {

    private const val TAG = "LlmServiceClient"
    private const val PREFS = "ourspace_llm_gate"
    private const val KEY_GATE_DISABLED = "disabled"
    private const val KEY_GATE_REASON = "reason"

    private const val BIND_TIMEOUT_MS = 8_000L
    private const val PING_TIMEOUT_MS = 8_000L
    const val LOAD_TIMEOUT_MS = 60_000L
    const val COMPLETE_TIMEOUT_MS = 50_000L

    private const val CRASH_REASON =
        "موتور بومی هوش مصنوعی هنگام کار با این مدل متوقف شد؛ برای جلوگیری از بسته‌شدن برنامه، " +
            "فعلاً پاسخ قانون‌محمد جایگزین می‌شود. مدل سبک‌تری را امتحان کنید یا مدل دیگری انتخاب کنید."

    private val seq = AtomicInteger(1)
    private val pending = ConcurrentHashMap<Int, CompletableDeferred<Message>>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var appCtx: Context? = null

    @Volatile
    private var remote: Messenger? = null

    @Volatile
    private var connecting = false

    @Volatile
    private var connectedDeferred: CompletableDeferred<Unit> = CompletableDeferred()

    // کش مقادیر تا فراخوانی‌های روی رشتهٔ اصلی (مثل وضعیت مدل در تنظیمات) هیچ‌وقت مسدود نشوند.
    @Volatile
    private var cachedBackendKind = -1

    @Volatile
    private var cachedAvailable: Boolean? = null

    @Volatile
    private var warmUpStarted = false

    /** مسیر مدل آمادهٔ کاربر برای پیش‌بارگذاری پس از وصل‌شدن سرویس. */
    @Volatile
    private var preloadPathProvider: (() -> String?)? = null

    fun setPreloadPathProvider(provider: (() -> String?)?) {
        preloadPathProvider = provider
    }

    private val inbound = Messenger(object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            pending.remove(msg.arg1)?.complete(msg)
        }
    })

    private val deathRecipient = IBinder.DeathRecipient { handleRemoteDeath("binderDied") }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            connecting = false
            if (service == null) {
                connectedDeferred = CompletableDeferred()
                return
            }
            remote = Messenger(service)
            runCatching { service.linkToDeath(deathRecipient, 0) }
            connectedDeferred.complete(Unit)
            launchPing()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            // قطع موقت؛ درخواست‌های در جریان با شکست مواجه شوند و فراخوانی بعدی دوباره وصل شود.
            remote = null
            connectedDeferred = CompletableDeferred()
            failAllPending()
        }
    }

    fun init(context: Context) {
        if (appCtx == null) appCtx = context.applicationContext
    }

    // ---- گیت ضدِ کرش‌لوپ: بعد از مرگ پروسهٔ بومی تا تغییر مدل غیرفعال می‌ماند ----
    fun isGateDisabled(context: Context? = appCtx): Boolean {
        val ctx = context ?: return false
        return runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_GATE_DISABLED, false)
        }.getOrDefault(false)
    }

    fun gateReason(context: Context? = appCtx): String? {
        val ctx = context ?: return null
        return runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_GATE_REASON, null)
        }.getOrNull()
    }

    fun resetGate(context: Context? = appCtx) {
        val ctx = context ?: return
        runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().clear().apply()
        }
        // کش مرگ قبلی پاک و سرویس تازه دوباره کاوش شود.
        cachedBackendKind = -1
        cachedAvailable = null
        warmUpStarted = false
        scheduleWarmUp()
    }

    /** ارسال پیام بدون انتظار پاسخ (UNLOAD/CANCEL)؛ هیچ درخواست معلق‌ی ثبت نمی‌شود. */
    fun sendOneWay(what: Int) {
        val ctx = appCtx ?: return
        if (isGateDisabled(ctx)) return
        scope.launch {
            if (!connectBlocking()) return@launch
            runCatching {
                remote?.send(Message.obtain().apply { this.what = what })
            }
        }
    }

    private fun disableGate(reason: String) {
        val ctx = appCtx ?: return
        runCatching {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_GATE_DISABLED, true)
                .putString(KEY_GATE_REASON, reason)
                .apply()
        }
        cachedAvailable = false
    }

    // ---- کش بدون انسداد برای فراخوان‌های رشتهٔ اصلی ----
    fun isNativeAvailableCached(): Boolean {
        val ctx = appCtx
        if (ctx != null && isGateDisabled(ctx)) return false
        val known = cachedAvailable
        if (known == null) scheduleWarmUp()
        return known ?: true
    }

    fun backendKindCached(): Int {
        val ctx = appCtx
        if (ctx != null && isGateDisabled(ctx) && cachedBackendKind < 0) return 0
        if (cachedBackendKind < 0) scheduleWarmUp()
        // خوش‌بینانه ۲؛ اگر بیلد واقعاً پل باشد، warmup خیلی سریع کش را اصلاح می‌کند
        // و در بدترین حالت یک درخواست IPC هم به‌سلامت به پاسخ قانون‌محمد می‌رسد.
        return if (cachedBackendKind >= 0) cachedBackendKind else 2
    }

    fun scheduleWarmUp() {
        if (warmUpStarted) return
        warmUpStarted = true
        scope.launch {
            runCatching {
                val reply = requestBlocking(MSG_PING, null, 0, PING_TIMEOUT_MS)
                if (reply != null && reply.arg2 >= 0) {
                    cachedBackendKind = reply.arg2
                    cachedAvailable = true
                    // فقط با استنتاج واقعی llama.cpp پیش‌بارگذاری ارزش دارد؛ پل قالبی مدل لازم ندارد.
                    if (reply.arg2 == 2) preloadModel()
                } else {
                    cachedAvailable = false
                }
            }.onFailure {
                cachedAvailable = false
                Log.w(TAG, "warm-up ping failed: ${it.message}")
            }
        }
    }

    /**
     * بارگذاری مدل در پس‌زمینه، بلافاصله بعد از اتصال سرویس؛ اولین پیام کاربر دیگر
     * معطل تجزیهٔ فایل چندگیگابایتی GGUF نمی‌شود. اگر مدل ناسازگار باشد و پروسه بمیرد،
     * همان گیت ایمنی فعال می‌شود و در چت پاسخ قانون‌محمد جایگزین می‌شود.
     */
    private fun preloadModel() {
        val ctx = appCtx ?: return
        if (isGateDisabled(ctx)) return
        val path = runCatching { preloadPathProvider?.invoke() }.getOrNull()
        if (path.isNullOrBlank()) return
        scope.launch {
            runCatching {
                val reply = requestBlocking(
                    what = MSG_LOAD,
                    data = Bundle().apply { putString(KEY_PATH, path) },
                    timeoutMs = LOAD_TIMEOUT_MS
                )
                if (reply != null && reply.arg2 == 0) {
                    Log.i(TAG, "model preloaded ahead of first chat: $path")
                } else {
                    Log.w(TAG, "model preload did not complete; will retry on first chat")
                }
            }
        }
    }

    private fun launchPing() = scheduleWarmUp()

    @Synchronized
    private fun connectBlocking(): Boolean {
        val ctx = appCtx ?: return false
        remote?.let { return true }
        if (!connecting) {
            connecting = true
            connectedDeferred = CompletableDeferred()
            val intent = Intent(ctx, LlmIsolationService::class.java).apply {
                setPackage(ctx.packageName)
            }
            val bound = runCatching {
                ctx.bindService(intent, connection, Context.BIND_AUTO_CREATE)
            }.getOrDefault(false)
            if (!bound) {
                connecting = false
                return false
            }
        }
        val ok = runBlocking {
            withTimeoutOrNull(BIND_TIMEOUT_MS) { connectedDeferred.await() }
        } != null
        if (!ok) connecting = remote == null
        return ok && remote != null
    }

    /**
     * فراخوانی همگام از رشته‌های پس‌زمینه؛ هرگز روی رشتهٔ اصلی صدا زده نشود
     * (همهٔ فراخوان‌های فعلی از Dispatchers.IO/Default یا رشتهٔ پولر هستند).
     */
    fun requestBlocking(
        what: Int,
        data: Bundle? = null,
        arg2: Int = 0,
        timeoutMs: Long
    ): Message? {
        val ctx = appCtx ?: return null
        if (what != MSG_PING && isGateDisabled(ctx)) return null
        if (!connectBlocking()) return null

        val id = seq.getAndIncrement()
        val msg = Message.obtain().apply {
            this.what = what
            this.arg1 = id
            this.arg2 = arg2
            if (data != null) setData(data)
            replyTo = inbound
        }
        val deferred = CompletableDeferred<Message>()
        pending[id] = deferred

        val target = remote ?: run {
            pending.remove(id)
            return null
        }
        val sent = runCatching { target.send(msg) }.isSuccess
        if (!sent) {
            pending.remove(id)
            return null
        }

        val reply = runBlocking {
            withTimeoutOrNull(timeoutMs) { deferred.await() }
        }
        if (reply == null) {
            pending.remove(id)
            if (what == MSG_COMPLETE) {
                // تولید بومی طولانی شده؛ توقف حلقهٔ توکن را درخواست کن تا CPU هدر نرود.
                runCatching {
                    val cancel = Message.obtain().apply { what = MSG_CANCEL }
                    remote?.send(cancel)
                }
            }
            Log.w(TAG, "request $what timed out after ${timeoutMs}ms")
        }
        return reply
    }

    private fun failAllPending() {
        val entries = pending.entries.toList()
        pending.clear()
        entries.forEach { (_, deferred) ->
            runCatching { deferred.complete(Message.obtain().apply { arg2 = -1 }) }
        }
    }

    private fun handleRemoteDeath(cause: String) {
        Log.e(TAG, "isolated LLM process died ($cause) — engaging safety gate")
        remote = null
        connecting = false
        connectedDeferred = CompletableDeferred()
        runCatching { appCtx?.unbindService(connection) }
        failAllPending()
        disableGate(CRASH_REASON)
    }
}
