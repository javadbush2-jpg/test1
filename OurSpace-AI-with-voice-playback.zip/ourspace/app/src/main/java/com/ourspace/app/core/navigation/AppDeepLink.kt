package com.ourspace.app.core.navigation

/**
 * هدف ناوبری داخلی — نه فقط تب، بلکه خودِ آیتم.
 */
data class AppDeepLink(
    val section: Int,
    val itemId: String? = null,
    /** task | event | shopping | habit | message | memory | debt | account | watchlist | book | food | special | place */
    val category: String? = null,
    val dayKey: String? = null,
    val financeTab: Int? = null,
    val usTab: Int? = null
) {
    companion object {
        const val SECTION_HOME = 0
        const val SECTION_PLANNER = 1
        const val SECTION_CALENDAR = 2
        const val SECTION_CHAT = 3
        const val SECTION_FINANCE = 4
        const val SECTION_MAP = 5
        const val SECTION_US = 6
        const val SECTION_GAMES = 7
        const val SECTION_AI = 8
        const val SECTION_SETTINGS = 9

        fun plannerTask(id: String) = AppDeepLink(SECTION_PLANNER, id, "task")
        fun plannerEvent(id: String) = AppDeepLink(SECTION_PLANNER, id, "event")
        fun plannerShopping(id: String) = AppDeepLink(SECTION_PLANNER, id, "shopping")
        fun plannerHabit(id: String) = AppDeepLink(SECTION_PLANNER, id, "habit")
        fun calendarDay(dayKey: String, itemId: String? = null, category: String? = null) =
            AppDeepLink(SECTION_CALENDAR, itemId, category, dayKey = dayKey)
        fun chatMessage(id: String) = AppDeepLink(SECTION_CHAT, id, "message")
        fun financeDebt(id: String) = AppDeepLink(SECTION_FINANCE, id, "debt", financeTab = 0)
        fun financeTx(id: String) = AppDeepLink(SECTION_FINANCE, id, "transaction", financeTab = 0)
        fun mapPlace(id: String) = AppDeepLink(SECTION_MAP, id, "place")
        fun usMemory(id: String) = AppDeepLink(SECTION_US, id, "memory", usTab = 0)
        fun usWatchlist(id: String) = AppDeepLink(SECTION_US, id, "watchlist", usTab = 1)
        fun usBook(id: String) = AppDeepLink(SECTION_US, id, "book", usTab = 2)
        fun usFood(id: String) = AppDeepLink(SECTION_US, id, "food", usTab = 3)
        fun usSpecial(id: String) = AppDeepLink(SECTION_US, id, "special", usTab = 0)
    }
}
