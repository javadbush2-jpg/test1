package com.ourspace.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.ui.design.OSFormDialog
import com.ourspace.app.ui.design.OSRadius
import com.ourspace.app.ui.design.OSSpacing
import java.util.Calendar

@Composable
fun PersianDatePickerDialog(
    title: String,
    initialEpochMillis: Long = System.currentTimeMillis(),
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit
) {
    val initial = remember(initialEpochMillis) { PersianDateFormatter.jalaliDate(initialEpochMillis) }
    var visibleYear by remember { mutableIntStateOf(initial.year) }
    var visibleMonth by remember { mutableIntStateOf(initial.month) }
    var selectedYear by remember { mutableIntStateOf(initial.year) }
    var selectedMonth by remember { mutableIntStateOf(initial.month) }
    var selectedDay by remember { mutableIntStateOf(initial.day) }

    fun moveMonth(delta: Int) {
        val absolute = visibleYear * 12 + visibleMonth - 1 + delta
        val targetYear = Math.floorDiv(absolute, 12)
        if (targetYear in 1200..1600) {
            visibleYear = targetYear
            visibleMonth = Math.floorMod(absolute, 12) + 1
        }
    }

    val daysInMonth = PersianDateFormatter.daysInJalaliMonth(visibleYear, visibleMonth)
    val firstDayEpoch = PersianDateFormatter.toEpochMillis(visibleYear, visibleMonth, 1)
    val firstWeekday = Calendar.getInstance().apply { timeInMillis = firstDayEpoch }
        .get(Calendar.DAY_OF_WEEK) % 7 // Saturday = 0
    val weekDays = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

    OSFormDialog(
        title = title,
        emoji = "📅",
        onDismiss = onDismiss,
        onConfirm = {
            onConfirm(PersianDateFormatter.toEpochMillis(selectedYear, selectedMonth, selectedDay))
        },
        confirmLabel = "تأیید تاریخ",
        dismissLabel = "انصراف"
    ) {
        // Month navigation
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(OSRadius.md))
                .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.55f))
                .padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                Modifier
                    .clip(CircleShape)
                    .clickable { moveMonth(-1) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    "‹ ماه قبل",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                "${PersianDateFormatter.jalaliMonthName(visibleMonth)} ${PersianDateFormatter.toPersianDigits(visibleYear)}",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Box(
                Modifier
                    .clip(CircleShape)
                    .clickable { moveMonth(1) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    "ماه بعد ›",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Weekday headers
        Row(Modifier.fillMaxWidth()) {
            weekDays.forEach { day ->
                Text(
                    day,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }

        // Day grid
        repeat(6) { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                repeat(7) { column ->
                    val day = row * 7 + column - firstWeekday + 1
                    val inMonth = day in 1..daysInMonth
                    val selected = inMonth &&
                        visibleYear == selectedYear &&
                        visibleMonth == selectedMonth &&
                        day == selectedDay

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .padding(2.dp)
                            .clip(CircleShape)
                            .then(
                                when {
                                    selected -> Modifier.background(MaterialTheme.colorScheme.primary)
                                    inMonth -> Modifier.clickable {
                                        selectedYear = visibleYear
                                        selectedMonth = visibleMonth
                                        selectedDay = day
                                    }
                                    else -> Modifier
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (inMonth) {
                            Text(
                                PersianDateFormatter.toPersianDigits(day),
                                color = if (selected) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Text(
            "تاریخ انتخاب‌شده: ${PersianDateFormatter.formatDate(PersianDateFormatter.toEpochMillis(selectedYear, selectedMonth, selectedDay))}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(OSRadius.sm))
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                .padding(horizontal = OSSpacing.sm, vertical = OSSpacing.xs)
        )
    }
}
