package com.ourspace.app.feature.games

import com.ourspace.app.core.sync.GameEvent
import com.ourspace.app.core.sync.GameMessageProtocol

internal enum class SharedGame(val wireId: String, val title: String, val description: String) {
    TIC_TAC_TOE("tic_tac_toe", "دوز", "سه خانهٔ پشت‌سرهم را پر کنید."),
    CONNECT_FOUR("connect_four", "چهار در یک خط", "چهار مهره را در یک ردیف، ستون یا قطر بچینید."),
    ROCK_PAPER_SCISSORS("rock_paper_scissors", "سنگ، کاغذ، قیچی", "انتخاب‌ها با تعهد رمزنگاری‌شده پنهان می‌مانند."),
    NIM("nim", "برداشت چوب", "در هر نوبت یک تا سه چوب بردارید؛ برداشتن چوب آخر برنده است."),
    REVERSI("reversi", "ریورسی", "با محاصرهٔ مهره‌های حریف، آن‌ها را به رنگ خود برگردانید.");

    companion object {
        fun fromWireId(value: String): SharedGame? = entries.firstOrNull { it.wireId == value }
    }
}

internal data class RpsRoundResult(
    val round: Int,
    val hostChoice: String,
    val guestChoice: String,
    val winnerDeviceId: String?
)

internal data class OnlineGameSnapshot(
    val board: List<Int> = emptyList(),
    val remainingTokens: Int = 15,
    val moveCount: Int = 0,
    val currentPlayerDeviceId: String? = null,
    val winnerDeviceId: String? = null,
    val isDraw: Boolean = false,
    val isFinished: Boolean = false,
    val legalMoves: Set<Int> = emptySet(),
    val passNotice: Boolean = false,
    val hostScore: Int = 0,
    val guestScore: Int = 0,
    val rpsRound: Int = 1,
    val committedDeviceIds: Set<String> = emptySet(),
    val revealedChoices: Map<String, String> = emptyMap(),
    val lastCompletedRpsRound: RpsRoundResult? = null
)

internal data class OnlineGameSession(
    val id: String,
    val game: SharedGame,
    val hostDeviceId: String,
    val guestDeviceId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val snapshot: OnlineGameSnapshot
) {
    val isJoined: Boolean get() = guestDeviceId != null
    val isFinished: Boolean get() = snapshot.isFinished
}

/** Rebuild every shared game from the append-only, synced event messages. */
internal fun buildOnlineGameSessions(events: List<GameEvent>): List<OnlineGameSession> {
    val ordered = events.sortedWith(compareBy<GameEvent> { it.createdAt }.thenBy { it.messageId })
    return ordered.groupBy { it.sessionId }
        .values
        .mapNotNull { sessionEvents ->
            val start = sessionEvents.firstOrNull { it.action == "start" && it.arguments.isEmpty() } ?: return@mapNotNull null
            val game = SharedGame.fromWireId(start.gameId) ?: return@mapNotNull null
            val sameGameEvents = sessionEvents.filter { it.gameId == game.wireId }
                .sortedWith(compareBy<GameEvent> { it.createdAt }.thenBy { it.messageId })
            // رویداد delete (از هر یک از دو گوشی) جلسه را برای هر دو طرف از لیست برمی‌دارد
            if (sameGameEvents.any { it.action == "delete" && it.arguments.isEmpty() }) {
                return@mapNotNull null
            }
            val guest = sameGameEvents.firstOrNull {
                it.action == "join" && it.arguments.isEmpty() && it.senderDeviceId != start.senderDeviceId
            }?.senderDeviceId
            val snapshot = reduceOnlineGame(game, start.sessionId, start.senderDeviceId, guest, sameGameEvents)
            OnlineGameSession(
                id = start.sessionId,
                game = game,
                hostDeviceId = start.senderDeviceId,
                guestDeviceId = guest,
                createdAt = start.createdAt,
                updatedAt = sameGameEvents.maxOfOrNull { it.createdAt } ?: start.createdAt,
                snapshot = snapshot
            )
        }
        .sortedWith(compareByDescending<OnlineGameSession> { it.updatedAt }.thenByDescending { it.id })
}

private fun reduceOnlineGame(
    game: SharedGame,
    sessionId: String,
    hostDeviceId: String,
    guestDeviceId: String?,
    events: List<GameEvent>
): OnlineGameSnapshot = when (game) {
    SharedGame.TIC_TAC_TOE -> reduceTicTacToe(hostDeviceId, guestDeviceId, events)
    SharedGame.CONNECT_FOUR -> reduceConnectFour(hostDeviceId, guestDeviceId, events)
    SharedGame.ROCK_PAPER_SCISSORS -> reduceRockPaperScissors(sessionId, hostDeviceId, guestDeviceId, events)
    SharedGame.NIM -> reduceNim(hostDeviceId, guestDeviceId, events)
    SharedGame.REVERSI -> reduceReversi(hostDeviceId, guestDeviceId, events)
}

private fun reduceTicTacToe(
    host: String,
    guest: String?,
    events: List<GameEvent>
): OnlineGameSnapshot {
    val board = MutableList(9) { 0 }
    var moves = 0
    var winnerMark = 0
    for (event in orderedTurnMoves(events)) {
        if (guest == null || winnerMark != 0) continue
        val ply = event.arguments[0].toIntOrNull() ?: continue
        if (ply != moves) continue
        val expected = if (moves % 2 == 0) host else guest
        if (event.senderDeviceId != expected) continue
        val cell = event.arguments[1].toIntOrNull() ?: continue
        if (cell !in board.indices || board[cell] != 0) continue
        val mark = if (event.senderDeviceId == host) 1 else 2
        board[cell] = mark
        moves++
        winnerMark = ticTacToeWinner(board)
    }
    val draw = winnerMark == 0 && board.none { it == 0 }
    val finished = winnerMark != 0 || draw
    return OnlineGameSnapshot(
        board = board,
        moveCount = moves,
        currentPlayerDeviceId = if (guest != null && !finished) if (moves % 2 == 0) host else guest else null,
        winnerDeviceId = when (winnerMark) { 1 -> host; 2 -> guest; else -> null },
        isDraw = draw,
        isFinished = finished
    )
}

private fun reduceConnectFour(
    host: String,
    guest: String?,
    events: List<GameEvent>
): OnlineGameSnapshot {
    val rows = 6
    val columns = 7
    val board = MutableList(rows * columns) { 0 }
    var moves = 0
    var winnerMark = 0
    for (event in orderedTurnMoves(events)) {
        if (guest == null || winnerMark != 0) continue
        val ply = event.arguments[0].toIntOrNull() ?: continue
        if (ply != moves) continue
        val expected = if (moves % 2 == 0) host else guest
        if (event.senderDeviceId != expected) continue
        val column = event.arguments[1].toIntOrNull() ?: continue
        if (column !in 0 until columns) continue
        val row = (rows - 1 downTo 0).firstOrNull { board[it * columns + column] == 0 } ?: continue
        val mark = if (event.senderDeviceId == host) 1 else 2
        board[row * columns + column] = mark
        moves++
        if (hasConnectFour(board, row, column, mark, rows, columns)) winnerMark = mark
    }
    val draw = winnerMark == 0 && board.none { it == 0 }
    val finished = winnerMark != 0 || draw
    return OnlineGameSnapshot(
        board = board,
        moveCount = moves,
        currentPlayerDeviceId = if (guest != null && !finished) if (moves % 2 == 0) host else guest else null,
        winnerDeviceId = when (winnerMark) { 1 -> host; 2 -> guest; else -> null },
        isDraw = draw,
        isFinished = finished
    )
}

private fun reduceNim(
    host: String,
    guest: String?,
    events: List<GameEvent>
): OnlineGameSnapshot {
    var remaining = 15
    var moves = 0
    var winner: String? = null
    for (event in orderedTurnMoves(events)) {
        if (guest == null || winner != null) continue
        val ply = event.arguments[0].toIntOrNull() ?: continue
        if (ply != moves) continue
        val expected = if (moves % 2 == 0) host else guest
        if (event.senderDeviceId != expected) continue
        val take = event.arguments[1].toIntOrNull() ?: continue
        if (take !in 1..3 || take > remaining) continue
        remaining -= take
        moves++
        if (remaining == 0) winner = event.senderDeviceId
    }
    return OnlineGameSnapshot(
        remainingTokens = remaining,
        moveCount = moves,
        currentPlayerDeviceId = if (guest != null && winner == null) if (moves % 2 == 0) host else guest else null,
        winnerDeviceId = winner,
        isFinished = winner != null
    )
}

private fun reduceReversi(
    host: String,
    guest: String?,
    events: List<GameEvent>
): OnlineGameSnapshot {
    val board = initialReversiBoard()
    if (guest == null) return OnlineGameSnapshot(board = board)
    var current = host
    var moves = 0
    var winner: String? = null
    var draw = false
    var passNotice = false
    for (event in orderedTurnMoves(events)) {
        if (winner != null || draw) continue
        val ply = event.arguments[0].toIntOrNull() ?: continue
        if (ply != moves) continue
        if (event.senderDeviceId != current) continue
        val mark = if (current == host) 1 else 2
        val cell = event.arguments[1].toIntOrNull() ?: continue
        val updated = applyReversiMove(board, cell, mark) ?: continue
        for (index in board.indices) board[index] = updated[index]
        moves++
        val opponent = if (current == host) guest else host
        val opponentMark = if (opponent == host) 1 else 2
        val ownLegal = reversiLegalMoves(board, mark)
        val opponentLegal = reversiLegalMoves(board, opponentMark)
        passNotice = false
        when {
            opponentLegal.isNotEmpty() -> current = opponent
            ownLegal.isNotEmpty() -> passNotice = true
            else -> {
                val hostCount = board.count { it == 1 }
                val guestCount = board.count { it == 2 }
                draw = hostCount == guestCount
                winner = when {
                    hostCount > guestCount -> host
                    guestCount > hostCount -> guest
                    else -> null
                }
            }
        }
    }
    val currentMark = if (current == host) 1 else 2
    val legal = if (winner == null && !draw) reversiLegalMoves(board, currentMark) else emptySet()
    return OnlineGameSnapshot(
        board = board.toList(),
        moveCount = moves,
        currentPlayerDeviceId = if (winner == null && !draw) current else null,
        winnerDeviceId = winner,
        isDraw = draw,
        isFinished = winner != null || draw,
        legalMoves = legal,
        passNotice = passNotice
    )
}

private fun reduceRockPaperScissors(
    sessionId: String,
    host: String,
    guest: String?,
    events: List<GameEvent>
): OnlineGameSnapshot {
    if (guest == null) return OnlineGameSnapshot()
    var round = 1
    var hostScore = 0
    var guestScore = 0
    var previous: RpsRoundResult? = null
    var activeCommits: Map<String, String> = emptyMap()
    var activeReveals: Map<String, String> = emptyMap()

    // Rounds are resolved from the complete event set, not arrival order. This keeps the
    // result identical on both phones even if their clocks or packet arrival order differ.
    while (round <= events.size + 1) {
        val commitments = mutableMapOf<String, String>()
        for (player in listOf(host, guest)) {
            val first = events.firstOrNull { event ->
                event.action == "commit" && event.senderDeviceId == player && event.arguments.size == 2 &&
                    event.arguments[0].toIntOrNull() == round && event.arguments[1].matches(HEX_SHA256)
            }
            if (first != null) commitments[player] = first.arguments[1]
        }
        val reveals = mutableMapOf<String, String>()
        for (player in listOf(host, guest)) {
            val commitment = commitments[player] ?: continue
            val valid = events.firstOrNull { event ->
                if (event.action != "reveal" || event.senderDeviceId != player || event.arguments.size != 3 ||
                    event.arguments[0].toIntOrNull() != round
                ) return@firstOrNull false
                val choice = event.arguments[1]
                val nonce = event.arguments[2]
                choice in RPS_CHOICES && nonce.isNotBlank() &&
                    GameMessageProtocol.rockPaperScissorsCommitment(sessionId, round, player, choice, nonce) == commitment
            }
            if (valid != null) reveals[player] = valid.arguments[1]
        }
        if (commitments.keys.containsAll(listOf(host, guest)) && reveals.keys.containsAll(listOf(host, guest))) {
            val hostChoice = reveals.getValue(host)
            val guestChoice = reveals.getValue(guest)
            val result = handWinner(hostChoice, guestChoice)
            val winner = when (result) {
                1 -> host
                2 -> guest
                else -> null
            }
            if (winner == host) hostScore++ else if (winner == guest) guestScore++
            previous = RpsRoundResult(round, hostChoice, guestChoice, winner)
            round++
        } else {
            activeCommits = commitments
            activeReveals = reveals
            break
        }
    }
    return OnlineGameSnapshot(
        hostScore = hostScore,
        guestScore = guestScore,
        rpsRound = round,
        committedDeviceIds = activeCommits.keys,
        revealedChoices = activeReveals,
        lastCompletedRpsRound = previous
    )
}

private fun orderedTurnMoves(events: List<GameEvent>): List<GameEvent> =
    events.asSequence()
        .filter { it.action == "move" && it.arguments.size == 2 && it.arguments[0].toIntOrNull() != null }
        .sortedWith(
            compareBy<GameEvent> { it.arguments[0].toIntOrNull() ?: Int.MAX_VALUE }
                .thenBy { it.createdAt }
                .thenBy { it.messageId }
        )
        .toList()

internal fun ticTacToeWinner(board: List<Int>): Int {
    val lines = listOf(
        listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
        listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
        listOf(0, 4, 8), listOf(2, 4, 6)
    )
    return lines.firstNotNullOfOrNull { line ->
        val player = board[line.first()]
        player.takeIf { it != 0 && line.all { cell -> board[cell] == player } }
    } ?: 0
}

internal fun hasConnectFour(board: List<Int>, row: Int, column: Int, player: Int, rows: Int = 6, columns: Int = 7): Boolean {
    fun countDirection(rowStep: Int, columnStep: Int, sign: Int): Int {
        var r = row + rowStep * sign
        var c = column + columnStep * sign
        var count = 0
        while (r in 0 until rows && c in 0 until columns && board[r * columns + c] == player) {
            count++
            r += rowStep * sign
            c += columnStep * sign
        }
        return count
    }
    return listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1).any { (rowStep, columnStep) ->
        1 + countDirection(rowStep, columnStep, 1) + countDirection(rowStep, columnStep, -1) >= 4
    }
}

internal fun initialReversiBoard(): MutableList<Int> = MutableList(64) { 0 }.also { board ->
    board[3 * 8 + 3] = 2
    board[3 * 8 + 4] = 1
    board[4 * 8 + 3] = 1
    board[4 * 8 + 4] = 2
}

internal fun reversiLegalMoves(board: List<Int>, player: Int): Set<Int> =
    board.indices.filterTo(linkedSetOf()) { cell -> board[cell] == 0 && reversiFlips(board, cell, player).isNotEmpty() }

internal fun applyReversiMove(board: List<Int>, cell: Int, player: Int): List<Int>? {
    if (cell !in board.indices || board[cell] != 0) return null
    val flips = reversiFlips(board, cell, player)
    if (flips.isEmpty()) return null
    return board.toMutableList().also { updated ->
        updated[cell] = player
        flips.forEach { updated[it] = player }
    }
}

private fun reversiFlips(board: List<Int>, cell: Int, player: Int): Set<Int> {
    if (cell !in board.indices || board[cell] != 0 || player !in 1..2) return emptySet()
    val row = cell / 8
    val column = cell % 8
    val opponent = if (player == 1) 2 else 1
    val directions = listOf(-1 to -1, -1 to 0, -1 to 1, 0 to -1, 0 to 1, 1 to -1, 1 to 0, 1 to 1)
    val result = linkedSetOf<Int>()
    for ((rowStep, columnStep) in directions) {
        var r = row + rowStep
        var c = column + columnStep
        val line = mutableListOf<Int>()
        while (r in 0..7 && c in 0..7 && board[r * 8 + c] == opponent) {
            line += r * 8 + c
            r += rowStep
            c += columnStep
        }
        if (line.isNotEmpty() && r in 0..7 && c in 0..7 && board[r * 8 + c] == player) result += line
    }
    return result
}

private fun handWinner(first: String, second: String): Int = when {
    first == second -> 0
    first == "rock" && second == "scissors" -> 1
    first == "paper" && second == "rock" -> 1
    first == "scissors" && second == "paper" -> 1
    else -> 2
}

private val RPS_CHOICES = setOf("rock", "paper", "scissors")
private val HEX_SHA256 = Regex("[0-9a-f]{64}")
