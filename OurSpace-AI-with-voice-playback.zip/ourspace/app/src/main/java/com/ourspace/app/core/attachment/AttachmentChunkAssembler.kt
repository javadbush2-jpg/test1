package com.ourspace.app.core.attachment

import android.content.Context
import android.util.Base64
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import org.json.JSONObject

/** Durable-enough receiver for realtime attachment chunks. A reconnect can simply resend chunks. */
class AttachmentChunkAssembler(context: Context) {
    private val root = File(context.cacheDir, "ourspace_attachment_chunks").apply { mkdirs() }

    @Synchronized
    fun accept(chunk: JSONObject): JSONObject? {
        val transferId = chunk.getString("transferId").take(100)
        require(transferId.matches(Regex("[A-Za-z0-9_-]{8,100}"))) { "Invalid transfer id" }
        val index = chunk.getInt("index")
        val total = chunk.getInt("total")
        require(total in 1..MAX_CHUNKS) { "Invalid attachment chunk count" }
        require(index in 0 until total)
        val bytes = Base64.decode(chunk.getString("data"), Base64.NO_WRAP)
        require(bytes.size in 1..CHUNK_BYTES)

        val dir = File(root, transferId).apply { mkdirs() }
        val meta = File(dir, "meta.json")
        val incomingMetadata = chunk.getJSONObject("attachment")
        if (!meta.exists()) {
            meta.writeText(incomingMetadata.toString(), Charsets.UTF_8)
            File(dir, "total").writeText(total.toString(), Charsets.UTF_8)
        } else {
            require(File(dir, "total").readText() == total.toString())
            val existingMetadata = JSONObject(meta.readText(Charsets.UTF_8))
            require(existingMetadata.optString("id") == incomingMetadata.optString("id")) { "Attachment metadata changed during transfer" }
            require(existingMetadata.optString("sha256") == incomingMetadata.optString("sha256")) { "Attachment hash changed during transfer" }
            require(existingMetadata.optLong("sizeBytes") == incomingMetadata.optLong("sizeBytes")) { "Attachment size changed during transfer" }
        }

        val metadata = JSONObject(meta.readText(Charsets.UTF_8))
        val expectedSize = metadata.getLong("sizeBytes")
        require(expectedSize in 1..(CHUNK_BYTES.toLong() * MAX_CHUNKS)) { "Invalid attachment size" }
        require(total == ((expectedSize + CHUNK_BYTES - 1) / CHUNK_BYTES).toInt()) { "Attachment chunk count mismatch" }
        val expectedChunkSize = minOf(CHUNK_BYTES.toLong(), expectedSize - index.toLong() * CHUNK_BYTES).toInt()
        require(expectedChunkSize > 0 && bytes.size == expectedChunkSize) { "Attachment chunk size mismatch" }

        RandomAccessFile(File(dir, "data.bin"), "rw").use { raf ->
            raf.seek(index.toLong() * CHUNK_BYTES)
            raf.write(bytes)
        }
        File(dir, "part_$index").writeText(bytes.size.toString(), Charsets.UTF_8)

        val received = (0 until total).count { File(dir, "part_$it").exists() }
        if (received < total) return null

        val dataFile = File(dir, "data.bin")
        val content = ByteArray(expectedSize.toInt())
        RandomAccessFile(dataFile, "r").use { it.readFully(content) }
        val expectedHash = metadata.getString("sha256")
        require(AttachmentIntegrity.verify(content, expectedSize, expectedHash)) { "Attachment integrity check failed" }

        val result = JSONObject(metadata.toString())
            // SyncSnapshotCodec decodes URL-safe Base64, so use the matching alphabet.
            .put("content", Base64.encodeToString(content, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING))
            .put("deleted", false)
        // Do not delete the assembled bytes yet. The database may reject the attachment
        // temporarily if its message/memory parent has not arrived. The caller commits the
        // attachment first, then calls complete(); a retry can re-assemble from cached chunks.
        return result
    }

    @Synchronized
    fun complete(transferId: String) {
        if (transferId.matches(Regex("[A-Za-z0-9_-]{8,100}"))) {
            File(root, transferId).deleteRecursively()
        }
    }

    companion object {
        const val CHUNK_BYTES = 24 * 1024
        // Supports the app's 20 MiB attachment limit (roughly 854 chunks at 24 KiB).
        private const val MAX_CHUNKS = 1024
    }
}
