package com.ourspace.app.feature.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.ai.AiProtocol

data class AiChatMessage(
    val id: String,
    val role: String,
    val text: String,
    val engine: String? = null
)

@Composable
fun AiChatScreen(
    isHost: Boolean,
    isPaired: Boolean,
    busy: Boolean,
    lastError: String?,
    latestSuggestion: AiProtocol.Suggestion?,
    modelStatusLabel: String,
    onSend: (message: String, history: List<Pair<String, String>>) -> Unit,
    onClearError: () -> Unit = {},
    onOpenSettings: () -> Unit = {}
) {
    val messages = remember { mutableStateListOf<AiChatMessage>() }
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(latestSuggestion?.requestId) {
        val suggestion = latestSuggestion ?: return@LaunchedEffect
        val answerId = "a-" + suggestion.requestId
        if (messages.none { it.id == answerId }) {
            val body = suggestion.text.ifBlank {
                suggestion.alternatives.firstOrNull().orEmpty()
            }
            if (body.isNotBlank()) {
                messages.add(
                    AiChatMessage(
                        id = answerId,
                        role = "assistant",
                        text = body,
                        engine = suggestion.engine
                    )
                )
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            runCatching { listState.animateScrollToItem(messages.lastIndex) }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "چت با هوش مصنوعی",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black
                )
                Text(
                    if (isHost) "میزبان · $modelStatusLabel" else "همراه · از طریق میزبان",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { messages.clear() }) {
                Icon(Icons.Outlined.DeleteSweep, contentDescription = "پاک کردن")
            }
        }

        if (!isPaired && !isHost) {
            Text(
                "برای استفاده روی گوشی همراه، جفت‌سازی لازم است.",
                Modifier.padding(16.dp),
                color = MaterialTheme.colorScheme.error
            )
        }

        if (!lastError.isNullOrBlank()) {
            Surface(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        lastError.orEmpty(),
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    TextButton(onClick = onClearError) { Text("باشه") }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Outlined.Psychology,
                                contentDescription = null,
                                Modifier.size(36.dp),
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("از من بپرس", fontWeight = FontWeight.Bold)
                        Text(
                            "پیشنهاد قرار، پیام، ایدهٔ کادو و …",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(onClick = onOpenSettings) { Text("تنظیمات مدل") }
                    }
                }
            }
            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        Modifier.widthIn(max = 300.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = if (isUser) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(msg.text, style = MaterialTheme.typography.bodyMedium)
                            val engineLabel = msg.engine
                            if (!engineLabel.isNullOrBlank()) {
                                Text(
                                    engineLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            }
            if (busy) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text("در حال فکر کردن…", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it.take(2000) },
                modifier = Modifier.weight(1f),
                placeholder = { Text("پیامت را بنویس…") },
                maxLines = 4
            )
            FilledIconButton(
                onClick = {
                    val text = draft.trim()
                    if (text.isEmpty() || busy) return@FilledIconButton
                    messages.add(
                        AiChatMessage(
                            id = "u-" + System.currentTimeMillis(),
                            role = "user",
                            text = text
                        )
                    )
                    draft = ""
                    val history = messages.map { m -> m.role to m.text }
                    onSend(text, history)
                },
                enabled = draft.isNotBlank() && !busy
            ) {
                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "ارسال")
            }
        }
    }
}
