package com.ourspace.app.core.reminder

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Small process-lifetime IO scope used only for reading reminder records. */
internal object ReminderSchedulingScope {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    fun launch(block: suspend () -> Unit) { scope.launch { block() } }
}
