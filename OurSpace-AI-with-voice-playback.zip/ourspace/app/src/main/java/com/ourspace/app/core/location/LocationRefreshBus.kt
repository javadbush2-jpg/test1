package com.ourspace.app.core.location

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * One-shot events for partner location refresh outcomes so the UI can show real success/failure
 * instead of only "request was queued".
 */
object LocationRefreshBus {
    sealed class Event {
        data class Success(val locationId: String, val at: Long = System.currentTimeMillis()) : Event()
        data class Failure(val reason: String, val at: Long = System.currentTimeMillis()) : Event()
    }

    private val _events = MutableSharedFlow<Event>(extraBufferCapacity = 8)
    val events: SharedFlow<Event> = _events.asSharedFlow()

    fun emitSuccess(locationId: String) {
        _events.tryEmit(Event.Success(locationId))
    }

    fun emitFailure(reason: String) {
        _events.tryEmit(Event.Failure(reason))
    }
}
