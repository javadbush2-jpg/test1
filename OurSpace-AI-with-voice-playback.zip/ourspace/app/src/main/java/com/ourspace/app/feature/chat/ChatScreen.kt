package com.ourspace.app.feature.chat

import java.io.File

import androidx.core.content.ContextCompat

import androidx.compose.material.icons.outlined.Stop

import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause

import android.media.MediaRecorder
import android.media.MediaPlayer
import android.media.AudioAttributes

import android.content.pm.PackageManager

import android.Manifest

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Reply
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import kotlin.math.abs
import androidx.compose.material3.AlertDialog
import com.ourspace.app.ui.design.OSConfirmDialog
import com.ourspace.app.ui.design.OSFormDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.core.database.AttachmentEntity
import com.ourspace.app.core.notification.OurSpaceNotificationCenter

import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import com.ourspace.app.core.database.TelegramStickerEntity
import com.ourspace.app.core.database.TelegramStickerPackEntity
import com.ourspace.app.core.sync.GameMessageProtocol
import com.ourspace.app.core.telegram.TelegramStickerClient
import java.util.zip.GZIPInputStream
import java.io.ByteArrayInputStream
import com.ourspace.app.core.database.MessageEntity
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.core.security.AppLockSession
import com.ourspace.app.ui.AppViewModel
import androidx.compose.runtime.collectAsState
import com.ourspace.app.ui.components.ChatBackgroundFromPrefs

@Composable
fun ChatScreen(
    focusMessageId: String? = null,
    onFocusConsumed: () -> Unit = {},
    onOpenDeepLink: (com.ourspace.app.core.navigation.AppDeepLink) -> Unit = {},
    ownDeviceId: String,
    isPaired: Boolean,
    messages: List<MessageEntity>,
    attachments: List<AttachmentEntity>,
    syncState: AppViewModel.SyncState,
    attachmentAction: AppViewModel.AttachmentActionState,
    chatAction: AppViewModel.ChatActionState = AppViewModel.ChatActionState(),
    peerTyping: Boolean = false,
    pendingSendIds: Set<String> = emptySet(),
    onSend: suspend (String, String?) -> Boolean,
    onSendAttachment: (String, String?) -> Unit,
    onSaveAttachment: (String, String) -> Unit,
    onEdit: (MessageEntity, String) -> Unit,
    onDelete: (MessageEntity) -> Unit,
    onReact: (MessageEntity, String) -> Unit,
    onMarkVisibleRead: (List<String>) -> Unit = {},
    onTyping: (Boolean) -> Unit = {},
    onStampDeliveries: () -> Unit = {},
    onSearchMessages: suspend (String) -> List<MessageEntity> = { emptyList() },
    onFindMessage: suspend (String) -> MessageEntity? = { null },
    onLoadOlder: suspend (MessageEntity) -> Int,
    onLoadAttachment: suspend (String) -> AttachmentEntity? = { null },
    onSync: () -> Unit,
    telegramStickerPacks: List<TelegramStickerPackEntity> = emptyList(),
    onDeleteTelegramPack: (String) -> Unit = {},
    onObserveTelegramStickers: (String) -> Flow<List<TelegramStickerEntity>> = { kotlinx.coroutines.flow.emptyFlow() },
    onSendTelegramSticker: (String, String?) -> Unit = { _, _ -> },
    peerLastSeenAt: Long = 0L,
    onSendVoiceMessage: (ByteArray, Int, String?) -> Unit = { _, _, _ -> },
    onRequestAiSuggestion: (String) -> Unit = {},
    aiSuggestionText: String? = null,
    aiAlternatives: List<String> = emptyList(),
    aiBusy: Boolean = false,
    aiError: String? = null,
    onClearAiSuggestion: () -> Unit = {}
) {
    if (!isPaired) {
        ChatLockedState()
        return
    }

    // وقتی گفتگو باز و در پیش‌زمینه است: نوتیف پیام جدید نده و قبلی‌ها را پاک کن
    val chatContext = LocalContext.current.applicationContext
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val notifications = OurSpaceNotificationCenter(chatContext)
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    OurSpaceNotificationCenter.setChatScreenActive(true)
                    notifications.clearChatMessageNotifications()
                }
                Lifecycle.Event.ON_PAUSE,
                Lifecycle.Event.ON_STOP -> {
                    OurSpaceNotificationCenter.setChatScreenActive(false)
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            OurSpaceNotificationCenter.setChatScreenActive(true)
            notifications.clearChatMessageNotifications()
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            OurSpaceNotificationCenter.setChatScreenActive(false)
        }
    }

    val chatMessages = remember(messages) {
        messages.filterNot { GameMessageProtocol.isProtocolMessage(it.text) }
    }
    LaunchedEffect(chatMessages.size) {
        onStampDeliveries()
    }

    val listState = rememberLazyListState()
    LaunchedEffect(focusMessageId, chatMessages) {
        val target = focusMessageId?.takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        val idx = chatMessages.indexOfFirst { it.id == target }
        if (idx >= 0) {
            runCatching { listState.animateScrollToItem(idx.coerceAtLeast(0)) }
            onFocusConsumed()
        }
    }
    val chatScope = rememberCoroutineScope()
    var pendingScrollToId by remember { mutableStateOf<String?>(null) }
    var highlightMessageId by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<MessageEntity>?>(null) }
    var searchFailed by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var pendingDeleteMessage by remember { mutableStateOf<MessageEntity?>(null) }
    var isSearching by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    val messageMap = remember(chatMessages, searchResults) { (chatMessages + searchResults.orEmpty()).associateBy { it.id } }
    var replyTo by remember { mutableStateOf<MessageEntity?>(null) }
    var selected by remember { mutableStateOf<MessageEntity?>(null) }
    var editing by remember { mutableStateOf<MessageEntity?>(null) }
    var selectedAttachment by remember { mutableStateOf<AttachmentEntity?>(null) }
    var pendingExport by remember { mutableStateOf<AttachmentEntity?>(null) }
    var resolvedQuotes by remember { mutableStateOf<Map<String, MessageEntity>>(emptyMap()) }
    val loadedMessageIds = remember(chatMessages, searchResults) {
        (chatMessages + searchResults.orEmpty()).mapTo(HashSet()) { it.id }
    }
    val attachmentsByMessage = remember(attachments, loadedMessageIds) {
        // Only index attachments for currently loaded/search-result messages; do not build a
        // second in-memory map for unrelated memories or older, unloaded chat pages.
        attachments.asSequence()
            .mapNotNull { attachment ->
                val messageId = attachment.messageId
                if (messageId != null && messageId in loadedMessageIds) messageId to attachment else null
            }
            .groupBy(keySelector = { it.first }, valueTransform = { it.second })
    }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            onSendAttachment(it.toString(), replyTo?.id)
            replyTo = null
        }
    }
    val attachmentSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val attachment = pendingExport
        if (uri != null && attachment != null) onSaveAttachment(attachment.id, uri.toString())
        pendingExport = null
    }

    val visibleMessages = if (searchQuery.isBlank()) chatMessages else searchResults.orEmpty()

    // لمس پیش‌نمایش ریپلای → اسکرول به پیام اصلی (در صورت نیاز با بارگذاری تاریخچهٔ قدیمی‌تر)
    LaunchedEffect(pendingScrollToId, visibleMessages.map { it.id }) {
        val targetId = pendingScrollToId ?: return@LaunchedEffect
        val index = visibleMessages.indexOfFirst { it.id == targetId }
        if (index >= 0) {
            listState.animateScrollToItem(index)
            highlightMessageId = targetId
            delay(1_400L)
            if (highlightMessageId == targetId) highlightMessageId = null
            pendingScrollToId = null
            return@LaunchedEffect
        }
        if (searchQuery.isNotBlank() || visibleMessages.isEmpty()) {
            pendingScrollToId = null
            return@LaunchedEffect
        }
        val added = onLoadOlder(visibleMessages.first())
        if (added <= 0) {
            pendingScrollToId = null
        }
    }

    LaunchedEffect(searchQuery) {
        val query = searchQuery.trim()
        if (query.isBlank()) {
            searchResults = null
            searchFailed = false
            isSearching = false
        } else {
            searchResults = emptyList()
            searchFailed = false
            isSearching = true
            delay(250)
            try {
                searchResults = onSearchMessages(query).filterNot {
                    GameMessageProtocol.isProtocolMessage(it.text)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                searchFailed = true
            } finally {
                isSearching = false
            }
        }
    }
    LaunchedEffect(searchQuery, searchResults) {
        val results = searchResults
        if (searchQuery.isNotBlank() && !results.isNullOrEmpty()) {
            withFrameNanos { }
            // The list may have been cleared while waiting for the next frame.
            val itemCount = listState.layoutInfo.totalItemsCount
            if (itemCount > 0) {
                listState.scrollToItem(results.lastIndex.coerceIn(0, itemCount - 1))
            }
        }
    }
    LaunchedEffect(chatMessages, searchResults) {
        val known = (chatMessages + searchResults.orEmpty()).associateBy { it.id }
        val missingReplyIds = (chatMessages + searchResults.orEmpty())
            .mapNotNull { it.replyToId }
            .distinct()
            .filter { it !in known && it !in resolvedQuotes }
        var resolved = resolvedQuotes
        for (id in missingReplyIds) {
            try {
                val found = onFindMessage(id)
                if (found != null && !found.isDeleted) resolved = resolved + (id to found)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // Keep the conversation usable if a reply target cannot be loaded right now.
            }
        }
        resolvedQuotes = resolved
    }
    // Read receipts are only written for incoming messages that are actually visible.
    LaunchedEffect(listState, visibleMessages, ownDeviceId) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.mapNotNull { it.key as? String } }
            .collect { visibleIds ->
                val ids = visibleIds.toSet()
                val unreadVisible = visibleMessages.asSequence()
                    .filter { it.id in ids && it.senderDeviceId != ownDeviceId && it.readAt == null }
                    .map { it.id }.toList()
                if (unreadVisible.isNotEmpty()) onMarkVisibleRead(unreadVisible)
            }
    }
    // Latest page is initially shown at the bottom. History loading is only triggered by
    // an actual user scroll to the top, never by the initial empty/top layout pass.
    var initialBottomDone by remember { mutableStateOf(false) }
    var lastRequestedOldestId by remember { mutableStateOf<String?>(null) }
    var isNearBottom by remember { mutableStateOf(true) }
    var unseenNewMessages by remember { mutableStateOf(0) }
    val lastVisibleId = visibleMessages.lastOrNull()?.id

    LaunchedEffect(lastVisibleId, searchQuery) {
        if (visibleMessages.isNotEmpty() && searchQuery.isBlank()) {
            if (!initialBottomDone) {
                withFrameNanos { }
                listState.scrollToItem(visibleMessages.lastIndex)
                initialBottomDone = true
                isNearBottom = true
                unseenNewMessages = 0
            } else if (lastVisibleId != null) {
                if (isNearBottom) {
                    listState.animateScrollToItem(visibleMessages.lastIndex)
                    unseenNewMessages = 0
                } else {
                    unseenNewMessages += 1
                }
            }
        }
    }

    LaunchedEffect(listState, visibleMessages.size, searchQuery, initialBottomDone) {
        snapshotFlow {
            val info = listState.layoutInfo
            val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            val total = info.totalItemsCount
            val atBottom = total > 0 && lastVisible >= total - 2
            Triple(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset, atBottom)
        }.collect { (index, offset, atBottom) ->
            isNearBottom = atBottom
            if (initialBottomDone && searchQuery.isBlank() && listState.isScrollInProgress && index == 0 && visibleMessages.isNotEmpty()) {
                val oldest = visibleMessages.first()
                if (oldest.id != lastRequestedOldestId) {
                    lastRequestedOldestId = oldest.id
                    val added = onLoadOlder(oldest)
                    if (added > 0) {
                        withFrameNanos { }
                        listState.scrollToItem(added, offset)
                    }
                }
            }
        }
    }

    // وقتی کیبورد باز می‌شود ارتفاع لیست کم می‌شود؛ اگر نزدیک ته لیست بودیم
    // (یا خود کیبورد باز شد) آخرین پیام را دوباره در دید نگه می‌داریم.
    val density = LocalDensity.current
    val imeBottomPx = WindowInsets.ime.getBottom(density)
    val nearBottomRef = rememberUpdatedState(isNearBottom)
    LaunchedEffect(imeBottomPx, visibleMessages.size, searchQuery) {
        if (imeBottomPx <= 0 || visibleMessages.isEmpty() || searchQuery.isNotBlank()) return@LaunchedEffect
        // دو فریم صبر تا imePadding و اندازه‌ی LazyColumn اعمال شود
        withFrameNanos { }
        withFrameNanos { }
        val last = visibleMessages.lastIndex
        listState.scrollToItem(last)
        delay(64)
        listState.scrollToItem(last)
        isNearBottom = true
    }
    LaunchedEffect(listState, searchQuery) {
        var prevViewportH = 0
        snapshotFlow { listState.layoutInfo.viewportSize.height }.collect { h ->
            if (
                prevViewportH > 0 &&
                h > 0 &&
                prevViewportH - h > 60 &&
                visibleMessages.isNotEmpty() &&
                searchQuery.isBlank() &&
                nearBottomRef.value
            ) {
                val last = (listState.layoutInfo.totalItemsCount - 1).coerceAtLeast(0)
                listState.scrollToItem(last)
                isNearBottom = true
            }
            if (h > 0) prevViewportH = h
        }
    }

    CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface) {
    Box(Modifier.fillMaxSize()) {
        // پس‌زمینه متحرک گفتگو (از تنظیمات → ظاهر قابل تغییر)
        ChatBackgroundFromPrefs(Modifier.fillMaxSize())
    Column(
        // edge-to-edge: پنجره خودش با کیبورد جمع نمی‌شود؛ imePadding باکس تایپ را بالا می‌آورد.
        // نوار پایین در MainShell هنگام باز بودن کیبورد مخفی می‌شود تا فاصله اضافه نماند.
        Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        // نوار بالا: فقط نشان تایپ طرف مقابل (بدون متن وضعیت اتصال/لینک)
        // دکمه‌های همگام‌سازی و جست‌وجو برای کار باقی می‌مانند.
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (peerTyping) {
                Text(
                    "طرف مقابل در حال تایپ است…",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
            } else {
                Spacer(Modifier.weight(1f))
            }
            TextButton(onClick = onSync, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                Text(
                    when {
                        syncState.isSyncing -> "همگام…"
                        else -> "همگام‌سازی"
                    },
                    style = MaterialTheme.typography.labelMedium
                )
            }
            TextButton(
                onClick = { showSearch = !showSearch; if (!showSearch) searchQuery = "" },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(if (showSearch) "بستن" else "جست‌وجو", style = MaterialTheme.typography.labelMedium)
            }
        }
        if (showSearch) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it.take(120) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
                singleLine = true,
                label = { Text("جست‌وجوی متن پیام‌ها") },
                placeholder = { Text("عبارت را بنویسید…") }
            )
        }
        if (chatMessages.isEmpty()) {
            EmptyChat(modifier = Modifier.weight(1f))
        } else if (visibleMessages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        searchFailed -> "جست‌وجو انجام نشد؛ دوباره تلاش کنید."
                        searchQuery.isNotBlank() && isSearching -> "در حال جست‌وجو…"
                        else -> "نتیجه‌ای برای این جست‌وجو نیست"
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 10.dp,
                    end = 10.dp,
                    top = 4.dp,
                    bottom = 8.dp
                ),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                itemsIndexed(visibleMessages, key = { _, message -> message.id }) { index, message ->
                    val currentDate = PersianDateFormatter.formatDate(message.createdAt)
                    val previousDate = visibleMessages.getOrNull(index - 1)?.let { PersianDateFormatter.formatDate(it.createdAt) }
                    if (index == 0 || currentDate != previousDate) {
                        Text(
                            currentDate,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    MessageBubble(
                        message = message,
                        quoted = message.replyToId?.let { messageMap[it] ?: resolvedQuotes[it] },
                        attachments = attachmentsByMessage[message.id].orEmpty(),
                        onLoadAttachment = onLoadAttachment,
                        isOwn = message.senderDeviceId == ownDeviceId,
                        isSending = message.id in pendingSendIds,
                        isHighlighted = message.id == highlightMessageId,
                        onClick = { selected = message },
                        onReply = { replyTo = message },
                        onQuotedClick = message.replyToId?.let { replyId ->
                            { pendingScrollToId = replyId }
                        },
                        onAttachmentClick = { selectedAttachment = it },
                        onOpenDeepLink = onOpenDeepLink
                    )
                }
            }
            if (unseenNewMessages > 0 && !isNearBottom && searchQuery.isBlank()) {
                TextButton(
                    onClick = {
                        chatScope.launch { listState.animateScrollToItem((visibleMessages.size - 1).coerceAtLeast(0)) }
                        unseenNewMessages = 0
                        isNearBottom = true
                    },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
                ) { Text("پیام جدید: $unseenNewMessages") }
            }
            }
        }
        ChatComposer(
            draft = draft,
            replyTo = replyTo,
            onDraftChange = { draft = it.take(5_000) },
            attachmentAction = attachmentAction,
            chatAction = chatAction,
            peerTyping = peerTyping,
            onTyping = onTyping,
            onAttach = {
                AppLockSession.suppressRelock(180_000L)
                attachmentPicker.launch("*/*")
            },
            onCancelReply = { replyTo = null },
            onSend = {
                if (draft.isNotBlank() && !chatAction.isSending) {
                    val outgoingText = draft
                    val replyId = replyTo?.id
                    chatScope.launch {
                        if (onSend(outgoingText, replyId)) {
                            draft = ""
                            replyTo = null
                        }
                    }
                }
            },
            telegramStickerPacks = telegramStickerPacks,
            onDeleteTelegramPack = onDeleteTelegramPack,
            onObserveTelegramStickers = onObserveTelegramStickers,
            onSendTelegramSticker = { id -> onSendTelegramSticker(id, replyTo?.id) },
            onSendVoice = { bytes, durationMs ->
                onSendVoiceMessage(bytes, durationMs, replyTo?.id)
                replyTo = null
            },

        )
    } // Column — messages + composer

    selectedAttachment?.let { attachment ->
        if (attachment.mimeType.startsWith("image/")) {
            ChatTelegramImageViewer(
                attachment = attachment,
                onLoadAttachment = onLoadAttachment,
                isSaving = attachmentAction.isLoading,
                onDismiss = { selectedAttachment = null },
                onSaveCopy = {
                    pendingExport = attachment
                    attachmentSaver.launch(
                        attachment.fileName.replace('/', '_').replace('\\', '_')
                    )
                }
            )
        } else {
            AttachmentDetailsDialog(
                attachment = attachment,
                onLoadAttachment = onLoadAttachment,
                isSaving = attachmentAction.isLoading,
                onDismiss = { selectedAttachment = null },
                onSaveCopy = {
                    pendingExport = attachment
                    selectedAttachment = null
                    attachmentSaver.launch(
                        attachment.fileName.replace('/', '_').replace('\\', '_')
                    )
                }
            )
        }
    }

    selected?.let { message ->
        MessageActionsDialog(
            message = message,
            isOwn = message.senderDeviceId == ownDeviceId,
            onDismiss = { selected = null },
            onReply = {
                replyTo = message
                selected = null
            },
            onReact = { reaction ->
                onReact(message, reaction)
                selected = null
            },
            onEdit = {
                editing = message
                selected = null
            },
            onDelete = {
                pendingDeleteMessage = message
                selected = null
                showDeleteConfirmation = true
            }
        )
    }


    if (showDeleteConfirmation) {
        OSConfirmDialog(
            title = "حذف پیام؟",
            message = "این پیام و پیوست‌های وابسته به آن از گفت‌وگو حذف می‌شوند. پس از همگام‌سازی، حذف به گوشی مقابل نیز منتقل خواهد شد.",
            confirmLabel = "حذف",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "💬",
            onConfirm = {
                pendingDeleteMessage?.let(onDelete)
                pendingDeleteMessage = null
                showDeleteConfirmation = false
            },
            onDismiss = { showDeleteConfirmation = false; pendingDeleteMessage = null }
        )
    }

    editing?.let { message ->
        EditMessageDialog(
            initialText = message.text,
            onDismiss = { editing = null },
            onSave = { newText ->
                onEdit(message, newText)
                editing = null
            }
        )
    }
    } // Box — chat animated background + content
    } // CompositionLocalProvider
}

@Composable
private fun MessageBubble(
    message: MessageEntity,
    quoted: MessageEntity?,
    attachments: List<AttachmentEntity>,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    isOwn: Boolean,
    isSending: Boolean = false,
    isHighlighted: Boolean = false,
    onClick: () -> Unit,
    onReply: () -> Unit = {},
    onQuotedClick: (() -> Unit)? = null,
    onAttachmentClick: (AttachmentEntity) -> Unit,
    onOpenDeepLink: (com.ourspace.app.core.navigation.AppDeepLink) -> Unit = {}
) {
    val density = LocalDensity.current
    // آستانهٔ بالاتر مثل تلگرام تا اسکرول عمودی اشتباه نگیرد
    val replyThresholdPx = with(density) { 72.dp.toPx() }
    val maxSwipePx = with(density) { 96.dp.toPx() }
    val swipeOffset = remember(message.id) { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val latestOnReply = rememberUpdatedState(onReply)
    val touchSlop = LocalViewConfiguration.current.touchSlop

    Box(modifier = Modifier.fillMaxWidth()) {
        // آیکون پاسخ در سمت راست (پشت حباب هنگام کشیدن به چپ)
        val progress = (abs(swipeOffset.value) / replyThresholdPx).coerceIn(0f, 1f)
        if (progress > 0.05f) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.Reply,
                contentDescription = "پاسخ",
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f + 0.65f * progress),
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 10.dp)
                    .size((18 + 6 * progress).dp)
            )
        }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .offset { IntOffset(swipeOffset.value.roundToInt(), 0) }
            .pointerInput(message.id, touchSlop, replyThresholdPx, maxSwipePx) {
                // مثل تلگرام: فقط وقتی حرکت افقی غالب و به چپ باشد قفل می‌شود؛
                // در غیر این صورت رویداد مصرف نمی‌شود تا LazyColumn اسکرول کند.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var totalX = 0f
                    var totalY = 0f
                    var lockedHorizontal = false
                    var triggered = false

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break

                        val delta = change.positionChange()
                        totalX += delta.x
                        totalY += delta.y

                        if (!lockedHorizontal) {
                            val pastSlop = abs(totalX) > touchSlop || abs(totalY) > touchSlop
                            if (!pastSlop) continue
                            // فقط اگر حرکت عمدتاً افقی و به سمت چپ باشد → ریپلای
                            // ضریب ۱.۷۵ یعنی اسکرول مورب/عمودی به ریپلای تبدیل نشود
                            if (abs(totalX) > abs(totalY) * 1.75f && totalX < -touchSlop) {
                                lockedHorizontal = true
                                change.consume()
                                val next = totalX.coerceIn(-maxSwipePx, 0f)
                                scope.launch { swipeOffset.snapTo(next) }
                            } else {
                                // عمودی یا راست → رها کن تا اسکرول لیست کار کند
                                break
                            }
                        } else {
                            change.consume()
                            val next = (swipeOffset.value + delta.x).coerceIn(-maxSwipePx, 0f)
                            scope.launch { swipeOffset.snapTo(next) }
                            if (swipeOffset.value <= -replyThresholdPx) {
                                triggered = true
                            }
                        }
                    }

                    val shouldReply = lockedHorizontal &&
                        (triggered || swipeOffset.value <= -replyThresholdPx)
                    scope.launch {
                        swipeOffset.animateTo(
                            0f,
                            animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                        )
                    }
                    if (shouldReply) {
                        latestOnReply.value()
                    }
                }
            },
        horizontalArrangement = if (isOwn) Arrangement.Start else Arrangement.End
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clickable(onClick = onClick),
            shape = if (isOwn) {
                RoundedCornerShape(topStart = 8.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp)
            } else {
                RoundedCornerShape(topStart = 16.dp, topEnd = 8.dp, bottomEnd = 16.dp, bottomStart = 16.dp)
            },
            colors = CardDefaults.cardColors(
                containerColor = when {
                    isHighlighted -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.95f)
                    isOwn -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f)
                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                }
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isHighlighted) 2.dp else 0.dp)
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (message.replyToId != null) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = .75f))
                            .then(
                                if (onQuotedClick != null) {
                                    Modifier.clickable(onClick = onQuotedClick)
                                } else {
                                    Modifier
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Column {
                            Text(
                                "پاسخ به",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                quoted?.text?.ifBlank { "پیوست" } ?: "پیام اصلی حذف شده یا در دسترس نیست",
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    Spacer(Modifier.size(4.dp))
                }
                attachments.forEach { attachment ->
                    AttachmentPreview(attachment, onLoadAttachment = onLoadAttachment, onClick = { onAttachmentClick(attachment) })
                    if (message.text.isNotBlank()) Spacer(Modifier.size(4.dp))
                }
                if (message.text.isNotBlank()) {
                    val shareCard = ChatShareCard.parse(message.text)
                    val onlyTgSticker = attachments.isNotEmpty() && attachments.all {
                        it.mimeType == TelegramStickerClient.MIME_TGS ||
                            (it.mimeType == "image/webp" && it.fileName.startsWith("tg_"))
                    } && isStickerOnlyMessage(message.text)
                    val onlyVoiceCaption = attachments.isNotEmpty() &&
                        attachments.all { isVoiceAttachment(it.mimeType) } &&
                        message.text.trim().startsWith("🎤")
                    if (shareCard != null) {
                        ShareCardContent(
                            card = shareCard,
                            onOpen = {
                                val link = when (shareCard.type) {
                                    ChatShareCard.Type.TASK -> com.ourspace.app.core.navigation.AppDeepLink.plannerTask(shareCard.id)
                                    ChatShareCard.Type.EVENT -> com.ourspace.app.core.navigation.AppDeepLink.plannerEvent(shareCard.id)
                                    ChatShareCard.Type.DEBT -> com.ourspace.app.core.navigation.AppDeepLink.financeDebt(shareCard.id)
                                    ChatShareCard.Type.MEMORY -> com.ourspace.app.core.navigation.AppDeepLink.usMemory(shareCard.id)
                                    ChatShareCard.Type.LOCATION -> com.ourspace.app.core.navigation.AppDeepLink.mapPlace(shareCard.id)
                                }
                                onOpenDeepLink(link)
                            }
                        )
                    } else if (!onlyTgSticker && !onlyVoiceCaption) {
                        val stickerLike = isStickerOnlyMessage(message.text)
                        Text(
                            message.text,
                            style = if (stickerLike) {
                                MaterialTheme.typography.displaySmall.copy(fontSize = 34.sp, lineHeight = 40.sp)
                            } else {
                                MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 14.5.sp,
                                    lineHeight = 20.sp
                                )
                            },
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Row(
                    modifier = Modifier.padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.editedAt != null) {
                        Text("ویرایش‌شده • ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        PersianDateFormatter.formatTime(message.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isOwn) {
                        val (statusText, statusColor) = when {
                            isSending -> "  در صف" to MaterialTheme.colorScheme.onSurfaceVariant
                            message.readAt != null -> "  ✓✓" to MaterialTheme.colorScheme.primary
                            message.deliveredAt != null -> "  ✓✓" to MaterialTheme.colorScheme.onSurfaceVariant
                            else -> "  ✓" to MaterialTheme.colorScheme.onSurfaceVariant // روی سرور/ارسال‌شده
                        }
                        Text(
                            statusText,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor
                        )
                    }
                }
                val reactions = listOfNotNull(message.reaction, message.reaction2)
                if (reactions.isNotEmpty()) {
                    Row(
                        modifier = Modifier.padding(top = 4.dp).clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface).padding(horizontal = 8.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        reactions.forEach { reaction -> Text(reaction) }
                    }
                }
            }
        }
    } // Row (swipeable bubble)
    } // Box
}

@Composable
private fun isVoiceAttachment(mimeType: String): Boolean {
    val m = mimeType.lowercase()
    return m.startsWith("audio/") || m == "application/ogg"
}

@Composable
private fun AttachmentPreview(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    onClick: () -> Unit
) {
    if (isVoiceAttachment(attachment.mimeType)) {
        VoiceMessagePlayer(
            attachment = attachment,
            onLoadAttachment = onLoadAttachment,
            onLongClickDetails = onClick
        )
        return
    }

    val isTgs = attachment.mimeType == TelegramStickerClient.MIME_TGS
    val isStickerFile = isTgs || (
        attachment.mimeType == "image/webp" && attachment.fileName.startsWith("tg_")
    )

    if (isTgs) {
        val lottieJson by produceState<String?>(initialValue = null, attachment.id, attachment.sha256) {
            val full = onLoadAttachment(attachment.id)
            val bytes = full?.content
            value = if (bytes != null && bytes.isNotEmpty()) {
                withContext(Dispatchers.Default) {
                    runCatching {
                        GZIPInputStream(ByteArrayInputStream(bytes)).use { it.readBytes() }.decodeToString()
                    }.getOrNull()
                }
            } else null
        }
        val json = lottieJson
        if (json != null) {
            val composition by rememberLottieComposition(LottieCompositionSpec.JsonString(json))
            LottieAnimation(
                composition = composition,
                iterations = LottieConstants.IterateForever,
                modifier = Modifier
                    .size(128.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onClick)
            )
        } else {
            Text("🎬 استیکر انیمیشنی", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
        value = if (attachment.mimeType.startsWith("image/")) {
            val full = onLoadAttachment(attachment.id)
            val bytes = full?.content
            if (bytes != null && bytes.isNotEmpty()) {
                withContext(Dispatchers.Default) { decodeAttachmentPreview(bytes) }
            } else null
        } else null
    }
    val previewBitmap = preview
    if (previewBitmap != null) {
        Column {
            Image(
                bitmap = previewBitmap.asImageBitmap(),
                contentDescription = attachment.fileName,
                contentScale = if (isStickerFile) ContentScale.Fit else ContentScale.Crop,
                modifier = if (isStickerFile) {
                    Modifier.size(120.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick)
                } else {
                    Modifier.fillMaxWidth().widthIn(max = 240.dp).aspectRatio(4f / 3f)
                        .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
                }
            )
            if (!isStickerFile) {
                Text(
                    "${attachment.fileName} • ${formatAttachmentSize(attachment.sizeBytes)}",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    } else {
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = .7f)).padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.AttachFile, null, modifier = Modifier.size(22.dp))
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text(attachment.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(
                    "${formatAttachmentSize(attachment.sizeBytes)} • ${attachment.mimeType}",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}


/** پخش‌کننده پیام صوتی داخل حباب گفتگو — فقط یک MediaPlayer در هر حباب. */
@Composable
private fun VoiceMessagePlayer(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    onLongClickDetails: () -> Unit
) {
    val context = LocalContext.current
    var isPlaying by remember(attachment.id) { mutableStateOf(false) }
    var isPrepared by remember(attachment.id) { mutableStateOf(false) }
    var isLoading by remember(attachment.id) { mutableStateOf(false) }
    var loadError by remember(attachment.id) { mutableStateOf<String?>(null) }
    var durationMs by remember(attachment.id) { mutableStateOf(0) }
    var positionMs by remember(attachment.id) { mutableStateOf(0) }
    var player by remember(attachment.id) { mutableStateOf<MediaPlayer?>(null) }
    val scope = rememberCoroutineScope()

    fun releasePlayer() {
        try {
            player?.setOnCompletionListener(null)
            player?.setOnPreparedListener(null)
            player?.setOnErrorListener(null)
            if (player?.isPlaying == true) player?.stop()
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        isPlaying = false
        isPrepared = false
        positionMs = 0
    }

    DisposableEffect(attachment.id) {
        onDispose { releasePlayer() }
    }

    // پیشرفت پخش را هر ~200ms به‌روز کن
    LaunchedEffect(isPlaying, player) {
        val p = player
        if (!isPlaying || p == null) return@LaunchedEffect
        while (isPlaying) {
            try {
                if (p.isPlaying) positionMs = p.currentPosition.coerceAtLeast(0)
            } catch (_: Exception) {
                break
            }
            delay(200)
        }
    }

    fun ensurePreparedAndPlay() {
        if (isLoading) return
        val existing = player
        if (existing != null && isPrepared) {
            try {
                existing.start()
                isPlaying = true
            } catch (e: Exception) {
                loadError = e.message ?: "پخش ممکن نیست"
                releasePlayer()
            }
            return
        }
        isLoading = true
        loadError = null
        scope.launch {
            val full = runCatching { onLoadAttachment(attachment.id) }.getOrNull()
            val bytes = full?.content
            if (bytes == null || bytes.isEmpty()) {
                isLoading = false
                loadError = "فایل صوتی در دسترس نیست"
                return@launch
            }
            val cacheFile = File(context.cacheDir, "voice_play_${attachment.id}.m4a")
            try {
                withContext(Dispatchers.IO) {
                    cacheFile.writeBytes(bytes)
                }
                withContext(Dispatchers.Main) {
                    releasePlayer()
                    val mp = MediaPlayer()
                    mp.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    mp.setDataSource(cacheFile.absolutePath)
                    mp.setOnPreparedListener { prepared ->
                        durationMs = prepared.duration.coerceAtLeast(0)
                        isPrepared = true
                        isLoading = false
                        try {
                            prepared.start()
                            isPlaying = true
                        } catch (e: Exception) {
                            loadError = e.message ?: "شروع پخش ممکن نیست"
                            releasePlayer()
                        }
                    }
                    mp.setOnCompletionListener {
                        isPlaying = false
                        positionMs = 0
                        try {
                            it.seekTo(0)
                        } catch (_: Exception) {
                        }
                    }
                    mp.setOnErrorListener { _, what, extra ->
                        loadError = "خطای پخش ($what/$extra)"
                        isLoading = false
                        releasePlayer()
                        true
                    }
                    player = mp
                    mp.prepareAsync()
                }
            } catch (e: Exception) {
                isLoading = false
                loadError = e.message ?: "آماده‌سازی صدا ممکن نیست"
                releasePlayer()
            }
        }
    }

    fun togglePlay() {
        val p = player
        if (p != null && isPrepared && isPlaying) {
            try {
                p.pause()
                positionMs = p.currentPosition.coerceAtLeast(0)
            } catch (_: Exception) {
            }
            isPlaying = false
            return
        }
        ensurePreparedAndPlay()
    }

    val progress = if (durationMs > 0) {
        (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    fun formatMs(ms: Int): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        val m = totalSec / 60
        val s = totalSec % 60
        val raw = "%d:%02d".format(m, s)
        return PersianDateFormatter.toPersianDigits(raw)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.72f))
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = { onLongClickDetails() }
                )
            }
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f))
                .clickable(enabled = !isLoading) { togglePlay() },
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "توقف" else "پخش ویس",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 10.dp)
        ) {
            Text(
                "پیام صوتی",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
            )
            Spacer(Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    if (isPlaying || positionMs > 0) formatMs(positionMs) else formatMs(0),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    if (durationMs > 0) formatMs(durationMs) else "—:—",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (loadError != null) {
                Text(
                    loadError!!,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                    maxLines = 2
                )
            }
        }
    }
}

private fun decodeAttachmentPreview(bytes: ByteArray): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 1_024 || bounds.outHeight / sample > 1_024) sample *= 2
    BitmapFactory.decodeByteArray(
        bytes,
        0,
        bytes.size,
        BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
    )
}.getOrNull()

private fun isTelegramStickerMime(mime: String): Boolean =
    mime == TelegramStickerClient.MIME_TGS || mime == "image/webp"

private fun isStickerOnlyMessage(text: String): Boolean {
    val t = text.trim()
    if (t.isEmpty() || t.length > 16) return false
    val cps = t.codePoints().toArray()
    if (cps.size > 8) return false
    return cps.all { cp ->
        cp in 0x1F300..0x1FAFF ||
            cp in 0x2600..0x27BF ||
            cp in 0x1F600..0x1F64F ||
            cp in 0x1F680..0x1F6FF ||
            cp in 0xFE00..0xFE0F ||
            cp == 0x200D ||
            cp == 0x2764 ||
            cp == 0x2665
    }
}

private fun formatAttachmentSize(bytes: Long): String {
    val value = when {
        bytes >= 1024 * 1024 -> "${bytes / (1024 * 1024)} مگابایت"
        bytes >= 1024 -> "${bytes / 1024} کیلوبایت"
        else -> "$bytes بایت"
    }
    return PersianDateFormatter.toPersianDigits(value)
}

@Composable
private fun AttachmentDetailsDialog(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSaveCopy: () -> Unit
) {
    var showFullscreen by remember(attachment.id) { mutableStateOf(false) }
    val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
        value = if (attachment.mimeType.startsWith("image/")) {
            val full = onLoadAttachment(attachment.id)
            val bytes = full?.content
            if (bytes != null && bytes.isNotEmpty()) {
                withContext(Dispatchers.Default) { decodeAttachmentPreview(bytes) }
            } else null
        } else null
    }
    OSFormDialog(
        title = attachment.fileName,
        emoji = "📎",
        onDismiss = onDismiss,
        onConfirm = onSaveCopy,
        confirmLabel = "ذخیره نسخه",
        confirmEnabled = !isSaving,
        dismissLabel = "بستن"
    ) {

                val previewBitmap = preview
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = attachment.fileName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 260.dp, max = 480.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { showFullscreen = true }
                    )
                    Text(
                        "برای نمایش کامل لمس کنید",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                } else {
                    Box(
                        Modifier.fillMaxWidth().background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(16.dp)
                        ).padding(22.dp),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Outlined.AttachFile, null, modifier = Modifier.size(48.dp)) }
                }
                Text("حجم: ${formatAttachmentSize(attachment.sizeBytes)}")
                Text(
                    "نوع: ${attachment.mimeType}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "پیش از ذخیره، اندازه و اثر انگشت SHA-256 دوباره بررسی می‌شود.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
    }
    if (showFullscreen && preview != null) {
        ChatFullscreenImageViewer(
            bitmap = preview!!,
            fileName = attachment.fileName,
            onDismiss = { showFullscreen = false }
        )
    }
}

@Composable
private fun ChatTelegramImageViewer(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSaveCopy: () -> Unit
) {
    val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
        val full = onLoadAttachment(attachment.id)
        val bytes = full?.content
        value = if (bytes != null && bytes.isNotEmpty()) {
            withContext(Dispatchers.Default) { decodeAttachmentPreview(bytes) }
        } else null
    }
    if (preview != null) {
        ChatFullscreenImageViewer(
            bitmap = preview!!,
            fileName = attachment.fileName,
            onDismiss = onDismiss,
            onSaveCopy = onSaveCopy,
            saveEnabled = !isSaving
        )
    } else {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable(onClick = onDismiss),
                contentAlignment = Alignment.Center
            ) {
                Text("در حال بارگذاری…", color = Color.White.copy(alpha = 0.75f))
            }
        }
    }
}

@Composable
private fun ChatFullscreenImageViewer(
    bitmap: Bitmap,
    fileName: String,
    onDismiss: () -> Unit,
    onSaveCopy: (() -> Unit)? = null,
    saveEnabled: Boolean = true
) {
    val density = LocalDensity.current
    val dismissThresholdPx = with(density) { 140.dp.toPx() }
    val dragOffset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var menuExpanded by remember { mutableStateOf(false) }
    val bgAlpha = (1f - (abs(dragOffset.value) / (dismissThresholdPx * 2.2f)).coerceIn(0f, 0.85f))

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.92f * bgAlpha))
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = fileName,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .offset { IntOffset(0, dragOffset.value.roundToInt()) }
                    .pointerInput(fileName) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var totalY = 0f
                            var totalX = 0f
                            var locked = false
                            val touchSlop = viewConfiguration.touchSlop
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (!change.pressed) break
                                val delta = change.positionChange()
                                totalX += delta.x
                                totalY += delta.y
                                if (!locked) {
                                    if (abs(totalY) > touchSlop || abs(totalX) > touchSlop) {
                                        if (abs(totalY) > abs(totalX) * 1.2f && totalY > 0f) {
                                            locked = true
                                            change.consume()
                                            scope.launch { dragOffset.snapTo(totalY) }
                                        } else break
                                    }
                                } else {
                                    change.consume()
                                    scope.launch {
                                        dragOffset.snapTo((dragOffset.value + delta.y).coerceAtLeast(0f))
                                    }
                                }
                            }
                            if (locked) {
                                if (dragOffset.value >= dismissThresholdPx) onDismiss()
                                else scope.launch {
                                    dragOffset.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 400f))
                                }
                            }
                        }
                    }
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(Color.Black.copy(alpha = 0.45f * bgAlpha))
                    .padding(horizontal = 2.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "بستن", tint = Color.White)
                }
                Text(
                    fileName,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (onSaveCopy != null) {
                    Box {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(Icons.Outlined.MoreVert, contentDescription = "بیشتر", tint = Color.White)
                        }
                        DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                            DropdownMenuItem(
                                text = { Text("ذخیره تصویر") },
                                onClick = { menuExpanded = false; onSaveCopy() },
                                enabled = saveEnabled
                            )
                            DropdownMenuItem(
                                text = { Text("بستن") },
                                onClick = { menuExpanded = false; onDismiss() }
                            )
                        }
                    }
                }
            }
            if (dragOffset.value < 8f) {
                Text(
                    "برای بستن به پایین بکشید",
                    color = Color.White.copy(alpha = 0.45f),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 16.dp)
                )
            }
        }
    }
}

@Composable
private fun ChatComposer(
    draft: String,
    replyTo: MessageEntity?,
    attachmentAction: AppViewModel.AttachmentActionState,
    chatAction: AppViewModel.ChatActionState,
    peerTyping: Boolean = false,
    onDraftChange: (String) -> Unit,
    onTyping: (Boolean) -> Unit = {},
    onAttach: () -> Unit,
    onCancelReply: () -> Unit,
    onSend: () -> Unit,
    telegramStickerPacks: List<TelegramStickerPackEntity> = emptyList(),
    onDeleteTelegramPack: (String) -> Unit = {},
    onObserveTelegramStickers: (String) -> Flow<List<TelegramStickerEntity>> = { kotlinx.coroutines.flow.emptyFlow() },
    onSendTelegramSticker: (String) -> Unit = {},
    onSendVoice: (ByteArray, Int) -> Unit = { _, _ -> }
) {
    var showStickers by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var isRecording by remember { mutableStateOf(false) }
    var recordStartedAt by remember { mutableStateOf(0L) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordFile by remember { mutableStateOf<File?>(null) }
    var recordError by remember { mutableStateOf<String?>(null) }

    fun stopAndSendVoice() {
        val rec = recorder
        val file = recordFile
        val started = recordStartedAt
        recorder = null
        recordFile = null
        isRecording = false
        try {
            rec?.stop()
        } catch (_: Exception) {
        }
        try {
            rec?.release()
        } catch (_: Exception) {
        }
        val durationMs = (System.currentTimeMillis() - started).toInt().coerceAtLeast(0)
        if (file == null || !file.exists()) return
        if (durationMs < 400) {
            runCatching { file.delete() }
            recordError = "خیلی کوتاه بود"
            return
        }
        val bytes = runCatching { file.readBytes() }.getOrNull()
        runCatching { file.delete() }
        if (bytes == null || bytes.isEmpty()) {
            recordError = "ضبط ناموفق بود"
            return
        }
        // سقف حدود ۲ دقیقه
        if (durationMs > 120_000) {
            recordError = "حداکثر ۲ دقیقه"
            return
        }
        onSendVoice(bytes, durationMs)
        recordError = null
    }

    fun cancelVoice() {
        val rec = recorder
        val file = recordFile
        recorder = null
        recordFile = null
        isRecording = false
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        runCatching { file?.delete() }
    }

    fun startVoice() {
        recordError = null
        cancelVoice()
        val out = File(context.cacheDir, "voice_rec_${System.currentTimeMillis()}.m4a")
        val mr = if (android.os.Build.VERSION.SDK_INT >= 31) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        try {
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioEncodingBitRate(64_000)
            mr.setAudioSamplingRate(44_100)
            mr.setOutputFile(out.absolutePath)
            mr.prepare()
            mr.start()
            recorder = mr
            recordFile = out
            recordStartedAt = System.currentTimeMillis()
            isRecording = true
        } catch (e: Exception) {
            try { mr.release() } catch (_: Exception) {}
            runCatching { out.delete() }
            recordError = e.message ?: "شروع ضبط ممکن نیست"
            isRecording = false
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoice() else recordError = "دسترسی میکروفون لازم است"
    }

    fun onMicPress() {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startVoice() else {
            AppLockSession.suppressRelock(120_000L)
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    DisposableEffect(Unit) {
        onDispose { cancelVoice() }
    }

    // Typing presence: notify peer while drafting; auto-clear after idle.
    LaunchedEffect(draft) {
        if (draft.isBlank()) {
            onTyping(false)
        } else {
            onTyping(true)
            kotlinx.coroutines.delay(1_600)
            onTyping(false)
        }
    }
    DisposableEffect(Unit) {
        onDispose { onTyping(false) }
    }
    val stickerPacks = remember { StickerCatalog.packs }

    Column(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.96f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        if (replyTo != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowBack,
                    null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    replyTo.text.ifBlank { "پیوست" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onCancelReply, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Outlined.Close, "لغو پاسخ", modifier = Modifier.size(15.dp))
                }
            }
            Spacer(Modifier.size(4.dp))
        }
        // پیام‌های موفقیت ارسال/استیکر/همگام‌سازی نمایش داده نمی‌شوند؛ فقط خطا
        attachmentAction.error?.let {
            Text(
                it,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 2.dp)
            )
        }
        chatAction.error?.let {
            Text(it, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 2.dp))
        }

        // نشان تایپ فقط در نوار بالای صفحه گفتگو نمایش داده می‌شود (نه اینجا).

        // فشرده: دکمه‌های کوچک‌تر + فیلد متن باریک‌تر تا پیام‌های بیشتری دیده شود
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { showStickers = !showStickers },
                    modifier = Modifier
                        .size(34.dp)
                        .background(
                            if (showStickers) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Outlined.EmojiEmotions,
                        contentDescription = "استیکر و شکلک",
                        modifier = Modifier.size(18.dp),
                        tint = if (showStickers) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.size(4.dp))
                OutlinedTextField(
                    value = draft,
                    onValueChange = onDraftChange,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 36.dp, max = 88.dp),
                    placeholder = {
                        Text(
                            "پیام بنویسید…",
                            style = MaterialTheme.typography.bodySmall
                        )
                    },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
                    maxLines = 3,
                    singleLine = false,
                    shape = RoundedCornerShape(18.dp)
                )
                Spacer(Modifier.size(4.dp))
                IconButton(
                    onClick = {
                        showStickers = false
                        onAttach()
                    },
                    enabled = !attachmentAction.isLoading,
                    modifier = Modifier
                        .size(34.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Outlined.AttachFile,
                        contentDescription = "پیوست فایل یا تصویر",
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.size(3.dp))
                if (draft.isNotBlank()) {
                    IconButton(
                        onClick = {
                            showStickers = false
                            onSend()
                        },
                        enabled = !chatAction.isSending,
                        modifier = Modifier
                            .size(36.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Outlined.Send,
                            contentDescription = "ارسال",
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                } else {
                    // دکمه ویس: نگه دارید برای ضبط، رها کنید برای ارسال
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (isRecording) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.primary,
                                CircleShape
                            )
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = {
                                        onMicPress()
                                        val released = try {
                                            tryAwaitRelease()
                                        } catch (_: Exception) {
                                            false
                                        }
                                        // همیشه بعد از رها کردن، اگر فایلی هست ارسال کن
                                        if (released) stopAndSendVoice() else cancelVoice()
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isRecording) Icons.Outlined.Stop else Icons.Outlined.Mic,
                            contentDescription = if (isRecording) "توقف و ارسال ویس" else "ضبط پیام صوتی",
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }

        if (isRecording) {
            Text(
                "در حال ضبط… رها کنید تا ارسال شود",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
            )
        }
        if (!recordError.isNullOrBlank()) {
            Text(
                recordError.orEmpty(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
            )
        }

        if (showStickers) {
            Spacer(Modifier.size(6.dp))
            StickerPickerPanel(
                emojiPacks = stickerPacks,
                telegramPacks = telegramStickerPacks,
                onInsertEmoji = { emoji ->
                    // Emojis are only appended to the draft; sending happens exclusively
                    // via the send button, so any number of emojis can be composed first.
                    onDraftChange(draft + emoji)
                },
                onDeleteTelegramPack = onDeleteTelegramPack,
                onObserveTelegramStickers = onObserveTelegramStickers,
                onSendTelegramSticker = { id ->
                    onSendTelegramSticker(id)
                    showStickers = false
                }
            )
        }
    }
}

@Composable
private fun ShareCardContent(card: ChatShareCard.Card, onOpen: () -> Unit = {}) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.55f))
            .clickable(onClick = onOpen)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            "${card.type.emoji} ${card.type.label}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            card.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        card.subtitle?.takeIf { it.isNotBlank() }?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** Curated sticker / emoji packs for the private couple chat (no network). */
private object StickerCatalog {
    data class Pack(val title: String, val items: List<String>)

    val packs: List<Pack> = listOf(
        Pack(
            "عاشقانه",
            listOf(
                "❤️", "💕", "💖", "💗", "💓", "💞", "💘", "💝", "😍", "🥰",
                "😘", "💋", "🌹", "🌷", "💍", "🤍", "💌", "🔥"
            )
        ),
        Pack(
            "احساس",
            listOf(
                "😊", "😂", "🥺", "😢", "😅", "🤗", "😌", "😎", "🤔", "😴",
                "🤤", "😏", "😇", "🤩", "😤", "🤦", "🙌", "👍"
            )
        ),
        Pack(
            "روزمره",
            listOf(
                "☕", "🍰", "🍕", "🏠", "🌙", "☀️", "🌧️", "🌸", "🎵", "📱",
                "✈️", "🎁", "🎂", "🐶", "🐱", "✨", "⭐", "🌟"
            )
        ),
        Pack(
            "استیکر",
            listOf(
                "🫶", "🙈", "🙉", "🙊", "🐱‍👤", "🐼", "🦋", "🍀", "🌈", "🍑",
                "🍓", "🥂", "🧸", "💤", "🫡", "🫠", "😈", "👻"
            )
        )
    )
}

@Composable
private fun StickerPickerPanel(
    emojiPacks: List<StickerCatalog.Pack>,
    telegramPacks: List<TelegramStickerPackEntity>,
    onInsertEmoji: (String) -> Unit,
    onDeleteTelegramPack: (String) -> Unit,
    onObserveTelegramStickers: (String) -> Flow<List<TelegramStickerEntity>>,
    onSendTelegramSticker: (String) -> Unit
) {
    var tab by remember { mutableStateOf(0) } // 0=emoji 1=telegram
    // همهٔ استیکرهای پک‌های تلگرام برای اسکرول پیوسته مثل تلگرام
    var tgByPack by remember { mutableStateOf<Map<String, List<TelegramStickerEntity>>>(emptyMap()) }
    val packNamesKey = telegramPacks.joinToString("|") { it.name }
    LaunchedEffect(packNamesKey) {
        if (telegramPacks.isEmpty()) {
            tgByPack = emptyMap()
            return@LaunchedEffect
        }
        kotlinx.coroutines.coroutineScope {
            telegramPacks.forEach { pack ->
                launch {
                    onObserveTelegramStickers(pack.name).collect { list ->
                        tgByPack = tgByPack + (pack.name to list)
                    }
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .padding(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ایموجی", "تلگرام").forEachIndexed { i, label ->
                val selected = tab == i
                Text(
                    text = label,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                        )
                        .clickable { tab = i }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = if (selected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.size(8.dp))

        if (tab == 0) {
            EmojiPacksGrid(
                packs = emojiPacks,
                onInsertEmoji = onInsertEmoji
            )
        } else {
            TelegramStickersGrid(
                packs = telegramPacks,
                stickersByPack = tgByPack,
                onSendTelegramSticker = onSendTelegramSticker
            )
        }
    }
}

@Composable
private fun EmojiPacksGrid(
    packs: List<StickerCatalog.Pack>,
    onInsertEmoji: (String) -> Unit
) {
    // گرید مسطح و سبک: بدون هدر، چیپ و متن راهنما تا تمام فضا به ایموجی برسد.
    // LazyVerticalGrid فقط سلول‌های دیده‌شده را می‌سازد و clickable هم از pointerInput
    // سنگین‌ترِ هر آیتم ارزان‌تر است، پس اسکرول نرم و بدون لگ می‌ماند.
    val allEmojis = remember(packs) { packs.flatMap { it.items } }
    LazyVerticalGrid(
        columns = GridCells.Fixed(6),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        gridItemsIndexed(items = allEmojis, key = { index, _ -> "emoji-$index" }) { _, emoji ->
            Box(
                modifier = Modifier
                    .height(44.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onInsertEmoji(emoji) },
                contentAlignment = Alignment.Center
            ) {
                Text(text = emoji, fontSize = 28.sp)
            }
        }
    }
}

@Composable
private fun TelegramStickersGrid(
    packs: List<TelegramStickerPackEntity>,
    stickersByPack: Map<String, List<TelegramStickerEntity>>,
    onSendTelegramSticker: (String) -> Unit
) {
    // همهٔ پک‌ها در یک گرید پیوسته؛ بدون هدر/چیپ/متن اضافه.
    val allStickers = remember(packs, stickersByPack) {
        packs.flatMap { stickersByPack[it.name].orEmpty() }
    }
    when {
        allStickers.isNotEmpty() -> LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            gridItemsIndexed(items = allStickers, key = { _, sticker -> sticker.id }) { _, sticker ->
                TelegramStickerThumb(
                    sticker = sticker,
                    onClick = { onSendTelegramSticker(sticker.id) }
                )
            }
        }
        packs.isNotEmpty() -> Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                strokeWidth = 2.dp
            )
        }
        else -> Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "هنوز پک استیکری وارد نشده؛ از تنظیمات یک پک تلگرام اضافه کن.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun TelegramStickerThumb(
    sticker: TelegramStickerEntity,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        if (sticker.isAnimated || sticker.mimeType == TelegramStickerClient.MIME_TGS) {
            val jsonBytes = remember(sticker.id) {
                runCatching {
                    GZIPInputStream(ByteArrayInputStream(sticker.content)).use { it.readBytes() }
                }.getOrNull()
            }
            if (jsonBytes != null) {
                val composition by rememberLottieComposition(
                    LottieCompositionSpec.JsonString(jsonBytes.decodeToString())
                )
                // فقط یک‌بار پخش؛ حلقهٔ بی‌پایان هم‌زمان برای چند استیکر، اسکرول پنل را لگ‌دار می‌کرد.
                LottieAnimation(
                    composition = composition,
                    iterations = 1,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(sticker.emoji, fontSize = 28.sp)
            }
        } else {
            val bitmap = remember(sticker.id) {
                runCatching {
                    android.graphics.BitmapFactory.decodeByteArray(sticker.content, 0, sticker.content.size)
                }.getOrNull()
            }
            if (bitmap != null) {
                androidx.compose.foundation.Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = sticker.emoji,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(sticker.emoji, fontSize = 28.sp)
            }
        }
    }
}


@Composable
private fun MessageActionsDialog(
    message: MessageEntity,
    isOwn: Boolean,
    onDismiss: () -> Unit,
    onReply: () -> Unit,
    onReact: (String) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    OSFormDialog(
        title = "گزینه‌های پیام",
        emoji = "💬",
        onDismiss = onDismiss,
        onConfirm = onDismiss,
        confirmLabel = "بستن",
        showDismissButton = false
    ) {

                Text(message.text.ifBlank { "پیام دارای پیوست" }, maxLines = 3, overflow = TextOverflow.Ellipsis)
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("❤️", "👍", "😂", "👏").forEach { reaction ->
                        Text(
                            reaction,
                            modifier = Modifier.clip(CircleShape).clickable { onReact(reaction) }.padding(10.dp)
                        )
                    }
                }
                TextButton(onClick = onReply, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, null)
                    Text("پاسخ به پیام", modifier = Modifier.padding(start = 8.dp))
                }
                if (isOwn) {
                    if (message.text.isNotBlank()) {
                        TextButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Outlined.Edit, null)
                            Text("ویرایش", modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                    TextButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Outlined.Delete, null, tint = MaterialTheme.colorScheme.error)
                        Text("حذف", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(start = 8.dp))
                    }
                }
    }
}

@Composable
private fun EditMessageDialog(
    initialText: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var value by remember(initialText) { mutableStateOf(initialText) }
    OSFormDialog(
        title = "ویرایش پیام",
        emoji = "✏️",
        onDismiss = onDismiss,
        onConfirm = { onSave(value) },
        confirmLabel = "ذخیره",
        confirmEnabled = value.isNotBlank()
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = { value = it.take(5_000) },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 5
        )
    }
}

@Composable
private fun EmptyChat(modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(104.dp).background(
                brush = androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.tertiaryContainer
                    )
                ),
                shape = CircleShape
            ),
            contentAlignment = Alignment.Center
        ) {
            Text("💬", style = MaterialTheme.typography.displaySmall)
        }
        Text(
            "اولین پیام را بفرستید",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            "این گفتگو فقط بین دو دستگاه مورد اعتماد همگام می‌شود — رمزنگاری‌شده و خصوصی.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun ChatLockedState() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.Lock, null, modifier = Modifier.size(68.dp), tint = MaterialTheme.colorScheme.primary)
        Text("ابتدا دو گوشی را متصل کنید", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 18.dp))
        Text("بعد از تأیید جفت‌سازی، گفتگوی خصوصی فعال می‌شود.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
