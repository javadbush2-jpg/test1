package com.ourspace.app.core.sync

import android.content.Context
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.location.LocationPublisher
import com.ourspace.app.core.database.LocationShareEntity
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.security.DeviceIdentityManager
import java.io.IOException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

/** Shared host-side processor used by WebRTC and the simple internet relay. */
class HostSyncExchangeProcessor(context: Context) {
    private data class CachedResponse(val cachedAt: Long, val responseJson: String)

    private val appContext = context.applicationContext
    private val pairingStore = PairingStore(appContext)
    private val identityManager = DeviceIdentityManager()
    private val preferences = AppPreferences(appContext)
    private val database = OurSpaceDatabase.getInstance(appContext)
    private val snapshotCodec = SyncSnapshotCodec(database, appContext)
    private val incrementalCodec: IncrementalSyncCodec by lazy {
        val deviceId = runCatching { identityManager.getOrCreateIdentity().deviceId }.getOrDefault("")
        IncrementalSyncCodec(database, deviceId)
    }
    private val exchangeMutex = Mutex()
    private val responseCache = object : LinkedHashMap<String, CachedResponse>(MAX_CACHED_RESPONSES + 1, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedResponse>?): Boolean =
            size > MAX_CACHED_RESPONSES
    }

    /**
     * Entry point for the direct WebRTC DataChannel. That channel is already encrypted end to
     * end by WebRTC itself (DTLS), so the payload travels as plain JSON: no second encryption
     * layer, no clock-skew rules, no envelope parsing. It is simpler and noticeably faster.
     * Encrypted envelopes are still accepted for the optional relay path.
     */
    suspend fun processMessage(message: JSONObject): JSONObject = exchangeMutex.withLock {
        val now = System.currentTimeMillis()
        pruneResponseCache(now)
        val type = message.optString("type")
        val requestId = message.optString("requestId").takeIf { it.isNotBlank() }
        // پاسخ incremental نباید cache شود؛ outbox لحظه‌ای عوض می‌شود و ACK اشتباه برمی‌گردد
        if (type != "incremental_exchange" && type != "location_refresh_request") {
            requestId?.let { id ->
                responseCache[id]?.let { cached ->
                    return@withLock JSONObject(cached.responseJson)
                }
            }
        }
        val response = buildResponse(message)
        val responseJson = response.toString()
        if (type != "incremental_exchange" && type != "location_refresh_request") {
            requestId?.takeIf { responseJson.length <= MAX_CACHED_RESPONSE_CHARS }?.let { id ->
                responseCache[id] = CachedResponse(now, responseJson)
            }
        }
        response
    }

    suspend fun processEncryptedEnvelope(envelope: JSONObject): JSONObject = exchangeMutex.withLock {
        // Kept under the old method name for compatibility with existing callers.
        // The payload is now plain JSON; there is no application-level encryption.
        pairingStore.trustedSecret() ?: throw PairingRequiredException()
        val now = System.currentTimeMillis()
        val message = JSONObject(envelope.toString())
        require(message.optLong("sentAt", now) >= now - MAX_CLOCK_SKEW) {
            "درخواست قدیمی است. دوباره تلاش کنید."
        }
        val requestId = message.optString("requestId").takeIf { it.isNotBlank() }
        require(requestId == null || isSafeRequestId(requestId)) {
            "شناسه درخواست همگام‌سازی معتبر نیست."
        }
        pruneResponseCache(now)
        requestId?.let { id ->
            responseCache[id]?.let { cached ->
                return@withLock JSONObject(cached.responseJson)
            }
        }
        val response = buildResponse(message)
        val responseJson = response.toString()
        requestId?.takeIf { responseJson.length <= MAX_CACHED_RESPONSE_CHARS }?.let { id ->
            responseCache[id] = CachedResponse(now, responseJson)
        }
        response
    }

    /** Applies the peer delta and builds the reply. Shared by both transports. */
    private suspend fun buildResponse(message: JSONObject): JSONObject {
        val ownDeviceId = identityManager.getOrCreateIdentity().deviceId
        val beforeUnread = database.messageDao().unreadCountOnce(ownDeviceId)
        val incomingGameEventsOnly = message.optJSONObject("delta")
            ?.let { incrementalCodec.isGameEventsOnlyDelta(it) } == true
        val response = when (message.optString("type")) {
            "location_refresh_request" -> {
                val refreshError = runCatching { refreshOwnLocation() }.exceptionOrNull()
                // Include the exact fresh point in the response as well as the normal delta.
                // This makes manual refresh independent of outbox-trigger timing or a pending
                // incremental batch, so the requesting phone can update its map immediately.
                val refreshedLocation = if (refreshError == null) {
                    snapshotCodec.exportEntity("locationShares", ownDeviceId)
                } else null
                JSONObject()
                    .put("type", "incremental_exchange_result")
                    .put("sentAt", System.currentTimeMillis())
                    .put("locationRefresh", refreshError == null)
                    .put("locationRefreshError", refreshError?.message ?: JSONObject.NULL)
                    .put("refreshedLocation", refreshedLocation ?: JSONObject.NULL)
                    .put(
                        "delta",
                        incrementalCodec.handleHostRequest(
                            JSONObject()
                                .put("protocol", IncrementalSyncCodec.DELTA_PROTOCOL)
                                .put("schema", 1)
                                .put("changes", org.json.JSONArray())
                                .put("acknowledgements", org.json.JSONArray())
                        )
                    )
            }
            "incremental_exchange" -> JSONObject()
                .put("type", "incremental_exchange_result")
                .put("sentAt", System.currentTimeMillis())
                .put("delta", incrementalCodec.handleHostRequest(message.getJSONObject("delta")))

            "exchange" -> {
                snapshotCodec.mergeSnapshot(message.getJSONObject("snapshot"))
                com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(appContext)
                JSONObject()
                    .put("type", "exchange_result")
                    .put("sentAt", System.currentTimeMillis())
                    .put(
                        "snapshot",
                        snapshotCodec.exportSnapshot(includeAttachments = false, schemaVersion = 4)
                    )
            }

            else -> throw IllegalArgumentException("Unsupported sync request")
        }
        message.optString("requestId").takeIf { it.isNotBlank() }?.let { response.put("requestId", it) }
        val incomingApplied = response.optJSONObject("delta")?.optJSONArray("acknowledgedChanges")?.length() ?: 0
        if (incomingApplied > 0) {
            runCatching { com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(appContext) }
        }
        val afterUnread = database.messageDao().unreadCountOnce(ownDeviceId)
        val notifications = OurSpaceNotificationCenter(appContext)
        if (incomingApplied > 0 && !incomingGameEventsOnly) {
            notifications.showRemoteChanges(incomingApplied, listOf("اطلاعات مشترک"))
        }
        if (afterUnread > beforeUnread) {
            val includeMessageText =
                com.ourspace.app.core.notification.NotificationPreferenceStore.isEnabled(
                    appContext,
                    com.ourspace.app.core.notification.NotificationCategory.CHAT_MESSAGES
                ) && com.ourspace.app.core.notification.NotificationPreferenceStore.showChatMessageText(appContext)
            val latestMessageText = if (includeMessageText) {
                runCatching { database.messageDao().latestUnreadIncomingTextOnce(ownDeviceId) }.getOrNull()
            } else null
            notifications.showNewMessages(afterUnread - beforeUnread, latestMessageText)
        }
        database.heartPulseDao().getAllOnce()
            .filter { !it.isDeleted && it.consumedAt == null && it.senderDeviceId != ownDeviceId }
            .forEach { pulse ->
                notifications.showThinkingOfYou()
                val stamp = System.currentTimeMillis()
                database.heartPulseDao().upsert(pulse.copy(consumedAt = stamp, updatedAt = stamp))
            }
        return response
    }

    /**
     * Executes a peer-requested refresh on the device that owns the location.
     * The result is written to Room first; the normal incremental sync then carries
     * the fresh LocationShareEntity back to the requesting phone.
     */
    private suspend fun refreshOwnLocation() {
        val publisher = LocationPublisher(appContext)
        if (!publisher.hasPermission()) {
            throw IllegalStateException("مجوز موقعیت روی گوشی مقابل داده نشده است.")
        }
        // درخواست صریح گوشی جفت‌شده: یک‌بار موقعیت گرفته می‌شود حتی اگر اشتراک مداوم خاموش باشد.
        // اشتراک مداوم فقط برای به‌روزرسانی دوره‌ای پس‌زمینه لازم است.
        val sharingOn = preferences.isLocationSharingEnabled()
        val fix = publisher.readCurrentLocation(15_000L)
            ?: throw IllegalStateException(
                if (!sharingOn) {
                    "گرفتن موقعیت ناموفق بود. GPS را روشن کنید یا اشتراک موقعیت را فعال کنید."
                } else {
                    "گرفتن موقعیت گوشی مقابل ناموفق بود. GPS یا اینترنت مکان را بررسی کنید."
                }
            )
        val deviceId = identityManager.getOrCreateIdentity().deviceId
        val dao = database.locationShareDao()
        val now = System.currentTimeMillis()
        val existing = dao.findById(deviceId)
        dao.upsert(
            LocationShareEntity(
                id = deviceId,
                latitude = fix.latitude,
                longitude = fix.longitude,
                accuracyMeters = fix.accuracy,
                // اگر اشتراک مداوم خاموش است، فقط همین نقطهٔ درخواستی را با isSharing=true موقتاً می‌فرستیم
                // تا روی نقشهٔ گوشی مقابل دیده شود؛ کاربر همچنان می‌تواند اشتراک را خاموش نگه دارد.
                isSharing = true,
                isDeleted = false,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now
            )
        )
    }

    private fun pruneResponseCache(now: Long) {
        val iterator = responseCache.entries.iterator()
        while (iterator.hasNext()) {
            if (now - iterator.next().value.cachedAt > RESPONSE_CACHE_TTL) iterator.remove()
        }
    }

    private fun isSafeRequestId(value: String): Boolean =
        value.length in 16..100 && value.all {
            it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '-' || it == '_'
        }

    class PairingRequiredException : IOException("Trusted device is not paired")

    private companion object {
        const val MAX_CLOCK_SKEW = 5 * 60 * 1000L
        const val MAX_CACHED_RESPONSES = 32
        const val MAX_CACHED_RESPONSE_CHARS = 256 * 1024
        const val RESPONSE_CACHE_TTL = 10 * 60 * 1000L
    }
}
