package com.ourspace.app.core.ai

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Host on-device LLM bridge (phase native complete).
 *
 * - Backend 2: llama.cpp linked (`OURSPACE_HAS_LLAMA`) → real GGUF inference
 * - Backend 1: native bridge only (GGUF validated, template completion)
 * - Backend 0: library missing → caller falls back to Kotlin rules
 *
 * Every entry point is failure-proof: native errors (including OOM/unsupported
 * model) become null/false with a Persian [lastLoadError], never an exception
 * that could crash the app process.
 */
object HostLlmRuntime {
    private const val TAG = "HostLlmRuntime"
    private const val LIB = "ourspace_llm"
    private const val INFERENCE_TIMEOUT_SEC = 45L

    private val lock = ReentrantLock()
    private val libraryTried = AtomicBoolean(false)
    private val libraryLoaded = AtomicBoolean(false)
    private val backendKind = AtomicInteger(0) // 0 none, 1 bridge, 2 llama
    private var loadedModelPath: String? = null

    /** Last model-load failure in Persian, shown in model settings; null when healthy. */
    @Volatile
    var lastLoadError: String? = null
        private set

    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ourspace-llm").apply { isDaemon = true }
    }

    @JvmStatic external fun nativePing(): Int
    @JvmStatic external fun nativeBackendKind(): Int
    @JvmStatic external fun nativeLoadModel(path: String): Int
    @JvmStatic external fun nativeUnloadModel()
    @JvmStatic external fun nativeComplete(prompt: String, maxTokens: Int): String?
    @JvmStatic external fun nativeCancelGeneration()

    fun isNativeAvailable(): Boolean = ensureLibrary()

    /** 0=none, 1=bridge, 2=llama.cpp */
    fun backendKind(): Int {
        ensureLibrary()
        return backendKind.get()
    }

    fun backendLabel(): String = when (backendKind()) {
        2 -> "local-llama"
        1 -> "native-bridge"
        else -> "none"
    }

    private fun ensureLibrary(): Boolean {
        if (libraryLoaded.get()) return true
        if (libraryTried.get()) return libraryLoaded.get()
        synchronized(this) {
            if (libraryLoaded.get()) return true
            libraryTried.set(true)
            return try {
                System.loadLibrary(LIB)
                val ping = runCatching { nativePing() }.getOrDefault(0)
                val kind = runCatching { nativeBackendKind() }.getOrDefault(ping)
                backendKind.set(kind)
                libraryLoaded.set(ping >= 1)
                Log.i(TAG, "loadLibrary $LIB ping=$ping backend=$kind")
                libraryLoaded.get()
            } catch (t: Throwable) {
                Log.w(TAG, "Native LLM library not available: ${t.message}")
                libraryLoaded.set(false)
                backendKind.set(0)
                false
            }
        }
    }

    /**
     * Loads [modelPath] into the native runtime. When [context] is supplied, a
     * memory/size guard runs first so oversized models never reach ggml on a
     * low-RAM phone. Returns false (with [lastLoadError]) instead of throwing.
     */
    fun ensureModelLoaded(modelPath: String, context: Context? = null): Boolean {
        if (!ensureLibrary()) {
            lastLoadError = "کتابخانهٔ بومی هوش مصنوعی در این نصب در دسترس نیست."
            return false
        }
        val file = File(modelPath)
        if (!GgufSupport.isValidGguf(file)) {
            Log.w(TAG, "Invalid GGUF: $modelPath")
            lastLoadError = "فایل انتخاب‌شده GGUF معتبر نیست."
            return false
        }
        if (context != null) {
            val check = AiMemoryGuard.evaluate(context, file)
            if (!check.allowed) {
                lastLoadError = check.reason
                Log.w(TAG, "model load refused by memory guard: $lastLoadError")
                return false
            }
        }
        lock.withLock {
            if (loadedModelPath == modelPath) return true
            if (loadedModelPath != null) {
                runCatching { nativeUnloadModel() }
                loadedModelPath = null
            }
            val code = try {
                nativeLoadModel(modelPath)
            } catch (t: Throwable) {
                // UnsatisfiedLinkError / OOM raised on the JVM side must not propagate.
                Log.w(TAG, "nativeLoadModel threw: ${t.message}")
                -1
            }
            if (code == 0) {
                loadedModelPath = modelPath
                lastLoadError = null
                Log.i(TAG, "Model loaded (${backendLabel()}): $modelPath")
                return true
            }
            lastLoadError = when (code) {
                5 -> "حافظهٔ آزاد گوشی برای این مدل کافی نیست؛ مدل سبک‌تر ۳B را امتحان کنید."
                6 -> "این مدل با موتور بومی سازگار نیست؛ پاسخ قانون‌محمد جایگزین می‌شود."
                3 -> "خواندن فایل مدل ناموفق بود؛ ممکن است خراب یا ناقص دانلود شده باشد."
                4 -> "ساخت زمینهٔ مدل ناموفق بود (حافظه کم است)."
                else -> "بارگذاری مدل ناموفق بود (کد $code)."
            }
            Log.w(TAG, "nativeLoadModel failed code=$code")
            return false
        }
    }

    fun completeNative(
        request: JSONObject,
        modelPath: String,
        context: Context? = null
    ): LocalAiEngine.Result? {
        if (!ensureLibrary()) return null
        if (!ensureModelLoaded(modelPath, context)) return null
        val prompt = LlmPrompt.buildChatPrompt(request).take(5_000)
        val kind = request.optString("kind")
        // Bound on-device work to keep the phone responsive and limit heat.
        val maxTokens = if (kind == "free_chat") 96 else 64
        val future = try {
            executor.submit<LocalAiEngine.Result?> {
                lock.withLock {
                    val text = runCatching {
                        nativeComplete(prompt, maxTokens)
                    }.getOrNull()?.trim().orEmpty()
                    if (text.isBlank()) return@withLock null
                    LocalAiEngine.Result(
                        text = text.take(2000),
                        alternatives = emptyList(),
                        engine = backendLabel()
                    )
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Inference submit failed: ${t.message}")
            return null
        }
        return try {
            future.get(INFERENCE_TIMEOUT_SEC, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            if (t is TimeoutException) {
                // Stop both the queued/blocked JVM task and the native token loop so a
                // timed-out request does not keep burning CPU and heating the phone.
                future.cancel(true)
                runCatching { nativeCancelGeneration() }
                Log.w(TAG, "Inference timed out after ${INFERENCE_TIMEOUT_SEC}s")
            } else {
                Log.w(TAG, "Inference failed: ${t.message}")
            }
            null
        }
    }

    fun unload() {
        lock.withLock {
            if (loadedModelPath != null) {
                runCatching { nativeUnloadModel() }
                loadedModelPath = null
            }
        }
    }
}
