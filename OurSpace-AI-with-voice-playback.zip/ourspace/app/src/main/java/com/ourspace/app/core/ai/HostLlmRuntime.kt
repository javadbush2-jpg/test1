package com.ourspace.app.core.ai

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * پل مدل بومی روی گوشی میزبان.
 *
 * - Backend 2: llama.cpp لینک شده (OURSPACE_HAS_LLAMA) → استنتاج واقعی GGUF
 * - Backend 1: فقط پل بومی (اعتبارسنجی GGUF + تکمیل قالبی)
 * - Backend 0: کتابخانه موجود نیست → فراخوان به پاسخ قانون‌محمد برمی‌گردد
 *
 * ایزولاسیون پروسه: متدهای بومی فقط داخل سرویس [LlmIsolationService] (پروسهٔ «:llm»)
 * اجرا می‌شوند. در پروسهٔ اصلی همهٔ فراخوان‌ها از طریق IPC همان سرویس می‌روند تا
 * abort/SIGSEGV بومی هرگز اپ را نبندد؛ مرگ سرویس با گیت ایمنی تشخیص داده می‌شود و
 * موتور تا تغییر مدل غیرفعال می‌ماند.
 *
 * متدهای `direct*` فقط برای استفادهٔ داخل پروسهٔ «:llm» هستند.
 */
object HostLlmRuntime {
    private const val TAG = "HostLlmRuntime"
    private const val LIB = "ourspace_llm"
    private const val INFERENCE_TIMEOUT_SEC = 45L

    private val lock = ReentrantLock()
    private val libraryTried = AtomicBoolean(false)
    private val libraryLoaded = AtomicBoolean(false)
    private val backendKind = AtomicInteger(0) // 0 none, 1 bridge, 2 llama
    private var loadedModelPath: String? = null

    /** آخرین خطای بارگذاری مدل به فارسی؛ null وقتی سالم است. */
    @Volatile
    var lastLoadError: String? = null
        private set

    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ourspace-llm").apply { isDaemon = true }
    }

    @JvmStatic external fun nativePing(): Int
    @JvmStatic external fun nativeBackendKind(): Int
    @JvmStatic external fun nativeLoadModel(path: String): Int
    @JvmStatic external fun nativeUnloadModel()
    @JvmStatic external fun nativeComplete(prompt: String, maxTokens: Int): String?
    @JvmStatic external fun nativeCancelGeneration()

    /** آیا کد جاری داخل پروسهٔ ایزولهٔ موتور اجرا می‌شود؟ */
    private val isIsolatedProcess: Boolean
        get() = runCatching {
            Application.getProcessName()?.endsWith(":llm") == true
        }.getOrDefault(false)

    // ------------------------------------------------------------------
    // API عمومی — در هر پروسه‌ای امن است و خودش مسیر درست را انتخاب می‌کند.
    // ------------------------------------------------------------------

    fun isNativeAvailable(): Boolean {
        if (isIsolatedProcess) return directEnsureLibrary()
        return LlmServiceClient.isNativeAvailableCached()
    }

    /** 0=none, 1=bridge, 2=llama.cpp */
    fun backendKind(): Int {
        if (isIsolatedProcess) return directBackendKind()
        return LlmServiceClient.backendKindCached()
    }

    fun backendLabel(): String = when (backendKind()) {
        2 -> "local-llama"
        1 -> "native-bridge"
        else -> "none"
    }

    /** شرح فارسی وضعیت فعلی موتور برای نمایش در تنظیمات؛ null یعنی مشکلی نیست. */
    fun probeDiagnostic(): String? {
        if (isIsolatedProcess) return null
        return LlmServiceClient.probeError()
    }

    /** کاوش اجباری تازهٔ سرویس ایزوله (دکمهٔ بررسی/تلاش مجدد) و بازگشت نتیجه. */
    suspend fun reprobeAndWait(): ProbeResult {
        if (isIsolatedProcess) {
            val kind = directBackendKind()
            return ProbeResult(kind, kind >= 1, directLastError())
        }
        return LlmServiceClient.probeNow(force = true)
    }

    /**
     * مدل را در موتور بارگذاری می‌کند. قبل از دست‌زدن به ggml، گارد حافظه اجرا می‌شود
     * تا مدل بزرگ‌تر از توان گوشی هرگز به کد بومی نرسد. خطا به‌جای استثنا با
     * [lastLoadError] فارسی و مقدار false برمی‌گردد.
     */
    fun ensureModelLoaded(modelPath: String, context: Context? = null): Boolean {
        if (isIsolatedProcess) return directEnsureModelLoaded(modelPath, context)

        if (context != null && LlmServiceClient.isGateDisabled(context)) {
            lastLoadError = LlmServiceClient.gateReason(context)
            return false
        }
        val reply = LlmServiceClient.requestBlocking(
            what = MSG_LOAD,
            data = Bundle().apply { putString(KEY_PATH, modelPath) },
            timeoutMs = LlmServiceClient.LOAD_TIMEOUT_MS
        )
        if (reply == null) {
            lastLoadError = LlmServiceClient.gateReason(context)
                ?: "ارتباط با موتور بومی برقرار نشد؛ پاسخ قانون‌محمد جایگزین می‌شود."
            return false
        }
        if (reply.arg2 != 0) {
            lastLoadError = reply.data?.getString(KEY_ERROR)
                ?: "بارگذاری مدل ناموفق بود؛ پاسخ قانون‌محمد جایگزین می‌شود."
            return false
        }
        lastLoadError = null
        return true
    }

    fun completeNative(
        request: JSONObject,
        modelPath: String,
        context: Context? = null
    ): LocalAiEngine.Result? {
        if (isIsolatedProcess) return directCompleteNative(request, modelPath, context)

        if (context != null && LlmServiceClient.isGateDisabled(context)) {
            lastLoadError = LlmServiceClient.gateReason(context)
            return null
        }
        if (!ensureModelLoaded(modelPath, context)) return null

        val prompt = LlmPrompt.buildChatPrompt(request).take(5_000)
        val kind = request.optString("kind")
        // محدودکردن کار روی گوشی برای دما و پاسخ‌گویی.
        val maxTokens = if (kind == "free_chat") 96 else 64
        val reply = LlmServiceClient.requestBlocking(
            what = MSG_COMPLETE,
            data = Bundle().apply { putString(KEY_PROMPT, prompt) },
            arg2 = maxTokens,
            timeoutMs = LlmServiceClient.COMPLETE_TIMEOUT_MS
        ) ?: return null
        if (reply.arg2 != 0) return null
        val text = reply.data?.getString(KEY_TEXT)?.trim().orEmpty()
        if (text.isBlank()) return null
        return LocalAiEngine.Result(
            text = text.take(2000),
            alternatives = emptyList(),
            engine = backendLabel()
        )
    }

    fun unload() {
        if (isIsolatedProcess) {
            directUnload()
            return
        }
        // یک‌طرفه؛ سرویس پاسخی نمی‌دهد و رشته را معطل نمی‌کند.
        LlmServiceClient.sendOneWay(MSG_UNLOAD)
    }

    /** بعد از تغییر/حذف مدل توسط کاربر، گیت ضدِ کرش‌لوپ بازنشانی می‌شود. */
    fun resetFailureGate(context: Context? = null) {
        if (isIsolatedProcess) return
        LlmServiceClient.resetGate(context)
        lastLoadError = null
    }

    // ------------------------------------------------------------------
    // اجرای مستقیم بومی — فقط داخل پروسهٔ «:llm» فراخوانی شوند.
    // ------------------------------------------------------------------

    internal fun directEnsureLibrary(): Boolean {
        if (libraryLoaded.get()) return true
        if (libraryTried.get()) return libraryLoaded.get()
        synchronized(this) {
            if (libraryLoaded.get()) return true
            libraryTried.set(true)
            return try {
                System.loadLibrary(LIB)
                val ping = runCatching { nativePing() }.getOrDefault(0)
                val kind = runCatching { nativeBackendKind() }.getOrDefault(ping)
                backendKind.set(kind)
                libraryLoaded.set(ping >= 1)
                Log.i(TAG, "loadLibrary $LIB ping=$ping backend=$kind")
                libraryLoaded.get()
            } catch (t: Throwable) {
                Log.w(TAG, "Native LLM library not available: ${t.message}")
                libraryLoaded.set(false)
                backendKind.set(0)
                lastLoadError = "کتابخانهٔ بومی هوش مصنوعی در این نصب بارگذاری نشد (${t.javaClass.simpleName})."
                false
            }
        }
    }

    internal fun directBackendKind(): Int {
        directEnsureLibrary()
        return backendKind.get()
    }

    internal fun directLastError(): String? = lastLoadError

    internal fun directEnsureModelLoaded(modelPath: String, context: Context? = null): Boolean {
        if (!directEnsureLibrary()) {
            lastLoadError = "کتابخانهٔ بومی هوش مصنوعی در این نصب در دسترس نیست."
            return false
        }
        val file = File(modelPath)
        if (!GgufSupport.isValidGguf(file)) {
            Log.w(TAG, "Invalid GGUF: $modelPath")
            lastLoadError = "فایل انتخاب‌شده GGUF معتبر نیست."
            return false
        }
        if (context != null) {
            val check = AiMemoryGuard.evaluate(context, file)
            if (!check.allowed) {
                lastLoadError = check.reason
                Log.w(TAG, "model load refused by memory guard: $lastLoadError")
                return false
            }
        }
        lock.withLock {
            if (loadedModelPath == modelPath) return true
            if (loadedModelPath != null) {
                runCatching { nativeUnloadModel() }
                loadedModelPath = null
            }
            val code = try {
                nativeLoadModel(modelPath)
            } catch (t: Throwable) {
                // UnsatisfiedLinkError / OOM سمت JVM نباید پخش شود.
                Log.w(TAG, "nativeLoadModel threw: ${t.message}")
                -1
            }
            if (code == 0) {
                loadedModelPath = modelPath
                lastLoadError = null
                Log.i(TAG, "Model loaded (${backendLabel()}): $modelPath")
                return true
            }
            lastLoadError = when (code) {
                5 -> "حافظهٔ آزاد گوشی برای این مدل کافی نیست؛ مدل سبک‌تر ۳B را امتحان کنید."
                6 -> "این مدل با موتور بومی سازگار نیست؛ پاسخ قانون‌محمد جایگزین می‌شود."
                3 -> "خواندن فایل مدل ناموفق بود؛ ممکن است خراب یا ناقص دانلود شده باشد."
                4 -> "ساخت زمینهٔ مدل ناموفق بود (حافظه کم است)."
                else -> "بارگذاری مدل ناموفق بود (کد $code)."
            }
            Log.w(TAG, "nativeLoadModel failed code=$code")
            return false
        }
    }

    /**
     * اجرای مستقیم استنتاج روی پرامپت آماده. صداکننده (سرویس ایزوله) روی رشتهٔ
     * پس‌زمینه است؛ این متد با executor و تایم‌اوت داخلی سریال می‌شود.
     */
    internal fun directCompleteText(prompt: String, maxTokensInput: Int): String? {
        if (!directEnsureLibrary()) return null
        val maxTokens = maxTokensInput.coerceIn(16, 256)
        val future = try {
            executor.submit<String?> {
                lock.withLock {
                    runCatching {
                        nativeComplete(prompt, maxTokens)
                    }.getOrNull()?.trim()
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Inference submit failed: ${t.message}")
            return null
        }
        return try {
            future.get(INFERENCE_TIMEOUT_SEC, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            if (t is TimeoutException) {
                future.cancel(true)
                runCatching { nativeCancelGeneration() }
                Log.w(TAG, "Inference timed out after ${INFERENCE_TIMEOUT_SEC}s")
            } else {
                Log.w(TAG, "Inference failed: ${t.message}")
            }
            null
        }
    }

    internal fun directCompleteNative(
        request: JSONObject,
        modelPath: String,
        context: Context? = null
    ): LocalAiEngine.Result? {
        if (!directEnsureModelLoaded(modelPath, context)) return null
        val prompt = LlmPrompt.buildChatPrompt(request).take(5_000)
        val kind = request.optString("kind")
        val maxTokens = if (kind == "free_chat") 96 else 64
        val text = directCompleteText(prompt, maxTokens)?.take(2000).orEmpty()
        if (text.isBlank()) return null
        return LocalAiEngine.Result(
            text = text,
            alternatives = emptyList(),
            engine = backendLabel()
        )
    }

    internal fun directUnload() {
        lock.withLock {
            if (loadedModelPath != null) {
                runCatching { nativeUnloadModel() }
                loadedModelPath = null
            }
        }
    }

    internal fun directCancel() {
        runCatching { nativeCancelGeneration() }
    }
}
