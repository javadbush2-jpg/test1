package com.ourspace.app.core.ai

import android.util.Log
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Host on-device LLM bridge (phase native complete).
 *
 * - Backend 2: llama.cpp linked (`OURSPACE_HAS_LLAMA`) → real GGUF inference
 * - Backend 1: native bridge only (GGUF validated, template completion)
 * - Backend 0: library missing → caller falls back to Kotlin rules
 */
object HostLlmRuntime {
    private const val TAG = "HostLlmRuntime"
    private const val LIB = "ourspace_llm"

    private val lock = ReentrantLock()
    private val libraryTried = AtomicBoolean(false)
    private val libraryLoaded = AtomicBoolean(false)
    private val backendKind = AtomicInteger(0) // 0 none, 1 bridge, 2 llama
    private var loadedModelPath: String? = null
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ourspace-llm").apply { isDaemon = true }
    }

    @JvmStatic external fun nativePing(): Int
    @JvmStatic external fun nativeBackendKind(): Int
    @JvmStatic external fun nativeLoadModel(path: String): Int
    @JvmStatic external fun nativeUnloadModel()
    @JvmStatic external fun nativeComplete(prompt: String, maxTokens: Int): String?
    @JvmStatic external fun nativeCancelGeneration()

    fun isNativeAvailable(): Boolean = ensureLibrary()

    /** 0=none, 1=bridge, 2=llama.cpp */
    fun backendKind(): Int {
        ensureLibrary()
        return backendKind.get()
    }

    fun backendLabel(): String = when (backendKind()) {
        2 -> "local-llama"
        1 -> "native-bridge"
        else -> "none"
    }

    private fun ensureLibrary(): Boolean {
        if (libraryLoaded.get()) return true
        if (libraryTried.get()) return libraryLoaded.get()
        synchronized(this) {
            if (libraryLoaded.get()) return true
            libraryTried.set(true)
            return try {
                System.loadLibrary(LIB)
                val ping = runCatching { nativePing() }.getOrDefault(0)
                val kind = runCatching { nativeBackendKind() }.getOrDefault(ping)
                backendKind.set(kind)
                libraryLoaded.set(ping >= 1)
                Log.i(TAG, "loadLibrary $LIB ping=$ping backend=$kind")
                libraryLoaded.get()
            } catch (t: Throwable) {
                Log.w(TAG, "Native LLM library not available: ${t.message}")
                libraryLoaded.set(false)
                backendKind.set(0)
                false
            }
        }
    }

    fun ensureModelLoaded(modelPath: String): Boolean {
        if (!ensureLibrary()) return false
        val file = File(modelPath)
        if (!GgufSupport.isValidGguf(file)) {
            Log.w(TAG, "Invalid GGUF: $modelPath")
            return false
        }
        lock.withLock {
            if (loadedModelPath == modelPath) return true
            if (loadedModelPath != null) {
                runCatching { nativeUnloadModel() }
                loadedModelPath = null
            }
            val code = runCatching { nativeLoadModel(modelPath) }.getOrDefault(-1)
            if (code == 0) {
                loadedModelPath = modelPath
                Log.i(TAG, "Model loaded (${backendLabel()}): $modelPath")
                return true
            }
            Log.w(TAG, "nativeLoadModel failed code=$code")
            return false
        }
    }

    fun completeNative(request: JSONObject, modelPath: String): LocalAiEngine.Result? {
        if (!ensureLibrary()) return null
        if (!ensureModelLoaded(modelPath)) return null
        val prompt = LlmPrompt.buildChatPrompt(request).take(5_000)
        val kind = request.optString("kind")
        // Bound on-device work to keep the phone responsive and limit heat.
        val maxTokens = if (kind == "free_chat") 96 else 64
        return try {
            val future = executor.submit<LocalAiEngine.Result?> {
                lock.withLock {
                    val text = nativeComplete(prompt, maxTokens)?.trim().orEmpty()
                    if (text.isBlank()) return@withLock null
                    LocalAiEngine.Result(
                        text = text.take(2000),
                        alternatives = emptyList(),
                        engine = backendLabel()
                    )
                }
            }
            future.get(45, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            if (t is java.util.concurrent.TimeoutException) {
                // Ask the native token loop to stop so a timed-out request does not keep
                // burning CPU and heating the phone in the background.
                runCatching { nativeCancelGeneration() }
            }
            Log.w(TAG, "Inference failed: ${t.message}")
            null
        }
    }

    fun unload() {
        lock.withLock {
            if (loadedModelPath != null) {
                runCatching { nativeUnloadModel() }
                loadedModelPath = null
            }
        }
    }
}
