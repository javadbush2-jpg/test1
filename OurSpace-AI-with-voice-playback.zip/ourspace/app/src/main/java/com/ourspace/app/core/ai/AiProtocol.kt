package com.ourspace.app.core.ai

import android.content.Context
import com.ourspace.app.model.DeviceRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference

/**
 * Phase-1 AI transport bridge between companion and host.
 * - Companion (or any non-host) sends [TYPE_REQUEST]
 * - Host answers with [TYPE_RESPONSE] via [LocalAiEngine]
 * - Host can also answer locally without network when it is the requester
 */
object AiProtocol {
    const val TYPE_REQUEST = "ai_request"
    const val TYPE_RESPONSE = "ai_response"

    data class Suggestion(
        val requestId: String,
        val text: String,
        val alternatives: List<String>,
        val engine: String,
        val receivedAt: Long = System.currentTimeMillis()
    )

    data class PendingRequest(
        val requestId: String,
        val kind: String,
        val createdAt: Long = System.currentTimeMillis()
    )

    private val _latest = MutableStateFlow<Suggestion?>(null)
    val latestSuggestion: StateFlow<Suggestion?> = _latest.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _error.asStateFlow()

    private val pending = AtomicReference<PendingRequest?>(null)

    /** Set by duplex session: publish envelope toward peer. */
    @Volatile
    var publishToPeer: ((JSONObject) -> Unit)? = null

    /** Application context for host-side model access. */
    @Volatile
    var appContext: Context? = null

    fun clearSuggestion() {
        _latest.value = null
        _error.value = null
    }

    /** Surface a Persian failure to the UI and guarantee the busy flag is released. */
    fun markError(message: String) {
        _busy.value = false
        _error.value = message
        pending.set(null)
    }

    /**
     * Runs the host-side completion. The native path must never crash the app:
     * on any throwable we fall back to the rule-based engine so the chat still
     * gets an answer. Returns null only when even the fallback failed.
     */
    private fun runHostSafely(requestId: String, envelope: JSONObject): JSONObject? {
        return try {
            val ctx = appContext
            val result = if (ctx != null) HostAiGateway.complete(ctx, envelope)
            else LocalAiEngine.complete(envelope)
            LocalAiEngine.toResponseJson(requestId, result)
        } catch (t: Throwable) {
            markError("اجرای مدل روی گوشی با مشکل مواجه شد؛ از پاسخ قانون‌محمد استفاده می‌شود.")
            runCatching {
                LocalAiEngine.toResponseJson(requestId, LocalAiEngine.complete(envelope))
            }.getOrNull()
        }
    }

    /**
     * گفتگوی آزاد با دستیار (میزبان مدل را اجرا می‌کند؛ همراه از طریق رله می‌پرسد).
     * @param history لیست نقش/متن: role = user|assistant
     */
    fun requestFreeChat(
        role: DeviceRole?,
        message: String,
        history: List<Pair<String, String>> = emptyList()
    ) {
        val clean = message.trim()
        if (clean.isEmpty()) {
            _error.value = "پیام خالی است."
            return
        }
        val requestId = UUID.randomUUID().toString().replace("-", "")
        val historyJson = org.json.JSONArray()
        history.takeLast(12).forEach { (r, t) ->
            if (t.isNotBlank()) {
                historyJson.put(
                    JSONObject()
                        .put("role", r.take(16))
                        .put("text", t.take(500))
                )
            }
        }
        val envelope = JSONObject()
            .put("type", TYPE_REQUEST)
            .put("requestId", requestId)
            .put("kind", "free_chat")
            .put("message", clean.take(2_000))
            .put("draft", clean.take(2_000))
            .put("history", historyJson)
            .put("sentAt", System.currentTimeMillis())

        pending.set(PendingRequest(requestId, "free_chat"))
        _busy.value = true
        _error.value = null

        if (role == DeviceRole.HOST) {
            val response = runHostSafely(requestId, envelope)
            if (response != null) applyResponse(response)
            return
        }

        val publisher = publishToPeer
        if (publisher == null) {
            markError("ارتباط با میزبان آماده نیست. برای استفاده از مدل، به میزبان وصل شوید.")
            return
        }
        runCatching { publisher.invoke(envelope) }
            .onFailure {
                _busy.value = false
                _error.value = "ارسال درخواست به میزبان ناموفق بود."
                pending.set(null)
            }
    }

    /**
     * Request a chat suggestion. Host runs [LocalAiEngine] immediately.
     * Companion sends request to host and waits for [TYPE_RESPONSE].
     */
    fun requestChatSuggestion(
        role: DeviceRole?,
        draft: String,
        partnerMood: String?,
        ownMood: String?,
        partnerName: String?
    ) {
        val requestId = UUID.randomUUID().toString().replace("-", "")
        val envelope = JSONObject()
            .put("type", TYPE_REQUEST)
            .put("requestId", requestId)
            .put("kind", "chat_suggestion")
            .put("draft", draft.take(2_000))
            .put("partnerMood", partnerMood.orEmpty())
            .put("ownMood", ownMood.orEmpty())
            .put("partnerName", partnerName.orEmpty())
            .put("sentAt", System.currentTimeMillis())

        pending.set(PendingRequest(requestId, "chat_suggestion"))
        _busy.value = true
        _error.value = null

        if (role == DeviceRole.HOST) {
            val response = runHostSafely(requestId, envelope)
            if (response != null) applyResponse(response)
            return
        }

        val publisher = publishToPeer
        if (publisher == null) {
            markError("ارتباط با میزبان آماده نیست. کمی بعد دوباره تلاش کنید.")
            return
        }
        runCatching { publisher.invoke(envelope) }
            .onFailure {
                _busy.value = false
                _error.value = "ارسال درخواست به میزبان ناموفق بود."
                pending.set(null)
            }
    }

    /**
     * Called on inbound envelopes. Returns a response envelope when this device is host and
     * must answer, otherwise null.
     */
    fun handleIncoming(envelope: JSONObject, role: DeviceRole?): JSONObject? {
        return when (envelope.optString("type")) {
            TYPE_REQUEST -> {
                if (role != DeviceRole.HOST) return null
                val requestId = envelope.optString("requestId").ifBlank {
                    UUID.randomUUID().toString().replace("-", "")
                }
                // Runs on the relay/WebRTC poller thread: never let a native failure
                // escape here, otherwise the uncaught exception kills the whole app.
                runHostSafely(requestId, envelope)
            }
            TYPE_RESPONSE -> {
                runCatching { applyResponse(envelope) }
                null
            }
            else -> null
        }
    }

    private fun applyResponse(envelope: JSONObject) {
        val requestId = envelope.optString("requestId")
        val expected = pending.get()
        // Accept even if pending expired; still useful for UI.
        val alts = buildList {
            val arr = envelope.optJSONArray("alternatives")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val s = arr.optString(i)
                    if (s.isNotBlank()) add(s)
                }
            }
        }
        _latest.value = Suggestion(
            requestId = requestId,
            text = envelope.optString("text"),
            alternatives = alts,
            engine = envelope.optString("engine", "rules-v1")
        )
        _busy.value = false
        _error.value = null
        if (expected != null && expected.requestId == requestId) {
            pending.compareAndSet(expected, null)
        }
    }
}
