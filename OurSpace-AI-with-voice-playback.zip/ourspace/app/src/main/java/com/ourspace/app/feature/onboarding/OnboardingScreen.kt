package com.ourspace.app.feature.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.ui.design.OSRadius
import com.ourspace.app.ui.design.OSSpacing
import com.ourspace.app.core.relay.RelayClient
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.core.relay.RelayCredentials
import com.ourspace.app.ui.components.AmbientBackground
import com.ourspace.app.ui.components.GlowCard
import java.security.SecureRandom
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun OnboardingScreen(
    pairingInProgress: Boolean,
    pairingMessage: String?,
    pairingError: String?,
    defaultEndpoint: String = RelayConfig.DEFAULT_ENDPOINT,
    onSaveServer: (String) -> Unit = {},
    onHostReady: (String) -> Unit,
    onCompanionReady: (String) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var serverEndpoint by remember { mutableStateOf(defaultEndpoint) }

    AmbientBackground {
        AnimatedContent(
            targetState = step,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                if (targetState > initialState) {
                    (slideInHorizontally { it / 3 } + fadeIn()).togetherWith(slideOutHorizontally { -it / 4 } + fadeOut())
                } else {
                    (slideInHorizontally { -it / 3 } + fadeIn()).togetherWith(slideOutHorizontally { it / 4 } + fadeOut())
                }
            },
            label = "onboarding"
        ) { current ->
            when (current) {
                0 -> WelcomeStep(onContinue = { step = 1 })
                1 -> ServerSetupStep(
                    initialEndpoint = serverEndpoint,
                    onBack = { step = 0 },
                    onContinue = { endpoint ->
                        serverEndpoint = endpoint
                        onSaveServer(endpoint)
                        step = 2
                    }
                )
                2 -> RoleStep(onHost = { step = 3 }, onCompanion = { step = 4 })
                3 -> HostSetupStep(onBack = { step = 2 }, onReady = onHostReady)
                else -> CompanionSetupStep(
                    isLoading = pairingInProgress,
                    message = pairingMessage,
                    error = pairingError,
                    onBack = { step = 2 },
                    onConnect = onCompanionReady
                )
            }
        }
    }
}

@Composable
private fun WelcomeStep(onContinue: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 28.dp, vertical = 24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().align(Alignment.Center).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(112.dp)
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary
                            )
                        ),
                        shape = RoundedCornerShape(36.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Outlined.FavoriteBorder,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "OurSpace",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "فضای خصوصی زندگی دونفره شما",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(36.dp))
            FeatureLine(Icons.Outlined.Lock, "اطلاعات اصلی روی گوشی و سرور شخصی رمزشده")
            FeatureLine(Icons.Outlined.Person, "طراحی‌شده برای دو دستگاه مورد اعتماد")
            FeatureLine(Icons.Outlined.Cloud, "اتصال پایدار به سرور شخصی شما")
            Spacer(Modifier.height(32.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
                Text("شروع راه‌اندازی", modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}

@Composable
private fun FeatureLine(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .background(
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                    RoundedCornerShape(14.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
        }
        Text(
            text,
            modifier = Modifier.padding(start = 14.dp),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ServerSetupStep(
    initialEndpoint: String,
    onBack: () -> Unit,
    onContinue: (String) -> Unit
) {
    var endpoint by remember { mutableStateOf(initialEndpoint) }
    var testing by remember { mutableStateOf(false) }
    var testOk by remember { mutableStateOf<Boolean?>(null) }
    var testMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(topBar = { TopAppBar(title = { Text("سرور شخصی") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Outlined.Cloud, null, modifier = Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text(
                "آدرس سرور Relay را وارد کنید",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                "همین آدرس پایه باید روی هر دو گوشی یکسان باشد؛ مسیر /admin را وارد نکنید. برای دامنهٔ اینترنتی از HTTPS بدون پورت 8787 استفاده کنید؛ سرور خانگی مستقیم می‌تواند با IP:8787 باشد.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
            )
            OutlinedTextField(
                value = endpoint,
                onValueChange = {
                    endpoint = it.trim()
                    testOk = null
                    testMessage = null
                },
                label = { Text("آدرس سرور") },
                placeholder = { Text(RelayConfig.DEFAULT_ENDPOINT) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = {
                    testing = true
                    testOk = null
                    testMessage = null
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            runCatching {
                                val client = RelayClient(
                                    endpoint,
                                    RelayCredentials.fromAccessToken(RelayConfig.DEFAULT_ACCESS_TOKEN)
                                )
                                client.healthReport()
                            }
                        }
                        testing = false
                        result.onSuccess { report ->
                            testOk = report.ok
                            testMessage = if (report.ok) {
                                "سرور در دسترس است • protocol=${report.protocol}"
                            } else {
                                "پاسخ نامعتبر: ${report.raw.take(120)}"
                            }
                        }.onFailure { err ->
                            testOk = false
                            testMessage = err.message ?: "اتصال برقرار نشد"
                        }
                    }
                },
                enabled = !testing && endpoint.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (testing) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.size(8.dp))
                }
                Text(if (testing) "در حال تست…" else "تست اتصال سرور")
            }
            testMessage?.let { msg ->
                GlowCard(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    cornerRadius = 16.dp,
                    glowColor = if (testOk == true) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.error
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (testOk == true) {
                            Icon(Icons.Outlined.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Text(
                            msg,
                            modifier = Modifier.padding(start = 8.dp),
                            color = if (testOk == true) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { onContinue(endpoint.trim()) },
                enabled = endpoint.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (testOk == true) "ادامه با همین سرور" else "ذخیره و ادامه")
            }
            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
        }
    }
}

@Composable
private fun RoleStep(onHost: () -> Unit, onCompanion: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("نقش این گوشی", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        Text(
            "یک گوشی میزبان و یک گوشی همراه. هر دو به یک سرور شخصی وصل می‌شوند.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
        )
        RoleCard(
            title = "میزبان",
            subtitle = "سرور شخصی را نگه می‌دارد و کد جفت‌سازی می‌سازد",
            onClick = onHost
        )
        Spacer(Modifier.height(12.dp))
        RoleCard(
            title = "همراه",
            subtitle = "با کد چهاررقمی میزبان به فضای مشترک وصل می‌شود",
            onClick = onCompanion
        )
    }
}

@Composable
private fun RoleCard(title: String, subtitle: String, onClick: () -> Unit) {
    GlowCard(onClick = onClick, modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HostSetupStep(onBack: () -> Unit, onReady: (String) -> Unit) {
    val pin = remember {
        val n = SecureRandom().nextInt(10_000)
        n.toString().padStart(4, '0')
    }
    Scaffold(topBar = { TopAppBar(title = { Text("راه‌اندازی میزبان") }) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("کد جفت‌سازی این میزبان", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text(pin, fontSize = 42.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text(
                "این کد را به همراه بده. همراه باید همین کد را در گوشی خودش وارد کند.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = { onReady(pin) }, modifier = Modifier.fillMaxWidth()) { Text("فعال‌کردن میزبان") }
            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CompanionSetupStep(
    isLoading: Boolean,
    message: String?,
    error: String?,
    onBack: () -> Unit,
    onConnect: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("اتصال گوشی همراه") }) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Outlined.Share, null, modifier = Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Text("کد میزبان را وارد کن", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 18.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.filter(Char::isDigit).take(4) },
                label = { Text("کد چهاررقمی") },
                placeholder = { Text("مثلاً 4821") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            if (isLoading) CircularProgressIndicator(modifier = Modifier.padding(top = 14.dp))
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp), textAlign = TextAlign.Center) }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp), textAlign = TextAlign.Center) }
            Button(enabled = !isLoading && pin.length == 4, onClick = { onConnect(pin) }, modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) {
                Text(if (isLoading) "در حال اتصال…" else "اتصال به میزبان")
            }
            OutlinedButton(onClick = onBack, enabled = !isLoading, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
        }
    }
}
