package com.ourspace.app.core.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.Build
import android.os.SystemClock
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.ourspace.app.MainActivity
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.R
import com.ourspace.app.core.relay.RelayDuplexPoller
import com.ourspace.app.core.push.FcmTokenRegistrar
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.core.location.LocationPublisher
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.preferences.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class HostServerService : Service() {
    private data class TypingRequest(val isTyping: Boolean, val sentAt: Long, val queuedAtElapsedMs: Long)
    private data class LastSeenRequest(val openedAt: Long, val queuedAtElapsedMs: Long)

    private var hostServer: LocalHostServer? = null
    private var relayDuplex: RelayDuplexPoller? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var recurringJob: Job? = null
    private var locationJob: Job? = null
    @Volatile private var immediateSyncRequested = false
    @Volatile private var partnerLocationRefreshPending = false
    @Volatile private var pendingTyping: TypingRequest? = null
    @Volatile private var pendingLastSeen: LastSeenRequest? = null
    private val transportLock = Any()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // IMPORTANT: do not start the service with LOCATION type unconditionally.
        // On Android 14+ that requires a granted location permission at the moment
        // startForeground() is called. A fresh install can legitimately have no
        // location permission yet, and the old implementation could crash the
        // process here and persist the HOST role, creating a crash-on-every-launch loop.
        ensureForegroundStarted(includeLocation = false)
        ensureTransportsStarted()
        ensureRecurringMaterializerStarted()
        ensureLocationUpdatesStarted()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureForegroundStarted(includeLocation = false)
        ensureTransportsStarted()
        ensureRecurringMaterializerStarted()
        ensureLocationUpdatesStarted()
        when (intent?.action) {
            ACTION_SYNC_NOW -> {
                immediateSyncRequested = true
                relayDuplex?.requestImmediateSync()
            }
            ACTION_REFRESH_PARTNER_LOCATION -> {
                partnerLocationRefreshPending = true
                synchronized(transportLock) {
                    relayDuplex?.let { duplex ->
                        partnerLocationRefreshPending = false
                        duplex.requestPartnerLocationRefresh()
                    }
                }
            }
            ACTION_TYPING -> {
                val request = TypingRequest(
                    isTyping = intent?.getBooleanExtra(EXTRA_TYPING_STATE, false) ?: false,
                    sentAt = intent?.getLongExtra(EXTRA_TYPING_SENT_AT, 0L) ?: 0L,
                    queuedAtElapsedMs = SystemClock.elapsedRealtime()
                )
                synchronized(transportLock) {
                    val duplex = relayDuplex
                    if (duplex == null) pendingTyping = request
                    else duplex.requestTyping(request.isTyping, request.sentAt, request.queuedAtElapsedMs)
                }
            }
            ACTION_LAST_SEEN -> {
                val request = LastSeenRequest(
                    openedAt = intent?.getLongExtra(EXTRA_LAST_SEEN_AT, 0L) ?: 0L,
                    queuedAtElapsedMs = SystemClock.elapsedRealtime()
                )
                synchronized(transportLock) {
                    val duplex = relayDuplex
                    if (duplex == null) pendingLastSeen = request
                    else duplex.requestLastSeen(request.openedAt, request.queuedAtElapsedMs)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        recurringJob?.cancel()
        recurringJob = null
        locationJob?.cancel()
        locationJob = null
        serviceScope.cancel()
        relayDuplex?.stop()
        relayDuplex = null
        hostServer?.stop()
        hostServer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun ensureTransportsStarted() {
        serviceScope.launch {
            val preferences = AppPreferences(applicationContext)
            val role = preferences.currentRole()
            if (role == null) return@launch

            val relay = preferences.currentRelayConfig()
            synchronized(transportLock) {
                if (!relay.isUsable) {
                    relayDuplex?.stop()
                    relayDuplex = null
                    return@launch
                }
                val duplex = relayDuplex ?: RelayDuplexPoller(applicationContext).also {
                    FcmTokenRegistrar.refreshAndUpload(applicationContext)

                    relayDuplex = it
                }
                duplex.start()
                if (immediateSyncRequested) {
                    immediateSyncRequested = false
                    duplex.requestImmediateSync()
                }
                // onStartCommand can run before this async transport setup completes.
                // Keep location refresh requests until the duplex poller is actually ready.
                if (partnerLocationRefreshPending) {
                    partnerLocationRefreshPending = false
                    duplex.requestPartnerLocationRefresh()
                }
                // Typing is ephemeral. Retain only the newest signal while async transport
                // setup completes, and never replay an old state after a long delay.
                pendingTyping?.let { request ->
                    pendingTyping = null
                    val age = SystemClock.elapsedRealtime() - request.queuedAtElapsedMs
                    if (request.sentAt > 0L && age in 0L..MAX_PENDING_TYPING_AGE_MS) {
                        duplex.requestTyping(request.isTyping, request.sentAt, request.queuedAtElapsedMs)
                    }
                }
                pendingLastSeen?.let { request ->
                    pendingLastSeen = null
                    val age = SystemClock.elapsedRealtime() - request.queuedAtElapsedMs
                    if (request.openedAt > 0L && age in 0L..120_000L) {
                        duplex.requestLastSeen(request.openedAt, request.queuedAtElapsedMs)
                    }
                }
            }
        }
    }


    private fun ensureLocationUpdatesStarted() {
        if (locationJob?.isActive == true) return
        locationJob = serviceScope.launch {
            val preferences = AppPreferences(applicationContext)
            val repository = (application as OurSpaceApplication).repository
            val deviceId = DeviceIdentityManager().getOrCreateIdentity().deviceId
            var nextUpdateAt = System.currentTimeMillis()
            while (isActive) {
                val now = System.currentTimeMillis()
                val waitMs = (nextUpdateAt - now).coerceAtLeast(0L)
                if (waitMs > 0L) delay(waitMs)
                if (!isActive) break

                if (preferences.isLocationSharingEnabled()) {
                    // A background location FGS promotion can be rejected by Android/OEM
                    // policy. Do not let that exception silently kill this long-lived loop.
                    val locationForegroundReady = runCatching {
                        ensureForegroundStarted(includeLocation = true)
                        true
                    }.getOrDefault(false)
                    if (locationForegroundReady) {
                        runCatching {
                            val publisher = LocationPublisher(applicationContext)
                            if (publisher.hasPermission()) {
                                val fix = publisher.readCurrentLocation(8_000L)
                                if (fix != null) {
                                    repository.publishLocation(
                                        deviceId = deviceId,
                                        latitude = fix.latitude,
                                        longitude = fix.longitude,
                                        accuracyMeters = fix.accuracy,
                                        isSharing = true
                                    )
                                }
                            }
                        }
                    }
                }

                // Keep a stable ten-minute cadence instead of adding the GPS acquisition
                // time to the interval. If a fix takes 8 seconds, the next update is still
                // scheduled for the original ten-minute boundary.
                nextUpdateAt += LOCATION_UPDATE_INTERVAL
                if (nextUpdateAt < System.currentTimeMillis()) {
                    nextUpdateAt = System.currentTimeMillis() + LOCATION_UPDATE_INTERVAL
                }
            }
        }
    }

    private fun ensureRecurringMaterializerStarted() {
        if (recurringJob?.isActive == true) return
        recurringJob = serviceScope.launch {
            val deviceId = DeviceIdentityManager().getOrCreateIdentity().deviceId
            val repository = (application as OurSpaceApplication).repository
            while (isActive) {
                runCatching { repository.materializeDueRecurringTransactions(deviceId) }
                delay(RECURRING_CHECK_INTERVAL)
            }
        }
    }

    /**
     * Starts/updates the foreground service without requiring location permission unless
     * location sharing is actually enabled and the permission has already been granted.
     * This is critical on Android 14+ where an undeclared/ungranted foreground-service
     * type can throw SecurityException during startup.
     */
    private fun ensureForegroundStarted(includeLocation: Boolean) {
        val locationAllowed =
            ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        val useLocation = includeLocation && locationAllowed

        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                var types = 0
                // REMOTE_MESSAGING is available from Android 12. On Android 10/11
                // keep the type unspecified rather than referencing an unsupported type.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    types = ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING
                }
                if (useLocation) {
                    types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                }
                startForeground(NOTIFICATION_ID, buildNotification(), types)
            } else {
                @Suppress("DEPRECATION")
                startForeground(NOTIFICATION_ID, buildNotification())
            }
        }.onFailure { error ->
            // A foreground-type mismatch must never be allowed to crash the UI process.
            // The next start command / location cycle retries with the safe mode.
            com.ourspace.app.core.webrtc.ConnectionDiagnostics.log(
                "Foreground service start failed safely: ${error.javaClass.simpleName}"
            )
        }
    }

    private fun createNotificationChannel() {
        // minSdk is 29, so notification channels are available on every supported device.
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.host_service_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.host_service_body)
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_ourspace)
            .setContentTitle(getString(R.string.host_service_title))
            .setContentText(getString(R.string.host_service_body))
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "ourspace_host_service"
        private const val NOTIFICATION_ID = 4101
        private const val RECURRING_CHECK_INTERVAL = 15 * 60 * 1000L
        private const val LOCATION_UPDATE_INTERVAL = 10 * 60 * 1000L
        private const val ACTION_SYNC_NOW = "com.ourspace.app.action.SYNC_NOW"
        private const val ACTION_REFRESH_PARTNER_LOCATION =
            "com.ourspace.app.action.REFRESH_PARTNER_LOCATION"
        private const val ACTION_TYPING = "com.ourspace.app.action.TYPING_PRESENCE"
        private const val ACTION_LAST_SEEN = "com.ourspace.app.action.APP_LAST_SEEN"
        private const val EXTRA_TYPING_STATE = "typing_state"
        private const val EXTRA_TYPING_SENT_AT = "typing_sent_at"
        private const val EXTRA_LAST_SEEN_AT = "last_seen_at"
        private const val MAX_PENDING_TYPING_AGE_MS = 15_000L

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, HostServerService::class.java)
            )
        }

        fun requestImmediateSync(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, HostServerService::class.java).setAction(ACTION_SYNC_NOW)
            )
        }

        fun requestPartnerLocationRefresh(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, HostServerService::class.java).setAction(ACTION_REFRESH_PARTNER_LOCATION)
            )
        }

        fun requestTyping(context: Context, isTyping: Boolean, sentAt: Long) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, HostServerService::class.java)
                    .setAction(ACTION_TYPING)
                    .putExtra(EXTRA_TYPING_STATE, isTyping)
                    .putExtra(EXTRA_TYPING_SENT_AT, sentAt)
            )
        }

        fun requestLastSeen(context: Context, openedAt: Long) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, HostServerService::class.java)
                    .setAction(ACTION_LAST_SEEN)
                    .putExtra(EXTRA_LAST_SEEN_AT, openedAt)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, HostServerService::class.java))
        }
    }
}
