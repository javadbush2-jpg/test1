package com.ourspace.app.core.webrtc

/**
 * Central WebRTC transport policy.
 *
 * Stability is the priority here:
 * - Optional custom TURN from settings is preferred when set.
 * - TCP/TLS TURN candidates are accepted.
 * - ICE gathering is given enough time to collect relay candidates.
 * - The signaling layer can retry without rebuilding application state.
 */
object WebRtcConfig {
    data class IceServerConfig(
        val url: String,
        val username: String? = null,
        val credential: String? = null
    )

    // STUN helps direct paths; TURN remains the fallback for carrier-grade NAT.
    val STUN_SERVERS = listOf(
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
        "stun:stun.cloudflare.com:3478"
    )
    val DEFAULT_TURN_SERVERS = emptyList<IceServerConfig>()

    const val DATA_CHANNEL_LABEL = "ourspace-sync"
    const val PROTOCOL_VERSION = 2

    const val ICE_GATHER_TIMEOUT_MS = 30_000L
    const val ICE_GATHER_GOOD_ENOUGH_MS = 12_000L
    const val CONNECTION_TIMEOUT_MS = 35_000L
    const val CHANNEL_IDLE_TIMEOUT_MS = 10 * 60_000L
    const val MAX_MESSAGE_BYTES = 256 * 1024

    const val SIGNALING_HEARTBEAT_MS = 8_000L
    const val SIGNALING_CONNECT_TIMEOUT_MS = 15_000L
}
