package com.ourspace.app.core.ai

import android.content.Context
import android.util.Log
import org.json.JSONObject

/**
 * Host entry for AI completion (phase 1 rules + phase 2b native GGUF bridge).
 *
 * This is the process-crash boundary: any failure of the native runtime
 * (UnsatisfiedLinkError, OOM, unsupported GGUF architecture, timeout) is
 * contained here and degrades to the deterministic rule-based engine so the
 * AI chat keeps answering instead of the app closing.
 */
object HostAiGateway {
    private const val TAG = "HostAiGateway"

    @Volatile
    private var store: AiModelStore? = null

    fun init(context: Context) {
        if (store == null) {
            synchronized(this) {
                if (store == null) {
                    store = AiModelStore(context.applicationContext).also { it.refresh() }
                }
            }
        }
    }

    fun modelStore(context: Context): AiModelStore {
        init(context)
        return store!!
    }

    fun complete(context: Context, request: JSONObject): LocalAiEngine.Result =
        runCatching { completeUnsafe(context, request) }
            .getOrElse { throwable ->
                Log.w(TAG, "native AI path failed, using rules fallback: ${throwable.message}")
                LocalAiEngine.complete(request).copy(engine = "rules-v1 (fallback)")
            }

    private fun completeUnsafe(context: Context, request: JSONObject): LocalAiEngine.Result {
        init(context)
        val st = store!!.state.value
        val path = st.localPath
        if (!path.isNullOrBlank() &&
            st.status == AiModelStatus.READY &&
            HostLlmRuntime.backendKind() == 2
        ) {
            // Backend 2 is actual llama.cpp inference. Backend 1 is only a canned bridge,
            // not a language model, so don't pretend it generated the answer.
            HostLlmRuntime.completeNative(request, path, context)?.let { return it }
        }
        // Honest fallback when the native runtime is absent or llama.cpp was not linked.
        val base = LocalAiEngine.complete(request)
        val engine = when {
            HostLlmRuntime.backendKind() == 1 -> "rules-v1 (llama.cpp unavailable)"
            !path.isNullOrBlank() -> "rules-v1 (model not loaded)"
            else -> "rules-v1"
        }
        return base.copy(engine = engine)
    }
}
