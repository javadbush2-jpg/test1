package com.ourspace.app.core.ai

import android.content.Context
import org.json.JSONObject

/**
 * Host entry for AI completion (phase 1 rules + phase 2b native GGUF bridge).
 */
object HostAiGateway {
    @Volatile
    private var store: AiModelStore? = null

    fun init(context: Context) {
        if (store == null) {
            synchronized(this) {
                if (store == null) {
                    store = AiModelStore(context.applicationContext).also { it.refresh() }
                }
            }
        }
    }

    fun modelStore(context: Context): AiModelStore {
        init(context)
        return store!!
    }

    fun complete(context: Context, request: JSONObject): LocalAiEngine.Result {
        init(context)
        val st = store!!.state.value
        val path = st.localPath
        if (!path.isNullOrBlank() &&
            st.status == AiModelStatus.READY &&
            HostLlmRuntime.backendKind() == 2
        ) {
            // Backend 2 is actual llama.cpp inference. Backend 1 is only a canned bridge,
            // not a language model, so don't pretend it generated the answer.
            HostLlmRuntime.completeNative(request, path)?.let { return it }
        }
        // Honest fallback when the native runtime is absent or llama.cpp was not linked.
        val base = LocalAiEngine.complete(request)
        val engine = when {
            HostLlmRuntime.backendKind() == 1 -> "rules-v1 (llama.cpp unavailable)"
            !path.isNullOrBlank() -> "rules-v1 (model not loaded)"
            else -> "rules-v1"
        }
        return base.copy(engine = engine)
    }
}
