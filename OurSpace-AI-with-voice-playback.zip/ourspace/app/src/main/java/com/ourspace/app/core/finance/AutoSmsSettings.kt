package com.ourspace.app.core.finance

import android.content.Context

/**
 * تنظیم دریافت خودکار پیامک بانکی. به‌صورت SharedPreferences نگه داشته می‌شود تا
 * گیرندهٔ پیامک (BroadcastReceiver) بدون نیاز به DataStoreِ معلق بتواند همگام آن را بخواند.
 */
object AutoSmsSettings {
    private const val PREFS = "ourspace_auto_sms"
    private const val KEY_ENABLED = "auto_capture_enabled"

    /** پیش‌فرض روشن است؛ گیرنده بدون مجوز READ_SMS/RECEIVE_SMS عملاً کاری نمی‌کند. */
    fun isEnabled(context: Context): Boolean =
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }
}
