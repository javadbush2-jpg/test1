package com.ourspace.app.feature.games

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.core.database.MessageEntity
import com.ourspace.app.core.sync.GameMessageProtocol
import com.ourspace.app.ui.design.OSConfirmDialog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun GamesScreen(
    gameMessages: List<MessageEntity>,
    ownDeviceId: String,
    isPaired: Boolean,
    onSendGameMessage: suspend (String) -> Boolean,
    onSync: () -> Unit
) {
    val events = remember(gameMessages) {
        gameMessages.asSequence()
            .filterNot { it.isDeleted }
            .mapNotNull { message ->
                GameMessageProtocol.decode(message.text, message.senderDeviceId, message.id, message.createdAt)
            }
            .toList()
    }
    val sessions = remember(events) { buildOnlineGameSessions(events) }
    var selectedSessionId by remember { mutableStateOf<String?>(null) }
    var sending by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }
    var actionError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun submitRaw(message: String, afterSuccess: () -> Unit = {}) {
        if (sending) return
        if (!isPaired) {
            actionError = "برای بازی دونفره، ابتدا این گوشی را با گوشی مقابل جفت کنید."
            return
        }
        scope.launch {
            sending = true
            actionError = null
            actionMessage = null
            try {
                if (onSendGameMessage(message)) {
                    actionMessage = "حرکت روی این گوشی ثبت شد و در صف همگام‌سازی با گوشی مقابل قرار گرفت."
                    afterSuccess()
                } else {
                    actionError = "حرکت ثبت نشد. اتصال را بررسی کنید و دوباره تلاش کنید."
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                actionError = "ارسال حرکت انجام نشد. اتصال را بررسی کنید و دوباره تلاش کنید."
            } finally {
                sending = false
            }
        }
    }

    fun submitAction(
        sessionId: String,
        game: SharedGame,
        action: String,
        arguments: List<String> = emptyList(),
        afterSuccess: () -> Unit = {}
    ) {
        val encoded = runCatching {
            GameMessageProtocol.encode(sessionId, game.wireId, action, *arguments.toTypedArray())
        }.getOrElse {
            actionError = "حرکت بازی معتبر نیست."
            return
        }
        submitRaw(encoded, afterSuccess)
    }

    var sessionPendingDelete by remember { mutableStateOf<OnlineGameSession?>(null) }

    fun requestDeleteSession(session: OnlineGameSession) {
        sessionPendingDelete = session
    }

    fun confirmDeleteSession() {
        val session = sessionPendingDelete ?: return
        sessionPendingDelete = null
        submitAction(session.id, session.game, "delete") {
            if (selectedSessionId == session.id) {
                selectedSessionId = null
            }
            actionMessage = "بازی حذف شد و برای گوشی مقابل هم همگام می‌شود."
        }
    }

    val selectedSession = sessions.firstOrNull { it.id == selectedSessionId }
    when {
        selectedSessionId == null -> GamesHome(
            sessions = sessions,
            ownDeviceId = ownDeviceId,
            isPaired = isPaired,
            isSending = sending,
            onSync = onSync,
            onStartGame = { game ->
                val id = UUID.randomUUID().toString()
                submitAction(id, game, "start") {
                    selectedSessionId = id
                }
            },
            onJoinGame = { session ->
                submitAction(session.id, session.game, "join") {
                    selectedSessionId = session.id
                }
            },
            onOpenGame = { selectedSessionId = it },
            onDeleteGame = { requestDeleteSession(it) }
        )
        selectedSession == null -> MissingGameSession(
            sessionId = selectedSessionId.orEmpty(),
            isSending = sending,
            onBack = { selectedSessionId = null },
            onSync = onSync
        )
        else -> GameSessionScreen(
            session = selectedSession,
            ownDeviceId = ownDeviceId,
            isPaired = isPaired,
            isSending = sending,
            actionMessage = actionMessage,
            actionError = actionError,
            onBack = {
                selectedSessionId = null
                actionMessage = null
                actionError = null
            },
            onSync = onSync,
            onAction = { action, arguments ->
                submitAction(selectedSession.id, selectedSession.game, action, arguments)
            },
            onDelete = { requestDeleteSession(selectedSession) }
        )
    }

    sessionPendingDelete?.let { session ->
        OSConfirmDialog(
            title = "حذف این بازی؟",
            message = "«${session.game.title}» از فهرست هر دو گوشی حذف می‌شود. این کار قابل برگشت نیست.",
            confirmLabel = "حذف بازی",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "🎮",
            onConfirm = { confirmDeleteSession() },
            onDismiss = { sessionPendingDelete = null }
        )
    }
}

@Composable
private fun GamesHome(
    sessions: List<OnlineGameSession>,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    onSync: () -> Unit,
    onStartGame: (SharedGame) -> Unit,
    onJoinGame: (OnlineGameSession) -> Unit,
    onOpenGame: (String) -> Unit,
    onDeleteGame: (OnlineGameSession) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GamesHeroHeader()
        }
        item {
            PairingCard(isPaired = isPaired, onSync = onSync)
        }
        item {
            Text("بازی تازه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(
                "یکی را انتخاب کن و دعوت برای گوشی مقابل فرستاده می‌شود",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SharedGame.entries.forEach { game ->
                    GameCatalogCard(
                        game = game,
                        enabled = isPaired && !isSending,
                        onClick = { onStartGame(game) }
                    )
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("بازی‌های شما", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onSync) { Text("همگام‌سازی") }
            }
        }
        if (sessions.isEmpty()) {
            item { EmptyGamesCard(isPaired = isPaired) }
        } else {
            items(sessions, key = { "session-${it.id}" }) { session ->
                OnlineSessionCard(
                    session = session,
                    ownDeviceId = ownDeviceId,
                    isPaired = isPaired,
                    isSending = isSending,
                    onJoin = { onJoinGame(session) },
                    onOpen = { onOpenGame(session.id) },
                    onDelete = { onDeleteGame(session) }
                )
            }
        }
    }
}

@Composable
private fun GamesHeroHeader() {
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        primary.copy(alpha = 0.92f),
                        primary.copy(alpha = 0.78f),
                        tertiary.copy(alpha = 0.85f)
                    )
                )
            )
            .padding(horizontal = 20.dp, vertical = 22.dp)
    ) {
        Column {
            Text("🎮  سالن بازی", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text(
                "بازی دونفره روی دو گوشی · حرکت‌ها امن همگام می‌شوند",
                color = Color.White.copy(alpha = 0.9f),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("دوز", "چهارتایی", "سنگ‌کاغذ", "چوب", "ریورسی").forEach { tag ->
                    Text(
                        tag,
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color.White.copy(alpha = 0.22f))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PairingCard(isPaired: Boolean, onSync: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPaired) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.85f)
            else MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPaired) 4.dp else 0.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (isPaired) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surfaceContainerHighest
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isPaired) "🔗" else "📡", fontSize = 22.sp)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (isPaired) "اتصال دو گوشی آماده است" else "ابتدا دو گوشی را جفت کنید",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (isPaired) "بازی را بساز؛ طرف مقابل دعوت را روی گوشی خودش می‌بیند."
                    else "برای شروع یا پیوستن، هر دو گوشی باید جفت باشند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (isPaired) {
                TextButton(onClick = onSync) { Text("بررسی") }
            }
        }
    }
}

@Composable
private fun GameCatalogCard(game: SharedGame, enabled: Boolean, onClick: () -> Unit) {
    val (c1, c2) = gameGradient(game)
    Box(
        modifier = Modifier
            .width(148.dp)
            .height(168.dp)
            .shadow(
                elevation = if (enabled) 10.dp else 2.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = c1.copy(alpha = 0.35f),
                spotColor = c2.copy(alpha = 0.25f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(c1, c2)))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(14.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Text(gameEmoji(game), fontSize = 36.sp)
            Spacer(Modifier.weight(1f))
            Text(
                game.title,
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                game.description,
                color = Color.White.copy(alpha = 0.88f),
                style = MaterialTheme.typography.labelSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text(
                if (enabled) "شروع ←" else "قفل",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier
                    .padding(top = 10.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color.White.copy(alpha = 0.22f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        if (!enabled) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(Color.Black.copy(alpha = 0.28f))
            )
        }
    }
}

@Composable
private fun EmptyGamesCard(isPaired: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("🎲", fontSize = 40.sp)
            Text("هنوز بازی‌ای ندارید", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
            Text(
                if (isPaired) "از کارت‌های رنگی بالا یکی را انتخاب کن تا دعوت فرستاده شود."
                else "بعد از جفت‌کردن گوشی‌ها می‌توانی دعوت بازی بفرستی.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

private fun gameGradient(game: SharedGame): Pair<Color, Color> = when (game) {
    SharedGame.TIC_TAC_TOE -> Color(0xFF7B5CFF) to Color(0xFFB388FF)
    SharedGame.CONNECT_FOUR -> Color(0xFF1565C0) to Color(0xFF42A5F5)
    SharedGame.ROCK_PAPER_SCISSORS -> Color(0xFFE65100) to Color(0xFFFFB74D)
    SharedGame.NIM -> Color(0xFF2E7D32) to Color(0xFF81C784)
    SharedGame.REVERSI -> Color(0xFF1B5E20) to Color(0xFF66BB6A)
}

@Composable
private fun OnlineSessionCard(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    onJoin: () -> Unit,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val invitation = !session.isJoined && session.hostDeviceId != ownDeviceId
    val isMyTurn = session.isJoined &&
        !session.snapshot.isFinished &&
        session.snapshot.currentPlayerDeviceId == ownDeviceId
    val isTheirTurn = session.isJoined &&
        !session.snapshot.isFinished &&
        session.snapshot.currentPlayerDeviceId != null &&
        session.snapshot.currentPlayerDeviceId != ownDeviceId
    val containerColor = when {
        isMyTurn -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.95f)
        isTheirTurn -> MaterialTheme.colorScheme.surfaceContainerHigh
        invitation -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
        else -> MaterialTheme.colorScheme.surfaceContainerLow
    }
    val statusColor = when {
        isMyTurn -> MaterialTheme.colorScheme.onTertiaryContainer
        invitation -> MaterialTheme.colorScheme.onPrimaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(gameEmoji(session.game), fontSize = 25.sp)
                Column(Modifier.weight(1f)) {
                    Text(session.game.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        sessionStatus(session, ownDeviceId),
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor,
                        fontWeight = if (isMyTurn) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDelete,
                    enabled = !isSending
                ) {
                    Text("حذف", color = MaterialTheme.colorScheme.error)
                }
                if (invitation) {
                    Button(onClick = onJoin, enabled = isPaired && !isSending) { Text("پیوستن با این گوشی") }
                } else {
                    OutlinedButton(onClick = onOpen, enabled = !isSending) { Text("باز کردن بازی") }
                }
            }
        }
    }
}

@Composable
private fun MissingGameSession(
    sessionId: String,
    isSending: Boolean,
    onBack: () -> Unit,
    onSync: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("← بازی‌ها") }
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (isSending) CircularProgressIndicator(Modifier.size(26.dp))
                Text("در حال دریافت اطلاعات بازی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("پس از رسیدن دعوت یا حرکت‌های بازی از گوشی مقابل، این صفحه به‌روز می‌شود.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(sessionId.take(8), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = onSync) { Text("همگام‌سازی دوباره") }
            }
        }
    }
}

@Composable
private fun GameSessionScreen(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    actionMessage: String?,
    actionError: String?,
    onBack: () -> Unit,
    onSync: () -> Unit,
    onAction: (String, List<String>) -> Unit,
    onDelete: () -> Unit
) {
    val snapshot = session.snapshot
    val status = when {
        !isPaired -> "اتصال گوشی‌ها برقرار نیست؛ حرکت‌ها تا اتصال دوباره همگام نمی‌شوند."
        !session.isJoined -> if (session.hostDeviceId == ownDeviceId) "منتظر پیوستن گوشی مقابل هستید." else "برای شروع، این دعوت را بپذیرید."
        snapshot.isFinished && snapshot.isDraw -> "بازی مساوی شد."
        snapshot.isFinished && snapshot.winnerDeviceId != null -> "${playerLabel(session, snapshot.winnerDeviceId, ownDeviceId)} برنده شد!"
        session.game == SharedGame.ROCK_PAPER_SCISSORS -> "دور ${snapshot.rpsRound} · انتخاب هر دو نفر تا زمان رونمایی پنهان است."
        snapshot.currentPlayerDeviceId == ownDeviceId -> "نوبت شماست · ${playerNumber(session, ownDeviceId)}"
        snapshot.currentPlayerDeviceId != null -> "نوبت ${playerLabel(session, snapshot.currentPlayerDeviceId, ownDeviceId)} است."
        else -> "در انتظار همگام‌شدن وضعیت بازی."
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val secretStore = remember(context) { RpsSecretStore(context.applicationContext) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← بازی‌ها") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDelete, enabled = !isSending) {
                    Text("حذف بازی", color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = onSync, enabled = !isSending) { Text("همگام‌سازی") }
            }
            Text("${gameEmoji(session.game)}  ${session.game.title}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        }
        item { GameStatusCard(status = status, session = session, ownDeviceId = ownDeviceId) }
        if (actionError != null) item { FeedbackCard(actionError, isError = true) }
        if (actionMessage != null) item { FeedbackCard(actionMessage, isError = false) }
        if (!isPaired) {
            item {
                InfoCard("برای ادامهٔ بازی، اتصال دو گوشی را دوباره برقرار و سپس همگام‌سازی کنید.")
            }
        } else if (!session.isJoined) {
            item {
                if (session.hostDeviceId == ownDeviceId) {
                    WaitingForOpponentCard(onSync = onSync)
                } else {
                    InviteAcceptCard(
                        isSending = isSending,
                        onJoin = { onAction("join", emptyList()) }
                    )
                }
            }
        } else if (ownDeviceId != session.hostDeviceId && ownDeviceId != session.guestDeviceId) {
            item { InfoCard("این بازی به گوشی دیگری تعلق دارد.") }
        } else {
            item {
                SharedGameBoard(
                    session = session,
                    ownDeviceId = ownDeviceId,
                    isPaired = isPaired,
                    isSending = isSending,
                    secretStore = secretStore,
                    onAction = onAction
                )
            }
        }
        item {
            Text(
                "حرکت‌ها به‌صورت رویدادهای کوچک از همگام‌سازی جفت‌شدهٔ برنامه عبور می‌کنند و در صفحهٔ گفتگو نمایش داده نمی‌شوند.",
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun InviteAcceptCard(isSending: Boolean, onJoin: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.72f))
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("دعوت بازی رسید", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("با پذیرش دعوت، این گوشی بازیکن دوم می‌شود و نوبت‌ها بین دو گوشی جابه‌جا می‌شوند.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = onJoin, enabled = !isSending, modifier = Modifier.align(Alignment.End)) { Text("پذیرفتن و بازی") }
        }
    }
}

@Composable
private fun WaitingForOpponentCard(onSync: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("دعوت ارسال شد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("وقتی گوشی مقابل دعوت را بپذیرد، صفحهٔ بازی روی هر دو گوشی فعال می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = onSync, modifier = Modifier.align(Alignment.End)) { Text("بررسی پاسخ") }
        }
    }
}

@Composable
private fun GameStatusCard(status: String, session: OnlineGameSession, ownDeviceId: String) {
    val isMyTurn = session.isJoined &&
        !session.snapshot.isFinished &&
        session.snapshot.currentPlayerDeviceId == ownDeviceId
    val isTheirTurn = session.isJoined &&
        !session.snapshot.isFinished &&
        session.snapshot.currentPlayerDeviceId != null &&
        session.snapshot.currentPlayerDeviceId != ownDeviceId
    val containerColor = when {
        isMyTurn -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.95f)
        isTheirTurn -> MaterialTheme.colorScheme.surfaceContainerHighest
        session.snapshot.isFinished -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
        else -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.72f)
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(status, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (isMyTurn) {
                Text(
                    "الان نوبت شماست — حرکت خود را انجام دهید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (session.isJoined) {
                Text(
                    "بازیکن اول: ${if (session.hostDeviceId == ownDeviceId) "شما" else "گوشی مقابل"}  ·  بازیکن دوم: ${if (session.guestDeviceId == ownDeviceId) "شما" else "گوشی مقابل"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SharedGameBoard(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    secretStore: RpsSecretStore,
    onAction: (String, List<String>) -> Unit
) {
    when (session.game) {
        SharedGame.TIC_TAC_TOE -> TicTacToeBoard(session, ownDeviceId, isPaired, isSending, onAction)
        SharedGame.CONNECT_FOUR -> ConnectFourBoard(session, ownDeviceId, isPaired, isSending, onAction)
        SharedGame.ROCK_PAPER_SCISSORS -> RockPaperScissorsBoard(session, ownDeviceId, isPaired, isSending, secretStore, onAction)
        SharedGame.NIM -> NimBoard(session, ownDeviceId, isPaired, isSending, onAction)
        SharedGame.REVERSI -> ReversiBoard(session, ownDeviceId, isPaired, isSending, onAction)
    }
}

@Composable
private fun TicTacToeBoard(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    onAction: (String, List<String>) -> Unit
) {
    val board = session.snapshot.board
    val canMove = isPaired && !session.isFinished && session.snapshot.currentPlayerDeviceId == ownDeviceId && !isSending
    val xColor = Color(0xFF7C4DFF)
    val oColor = Color(0xFFFF6E40)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text("✖ بازیکن اول", color = xColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            Text("  ·  ", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("⭕ بازیکن دوم", color = oColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(28.dp), ambientColor = xColor.copy(alpha = 0.25f), spotColor = oColor.copy(alpha = 0.2f))
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF2A1B4A), Color(0xFF1A1430), Color(0xFF3A2040))
                    )
                )
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(3) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        repeat(3) { column ->
                            val index = row * 3 + column
                            val mark = board.getOrElse(index) { 0 }
                            Box(
                                Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(
                                        if (mark == 0) Color.White.copy(alpha = 0.08f)
                                        else Color.White.copy(alpha = 0.12f)
                                    )
                                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(18.dp))
                                    .clickable(enabled = canMove && mark == 0) {
                                        onAction("move", listOf(session.snapshot.moveCount.toString(), index.toString()))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                when (mark) {
                                    1 -> Text("✖", fontSize = 40.sp, color = xColor, fontWeight = FontWeight.Black)
                                    2 -> Text("⭕", fontSize = 36.sp, color = oColor, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectFourBoard(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    onAction: (String, List<String>) -> Unit
) {
    val board = session.snapshot.board
    val canMove = isPaired && !session.isFinished && session.snapshot.currentPlayerDeviceId == ownDeviceId && !isSending
    val frame = Color(0xFF0D47A1)
    val hole = Color(0xFF082C63)
    val red = Color(0xFFE53935)
    val yellow = Color(0xFFFFD600)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Text("🔴 بازیکن اول  ·  🟡 بازیکن دوم", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .shadow(14.dp, RoundedCornerShape(26.dp), ambientColor = frame.copy(alpha = 0.4f), spotColor = frame.copy(alpha = 0.3f))
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF1565C0), frame)))
                .padding(10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                repeat(7) { column ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable(enabled = canMove && board.getOrElse(column) { 1 } == 0) {
                                onAction("move", listOf(session.snapshot.moveCount.toString(), column.toString()))
                            },
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        repeat(6) { row ->
                            val mark = board.getOrElse(row * 7 + column) { 0 }
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .clip(CircleShape)
                                    .background(
                                        when (mark) {
                                            1 -> Brush.radialGradient(listOf(Color(0xFFFF8A80), red, Color(0xFFB71C1C)))
                                            2 -> Brush.radialGradient(listOf(Color(0xFFFFF59D), yellow, Color(0xFFF9A825)))
                                            else -> Brush.radialGradient(listOf(hole.copy(alpha = 0.9f), hole))
                                        }
                                    )
                                    .border(
                                        width = 1.5.dp,
                                        color = Color.White.copy(alpha = if (mark == 0) 0.15f else 0.35f),
                                        shape = CircleShape
                                    )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NimBoard(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    onAction: (String, List<String>) -> Unit
) {
    val snapshot = session.snapshot
    val canMove = isPaired && !session.isFinished && snapshot.currentPlayerDeviceId == ownDeviceId && !isSending
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(
                    Brush.linearGradient(listOf(Color(0xFF1B5E20), Color(0xFF33691E), Color(0xFF4E342E)))
                )
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "چوب‌های باقی‌مانده: ${snapshot.remainingTokens}",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )
                repeat(3) { row ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        repeat(5) { column ->
                            val tokenIndex = row * 5 + column
                            if (tokenIndex < snapshot.remainingTokens) {
                                Box(
                                    Modifier
                                        .padding(horizontal = 4.dp)
                                        .width(14.dp)
                                        .height(36.dp)
                                        .shadow(4.dp, RoundedCornerShape(8.dp))
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color(0xFFD7CCC8), Color(0xFF8D6E63), Color(0xFF5D4037))
                                            )
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..3).forEach { take ->
                Button(
                    onClick = { onAction("move", listOf(snapshot.moveCount.toString(), take.toString())) },
                    enabled = canMove && snapshot.remainingTokens >= take,
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2E7D32),
                        contentColor = Color.White
                    )
                ) { Text("−$take", fontWeight = FontWeight.Black, fontSize = 18.sp) }
            }
        }
        Text(
            "چوب آخر را بردار تا برنده شوی · فقط در نوبت خودت حرکت کن",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun ReversiBoard(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    onAction: (String, List<String>) -> Unit
) {
    val snapshot = session.snapshot
    val board = snapshot.board
    val canMove = isPaired && !session.isFinished && snapshot.currentPlayerDeviceId == ownDeviceId && !isSending
    val hostCount = board.count { it == 1 }
    val guestCount = board.count { it == 2 }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text(
            "● بازیکن اول: $hostCount  ·  ○ بازیکن دوم: $guestCount",
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            style = MaterialTheme.typography.labelLarge
        )
        if (snapshot.passNotice) {
            InfoCard("گوشی مقابل حرکت مجاز نداشت؛ نوبت شما دوباره ادامه دارد.")
        }
        Box(
            Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(20.dp), ambientColor = Color(0xFF1B5E20).copy(alpha = 0.35f))
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1B5E20), Color(0xFF2E7D32), Color(0xFF1B5E20))))
                .padding(8.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                repeat(8) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        repeat(8) { column ->
                            val index = row * 8 + column
                            val mark = board.getOrElse(index) { 0 }
                            val legal = index in snapshot.legalMoves
                            val cellTint = when {
                                legal -> Color(0xFF81C784).copy(alpha = 0.55f)
                                (row + column) % 2 == 0 -> Color(0xFF388E3C).copy(alpha = 0.55f)
                                else -> Color(0xFF2E7D32).copy(alpha = 0.45f)
                            }
                            Box(
                                Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(cellTint)
                                    .clickable(enabled = canMove && legal) {
                                        onAction("move", listOf(session.snapshot.moveCount.toString(), index.toString()))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                when (mark) {
                                    1 -> Box(
                                        Modifier
                                            .fillMaxSize(0.78f)
                                            .shadow(3.dp, CircleShape)
                                            .clip(CircleShape)
                                            .background(Brush.radialGradient(listOf(Color(0xFF424242), Color(0xFF000000))))
                                    )
                                    2 -> Box(
                                        Modifier
                                            .fillMaxSize(0.78f)
                                            .shadow(3.dp, CircleShape)
                                            .clip(CircleShape)
                                            .background(Brush.radialGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE0E0E0))))
                                    )
                                    else -> if (legal) {
                                        Box(
                                            Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFFFF176))
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RockPaperScissorsBoard(
    session: OnlineGameSession,
    ownDeviceId: String,
    isPaired: Boolean,
    isSending: Boolean,
    secretStore: RpsSecretStore,
    onAction: (String, List<String>) -> Unit
) {
    val snapshot = session.snapshot
    val ownIsHost = ownDeviceId == session.hostDeviceId
    val opponentId = if (ownIsHost) session.guestDeviceId else session.hostDeviceId
    val allPlayersCommitted = snapshot.committedDeviceIds.containsAll(listOf(session.hostDeviceId, session.guestDeviceId.orEmpty()))
    val ownCommitted = ownDeviceId in snapshot.committedDeviceIds
    val ownChoice = snapshot.revealedChoices[ownDeviceId]
    val peerChoice = opponentId?.let { snapshot.revealedChoices[it] }
    val canCommit = isPaired && !isSending && !ownCommitted && ownDeviceId in setOf(session.hostDeviceId, session.guestDeviceId)
    val secret = secretStore.load(session.id, snapshot.rpsRound)
    val canReveal = isPaired && !isSending && ownCommitted && allPlayersCommitted && ownChoice == null && secret != null
    val legalRps = listOf("rock", "paper", "scissors")
    val previous = snapshot.lastCompletedRpsRound

    LaunchedEffect(session.id, snapshot.rpsRound, snapshot.revealedChoices) {
        if (ownDeviceId in snapshot.revealedChoices) secretStore.remove(session.id, snapshot.rpsRound)
        if (snapshot.rpsRound > 1) secretStore.remove(session.id, snapshot.rpsRound - 1)
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    ScorePill("بازیکن اول", snapshot.hostScore)
                    ScorePill("بازیکن دوم", snapshot.guestScore)
                }
                if (previous != null) {
                    Text(
                        "دور ${previous.round}: ${choiceLabel(previous.hostChoice)} مقابل ${choiceLabel(previous.guestChoice)} — ${rpsOutcome(previous, session)}",
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                    )
                }
                when {
                    !isPaired -> Text("برای بازی، اتصال دو گوشی را دوباره برقرار کنید.", color = MaterialTheme.colorScheme.error)
                    ownChoice != null && peerChoice == null -> Text("انتخاب شما آشکار شد؛ منتظر رونمایی گوشی مقابل بمانید.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ownChoice != null && peerChoice != null -> Text("هر دو انتخاب دیده شدند؛ دور بعد آماده است.", color = MaterialTheme.colorScheme.primary)
                    ownCommitted && !allPlayersCommitted -> Text("انتخاب شما ثبت و پنهان شد؛ منتظر انتخاب گوشی مقابل هستیم.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ownCommitted && allPlayersCommitted && secret == null -> Text("انتخاب محرمانهٔ این دور روی گوشی پیدا نشد. برای جلوگیری از نتیجهٔ نادرست، یک بازی تازه بسازید.", color = MaterialTheme.colorScheme.error)
                    ownCommitted && allPlayersCommitted -> Text("هر دو انتخاب محرمانه ثبت شده‌اند. حالا انتخاب خودتان را آشکار کنید.", color = MaterialTheme.colorScheme.primary)
                    else -> Text("انتخاب کنید؛ تا وقتی هر دو گوشی انتخاب نکنند، حرکت طرف مقابل دیده نمی‌شود.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (canCommit) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        legalRps.forEach { choice ->
                            val accent = when (choice) {
                                "rock" -> Color(0xFF5D4037)
                                "paper" -> Color(0xFF1565C0)
                                else -> Color(0xFF2E7D32)
                            }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable(enabled = canCommit) {
                                        val nonce = UUID.randomUUID().toString().replace("-", "")
                                        val commitment = GameMessageProtocol.rockPaperScissorsCommitment(
                                            session.id, snapshot.rpsRound, ownDeviceId, choice, nonce
                                        )
                                        secretStore.save(session.id, snapshot.rpsRound, choice, nonce)
                                        onAction("commit", listOf(snapshot.rpsRound.toString(), commitment))
                                    }
                                    .padding(6.dp)
                            ) {
                                Box(
                                    Modifier
                                        .size(72.dp)
                                        .shadow(8.dp, CircleShape, ambientColor = accent.copy(alpha = 0.4f))
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(accent.copy(alpha = 0.85f), accent)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(choiceEmoji(choice), fontSize = 34.sp)
                                }
                                Text(
                                    choiceLabel(choice),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
                if (canReveal) {
                    Button(
                        onClick = {
                            val saved = secretStore.load(session.id, snapshot.rpsRound) ?: return@Button
                            onAction("reveal", listOf(snapshot.rpsRound.toString(), saved.choice, saved.nonce))
                        },
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFE65100),
                            contentColor = Color.White
                        )
                    ) { Text("✨ آشکار کردن انتخاب من", fontWeight = FontWeight.Bold) }
                }
            }
        }
        Text("سنگ‌کاغذقیچی با ثبت تعهد رمزنگاری‌شده انجام می‌شود؛ انتخاب اول، انتخاب دوم را لو نمی‌دهد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ScorePill(label: String, score: Int) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            score.toString(),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun InfoCard(text: String) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(16.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FeedbackCard(text: String, isError: Boolean) {
    Text(
        text,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(
            if (isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer
        ).padding(horizontal = 14.dp, vertical = 11.dp),
        color = if (isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
        style = MaterialTheme.typography.bodySmall
    )
}

private fun gameEmoji(game: SharedGame): String = when (game) {
    SharedGame.TIC_TAC_TOE -> "✖️"
    SharedGame.CONNECT_FOUR -> "🔴"
    SharedGame.ROCK_PAPER_SCISSORS -> "✊"
    SharedGame.NIM -> "🪵"
    SharedGame.REVERSI -> "⚫"
}

private fun sessionStatus(session: OnlineGameSession, ownDeviceId: String): String = when {
    !session.isJoined && session.hostDeviceId == ownDeviceId -> "منتظر پیوستن گوشی مقابل"
    !session.isJoined -> "دعوت تازه برای گوشی شما"
    session.snapshot.isFinished && session.snapshot.isDraw -> "پایان‌یافته · مساوی"
    session.snapshot.isFinished -> "پایان‌یافته · ${playerNumber(session, session.snapshot.winnerDeviceId.orEmpty())} برنده"
    session.game == SharedGame.ROCK_PAPER_SCISSORS -> "در جریان · دور ${session.snapshot.rpsRound}"
    session.snapshot.currentPlayerDeviceId == ownDeviceId -> "در جریان · نوبت شما"
    session.snapshot.currentPlayerDeviceId != null -> "در جریان · نوبت گوشی مقابل"
    else -> "در انتظار همگام‌سازی"
}

private fun playerNumber(session: OnlineGameSession, deviceId: String): String =
    if (deviceId == session.hostDeviceId) "بازیکن اول" else "بازیکن دوم"

private fun playerLabel(session: OnlineGameSession, deviceId: String, ownDeviceId: String): String =
    if (deviceId == ownDeviceId) "شما (${playerNumber(session, deviceId)})" else "گوشی مقابل (${playerNumber(session, deviceId)})"

private fun choiceLabel(choice: String): String = when (choice) {
    "rock" -> "سنگ"
    "paper" -> "کاغذ"
    "scissors" -> "قیچی"
    else -> "—"
}

private fun choiceEmoji(choice: String): String = when (choice) {
    "rock" -> "✊"
    "paper" -> "✋"
    "scissors" -> "✌️"
    else -> ""
}

private fun rpsOutcome(result: RpsRoundResult, session: OnlineGameSession): String = when (result.winnerDeviceId) {
    null -> "مساوی"
    session.hostDeviceId -> "بازیکن اول برد"
    else -> "بازیکن دوم برد"
}

private data class RpsSecret(val choice: String, val nonce: String)

private class RpsSecretStore(context: Context) {
    private val preferences = context.getSharedPreferences("online_game_rps_secrets", Context.MODE_PRIVATE)

    fun save(sessionId: String, round: Int, choice: String, nonce: String) {
        preferences.edit().putString(key(sessionId, round), "$choice|$nonce").commit()
    }

    fun load(sessionId: String, round: Int): RpsSecret? {
        val parts = preferences.getString(key(sessionId, round), null)?.split('|') ?: return null
        if (parts.size != 2 || parts[0] !in setOf("rock", "paper", "scissors") || parts[1].isBlank()) return null
        return RpsSecret(parts[0], parts[1])
    }

    fun remove(sessionId: String, round: Int) {
        preferences.edit().remove(key(sessionId, round)).apply()
    }

    private fun key(sessionId: String, round: Int) = "${sessionId}_$round"
}
