package com.ourspace.app.core.security

/**
 * کنترل موقت قفل مجدد هنگام خروج کوتاه برای Intentهای سیستمی
 * (انتخاب عکس، فایل، مجوز، و غیره) تا نتیجه Activity Result از بین نرود.
 */
object AppLockSession {
    @Volatile
    private var suppressRelockUntilMs: Long = 0L

    /** تا [durationMs] بعد از ON_STOP برنامه را دوباره قفل نکن. */
    fun suppressRelock(durationMs: Long = 120_000L) {
        val until = System.currentTimeMillis() + durationMs.coerceAtLeast(5_000L)
        if (until > suppressRelockUntilMs) {
            suppressRelockUntilMs = until
        }
    }

    fun clearSuppress() {
        suppressRelockUntilMs = 0L
    }

    fun shouldSuppressRelock(now: Long = System.currentTimeMillis()): Boolean =
        now < suppressRelockUntilMs
}
