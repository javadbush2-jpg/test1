package com.ourspace.app.core.notification

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ourspace.app.MainActivity
import com.ourspace.app.R
import com.ourspace.app.core.time.PersianDateFormatter
import java.util.concurrent.atomic.AtomicBoolean

/**
 * User-facing alert categories are controlled per device in Settings; chat and heart alerts
 * are enabled by default. Never puts message body or sensitive content on the lock screen.
 */
class OurSpaceNotificationCenter(private val context: Context) {
    init {
        val manager = context.getSystemService(NotificationManager::class.java)
        // کانال‌های قدیمی با IMPORTANCE_DEFAULT روی بسیاری از ساعت‌ها bridge نمی‌شوند.
        // شناسهٔ جدید + HIGH تا نصب‌های قبلی هم ارتقا پیدا کنند.
        LEGACY_CHANNEL_IDS.forEach { oldId ->
            runCatching { manager.deleteNotificationChannel(oldId) }
        }
        val alertSound = Settings.System.DEFAULT_NOTIFICATION_URI
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        manager.createNotificationChannel(
            NotificationChannel(
                MESSAGE_CHANNEL,
                "پیام‌های گفتگو",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اعلان پیام‌های جدید — قابل نمایش روی ساعت هوشمند"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 180, 120, 180)
                enableLights(true)
                setShowBadge(true)
                setSound(alertSound, audioAttrs)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
                // اجازهٔ bridge به Wear / ساعت‌های OEM
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setAllowBubbles(true)
                }
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                REMINDER_CHANNEL,
                "یادآوری‌ها",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قرار، مناسبت، عادت و کارها — قابل نمایش روی ساعت"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 220, 100, 220)
                enableLights(true)
                setShowBadge(true)
                setSound(alertSound, audioAttrs)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                HEART_CHANNEL,
                "تپش قلب",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "وقتی طرف مقابل به یاد شماست — روی ساعت هم می‌آید"
                enableVibration(true)
                vibrationPattern = HEARTBEAT_PATTERN
                enableLights(true)
                setShowBadge(true)
                setSound(alertSound, audioAttrs)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            }
        )
        if (legacyNotificationCleanupStarted.compareAndSet(false, true)) {
            clearDisallowedUserNotifications()
        }
    }

    /** Remove active alerts whose category is now disabled in this phone's preferences. */
    private fun clearDisallowedUserNotifications() {
        val manager = NotificationManagerCompat.from(context)
        runCatching {
            manager.activeNotifications
                .filter { active ->
                    val category = categoryForActiveNotification(active)
                    category != null && !NotificationPreferenceStore.isEnabled(context, category)
                }
                .forEach { active -> runCatching { manager.cancel(active.tag, active.id) } }
        }
    }

    /** Remove already-visible notifications immediately when a category is turned off. */
    fun clearNotificationsForCategory(category: NotificationCategory) {
        val manager = NotificationManagerCompat.from(context)
        runCatching {
            manager.activeNotifications
                .filter { active -> categoryForActiveNotification(active) == category }
                .forEach { active -> runCatching { manager.cancel(active.tag, active.id) } }
        }
    }

    /** پاک کردن نوتیف‌های «پیام جدید» وقتی کاربر وارد گفتگو می‌شود. */
    fun clearChatMessageNotifications() {
        val manager = NotificationManagerCompat.from(context)
        runCatching { manager.cancel(MESSAGE_NOTIFICATION_ID) }
        // نسخه‌های قدیمی‌تر احتمالی با tag
        runCatching {
            manager.activeNotifications
                .filter { active ->
                    active.id == MESSAGE_NOTIFICATION_ID ||
                        categoryForActiveNotification(active) == NotificationCategory.CHAT_MESSAGES
                }
                .forEach { active -> runCatching { manager.cancel(active.tag, active.id) } }
        }
    }

    private fun categoryForActiveNotification(active: android.service.notification.StatusBarNotification): NotificationCategory? {
        val storedKey = active.notification.extras?.getString(NOTIFICATION_CATEGORY_EXTRA)
        NotificationCategory.values().firstOrNull { it.key == storedKey }?.let { return it }
        return when (active.notification.channelId) {
            MESSAGE_CHANNEL -> when (active.id) {
                MESSAGE_NOTIFICATION_ID -> NotificationCategory.CHAT_MESSAGES
                REMOTE_CHANGE_NOTIFICATION_ID -> NotificationCategory.SHARED_DATA_UPDATES
                SYNC_NOTIFICATION_ID -> NotificationCategory.SYNC_STATUS
                MOOD_NOTIFICATION_ID -> NotificationCategory.PARTNER_MOOD_UPDATES
                else -> null
            }
            HEART_CHANNEL -> NotificationCategory.HEART_PULSES
            REMINDER_CHANNEL -> if (active.id == BUDGET_NOTIFICATION_ID) {
                NotificationCategory.BUDGET_ALERTS
            } else {
                NotificationCategory.REMINDERS
            }
            else -> null // Keep the persistent foreground-service notification.
        }
    }

    private fun preferenceForNotificationId(id: Int): NotificationCategory = when (id) {
        MESSAGE_NOTIFICATION_ID -> NotificationCategory.CHAT_MESSAGES
        REMOTE_CHANGE_NOTIFICATION_ID -> NotificationCategory.SHARED_DATA_UPDATES
        SYNC_NOTIFICATION_ID -> NotificationCategory.SYNC_STATUS
        MOOD_NOTIFICATION_ID -> NotificationCategory.PARTNER_MOOD_UPDATES
        HEART_NOTIFICATION_ID, HEART_ACK_NOTIFICATION_ID -> NotificationCategory.HEART_PULSES
        BUDGET_NOTIFICATION_ID -> NotificationCategory.BUDGET_ALERTS
        else -> NotificationCategory.REMINDERS
    }

    fun showRemoteChanges(count: Int, categories: List<String>) {
        if (count <= 0 || !canNotify()) return
        val summary = categories.distinct().take(3).joinToString("، ")
        val suffix = if (summary.isBlank()) "" else " — $summary"
        val text = if (count == 1) {
            "یک تغییر جدید از طرف مقابل دریافت شد$suffix."
        } else {
            "${PersianDateFormatter.toPersianDigits(count)} تغییر جدید از طرف مقابل دریافت شد$suffix."
        }
        notify(
            id = REMOTE_CHANGE_NOTIFICATION_ID,
            channel = MESSAGE_CHANNEL,
            title = "به‌روزرسانی جدید در OurSpace",
            text = text,
            category = NotificationCompat.CATEGORY_STATUS,
            requestCode = 212
        )
    }

    fun showNewMessages(count: Int) {
        // وقتی صفحه گفتگو روی صفحه و در پیش‌زمینه است، نوتیف پیام جدید لازم نیست
        if (isChatScreenActive()) return
        if (count <= 0 || !canNotify()) return
        val text = if (count == 1) {
            "یک پیام خصوصی جدید دارید."
        } else {
            "${PersianDateFormatter.toPersianDigits(count)} پیام خصوصی جدید دارید."
        }
        notify(
            id = MESSAGE_NOTIFICATION_ID,
            channel = MESSAGE_CHANNEL,
            title = "پیام جدید در OurSpace",
            text = text,
            category = NotificationCompat.CATEGORY_MESSAGE,
            requestCode = 200
        )
    }

    fun showSyncActivity(pendingChanges: Int) {
        if (pendingChanges <= 0 || !canNotify()) return
        notify(
            id = SYNC_NOTIFICATION_ID,
            channel = MESSAGE_CHANNEL,
            title = "همگام‌سازی در انتظار",
            text = "${PersianDateFormatter.toPersianDigits(pendingChanges)} تغییر امن منتظر ارسال یا دریافت است.",
            category = NotificationCompat.CATEGORY_STATUS,
            requestCode = 201
        )
    }

    fun showPartnerMoodUpdate() {
        if (!canNotify()) return
        notify(
            id = MOOD_NOTIFICATION_ID,
            channel = MESSAGE_CHANNEL,
            title = "حال امروز همراه",
            text = "حال امروز طرف مقابل به‌روز شد. در فضای «ما» ببینید.",
            category = NotificationCompat.CATEGORY_STATUS,
            requestCode = 202
        )
    }

    fun showUpcomingSpecialDate(title: String, daysUntil: Int, stableId: String = title) {
        if (!canNotify(REMINDER_CHANNEL)) return
        val whenText = when {
            daysUntil <= 0 -> "امروز"
            daysUntil == 1 -> "فردا"
            else -> "${PersianDateFormatter.toPersianDigits(daysUntil)} روز دیگر"
        }
        notify(
            id = stableNotificationId("special:$stableId"),
            channel = REMINDER_CHANNEL,
            title = "مناسبت نزدیک",
            text = "«$title» $whenText. جزئیات فقط داخل برنامه است.",
            category = NotificationCompat.CATEGORY_REMINDER,
            requestCode = stableNotificationId("special:$stableId")
        )
    }

    fun showHabitOrMedicineReminder(kind: String, stableId: String) {
        if (!canNotify()) return
        val isMedicine = kind.equals("MEDICINE", ignoreCase = true)
        val id = 5300 + (stableId.hashCode() and 0x3fffffff) % 100000
        notify(
            id = id,
            channel = REMINDER_CHANNEL,
            title = if (isMedicine) "یادآوری دارو" else "یادآوری عادت",
            text = if (isMedicine) "زمان یادآوری ثبت‌شده رسیده است. جزئیات را داخل برنامه ببین." else "زمان عادت برنامه‌ریزی‌شده رسیده است.",
            category = NotificationCompat.CATEGORY_REMINDER,
            requestCode = id
        )
    }

    fun showTaskReminder(openCount: Int) {
        if (openCount <= 0 || !canNotify()) return
        notify(
            id = TASK_NOTIFICATION_ID,
            channel = REMINDER_CHANNEL,
            title = "کارهای مشترک",
            text = "${PersianDateFormatter.toPersianDigits(openCount)} کار باز باقی مانده است.",
            category = NotificationCompat.CATEGORY_REMINDER,
            requestCode = 204
        )
    }

    fun showBudgetAlert(category: String, percent: Int) {
        if (!canNotify()) return
        notify(
            id = BUDGET_NOTIFICATION_ID,
            channel = REMINDER_CHANNEL,
            title = "هشدار بودجه",
            text = "دسته «$category» به حدود ${PersianDateFormatter.toPersianDigits(percent)}٪ سقف ماهانه رسیده است.",
            category = NotificationCompat.CATEGORY_STATUS,
            requestCode = 206
        )
    }

    fun showHeartAcknowledged() {
        if (!canNotify()) return
        notify(
            id = HEART_ACK_NOTIFICATION_ID,
            channel = HEART_CHANNEL,
            title = "تپش قلب دیده شد 💗",
            text = "طرف مقابل تپش قلبت را دید.",
            category = NotificationCompat.CATEGORY_STATUS,
            requestCode = 207
        )
    }

    /** Partner tapped the heart — "thinking of you". */
    fun showThinkingOfYou() {
        if (!NotificationPreferenceStore.isEnabled(context, NotificationCategory.HEART_PULSES)) return
        playHeartbeatVibration()
        if (!canNotify(HEART_CHANNEL)) return
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            205,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val publicVersion = NotificationCompat.Builder(context, HEART_CHANNEL)
            .setSmallIcon(R.drawable.ic_ourspace)
            .setContentTitle("اعلان جدید در OurSpace")
            .setContentText("برای مشاهده، برنامه را باز کنید.")
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
        val notification = NotificationCompat.Builder(context, HEART_CHANNEL)
            .setSmallIcon(R.drawable.ic_ourspace)
            .setContentTitle("به یاد تو هستم 💗")
            .setContentText("طرف مقابل الان به تو فکر می‌کند.")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setLocalOnly(false)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setVibrate(HEARTBEAT_PATTERN)
            .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
            .extend(
                NotificationCompat.WearableExtender()
                    .setHintShowBackgroundOnly(false)
            )
            .addExtras(Bundle().apply {
                putString(NOTIFICATION_CATEGORY_EXTRA, NotificationCategory.HEART_PULSES.key)
            })
            .build()
        notifyAfterPermissionCheck(
            HEART_NOTIFICATION_ID,
            notification,
            NotificationCategory.HEART_PULSES
        )
    }

    fun playHeartbeatVibration() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(HEARTBEAT_PATTERN, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(HEARTBEAT_PATTERN, -1)
        }
    }


    fun showOverdueTasks(count: Int) {
        if (count <= 0 || !canNotify()) return
        notify(
            id = OVERDUE_TASK_NOTIFICATION_ID,
            channel = REMINDER_CHANNEL,
            title = "کار از مهلت گذشته",
            text = "${PersianDateFormatter.toPersianDigits(count)} کار از موعد گذشته است.",
            category = NotificationCompat.CATEGORY_REMINDER,
            requestCode = 208
        )
    }

    fun showUpcomingEvent(title: String, stableId: String = title) {
        if (!canNotify(REMINDER_CHANNEL)) return
        val id = stableNotificationId("event:$stableId")
        notify(
            id = id,
            channel = REMINDER_CHANNEL,
            title = "قرار نزدیک",
            text = "«${title.take(40)}» در ۲۴ ساعت آینده است.",
            category = NotificationCompat.CATEGORY_EVENT,
            requestCode = id
        )
    }

    fun showMoodReminder() {
        if (!canNotify()) return
        notify(
            id = MOOD_REMINDER_NOTIFICATION_ID,
            channel = REMINDER_CHANNEL,
            title = "حال امروز",
            text = "هنوز حال امروزت را ثبت نکرده‌ای. در فضای «ما» یک لمس کافی است.",
            category = NotificationCompat.CATEGORY_REMINDER,
            requestCode = 210
        )
    }

    fun showCycleReminder(daysUntil: Int) {
        if (!canNotify()) return
        val whenText = when {
            daysUntil <= 0 -> "تقریباً امروز"
            daysUntil == 1 -> "تقریباً فردا"
            else -> "حدود ${PersianDateFormatter.toPersianDigits(daysUntil)} روز دیگر"
        }
        notify(
            id = CYCLE_NOTIFICATION_ID,
            channel = REMINDER_CHANNEL,
            title = "یادآوری چرخه",
            text = "شروع تقریبی دوره بعدی: $whenText. فقط داخل برنامه جزئیات ببینید.",
            category = NotificationCompat.CATEGORY_REMINDER,
            requestCode = 211
        )
    }

    fun showShoppingReminder(count: Int) {
        if (count <= 0 || !canNotify()) return
        notify(
            id = SHOPPING_NOTIFICATION_ID,
            channel = REMINDER_CHANNEL,
            title = "لیست خرید",
            text = "${PersianDateFormatter.toPersianDigits(count)} مورد در لیست خرید مانده است.",
            category = NotificationCompat.CATEGORY_REMINDER,
            requestCode = 212
        )
    }

    private fun notify(
        id: Int,
        channel: String,
        title: String,
        text: String,
        category: String,
        requestCode: Int
    ) {
        val preference = preferenceForNotificationId(id)
        if (!NotificationPreferenceStore.isEnabled(context, preference)) return
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            requestCode,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val publicVersion = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_ourspace)
            .setContentTitle("اعلان جدید در OurSpace")
            .setContentText("برای مشاهده، برنامه را باز کنید.")
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setLocalOnly(false)
            .build()
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_ourspace)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            // هر اعلان جدید باید alert شود تا روی ساعت هم bridge شود
            .setOnlyAlertOnce(false)
            // false = اجازهٔ انتقال به Wear / Galaxy Watch / ساعت‌های جفت‌شده
            .setLocalOnly(false)
            .setCategory(category)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
            .setVibrate(longArrayOf(0, 180, 120, 180))
            .extend(
                NotificationCompat.WearableExtender()
                    .setHintShowBackgroundOnly(false)
            )
            .addExtras(Bundle().apply {
                putString(NOTIFICATION_CATEGORY_EXTRA, preference.key)
            })
            .build()
        if (canNotify(channel)) notifyAfterPermissionCheck(id, notification, preference)
    }

    @SuppressLint("MissingPermission")
    private fun notifyAfterPermissionCheck(
        id: Int,
        notification: android.app.Notification,
        preference: NotificationCategory
    ) {
        if (!NotificationPreferenceStore.isEnabled(context, preference)) return
        runCatching { NotificationManagerCompat.from(context).notify(id, notification) }
    }

    /**
     * Clears user-facing alert notifications when the app is opened.
     * Does not cancel the HostServerService foreground notification.
     */
    fun clearAllUserNotifications() {
        val manager = NotificationManagerCompat.from(context)
        USER_NOTIFICATION_IDS.forEach { id ->
            runCatching { manager.cancel(id) }
        }
    }

    fun canPostReminders(): Boolean =
        NotificationPreferenceStore.isEnabled(context, NotificationCategory.REMINDERS) && canNotify(REMINDER_CHANNEL)

    fun canPostMessages(): Boolean =
        NotificationPreferenceStore.isEnabled(context, NotificationCategory.CHAT_MESSAGES) && canNotify(MESSAGE_CHANNEL)

    private fun canNotify(channelId: String? = null): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        val manager = NotificationManagerCompat.from(context)
        if (!manager.areNotificationsEnabled()) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && channelId != null) {
            val channel = context.getSystemService(NotificationManager::class.java).getNotificationChannel(channelId)
            if (channel == null || channel.importance == NotificationManager.IMPORTANCE_NONE) return false
        }
        return true
    }

    private fun stableNotificationId(key: String): Int = 100_000 + (key.hashCode() and 0x7fffffff) % 1_000_000

    companion object {
        private val legacyNotificationCleanupStarted = AtomicBoolean(false)
        /** صفحه گفتگو باز و resumed است → نوتیف پیام جدید نده / پاک کن */
        private val chatScreenActive = AtomicBoolean(false)

        fun setChatScreenActive(active: Boolean) {
            chatScreenActive.set(active)
        }

        fun isChatScreenActive(): Boolean = chatScreenActive.get()
        private const val NOTIFICATION_CATEGORY_EXTRA = "ourspace_notification_category"
        // شناسه‌های v2 با IMPORTANCE_HIGH برای bridge به ساعت هوشمند
        private const val MESSAGE_CHANNEL = "ourspace_private_updates_v2"
        private const val REMINDER_CHANNEL = "ourspace_reminders_v2"
        private const val HEART_CHANNEL = "ourspace_heart_pulse_v2"
        private val LEGACY_CHANNEL_IDS = arrayOf(
            "ourspace_private_updates",
            "ourspace_reminders",
            "ourspace_heart_pulse"
        )
        private const val MESSAGE_NOTIFICATION_ID = 5201
        private const val REMOTE_CHANGE_NOTIFICATION_ID = 5215
        private const val SYNC_NOTIFICATION_ID = 5202
        private const val MOOD_NOTIFICATION_ID = 5203
        private const val SPECIAL_DATE_NOTIFICATION_ID = 5204
        private const val TASK_NOTIFICATION_ID = 5205
        private const val HEART_NOTIFICATION_ID = 5206
        private const val BUDGET_NOTIFICATION_ID = 5207
        private const val HEART_ACK_NOTIFICATION_ID = 5208
        private const val OVERDUE_TASK_NOTIFICATION_ID = 5209
        private const val EVENT_NOTIFICATION_ID = 5210
        private const val MOOD_REMINDER_NOTIFICATION_ID = 5211
        private const val CYCLE_NOTIFICATION_ID = 5214
        private const val SHOPPING_NOTIFICATION_ID = 5213

        private val USER_NOTIFICATION_IDS = intArrayOf(
            MESSAGE_NOTIFICATION_ID,
            REMOTE_CHANGE_NOTIFICATION_ID,
            SYNC_NOTIFICATION_ID,
            MOOD_NOTIFICATION_ID,
            SPECIAL_DATE_NOTIFICATION_ID,
            TASK_NOTIFICATION_ID,
            HEART_NOTIFICATION_ID,
            BUDGET_NOTIFICATION_ID,
            HEART_ACK_NOTIFICATION_ID,
            OVERDUE_TASK_NOTIFICATION_ID,
            EVENT_NOTIFICATION_ID,
            MOOD_REMINDER_NOTIFICATION_ID,
            CYCLE_NOTIFICATION_ID,
            SHOPPING_NOTIFICATION_ID,
            5212 // legacy id from older builds (cycle/remote collision)
        )

        /** Heartbeat-like pattern (ms): silence, lub, gap, dub, rest, repeat. */
        val HEARTBEAT_PATTERN = longArrayOf(0, 90, 110, 140, 420, 90, 110, 140, 600, 90, 110, 140)
    }
}
