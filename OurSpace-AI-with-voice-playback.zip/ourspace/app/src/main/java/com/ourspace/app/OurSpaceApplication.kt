package com.ourspace.app

import com.ourspace.app.core.ai.AiProtocol
import com.ourspace.app.core.ai.HostAiGateway

import android.app.Application
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.reminder.DailyReminderWorker
import com.ourspace.app.core.server.HostServerService
import com.ourspace.app.core.sync.CompanionSyncWorker
import com.ourspace.app.core.push.FcmTokenRegistrar
import com.ourspace.app.data.OurSpaceRepository
import com.ourspace.app.model.DeviceRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class OurSpaceApplication : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        AiProtocol.appContext = applicationContext
        HostAiGateway.init(applicationContext)
        DailyReminderWorker.schedule(this)
        com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(this)
        // Restart background sync as soon as the process starts (not only when UI opens).
        appScope.launch {
            runCatching {
                val preferences = AppPreferences(this@OurSpaceApplication)
                val role = preferences.currentRole()
                val relayOk = preferences.currentRelayConfig().isUsable
                if (relayOk && (role == DeviceRole.HOST || role == DeviceRole.COMPANION)) {
                    CompanionSyncWorker.schedule(this@OurSpaceApplication)
                    // May be blocked by background FGS limits on some OEMs; WorkManager recovers.
                    runCatching { HostServerService.start(this@OurSpaceApplication) }
                    runCatching { HostServerService.requestImmediateSync(this@OurSpaceApplication) }
                    runCatching { FcmTokenRegistrar.refreshAndUpload(this@OurSpaceApplication) }
                }
            }
        }
    }

    val database: OurSpaceDatabase by lazy { OurSpaceDatabase.getInstance(this) }
    val repository: OurSpaceRepository by lazy {
        OurSpaceRepository(
            database = database,
            taskDao = database.taskDao(),
            eventDao = database.eventDao(),
            shoppingDao = database.shoppingDao(),
            messageDao = database.messageDao(),
            financialAccountDao = database.financialAccountDao(),
            financeTransactionDao = database.financeTransactionDao(),
            financeBudgetDao = database.financeBudgetDao(),
            sharedDebtDao = database.sharedDebtDao(),
            recurringTransactionDao = database.recurringTransactionDao(),
            memoryDao = database.memoryDao(),
            moodCheckInDao = database.moodCheckInDao(),
            specialDateDao = database.specialDateDao(),
            coupleProfileDao = database.coupleProfileDao(),
            cycleLogDao = database.cycleLogDao(),
            cycleSettingsDao = database.cycleSettingsDao(),
            locationShareDao = database.locationShareDao(),
            heartPulseDao = database.heartPulseDao(),
            sharedPlaceDao = database.sharedPlaceDao(),
            habitDao = database.habitDao(),
            watchlistDao = database.watchlistDao(),
            bookDao = database.bookDao(),
            foodDao = database.foodDao(),
            attachmentDao = database.attachmentDao(),
            telegramStickerPackDao = database.telegramStickerPackDao(),
            telegramStickerDao = database.telegramStickerDao()
        )
    }
}
