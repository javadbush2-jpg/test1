package com.ourspace.app

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection.Rtl
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import com.ourspace.app.core.finance.SmsPendingBus
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.security.AppLockGate
import com.ourspace.app.ui.design.OSConfirmDialog
import com.ourspace.app.ui.theme.AppFontFamily
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode
import com.ourspace.app.ui.theme.OurSpaceTheme

class MainActivity : FragmentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* The foreground service remains visible in Android's active-app UI. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        handleSmsDeepLink(intent)
        val preferences = AppPreferences(applicationContext)
        val consentStore = getSharedPreferences("ourspace_consent", MODE_PRIVATE)
        setContent {
            var showNotificationConsent by remember {
                mutableStateOf(
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        !consentStore.getBoolean("notification_prompted", false) &&
                        ContextCompat.checkSelfPermission(this@MainActivity, POST_NOTIFICATIONS_PERMISSION) !=
                        PackageManager.PERMISSION_GRANTED
                )
            }
            val palette by preferences.palette.collectAsState(initial = AppPalette.ROSE)
            val mode by preferences.themeMode.collectAsState(initial = AppThemeMode.SYSTEM)
            val dynamicColor by preferences.dynamicColor.collectAsState(initial = true)
            val fontScale by preferences.fontScale.collectAsState(initial = 1.0f)
            val fontFamily by preferences.fontFamily.collectAsState(initial = AppFontFamily.SANS)
            val darkTheme = when (mode) {
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
                AppThemeMode.LIGHT -> false
                AppThemeMode.DARK -> true
            }
            OurSpaceTheme(
                darkTheme = darkTheme,
                palette = palette,
                dynamicColor = dynamicColor,
                fontScale = fontScale,
                fontFamily = fontFamily
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides Rtl) {
                    AppLockGate {
                        OurSpaceApp()
                        if (showNotificationConsent) {
                            OSConfirmDialog(
                                title = "اعلان‌های خصوصی",
                                message = "برای پیام جدید و تغییرات مهم اعلان دریافت می‌کنید. متن پیام روی صفحه قفل نمایش داده نمی‌شود و این دسترسی بعداً از تنظیمات Android قابل لغو است.",
                                confirmLabel = "فعال‌کردن",
                                dismissLabel = "فعلاً نه",
                                emoji = "🔔",
                                onConfirm = {
                                    consentStore.edit().putBoolean("notification_prompted", true).apply()
                                    showNotificationConsent = false
                                    notificationPermission.launch(POST_NOTIFICATIONS_PERMISSION)
                                },
                                onDismiss = {
                                    consentStore.edit().putBoolean("notification_prompted", true).apply()
                                    showNotificationConsent = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSmsDeepLink(intent)
    }

    /** اعلان تراکنش پیامکی با شناسهٔ مورد لمس شده → مسیریاب داخلی به صفحهٔ مالی. */
    private fun handleSmsDeepLink(intent: android.content.Intent?) {
        val pendingId = intent?.getStringExtra(OurSpaceNotificationCenter.EXTRA_SMS_PENDING_ID)
        if (!pendingId.isNullOrBlank()) {
            SmsPendingBus.request(pendingId)
        }
    }

    private companion object {
        const val POST_NOTIFICATIONS_PERMISSION = "android.permission.POST_NOTIFICATIONS"
    }
}
