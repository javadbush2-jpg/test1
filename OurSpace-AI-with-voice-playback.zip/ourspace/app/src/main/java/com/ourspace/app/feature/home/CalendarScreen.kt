package com.ourspace.app.feature.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.roundToInt
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.Mood
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.cycle.CycleCalendarDisplay
import com.ourspace.app.core.database.*
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.preferences.CalendarVisibilityCategory
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import com.ourspace.app.ui.design.OSFormDialog
import com.ourspace.app.ui.design.OsTimePickerField
import com.ourspace.app.ui.design.OsDurationPickerField
import java.util.Calendar

private enum class CalendarCreateType(val label: String) {
    TASK("کار جدید"),
    EVENT("قرار یا برنامه"),
    HABIT("عادت یا یادآور"),
    MEMORY("خاطره مشترک"),
    OCCASION("مناسبت"),
    FINANCE("تراکنش مالی"),
    MOOD("ثبت حال روز")
}

/** رویداد شغلی تولیدشده از پروفایل کار (شیفتی یا اداری) */
private fun isOsWorkEvent(details: String?): Boolean =
    details.orEmpty().startsWith("OS_WORK|")

/** فقط شغل شیفتی — برای نشانگر ماه و لیست روز */
private fun isShiftWorkEvent(title: String, details: String?): Boolean {
    if (!isOsWorkEvent(details)) return false
    return title.contains("شیفت")
}

@Composable
private fun CalendarLegendItem(emoji: String, label: String, color: Color = Color.Transparent) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(emoji, style = MaterialTheme.typography.bodyMedium)
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(
    focusDayKey: String? = null,
    focusItemId: String? = null,
    onFocusConsumed: () -> Unit = {},

    tasks: List<TaskEntity>, events: List<EventEntity>, shoppingItems: List<ShoppingItemEntity>,
    messages: List<MessageEntity>, attachments: List<AttachmentEntity>, financeTransactions: List<FinanceTransactionEntity>,
    financialAccounts: List<FinancialAccountEntity>, onAddFinanceTransactionAt: (String, String?, String, Long, String, String, Long, String) -> Unit,
    sharedDebts: List<SharedDebtEntity>, recurringTransactions: List<RecurringTransactionEntity>, habits: List<HabitEntity> = emptyList(), memories: List<MemoryEntity>,
    moodCheckIns: List<MoodCheckInEntity>, specialDates: List<SpecialDateEntity>, cycleLogs: List<CycleLogEntity>,
    cycleSettings: CycleSettingsEntity?, onAddTask: (String, Int, String, Long?) -> Unit,
    onAddTimedTask: (String, Int, String, Long?, Int) -> Unit = { title, priority, assignee, dueAt, _ -> onAddTask(title, priority, assignee, dueAt) },
    onToggleTask: (TaskEntity) -> Unit, onDeleteTask: (TaskEntity) -> Unit,
    onUpdateTaskSchedule: (TaskEntity, Long, Int) -> Unit = { _, _, _ -> },
    onAddEvent: (String, Long) -> Unit, onDeleteEvent: (EventEntity) -> Unit,
    onAddTimedEvent: (String, Long, Int) -> Unit = { title, at, _ -> onAddEvent(title, at) },
    onUpdateEventSchedule: (EventEntity, Long, Long) -> Unit = { _, _, _ -> },
    onAddHabit: (
        title: String,
        kind: String,
        scheduleNote: String,
        note: String,
        frequency: String,
        timesPerWeek: Int,
        timesPerDay: Int,
        weekDays: String,
        priority: String
    ) -> Unit = { _, _, _, _, _, _, _, _, _ -> },
    onAddMemory: (String, String, String, Long) -> Unit, onToggleMemoryFavorite: (MemoryEntity) -> Unit,
    onDeleteMemory: (MemoryEntity) -> Unit, onAddSpecialDate: (String, String, Long, Boolean) -> Unit,
    onSetDailyMood: (String, String, String) -> Unit, onToggleShopping: (ShoppingItemEntity) -> Unit,
    onOpenPlanner: () -> Unit = {}, onOpenFinance: () -> Unit = {}, onOpenChat: () -> Unit = {}, onOpenMemories: () -> Unit = {}
) {
    val todayJ = remember { PersianDateFormatter.jalaliDate(System.currentTimeMillis()) }
    var monthOffset by remember { mutableIntStateOf(0) }
    val shownMonth = remember(monthOffset, todayJ) {
        val absolute = todayJ.year * 12 + todayJ.month - 1 + monthOffset
        (Math.floorDiv(absolute, 12)) to (Math.floorMod(absolute, 12) + 1)
    }
    val year = shownMonth.first
    val month = shownMonth.second
    val days = PersianDateFormatter.daysInJalaliMonth(year, month)
    val firstDayEpoch = remember(year, month) { PersianDateFormatter.toEpochMillis(year, month, 1, 12) }
    val firstDow = remember(firstDayEpoch) { Calendar.getInstance().apply { timeInMillis = firstDayEpoch }.get(Calendar.DAY_OF_WEEK) % 7 } // Saturday-first: Sat=0 … Fri=6
    var selectedEpoch by remember { mutableLongStateOf(dayStart(System.currentTimeMillis())) }
    LaunchedEffect(focusDayKey) {
        val key = focusDayKey?.takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        // dayKey format typically yyyy-MM-dd jalali
        val parts = key.split("-").mapNotNull { it.toIntOrNull() }
        if (parts.size >= 3) {
            val (y, m, d) = parts
            selectedEpoch = dayStart(PersianDateFormatter.toEpochMillis(y, m, d, 12))
            // همگام ماه
            val todayJ = PersianDateFormatter.jalaliDate(System.currentTimeMillis())
            monthOffset = (y * 12 + m) - (todayJ.year * 12 + todayJ.month)
        }
        onFocusConsumed()
    }
    var createType by remember { mutableStateOf<CalendarCreateType?>(null) }
    var showCreatePicker by remember { mutableStateOf(false) }
    var showDayHours by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("LOVE") }
    var repeatYearly by remember { mutableStateOf(true) }
    var financeAmount by remember { mutableStateOf("") }
    var financeCategory by remember { mutableStateOf("سایر") }
    var financeKind by remember { mutableStateOf("EXPENSE") }
    var selectedHour by remember { mutableIntStateOf(12) }
    var selectedMinute by remember { mutableIntStateOf(0) }
    var selectedDuration by remember { mutableIntStateOf(60) }
    var financeAccountId by remember(financialAccounts) { mutableStateOf(financialAccounts.firstOrNull { !it.isDeleted && !it.isArchived }?.id.orEmpty()) }
    val selectedJ = PersianDateFormatter.jalaliDate(selectedEpoch)
    val selectedKey = PersianDateFormatter.jalaliDayKey(selectedEpoch)
    val selectedEnd = dayEnd(selectedEpoch)
    val context = LocalContext.current
    val prefs = remember(context) { AppPreferences(context) }
    val visibleCategories by prefs.calendarVisibleCategories.collectAsState(initial = CalendarVisibilityCategory.ALL_IDS)
    val scope = rememberCoroutineScope()
    var showVisibilityDialog by remember { mutableStateOf(false) }
    fun isCat(id: String) = id in visibleCategories

    val dayTasksRaw = tasks.filter { !it.isDeleted && it.dueAt != null && it.dueAt!! in selectedEpoch..selectedEnd }.sortedBy { it.dueAt }
    val dayEventsRaw = events.filter { !it.isDeleted && !isOsWorkEvent(it.details) && it.startAt in selectedEpoch..selectedEnd }.sortedBy { it.startAt }
    val dayAllWorkEvents = events.filter { event ->
        !event.isDeleted &&
            isOsWorkEvent(event.details) &&
            event.startAt in selectedEpoch..selectedEnd
    }.sortedBy { it.startAt }
    val dayShiftEventsRaw = dayAllWorkEvents.filter { isShiftWorkEvent(it.title, it.details) }
    val dayOfficeEventsRaw = dayAllWorkEvents.filter { !isShiftWorkEvent(it.title, it.details) }
    val dayMemoriesRaw = memories.filter { !it.isDeleted && it.occurredAt in selectedEpoch..selectedEnd }.sortedBy { it.occurredAt }
    val daySpecialsRaw = specialDates.filter { item ->
        if (item.isDeleted) false else {
            val j = PersianDateFormatter.jalaliDate(item.occurredAt)
            j.month == selectedJ.month && j.day == selectedJ.day && (item.repeatYearly || j.year == selectedJ.year)
        }
    }
    val dayFinanceRaw = financeTransactions.filter { !it.isDeleted && it.occurredAt in selectedEpoch..selectedEnd }.sortedBy { it.occurredAt }
    val dayDebtsRaw = sharedDebts.filter { !it.isDeleted && it.settledAt == null && it.dueAt != null && it.dueAt!! in selectedEpoch..selectedEnd }
    val dayRecurringRaw = recurringTransactions.filter { !it.isDeleted && it.isActive && it.nextRunAt in selectedEpoch..selectedEnd }
    val dayMoodsRaw = moodCheckIns.filter { !it.isDeleted && it.dayKey == selectedKey }

    // فیلتر «نمایش موارد» فقط روی خود گرید تقویم (نشانگر روزها و راهنما) اعمال می‌شود.
    // برنامهٔ ساعتی و فهرست روز انتخاب‌شده همیشه همهٔ موارد آن روز را نشان می‌دهند.
    val dayTasks = dayTasksRaw
    val dayEvents = dayEventsRaw
    val dayShiftEvents = dayShiftEventsRaw
    val dayOfficeEvents = dayOfficeEventsRaw
    val dayMemories = dayMemoriesRaw
    val daySpecials = daySpecialsRaw
    val dayFinance = dayFinanceRaw
    val dayDebts = dayDebtsRaw
    val dayRecurring = dayRecurringRaw
    val dayMoods = dayMoodsRaw

    // Cycle estimates are day-based, so keep this key stable during the day for month-count memoization.
    val calendarNow = dayStart(System.currentTimeMillis())
    val predictedPeriod = CycleCalendarDisplay.predictedNextPeriod(cycleLogs, cycleSettings, calendarNow)
    val dayPeriodsRaw = cycleLogs.filter {
        CycleCalendarDisplay.isActualPeriodOn(it, selectedEpoch, selectedEnd, calendarNow)
    }
    val dayPeriods = dayPeriodsRaw
    val predictedPeriodOnSelectedDay = dayPeriods.isEmpty() &&
        predictedPeriod?.overlaps(selectedEpoch, selectedEnd) == true
    val openShopping = shoppingItems.filter { !it.isDeleted && !it.isChecked }
    val dayHabitsVisible = true
    val dayCount = dayTasks.size + dayEvents.size + dayShiftEvents.size + dayOfficeEvents.size +
        dayMemories.size + daySpecials.size + dayFinance.size + dayDebts.size + dayRecurring.size +
        dayMoods.size + dayPeriods.size +
        (if (dayHabitsVisible) habits.count { !it.isDeleted } else 0) +
        (if (predictedPeriodOnSelectedDay) 1 else 0)
    val monthCount = remember(
        tasks, events, memories, specialDates, financeTransactions, moodCheckIns,
        sharedDebts, recurringTransactions, habits, cycleLogs, cycleSettings, predictedPeriod,
        calendarNow, year, month, visibleCategories
    ) {
        val matches = { timestamp: Long -> val d = PersianDateFormatter.jalaliDate(timestamp); d.year == year && d.month == month }
        var total = 0
        if (CalendarVisibilityCategory.TASKS.id in visibleCategories) {
            total += tasks.count { !it.isDeleted && it.dueAt != null && matches(it.dueAt!!) }
        }
        if (CalendarVisibilityCategory.EVENTS.id in visibleCategories) {
            total += events.count { !it.isDeleted && !isOsWorkEvent(it.details) && matches(it.startAt) }
        }
        if (CalendarVisibilityCategory.WORK_SHIFT.id in visibleCategories) {
            total += events.count { !it.isDeleted && isShiftWorkEvent(it.title, it.details) && matches(it.startAt) }
        }
        if (CalendarVisibilityCategory.WORK_OFFICE.id in visibleCategories) {
            total += events.count { !it.isDeleted && isOsWorkEvent(it.details) && !isShiftWorkEvent(it.title, it.details) && matches(it.startAt) }
        }
        if (CalendarVisibilityCategory.MEMORIES.id in visibleCategories) {
            total += memories.count { !it.isDeleted && matches(it.occurredAt) }
        }
        if (CalendarVisibilityCategory.OCCASIONS.id in visibleCategories) {
            total += specialDates.count { item ->
                !item.isDeleted && runCatching {
                    val d = PersianDateFormatter.jalaliDate(item.occurredAt)
                    d.month == month && (item.repeatYearly || d.year == year)
                }.getOrDefault(false)
            }
        }
        if (CalendarVisibilityCategory.FINANCE.id in visibleCategories) {
            total += financeTransactions.count { !it.isDeleted && matches(it.occurredAt) }
        }
        if (CalendarVisibilityCategory.MOOD.id in visibleCategories) {
            total += moodCheckIns.count {
                !it.isDeleted && it.dayKey.startsWith("$year-${month.toString().padStart(2, '0')}")
            }
        }
        if (CalendarVisibilityCategory.DEBTS.id in visibleCategories) {
            total += sharedDebts.count { !it.isDeleted && it.settledAt == null && it.dueAt != null && matches(it.dueAt!!) }
        }
        if (CalendarVisibilityCategory.RECURRING.id in visibleCategories) {
            total += recurringTransactions.count { !it.isDeleted && it.isActive && matches(it.nextRunAt) }
        }
        if (CalendarVisibilityCategory.HABITS.id in visibleCategories) {
            total += habits.count { !it.isDeleted }
        }
        if (CalendarVisibilityCategory.CYCLE.id in visibleCategories) {
            total += (1..PersianDateFormatter.daysInJalaliMonth(year, month)).count { d ->
                val start = PersianDateFormatter.toEpochMillis(year, month, d, 0)
                val end = dayEnd(start)
                val actualPeriod = cycleLogs.any { CycleCalendarDisplay.isActualPeriodOn(it, start, end, calendarNow) }
                actualPeriod || predictedPeriod?.overlaps(start, end) == true
            }
        }
        total
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary))).padding(20.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Outlined.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(32.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("تقویم مشترک ما", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                    Text("همه اتفاق‌های مهم، در یک نگاه", color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                HeroStat("رویدادهای ماه", PersianDateFormatter.toPersianDigits(monthCount), Modifier.weight(1f))
                                HeroStat("روز انتخابی", PersianDateFormatter.toPersianDigits(dayCount), Modifier.weight(1f))
                                HeroStat("خریدهای باز", PersianDateFormatter.toPersianDigits(openShopping.size), Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.10f),
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
                            )
                        )
                    )
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            IconButton(onClick = { val nextOffset = monthOffset - 1; val absolute = todayJ.year * 12 + todayJ.month - 1 + nextOffset; val y = Math.floorDiv(absolute, 12); val m = Math.floorMod(absolute, 12) + 1; monthOffset = nextOffset; selectedEpoch = dayStart(PersianDateFormatter.toEpochMillis(y, m, 1, 12)) }) { Text("‹", style = MaterialTheme.typography.headlineMedium) }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${PersianDateFormatter.jalaliMonthName(month)} ${PersianDateFormatter.toPersianDigits(year)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                                TextButton(onClick = { monthOffset = 0; selectedEpoch = dayStart(System.currentTimeMillis()) }) { Text("رفتن به امروز") }
                            }
                            IconButton(onClick = { val nextOffset = monthOffset + 1; val absolute = todayJ.year * 12 + todayJ.month - 1 + nextOffset; val y = Math.floorDiv(absolute, 12); val m = Math.floorMod(absolute, 12) + 1; monthOffset = nextOffset; selectedEpoch = dayStart(PersianDateFormatter.toEpochMillis(y, m, 1, 12)) }) { Text("›", style = MaterialTheme.typography.headlineMedium) }
                        }
                        // هدر و سلول‌ها با یک Arrangement تا ستون‌ها دقیقاً زیر هم باشند
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEach { label ->
                                Text(
                                    label,
                                    modifier = Modifier.weight(1f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        repeat(6) { week ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                repeat(7) { col ->
                                    val day = week * 7 + col - firstDow + 1
                                    if (day in 1..days) {
                                        val epoch = dayStart(PersianDateFormatter.toEpochMillis(year, month, day, 12))
                                        val end = dayEnd(epoch)
                                        val isToday = PersianDateFormatter.jalaliDayKey(epoch) == PersianDateFormatter.currentJalaliDayKey()
                                        val hasTask = isCat(CalendarVisibilityCategory.TASKS.id) &&
                                            tasks.any { !it.isDeleted && it.dueAt != null && it.dueAt!! in epoch..end }
                                        val hasEvent = isCat(CalendarVisibilityCategory.EVENTS.id) &&
                                            events.any { !it.isDeleted && !isOsWorkEvent(it.details) && it.startAt in epoch..end }
                                        val hasShift = isCat(CalendarVisibilityCategory.WORK_SHIFT.id) &&
                                            events.any { e -> !e.isDeleted && isShiftWorkEvent(e.title, e.details) && e.startAt in epoch..end }
                                        val hasOffice = isCat(CalendarVisibilityCategory.WORK_OFFICE.id) &&
                                            events.any { e -> !e.isDeleted && isOsWorkEvent(e.details) && !isShiftWorkEvent(e.title, e.details) && e.startAt in epoch..end }
                                        val hasMemory = isCat(CalendarVisibilityCategory.MEMORIES.id) &&
                                            memories.any { !it.isDeleted && it.occurredAt in epoch..end }
                                        val hasSpecial = isCat(CalendarVisibilityCategory.OCCASIONS.id) &&
                                            specialDates.any { sd ->
                                                !sd.isDeleted && runCatching {
                                                    val j = PersianDateFormatter.jalaliDate(sd.occurredAt)
                                                    j.month == month && j.day == day && (sd.repeatYearly || j.year == year)
                                                }.getOrDefault(false)
                                            }
                                        val hasMood = isCat(CalendarVisibilityCategory.MOOD.id) &&
                                            moodCheckIns.any { !it.isDeleted && it.dayKey == PersianDateFormatter.jalaliDayKey(epoch) }
                                        val hasFinance = isCat(CalendarVisibilityCategory.FINANCE.id) &&
                                            financeTransactions.any { !it.isDeleted && it.occurredAt in epoch..end }
                                        val hasActualCycle = isCat(CalendarVisibilityCategory.CYCLE.id) && cycleLogs.any {
                                            CycleCalendarDisplay.isActualPeriodOn(it, epoch, end, calendarNow)
                                        }
                                        val hasPredictedCycle = isCat(CalendarVisibilityCategory.CYCLE.id) && !hasActualCycle && predictedPeriod?.overlaps(epoch, end) == true
                                        val active = PersianDateFormatter.jalaliDayKey(epoch) == selectedKey
                                        val markerPairs = buildList {
                                            if (hasTask) add(Color(0xFF3984F5) to "✓")
                                            if (hasEvent) add(Color(0xFFFF9F43) to "📅")
                                            if (hasShift) add(Color(0xFF5C6BC0) to "🔧")
                                            if (hasOffice) add(Color(0xFF00897B) to "💼")
                                            if (hasMemory) add(Color(0xFF9B59D0) to "📷")
                                            if (hasSpecial) add(Color(0xFFE84A8A) to "🎉")
                                            if (hasMood) add(Color(0xFFE0B323) to "🙂")
                                            if (hasFinance) add(Color(0xFF26A69A) to "💰")
                                            if (hasActualCycle) add(Color(0xFFDB6BC4) to "🌸")
                                            else if (hasPredictedCycle) add(Color(0xFFE9A4D8) to "🌸")
                                        }
                                        com.ourspace.app.ui.components.CalendarDayCell(
                                            dayNumber = PersianDateFormatter.toPersianDigits(day),
                                            isSelected = active,
                                            isToday = isToday,
                                            isCurrentMonth = true,
                                            markerColors = markerPairs.map { it.first },
                                            markerEmojis = markerPairs.map { it.second },
                                            modifier = Modifier.weight(1f).height(58.dp),
                                            onClick = { selectedEpoch = epoch }
                                        )
                                    } else Spacer(Modifier.weight(1f).height(58.dp))
                                }
                            }
                            Spacer(Modifier.height(5.dp))
                        }
                        Spacer(Modifier.height(4.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "راهنمای اموجی‌ها",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "هر اموجی زیر تاریخ یعنی در آن روز این مورد ثبت شده است.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (isCat(CalendarVisibilityCategory.TASKS.id)) CalendarLegendItem("✓", "کارها")
                                if (isCat(CalendarVisibilityCategory.EVENTS.id)) CalendarLegendItem("📅", "قرارها")
                                if (isCat(CalendarVisibilityCategory.WORK_SHIFT.id)) CalendarLegendItem("🔧", "شیفت کاری")
                                if (isCat(CalendarVisibilityCategory.WORK_OFFICE.id)) CalendarLegendItem("💼", "کار اداری")
                                if (isCat(CalendarVisibilityCategory.MEMORIES.id)) CalendarLegendItem("📷", "خاطرات")
                                if (isCat(CalendarVisibilityCategory.OCCASIONS.id)) CalendarLegendItem("🎉", "مناسبت")
                            }
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (isCat(CalendarVisibilityCategory.MOOD.id)) CalendarLegendItem("🙂", "حال‌وهوا")
                                if (isCat(CalendarVisibilityCategory.FINANCE.id)) CalendarLegendItem("💰", "مالی")
                                if (isCat(CalendarVisibilityCategory.CYCLE.id)) CalendarLegendItem("🌸", "قاعدگی (ثبت‌شده)")
                                if (predictedPeriod != null) {
                                    CalendarLegendItem(
                                        "🌸",
                                        "پیش‌بینی ${PersianDateFormatter.toPersianDigits(predictedPeriod.displayDays)}روزه"
                                    )
                                }
                            }
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(PersianDateFormatter.formatDate(selectedEpoch), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text(if (dayCount == 0) "برای این روز هنوز چیزی ثبت نشده" else "${PersianDateFormatter.toPersianDigits(dayCount)} مورد در این روز", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(onClick = { showVisibilityDialog = true }) {
                            Icon(Icons.Outlined.Visibility, null)
                            Spacer(Modifier.width(4.dp))
                            Text("نمایش")
                        }
                        FilledTonalButton(onClick = { showCreatePicker = true }) {
                            Icon(Icons.Outlined.Add, null)
                            Spacer(Modifier.width(4.dp))
                            Text("ثبت مورد")
                        }
                    }
                }
            }
            item {
                DayHourTimeline(
                    expanded = showDayHours,
                    onToggle = { showDayHours = !showDayHours },
                    selectedEpoch = selectedEpoch,
                    tasks = dayTasks,
                    // نمای ساعتی: همهٔ موارد روز (مستقل از فیلتر نمایش تقویم)
                    events = (dayEvents + dayShiftEvents + dayOfficeEvents).distinctBy { it.id }.sortedBy { it.startAt },
                    habits = habits.filter { !it.isDeleted },
                    onMoveTask = onUpdateTaskSchedule,
                    onMoveEvent = onUpdateEventSchedule,
                    onHourClick = { hour ->
                        selectedHour = hour
                        selectedMinute = 0
                        showCreatePicker = true
                    }
                )
            }
            if (dayTasks.isNotEmpty()) item { SectionHeading("کارها", Icons.Outlined.TaskAlt, dayTasks.size) }
            items(dayTasks, key = { "task-${it.id}" }) { task -> CalendarEntry(task.title, task.note.ifBlank { if (task.isCompleted) "انجام‌شده" else "شروع: ${task.dueAt?.let(PersianDateFormatter::formatTime) ?: "—"} · مدت: ${PersianDateFormatter.toPersianDigits(task.durationMinutes.toString())} دقیقه" }, Icons.Outlined.CheckCircle, MaterialTheme.colorScheme.primaryContainer, trailing = { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(task.isCompleted, onCheckedChange = { onToggleTask(task) }); IconButton(onClick = { onDeleteTask(task) }) { Icon(Icons.Outlined.DeleteOutline, "حذف کار") } } }) }
            if (dayEvents.isNotEmpty()) item { SectionHeading("قرارها و برنامه‌ها", Icons.Outlined.Event, dayEvents.size) }
            items(dayEvents, key = { "event-${it.id}" }) { event -> CalendarEntry(event.title, listOf("${PersianDateFormatter.formatTime(event.startAt)} تا ${PersianDateFormatter.formatTime(event.endAt ?: (event.startAt + 60L * 60_000L))}", event.details.orEmpty().takeUnless { it.startsWith("OS_WORK|") }).filterNotNull().filter { it.isNotBlank() }.joinToString(" · "), Icons.Outlined.Event, MaterialTheme.colorScheme.secondaryContainer, trailing = { IconButton(onClick = { onDeleteEvent(event) }) { Icon(Icons.Outlined.DeleteOutline, "حذف قرار") } }) }
            if (dayShiftEvents.isNotEmpty()) item { SectionHeading("شیفت شغلی", Icons.Outlined.Schedule, dayShiftEvents.size) }
            items(dayShiftEvents, key = { "work-shift-${it.id}" }) { event ->
                CalendarEntry(
                    event.title,
                    "${PersianDateFormatter.formatTime(event.startAt)} تا ${PersianDateFormatter.formatTime(event.endAt ?: (event.startAt + 60L * 60_000L))}",
                    Icons.Outlined.Schedule,
                    MaterialTheme.colorScheme.primaryContainer,
                    trailing = {
                        IconButton(onClick = { onDeleteEvent(event) }) {
                            Icon(Icons.Outlined.DeleteOutline, "حذف نوبت کاری")
                        }
                    }
                )
            }
            if (dayOfficeEvents.isNotEmpty()) item { SectionHeading("ساعت اداری", Icons.Outlined.Schedule, dayOfficeEvents.size) }
            items(dayOfficeEvents, key = { "work-office-${it.id}" }) { event ->
                CalendarEntry(
                    event.title,
                    "${PersianDateFormatter.formatTime(event.startAt)} تا ${PersianDateFormatter.formatTime(event.endAt ?: (event.startAt + 60L * 60_000L))}",
                    Icons.Outlined.Schedule,
                    MaterialTheme.colorScheme.tertiaryContainer,
                    trailing = {
                        IconButton(onClick = { onDeleteEvent(event) }) {
                            Icon(Icons.Outlined.DeleteOutline, "حذف نوبت کاری")
                        }
                    }
                )
            }
            if (dayMemories.isNotEmpty()) item { SectionHeading("خاطرات مشترک", Icons.Outlined.PhotoLibrary, dayMemories.size) }
            items(dayMemories, key = { "memory-${it.id}" }) { memory ->
                CalendarEntry(
                    memory.title,
                    listOf(memory.note, attachments.count { !it.isDeleted && it.memoryId == memory.id }.let { if (it > 0) "${PersianDateFormatter.toPersianDigits(it)} پیوست" else "" }).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "خاطره ثبت‌شده در این روز" },
                    Icons.Outlined.Favorite,
                    MaterialTheme.colorScheme.tertiaryContainer,
                    trailing = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { onToggleMemoryFavorite(memory) }) {
                                Icon(Icons.Outlined.Favorite, "علاقه‌مندی", tint = if (memory.isFavorite) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { onDeleteMemory(memory) }) {
                                Icon(Icons.Outlined.DeleteOutline, "حذف خاطره")
                            }
                        }
                    }
                )
            }
            if (daySpecials.isNotEmpty()) item { SectionHeading("مناسبت‌ها", Icons.Outlined.CalendarMonth, daySpecials.size) }
            items(daySpecials, key = { "special-${it.id}" }) { date ->
                CalendarEntry(
                    date.title,
                    date.note.orEmpty().ifBlank { if (date.repeatYearly) "تکرار سالانه" else "مناسبت ثبت‌شده" },
                    Icons.Outlined.CalendarMonth,
                    MaterialTheme.colorScheme.primaryContainer
                )
            }
            if (dayFinance.isNotEmpty()) item { SectionHeading("امور مالی", Icons.Outlined.Payments, dayFinance.size) }
            items(dayFinance, key = { "finance-${it.id}" }) { tx ->
                CalendarEntry(
                    tx.category,
                    "${tx.kind} · ${PersianDateFormatter.formatMoney(tx.amount)}${if (tx.note.isBlank()) "" else " · ${tx.note}"}",
                    Icons.Outlined.Payments,
                    MaterialTheme.colorScheme.secondaryContainer
                )
            }
            if (dayDebts.isNotEmpty()) item { SectionHeading("سررسید بدهی‌ها", Icons.Outlined.Payments, dayDebts.size) }
            items(dayDebts, key = { "debt-${it.id}" }) { debt ->
                CalendarEntry(
                    debt.title,
                    "سررسید · ${PersianDateFormatter.formatMoney(debt.amount)}${if (debt.note.isBlank()) "" else " · ${debt.note}"}",
                    Icons.Outlined.Payments,
                    MaterialTheme.colorScheme.errorContainer
                )
            }
            if (dayRecurring.isNotEmpty()) item { SectionHeading("پرداخت‌های دوره‌ای", Icons.Outlined.Payments, dayRecurring.size) }
            items(dayRecurring, key = { "recurring-${it.id}" }) { item ->
                CalendarEntry(
                    item.category,
                    "پرداخت برنامه‌ریزی‌شده · ${PersianDateFormatter.formatMoney(item.amount)}${if (item.note.isBlank()) "" else " · ${item.note}"}",
                    Icons.Outlined.Payments,
                    MaterialTheme.colorScheme.secondaryContainer
                )
            }
            if (dayMoods.isNotEmpty()) item { SectionHeading("حال‌وهوای ثبت‌شده", Icons.Outlined.Mood, dayMoods.size) }
            items(dayMoods, key = { "mood-${it.id}" }) { item ->
                CalendarEntry(
                    moodLabel(item.mood),
                    item.note.ifBlank { "ثبت حال روزانه" },
                    Icons.Outlined.Mood,
                    MaterialTheme.colorScheme.tertiaryContainer
                )
            }
            val activeHabits = habits.filter { !it.isDeleted }
            if (activeHabits.isNotEmpty()) item { SectionHeading("عادات و یادآورها", Icons.Outlined.CheckCircle, activeHabits.size) }
            items(activeHabits, key = { "habit-${it.id}" }) { habit -> CalendarEntry(habit.title, listOf(habit.scheduleNote, habit.note).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "برنامه تکرارشونده" } + if (selectedKey == PersianDateFormatter.currentJalaliDayKey() && habit.lastCompletedDayKey == selectedKey) " · امروز انجام شد" else "", Icons.Outlined.CheckCircle, MaterialTheme.colorScheme.surfaceVariant) }
            if (dayPeriods.isNotEmpty()) item { SectionHeading("قاعدگی ثبت‌شده", Icons.Outlined.Favorite, dayPeriods.size) }
            items(dayPeriods, key = { "cycle-${it.id}" }) { log -> CalendarEntry("دوره ثبت‌شده", log.note.ifBlank { "شدت: ${log.flowLevel}" }, Icons.Outlined.Favorite, MaterialTheme.colorScheme.errorContainer) }
            if (predictedPeriodOnSelectedDay) item {
                CalendarEntry(
                    "پیش‌بینی دورهٔ بعد",
                    "شروع تقریبی: ${predictedPeriod?.let { PersianDateFormatter.formatDate(it.startAt) } ?: "—"} · فقط ${PersianDateFormatter.toPersianDigits(predictedPeriod?.displayDays ?: 3)} روز اول پیش‌بینی نمایش داده می‌شود.",
                    Icons.Outlined.Favorite,
                    MaterialTheme.colorScheme.tertiaryContainer
                )
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("دسترسی سریع به بخش‌ها", fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = onOpenPlanner, label = { Text("کارها و خرید") }, leadingIcon = { Icon(Icons.Outlined.ShoppingCart, null) })
                            AssistChip(onClick = onOpenFinance, label = { Text("مالی") }, leadingIcon = { Icon(Icons.Outlined.Payments, null) })
                            AssistChip(onClick = onOpenChat, label = { Text("گفتگو") }, leadingIcon = { Icon(Icons.Outlined.ChatBubbleOutline, null) })
                            AssistChip(onClick = onOpenMemories, label = { Text("ما و خاطرات") }, leadingIcon = { Icon(Icons.Outlined.Favorite, null) })
                        }
                        if (openShopping.isNotEmpty()) {
                            Text("خریدهای باز (بدون تاریخ مشخص)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            openShopping.take(5).forEach { item ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = item.isChecked, onCheckedChange = { onToggleShopping(item) })
                                    Text(item.title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                    Text(item.quantity, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }


    if (showVisibilityDialog) {
        OSFormDialog(
            title = "نمایش موارد تقویم",
            emoji = "👁️",
            onDismiss = { showVisibilityDialog = false },
            onConfirm = { showVisibilityDialog = false },
            confirmLabel = "بستن",
            showDismissButton = false
        ) {
            Text(
                "هر موردی که خاموش باشد، در نشانگرها، لیست روز و شمارنده‌ها دیده نمی‌شود. ثبت مورد همچنان ممکن است.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    scope.launch { prefs.setCalendarVisibleCategories(CalendarVisibilityCategory.ALL_IDS) }
                }) { Text("همه") }
                TextButton(onClick = {
                    scope.launch {
                        prefs.setCalendarVisibleCategories(setOf(CalendarVisibilityCategory.TASKS.id, CalendarVisibilityCategory.EVENTS.id))
                    }
                }) { Text("حداقلی") }
            }
            CalendarVisibilityCategory.entries.forEach { category ->
                val checked = category.id in visibleCategories
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            scope.launch { prefs.setCalendarCategoryVisible(category.id, !checked) }
                        }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (checked) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                        contentDescription = null,
                        tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(category.label, modifier = Modifier.weight(1f))
                    Switch(
                        checked = checked,
                        onCheckedChange = { on ->
                            scope.launch { prefs.setCalendarCategoryVisible(category.id, on) }
                        }
                    )
                }
            }
        }
    }

    if (showCreatePicker) {
        OSFormDialog(
            title = "برای ${PersianDateFormatter.formatDate(selectedEpoch)} چه چیزی ثبت کنیم؟",
            emoji = "✨",
            onDismiss = { showCreatePicker = false },
            onConfirm = { showCreatePicker = false },
            confirmLabel = "بستن",
            showDismissButton = false
        ) {
                    CalendarCreateType.entries.forEach { type ->
                        OutlinedButton(
                            onClick = { createType = type; showCreatePicker = false; title = ""; note = ""; financeAmount = ""; selectedDuration = 60 },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text(type.label, modifier = Modifier.fillMaxWidth()) }
                    }
        }
    }

    if (createType != null) {
        val type = createType!!
        OSFormDialog(
            title = type.label,
            emoji = "📝",
            onDismiss = { createType = null },
            onConfirm = {
                val timed = dayAtTime(selectedEpoch, selectedHour, selectedMinute)
            when (type) {
                CalendarCreateType.TASK -> if (title.isNotBlank()) onAddTimedTask(title.trim(), 1, "مشترک", timed, selectedDuration)
                CalendarCreateType.EVENT -> if (title.isNotBlank()) onAddTimedEvent(title.trim(), timed, selectedDuration)
                CalendarCreateType.HABIT -> if (title.isNotBlank()) {
                    val schedule = "ساعت ${selectedHour.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}"
                    onAddHabit(
                        title.trim(),
                        "HABIT",
                        schedule,
                        note.trim(),
                        "DAILY",
                        7,
                        1,
                        "",
                        "NORMAL"
                    )
                }
                CalendarCreateType.MEMORY -> if (title.isNotBlank()) onAddMemory(title.trim(), note.trim(), mood, selectedEpoch)
                CalendarCreateType.OCCASION -> if (title.isNotBlank()) onAddSpecialDate(title.trim(), note.trim(), selectedEpoch, repeatYearly)
                CalendarCreateType.FINANCE -> {
                    val amount = financeAmount.toLongOrNull() ?: 0L
                    if (amount > 0 && financeAccountId.isNotBlank()) {
                        onAddFinanceTransactionAt(financeAccountId, null, financeKind, amount, financeCategory.ifBlank { "سایر" }, note.trim(), timed, "MANUAL")
                    }
                }
                CalendarCreateType.MOOD -> onSetDailyMood(selectedKey, mood, note.trim())
            }
            createType = null
            },
            confirmLabel = "ثبت",
            confirmEnabled = when (type) {
                CalendarCreateType.TASK, CalendarCreateType.EVENT, CalendarCreateType.HABIT,
                CalendarCreateType.MEMORY, CalendarCreateType.OCCASION -> title.isNotBlank()
                CalendarCreateType.FINANCE -> (financeAmount.toLongOrNull() ?: 0L) > 0 && financeAccountId.isNotBlank()
                CalendarCreateType.MOOD -> true
            }
        ) {
                if (type == CalendarCreateType.FINANCE) {
                    if (financialAccounts.none { !it.isDeleted && !it.isArchived }) {
                        Text("ابتدا در بخش مالی یک حساب بساز.", color = MaterialTheme.colorScheme.error)
                    } else {
                        Text("حساب", fontWeight = FontWeight.Bold)
                        financialAccounts.filter { !it.isDeleted && !it.isArchived }.forEach { account ->
                            FilterChip(selected = financeAccountId == account.id, onClick = { financeAccountId = account.id }, label = { Text(account.name) })
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = financeKind == "EXPENSE", onClick = { financeKind = "EXPENSE" }, label = { Text("هزینه") })
                            FilterChip(selected = financeKind == "INCOME", onClick = { financeKind = "INCOME" }, label = { Text("درآمد") })
                        }
                        OutlinedTextField(
                            value = financeAmount,
                            onValueChange = { input ->
                                financeAmount = input.map { c ->
                                    when (c) {
                                        in '۰'..'۹' -> ('0'.code + (c - '۰')).toChar()
                                        in '٠'..'٩' -> ('0'.code + (c - '٠')).toChar()
                                        else -> c
                                    }
                                }.filter(Char::isDigit).joinToString("")
                            },
                            label = { Text("مبلغ به تومان") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(value = financeCategory, onValueChange = { financeCategory = it }, label = { Text("دسته‌بندی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    }
                } else if (type == CalendarCreateType.MOOD) {
                    Text("حال‌وهوای این روز را انتخاب کن")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("LOVE" to "عاشقانه", "HAPPY" to "خوشحال", "CALM" to "آرام", "SAD" to "غمگین").forEach { (key, label) ->
                            FilterChip(selected = mood == key, onClick = { mood = key }, label = { Text(label) })
                        }
                    }
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it.take(80) },
                        label = { Text("توضیح کوتاه — چرا این حال؟ (اختیاری)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                } else {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                if (type == CalendarCreateType.HABIT || type == CalendarCreateType.MEMORY || type == CalendarCreateType.OCCASION) {
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                }
                if (type == CalendarCreateType.OCCASION) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = repeatYearly, onCheckedChange = { repeatYearly = it })
                        Text("هر سال تکرار شود")
                    }
                }
                if (type == CalendarCreateType.TASK || type == CalendarCreateType.EVENT || type == CalendarCreateType.HABIT) {
                    OsTimePickerField(
                        hour = selectedHour,
                        minute = selectedMinute,
                        onTimeChange = { h, m ->
                            selectedHour = h
                            selectedMinute = m
                        },
                        label = if (type == CalendarCreateType.HABIT) "ساعت یادآوری" else "ساعت شروع"
                    )
                    if (type == CalendarCreateType.TASK || type == CalendarCreateType.EVENT) {
                        OsDurationPickerField(
                            durationMinutes = selectedDuration,
                            onDurationChange = { selectedDuration = it }
                        )
                    }
                }
                Text("تاریخ انتخاب‌شده: ${PersianDateFormatter.formatDate(selectedEpoch)}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        }
    }
    // A separate quick-action sheet keeps day creation one tap away without obscuring the calendar.
    // The primary action opens task creation; users can choose the precise record type from this dialog.
}

@Composable
private fun HeroStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .16f)).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        Text(label, color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun Dot(color: Color) { Box(Modifier.size(4.dp).background(color, CircleShape)) }

@Composable
private fun SectionHeading(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, count: Int) {
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        SuggestionChip(onClick = {}, label = { Text(PersianDateFormatter.toPersianDigits(count)) })
    }
}

@Composable
private fun CalendarEntry(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, trailing: (@Composable () -> Unit)? = null) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(color), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title.ifBlank { "بدون عنوان" }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                if (subtitle.isNotBlank()) Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 3)
            }
            trailing?.invoke()
        }
    }
}

private fun dayStart(epoch: Long): Long = Calendar.getInstance().apply {
    timeInMillis = epoch
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

/** End of the local calendar day; unlike adding 24 hours, this handles DST transitions. */
private fun dayEnd(epoch: Long): Long = Calendar.getInstance().apply {
    timeInMillis = dayStart(epoch)
    add(Calendar.DAY_OF_YEAR, 1)
    add(Calendar.MILLISECOND, -1)
}.timeInMillis

private fun dayNoon(epoch: Long): Long = Calendar.getInstance().apply { timeInMillis = epoch; set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
private fun dayAtTime(epoch: Long, hour: Int, minute: Int = 0): Long = Calendar.getInstance().apply {
    timeInMillis = epoch
    set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
    set(Calendar.MINUTE, minute.coerceIn(0, 59))
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis
private fun hourOf(epoch: Long): Int = Calendar.getInstance().apply { timeInMillis = epoch }.get(Calendar.HOUR_OF_DAY)
private fun parseHabitHour(scheduleNote: String): Int? {
    val match = Regex("""(\d{1,2})\s*:\s*(\d{2})""").find(scheduleNote) ?: return null
    return match.groupValues[1].toIntOrNull()?.coerceIn(0, 23)
}
private fun moodLabel(value: String): String = when (value.uppercase()) {
    "LOVE" -> "عاشقانه"
    "HAPPY" -> "خوشحال"
    "CALM" -> "آرام"
    "SAD" -> "غمگین"
    "ANXIOUS" -> "نگران"
    else -> value
}

private data class HourSlotItem(val title: String, val kind: String, val color: Color)

@Composable
private fun DayHourTimeline(
    expanded: Boolean,
    onToggle: () -> Unit,
    selectedEpoch: Long,
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    habits: List<HabitEntity>,
    onHourClick: (Int) -> Unit,
    onMoveTask: (TaskEntity, Long, Int) -> Unit,
    onMoveEvent: (EventEntity, Long, Long) -> Unit
) {
    val density = LocalDensity.current.density
    val hourHeight = 60.dp
    val scrollState = rememberScrollState()
    var timelineNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(60_000L)
            timelineNow = System.currentTimeMillis()
        }
    }
    val isToday = PersianDateFormatter.jalaliDayKey(selectedEpoch) == PersianDateFormatter.currentJalaliDayKey()
    val currentMinute = minuteOfDay(timelineNow)
    val timeFormatter = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)).clickable(onClick = onToggle).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("برنامه‌ریزی ساعتی", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text(if (expanded) "موردها را بکش تا زمانشان تغییر کند" else "نمای روزانه با بازهٔ زمانی هر مورد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (isToday) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.primary) {
                        Text(PersianDateFormatter.toPersianDigits(timeFormatter.format(java.util.Date(timelineNow))), modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    }
                    Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, contentDescription = if (expanded) "بستن برنامه ساعتی" else "نمایش برنامه ساعتی", tint = MaterialTheme.colorScheme.primary)
                } else {
                    Text(if (expanded) "بستن" else "نمایش", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
                }
            }
            if (expanded) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    CalendarLegendItem("✓", "کارها")
                    CalendarLegendItem("📅", "قرارها")
                    CalendarLegendItem("🔧", "شیفت شغلی")
                    CalendarLegendItem("🔁", "عادات")
                    Spacer(Modifier.weight(1f))
                    Text("برای افزودن، روی ساعت بزن", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            AnimatedVisibility(visible = expanded) {
                Box(Modifier.fillMaxWidth().height(1440.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f)).verticalScroll(scrollState)) {
                    // Hour grid and clickable empty slots.
                    Column(Modifier.fillMaxWidth()) {
                        (0..23).forEach { hour ->
                            Row(
                                Modifier.fillMaxWidth().height(hourHeight)
                                    .background(if (hour % 2 == 0) MaterialTheme.colorScheme.surface.copy(alpha = 0.52f) else Color.Transparent)
                                    .clickable { onHourClick(hour) },
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    PersianDateFormatter.toPersianDigits(hour.toString().padStart(2, '0')) + ":۰۰",
                                    modifier = Modifier.width(54.dp).padding(top = 3.dp),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Column(Modifier.fillMaxWidth().weight(1f).padding(top = 9.dp)) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .7f), thickness = 1.dp)
                                    Spacer(Modifier.height(29.dp))
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .28f), thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                    // Tasks are scheduled by dueAt; duration is stored in the task record.
                    tasks.forEach { task ->
                        val start = task.dueAt ?: return@forEach
                        val minute = minuteOfDay(start)
                        val duration = task.durationMinutes.coerceIn(15, 720)
                        Box(
                            Modifier.offset(y = minute.coerceIn(0, 1440 - duration).dp)
                                .fillMaxWidth()
                                .padding(start = 58.dp, end = 4.dp)
                                .height(duration.coerceAtLeast(34).dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxSize(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF3984F5).copy(alpha = .94f))
                            ) {
                                Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 2.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(task.id, start, duration) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val endMinute = minute + duration
                                                val newStartMinute = (minute + delta).coerceIn(0, endMinute - 15)
                                                val newDuration = (endMinute - newStartMinute).coerceIn(15, 720)
                                                onMoveTask(task, dayAtTime(selectedEpoch, newStartMinute / 60, newStartMinute % 60), newDuration)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .65f)).fillMaxWidth())
                                    Text(task.title, color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1, fontWeight = FontWeight.Bold, modifier = Modifier.pointerInput(task.id, start, duration) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val newMinute = (minute + delta).coerceIn(0, 1440 - duration)
                                                onMoveTask(task, dayAtTime(selectedEpoch, newMinute / 60, newMinute % 60), duration)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    })
                                    Text("${PersianDateFormatter.formatTime(start)} · ${PersianDateFormatter.toPersianDigits(duration.toString())} دقیقه", color = Color.White.copy(alpha = .92f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                    Spacer(Modifier.weight(1f, fill = false))
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(task.id, start, duration) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) onMoveTask(task, start, (duration + delta).coerceIn(15, 720))
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .65f)))
                                }
                            }
                        }
                    }
                    events.forEach { event ->
                        val start = event.startAt
                        val minute = minuteOfDay(start)
                        val end = event.endAt ?: (start + 60L * 60_000L)
                        val duration = ((end - start) / 60_000L).toInt().coerceIn(15, 720)
                        val isShift = isShiftWorkEvent(event.title, event.details)
                        val isOffice = isOsWorkEvent(event.details) && !isShift
                        val eventColor = when {
                            isShift -> Color(0xFF5C6BC0)   // شیفتی: نیلی
                            isOffice -> Color(0xFF00897B)  // اداری: فیروزه‌ای
                            else -> Color(0xFFFF9F43)      // قرار عادی: نارنجی
                        }
                        Box(
                            Modifier.offset(y = minute.coerceIn(0, 1439).dp)
                                .fillMaxWidth().padding(start = 58.dp, end = 4.dp).height(duration.coerceAtLeast(34).dp)
                        ) {
                            Card(Modifier.fillMaxSize(), shape = RoundedCornerShape(10.dp), colors = CardDefaults.cardColors(containerColor = eventColor)) {
                                Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 2.dp)) {
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(event.id, start, end) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val endMinute = minute + duration
                                                val newStartMinute = (minute + delta).coerceIn(0, endMinute - 15)
                                                val newStart = dayAtTime(selectedEpoch, newStartMinute / 60, newStartMinute % 60)
                                                onMoveEvent(event, newStart, newStart + (endMinute - newStartMinute) * 60_000L)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .75f)))
                                    Text(event.title, color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1, fontWeight = FontWeight.Bold, modifier = Modifier.pointerInput(event.id, start, end) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val newMinute = (minute + delta).coerceIn(0, 1440 - duration)
                                                val newStart = dayAtTime(selectedEpoch, newMinute / 60, newMinute % 60)
                                                onMoveEvent(event, newStart, newStart + duration * 60_000L)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    })
                                    Text("${PersianDateFormatter.formatTime(start)}–${PersianDateFormatter.formatTime(end)}", color = Color.White.copy(alpha = .95f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                    Spacer(Modifier.weight(1f, fill = false))
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(event.id, start, end) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) onMoveEvent(event, start, start + (duration + delta).coerceIn(15, 720) * 60_000L)
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .75f)))
                                }
                            }
                        }
                    }
                    habits.forEach { habit ->
                        val match = Regex("""(\d{1,2})\s*:\s*(\d{2})""").find(habit.scheduleNote) ?: return@forEach
                        val h = match.groupValues[1].toIntOrNull()?.coerceIn(0, 23) ?: return@forEach
                        val m = match.groupValues[2].toIntOrNull()?.coerceIn(0, 59) ?: 0
                        Row(Modifier.offset(y = (h * 60 + m).dp).fillMaxWidth().padding(start = 58.dp, end = 4.dp).height(34.dp).background(Color(0xFF9B59D0), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(habit.title, color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }
                    }
                    if (isToday) {
                        Row(
                            Modifier.offset(y = currentMinute.dp).fillMaxWidth().padding(start = 52.dp, end = 5.dp).height(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFE5484D)))
                            Spacer(Modifier.width(2.dp))
                            Box(Modifier.fillMaxWidth().height(2.dp).background(Color(0xFFE5484D)))
                        }
                    }
                }
            }
        }
    }
}

private fun minuteOfDay(epoch: Long): Int = Calendar.getInstance().apply { timeInMillis = epoch }.let {
    it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE)
}

