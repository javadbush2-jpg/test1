package com.ourspace.app.ui.design

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Premium design tokens for OurSpace — warm, soft, couple-first.
 * Prefer hierarchy and breathing room over decoration noise.
 * Alpha114 visual polish: softer radii, richer elevation, refined glow.
 */
object OSSpacing {
    val xxs: Dp = 4.dp
    val xs: Dp = 8.dp
    val sm: Dp = 12.dp
    val md: Dp = 16.dp
    val lg: Dp = 20.dp
    val xl: Dp = 24.dp
    val xxl: Dp = 32.dp
    val xxxl: Dp = 48.dp

    /** Horizontal page inset. */
    val screenHorizontal: Dp = 20.dp
    val sectionGap: Dp = 28.dp

    /** Bottom padding so content clears the floating nav. */
    val bottomNavClearance: Dp = 100.dp
}

object OSRadius {
    val xs: Dp = 12.dp
    val sm: Dp = 16.dp
    val md: Dp = 20.dp
    val lg: Dp = 26.dp
    val xl: Dp = 32.dp
    val xxl: Dp = 40.dp
    val full: Dp = 999.dp
}

object OSElevation {
    val none: Dp = 0.dp
    val soft: Dp = 3.dp
    val card: Dp = 8.dp
    val floating: Dp = 14.dp
    val nav: Dp = 20.dp
    val fab: Dp = 12.dp
}

object OSMotion {
    val quick = tween<Float>(durationMillis = 160)
    val standard = tween<Float>(durationMillis = 280)
    val emphasize = tween<Float>(durationMillis = 360)
    val softSpring = spring<Float>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessMediumLow
    )
    val pressSpring = spring<Float>(
        dampingRatio = 0.68f,
        stiffness = 520f
    )
    val gentleBounce = spring<Float>(
        dampingRatio = 0.78f,
        stiffness = 380f
    )
    val navIndicator = spring<Float>(
        dampingRatio = 0.82f,
        stiffness = 380f
    )
}

/**
 * Visual intensity tokens for Canvas glows, orbs, and mesh backgrounds.
 * Keep alphas low so content stays readable. Refined for alpha114.
 */
object OSGlow {
    const val orbAlphaPrimary = 0.16f
    const val orbAlphaSecondary = 0.10f
    const val orbAlphaTertiary = 0.08f
    const val cardBorderAlpha = 0.18f
    const val navPillAlpha = 0.22f
    const val selectedDayRingAlpha = 0.32f
    const val markerDotAlpha = 0.95f
    const val heroOrbAlpha = 0.22f
}

/**
 * Press / interaction tokens for consistent micro-feedback.
 */
object OSPress {
    const val scaleDown = 0.96f
    const val scaleSelected = 1.04f
    const val alphaPressed = 0.88f
}
