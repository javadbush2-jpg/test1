# =============================================================================
# OurSpace — R8/ProGuard rules for release builds.
#
# Most third-party libraries (AndroidX, Compose, Room, OkHttp, Lottie, WebRTC,
# Firebase) ship their own consumer rules. The rules below protect the surfaces
# THIS app reaches through JNI, reflection, generated code or persisted names.
# =============================================================================

# --- JNI bridge for the on-device llama.cpp runtime (ourspace_llm.cpp) --------
# Native methods are resolved by exact class/method name, so they must not be
# renamed or stripped.
-keep class com.ourspace.app.core.ai.HostLlmRuntime { *; }
-keep class com.ourspace.app.core.ai.LlmIsolationService { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# --- Reflection by string name in FcmTokenRegistrar ---------------------------
# Firebase is optional (the app degrades gracefully without it), but when the
# classes are present they are looked up via Class.forName + getMethod.
-keep class com.google.firebase.messaging.** { *; }
-keep class com.google.android.gms.tasks.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**

# --- Room: entities, DAOs and the database contract ---------------------------
# Keeps table/column names and the 28-version migration chain intact even under
# R8 full mode.
-keep class com.ourspace.app.core.database.** { *; }

# --- WorkManager workers are instantiated by class name from persisted work ---
-keep class * extends androidx.work.ListenableWorker { *; }
-keep class com.ourspace.app.core.reminder.**Worker { *; }
-keep class com.ourspace.app.core.sync.CompanionSyncWorker { *; }

# --- Enums: values()/valueOf are reached reflectively -------------------------
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# --- Parcelable CREATOR fields ------------------------------------------------
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}

# --- Keep generic signatures, annotations and readable crash stack traces -----
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes InnerClasses, EnclosingMethod
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile

# --- Stream WebRTC (native peer connection layer) -----------------------------
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# --- Safety nets alongside the libraries' own consumer rules -----------------
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn com.airbnb.lottie.**
-dontwarn org.json.**
