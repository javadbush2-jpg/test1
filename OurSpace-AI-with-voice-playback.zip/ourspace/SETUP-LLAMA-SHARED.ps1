# One-time: put llama.cpp in a shared folder next to Android SDK
# Usage: right-click / or: powershell -ExecutionPolicy Bypass -File SETUP-LLAMA-SHARED.ps1

$Target = "C:\Android\llama.cpp"
$Parent = "C:\Android"

if (-not (Test-Path $Parent)) {
    New-Item -ItemType Directory -Path $Parent -Force | Out-Null
}

if (Test-Path (Join-Path $Target "CMakeLists.txt")) {
    Write-Host "OK: llama.cpp already at $Target"
    exit 0
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Git not found. Install Git first."
    exit 1
}

Write-Host "Cloning llama.cpp (b4381) into $Target ..."
git clone --depth 1 --branch b4381 https://github.com/ggml-org/llama.cpp.git $Target
if ($LASTEXITCODE -ne 0) {
    Write-Host "Clone failed."
    exit 1
}
Write-Host "Done. Future app builds will reuse this folder (no re-download of sources)."
