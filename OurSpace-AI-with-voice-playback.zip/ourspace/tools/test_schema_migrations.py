#!/usr/bin/env python3
"""SQLite contract test for the pending Room 5→6→7 migrations.

This is intentionally dependency-free so the release gate can run it beside JVM tests.
"""

import sqlite3
import unittest


TRACKED_TABLES = [
    ("tasks", "tasks"),
    ("events", "events"),
    ("shopping_items", "shopping"),
    ("messages", "messages"),
    ("financial_accounts", "financialAccounts"),
    ("finance_transactions", "financeTransactions"),
    ("finance_budgets", "financeBudgets"),
    ("shared_debts", "sharedDebts"),
    ("recurring_transactions", "recurringTransactions"),
    ("memories", "memories"),
    ("mood_checkins", "moodCheckIns"),
    ("special_dates", "specialDates"),
    ("couple_profile", "coupleProfile"),
    ("attachments", "attachments"),
]


class SchemaMigrationContractTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute(
            "CREATE TABLE sync_changes (changeId TEXT NOT NULL PRIMARY KEY, "
            "entityType TEXT NOT NULL, entityId TEXT NOT NULL, changedAt INTEGER NOT NULL)"
        )
        for table, _ in TRACKED_TABLES[:7] + TRACKED_TABLES[9:13]:
            self.db.execute(
                f"CREATE TABLE `{table}` (id TEXT NOT NULL PRIMARY KEY, updatedAt INTEGER NOT NULL)"
            )

    def tearDown(self):
        self.db.close()

    def migrate_5_to_6(self):
        self.db.executescript(
            """
            CREATE TABLE attachments (
                id TEXT NOT NULL PRIMARY KEY, messageId TEXT, memoryId TEXT,
                fileName TEXT NOT NULL, mimeType TEXT NOT NULL, sizeBytes INTEGER NOT NULL,
                sha256 TEXT NOT NULL, content BLOB NOT NULL, createdByDeviceId TEXT NOT NULL,
                isDeleted INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            );
            CREATE INDEX index_attachments_messageId ON attachments(messageId);
            CREATE INDEX index_attachments_memoryId ON attachments(memoryId);
            CREATE INDEX index_attachments_updatedAt ON attachments(updatedAt);
            """
        )

    def migrate_6_to_7(self):
        self.db.executescript(
            """
            CREATE TABLE shared_debts (
                id TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, amount INTEGER NOT NULL,
                creditorDeviceId TEXT NOT NULL, debtorDeviceId TEXT NOT NULL, note TEXT NOT NULL,
                dueAt INTEGER, settledAt INTEGER, isDeleted INTEGER NOT NULL,
                createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            );
            CREATE INDEX index_shared_debts_creditorDeviceId ON shared_debts(creditorDeviceId);
            CREATE INDEX index_shared_debts_debtorDeviceId ON shared_debts(debtorDeviceId);
            CREATE INDEX index_shared_debts_dueAt ON shared_debts(dueAt);
            CREATE INDEX index_shared_debts_updatedAt ON shared_debts(updatedAt);
            CREATE TABLE recurring_transactions (
                id TEXT NOT NULL PRIMARY KEY, accountId TEXT NOT NULL, targetAccountId TEXT,
                kind TEXT NOT NULL, amount INTEGER NOT NULL, category TEXT NOT NULL, note TEXT NOT NULL,
                interval TEXT NOT NULL, anchorJalaliDay INTEGER NOT NULL,
                nextRunAt INTEGER NOT NULL, lastGeneratedAt INTEGER,
                createdByDeviceId TEXT NOT NULL, isActive INTEGER NOT NULL, isDeleted INTEGER NOT NULL,
                createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            );
            CREATE INDEX index_recurring_transactions_accountId ON recurring_transactions(accountId);
            CREATE INDEX index_recurring_transactions_nextRunAt ON recurring_transactions(nextRunAt);
            CREATE INDEX index_recurring_transactions_createdByDeviceId ON recurring_transactions(createdByDeviceId);
            CREATE INDEX index_recurring_transactions_updatedAt ON recurring_transactions(updatedAt);
            """
        )

    def install_triggers(self):
        for table, entity_type in TRACKED_TABLES:
            for operation, suffix in (("INSERT", "insert"), ("UPDATE", "update")):
                self.db.execute(
                    f"CREATE TRIGGER sync_track_{table}_{suffix} AFTER {operation} ON `{table}` "
                    "BEGIN INSERT OR REPLACE INTO sync_changes "
                    "(changeId, entityType, entityId, changedAt) VALUES "
                    f"('{entity_type}:' || NEW.id || ':' || NEW.updatedAt, "
                    f"'{entity_type}', NEW.id, NEW.updatedAt); END"
                )

    def test_migrations_create_expected_columns_and_indexes(self):
        self.migrate_5_to_6()
        self.migrate_6_to_7()
        attachment_columns = {row[1] for row in self.db.execute("PRAGMA table_info(attachments)")}
        debt_columns = {row[1] for row in self.db.execute("PRAGMA table_info(shared_debts)")}
        recurring_columns = {row[1] for row in self.db.execute("PRAGMA table_info(recurring_transactions)")}
        self.assertIn("content", attachment_columns)
        self.assertIn("settledAt", debt_columns)
        self.assertIn("anchorJalaliDay", recurring_columns)
        self.assertIn("nextRunAt", recurring_columns)
        self.assertIn("createdByDeviceId", recurring_columns)

    def test_all_fourteen_tables_emit_incremental_changes(self):
        self.migrate_5_to_6()
        self.migrate_6_to_7()
        self.install_triggers()
        for table, _ in TRACKED_TABLES:
            if table == "attachments":
                self.db.execute(
                    "INSERT INTO attachments VALUES "
                    "('id', 'message', NULL, 'f', 'text/plain', 1, 'hash', X'01', 'device', 0, 1, 1)"
                )
            elif table == "shared_debts":
                self.db.execute(
                    "INSERT INTO shared_debts VALUES "
                    "('id', 'title', 1, 'a', 'b', '', NULL, NULL, 0, 1, 1)"
                )
            elif table == "recurring_transactions":
                self.db.execute(
                    "INSERT INTO recurring_transactions VALUES "
                    "('id', 'account', NULL, 'EXPENSE', 1, 'other', '', 'MONTHLY', 1, 1, NULL, "
                    "'device', 1, 0, 1, 1)"
                )
            else:
                self.db.execute(f"INSERT INTO `{table}` VALUES ('id', 1)")
        types = {row[0] for row in self.db.execute("SELECT entityType FROM sync_changes")}
        self.assertEqual({entity_type for _, entity_type in TRACKED_TABLES}, types)
        self.assertEqual(14, len(types))


if __name__ == "__main__":
    unittest.main()
