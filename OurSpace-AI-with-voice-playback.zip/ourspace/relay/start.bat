@echo off
cd /d "%~dp0"
if not exist relay-data mkdir relay-data
echo [OurSpace] Starting personal relay on port 8787 ...
if exist relay-data\fcm-server-key.txt (
  echo [OurSpace] FCM key file found — Google wake enabled
) else (
  echo [OurSpace] FCM optional — WebSocket + long-poll active
)
python server.py --host 0.0.0.0 --port 8787 --database relay-data/relay.sqlite3
pause
