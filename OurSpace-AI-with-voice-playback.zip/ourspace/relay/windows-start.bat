@echo off
cd /d "%~dp0"
if not exist relay-data mkdir relay-data
if not exist relay-data\logs mkdir relay-data\logs
if not exist relay-data\ddns.json if exist ddns.example.json (
  echo Creating relay-data\ddns.json from example — edit it and paste your DNSLab update URL.
  copy /Y ddns.example.json relay-data\ddns.json >nul
)
echo Starting OurSpace relay on 0.0.0.0:8787 ...
python server.py --host 0.0.0.0 --port 8787
pause
