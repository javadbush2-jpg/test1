#!/usr/bin/env python3
"""Content-addressed binary blob store for OurSpace relay photos/files.

Photos stay as real binary files on disk (not Base64 in SQLite).
JSON envelopes only carry sha256 references after ingest.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

LOG = logging.getLogger("ourspace.relay.blobs")


class BlobStore:
    def __init__(self, root: str) -> None:
        self.root = Path(os.path.abspath(os.path.expanduser(root)))
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "objects").mkdir(parents=True, exist_ok=True)
        (self.root / "meta").mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _object_path(self, sha256: str) -> Path:
        sha256 = sha256.lower().strip()
        return self.root / "objects" / sha256[:2] / sha256

    def _meta_path(self, sha256: str) -> Path:
        sha256 = sha256.lower().strip()
        return self.root / "meta" / f"{sha256}.json"

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def put(
        self,
        data: bytes,
        *,
        mime_type: str = "application/octet-stream",
        file_name: str = "",
        source: str = "upload",
    ) -> str:
        if not data:
            raise ValueError("empty_blob")
        if len(data) > 48 * 1024 * 1024:
            raise ValueError("blob_too_large")
        sha = self.hash_bytes(data)
        path = self._object_path(sha)
        with self._lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.is_file():
                tmp = path.with_suffix(".tmp")
                tmp.write_bytes(data)
                tmp.replace(path)
                LOG.info("blob_store put sha=%s bytes=%s source=%s", sha[:12], len(data), source)
            meta_path = self._meta_path(sha)
            if not meta_path.is_file():
                meta = {
                    "sha256": sha,
                    "sizeBytes": len(data),
                    "mimeType": mime_type or "application/octet-stream",
                    "fileName": (file_name or "")[:180],
                    "source": source,
                }
                meta_path.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
            else:
                # enrich mime/name if previously unknown
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    changed = False
                    if file_name and not meta.get("fileName"):
                        meta["fileName"] = file_name[:180]
                        changed = True
                    if mime_type and meta.get("mimeType", "").startswith("application/"):
                        meta["mimeType"] = mime_type
                        changed = True
                    if changed:
                        meta_path.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
                except Exception:  # noqa: BLE001
                    pass
        return sha

    def get(self, sha256: str) -> bytes | None:
        path = self._object_path(sha256.lower().strip())
        if not path.is_file():
            return None
        return path.read_bytes()

    def exists(self, sha256: str) -> bool:
        return self._object_path(sha256.lower().strip()).is_file()

    def meta(self, sha256: str) -> dict[str, Any] | None:
        path = self._meta_path(sha256.lower().strip())
        if path.is_file():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                pass
        obj = self._object_path(sha256.lower().strip())
        if not obj.is_file():
            return None
        return {
            "sha256": sha256.lower().strip(),
            "sizeBytes": obj.stat().st_size,
            "mimeType": "application/octet-stream",
            "fileName": "",
        }

    def list_blobs(self, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        limit = max(1, min(int(limit), 300))
        offset = max(0, int(offset))
        items: list[dict[str, Any]] = []
        objects_root = self.root / "objects"
        if objects_root.is_dir():
            files = sorted(objects_root.rglob("*"), key=lambda p: p.stat().st_mtime if p.is_file() else 0, reverse=True)
            files = [p for p in files if p.is_file() and not p.name.endswith(".tmp")]
            total = len(files)
            for path in files[offset : offset + limit]:
                sha = path.name
                m = self.meta(sha) or {
                    "sha256": sha,
                    "sizeBytes": path.stat().st_size,
                    "mimeType": "application/octet-stream",
                    "fileName": "",
                }
                m["mtime"] = int(path.stat().st_mtime * 1000)
                items.append(m)
        else:
            total = 0
        return {"total": total, "limit": limit, "offset": offset, "items": items}

    def stats(self) -> dict[str, Any]:
        total_files = 0
        total_bytes = 0
        objects_root = self.root / "objects"
        if objects_root.is_dir():
            for path in objects_root.rglob("*"):
                if path.is_file() and not path.name.endswith(".tmp"):
                    total_files += 1
                    total_bytes += path.stat().st_size
        return {
            "blobFiles": total_files,
            "blobBytes": total_bytes,
            "blobRoot": str(self.root),
        }


def extract_and_store_chunk_blobs(blob_store: BlobStore, envelope: dict) -> dict:
    """If envelope is attachment_chunk with Base64 data, store binary and slim the JSON."""
    if not isinstance(envelope, dict):
        return envelope
    if envelope.get("type") != "attachment_chunk":
        return envelope
    chunk = envelope.get("chunk")
    if not isinstance(chunk, dict):
        return envelope
    data_b64 = chunk.get("data")
    if not isinstance(data_b64, str) or not data_b64 or chunk.get("blobSha256"):
        return envelope
    try:
        import base64
        raw = base64.b64decode(data_b64, validate=False)
    except Exception:  # noqa: BLE001
        return envelope
    att = chunk.get("attachment") if isinstance(chunk.get("attachment"), dict) else {}
    mime = str(att.get("mimeType") or "application/octet-stream")
    name = str(att.get("fileName") or "")
    sha = blob_store.put(raw, mime_type=mime, file_name=name, source="attachment_chunk")
    slim_chunk = dict(chunk)
    slim_chunk.pop("data", None)
    slim_chunk["blobSha256"] = sha
    slim_chunk["blobBytes"] = len(raw)
    slim_chunk["dataOmitted"] = True
    out = dict(envelope)
    out["chunk"] = slim_chunk
    return out


def rehydrate_chunk_blobs(blob_store: BlobStore, envelope: dict) -> dict:
    """Restore Base64 data from blob store for clients that still expect classic chunks."""
    if not isinstance(envelope, dict):
        return envelope
    if envelope.get("type") != "attachment_chunk":
        return envelope
    chunk = envelope.get("chunk")
    if not isinstance(chunk, dict):
        return envelope
    if chunk.get("data"):
        return envelope
    sha = str(chunk.get("blobSha256") or "").strip().lower()
    if not sha:
        return envelope
    raw = blob_store.get(sha)
    if raw is None:
        return envelope
    import base64
    out_chunk = dict(chunk)
    out_chunk["data"] = base64.b64encode(raw).decode("ascii")
    out_chunk.pop("dataOmitted", None)
    out = dict(envelope)
    out["chunk"] = out_chunk
    return out
