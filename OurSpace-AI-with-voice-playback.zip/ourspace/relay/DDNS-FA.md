# DDNS با DNSLab — روش درست

## مهم
آدرس‌هایی مثل `https://dnslab.link/nic/update` معمولاً **صفحهٔ سایت (HTML)** برمی‌گردانند، نه آپدیت واقعی.
اگر در لاگ `body=<!DOCTYPE html>` دیدی، آپدیت **موفق نبوده**.

## روش پیشنهادی ۱: مودم (ساده‌ترین)
همان صفحهٔ راهنمای DNSLab:
- Provider: dyndns.org یا no-ip.com
- Hostname: ourspace.iddns.ir
- Username / Password: حساب DNSLab

مودم پروتکل را درست حرف می‌زند.

## روش پیشنهادی ۲: کلید API در پنل DNSLab (برای سرور)

طبق مستندات DNSLab:
1. وارد پنل DNSLab شو
2. منوی **کلیدها** (Keys)
3. **افزودن کلید** — نام بگذار و هاست `ourspace.iddns.ir` را تیک بزن
4. ذخیره
5. از منوی همان کلید، **اسکریپت** مربوط به سیستم‌عامل را دانلود کن یا URL آپدیت را کپی کن

در `relay-data/ddns.json`:

```json
{
  "enabled": true,
  "hostname": "ourspace.iddns.ir",
  "update_url": "URL_کامل_از_پنل_کلیدها",
  "interval_minutes": 60
}
```

`username` / `password` را برای این روش لازم نیست.

اگر در URL جایی برای IP بود، می‌توانی `{ip}` بگذاری.

## تست موفقیت واقعی
در لاگ باید چیزی شبیه این باشد (نه HTML):

```text
ddns ok ... body=good 2.190.x.x
```

یا `nochg` / `OK` کوتاه بدون تگ HTML.
