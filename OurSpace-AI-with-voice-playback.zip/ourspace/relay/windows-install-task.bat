@echo off
REM Run once as Administrator to auto-start relay when you log in
cd /d "%~dp0"
schtasks /Create /TN "OurSpaceRelay" /TR "\"%~dp0windows-start.bat\"" /SC ONLOGON /RL LIMITED /F
echo Task OurSpaceRelay created. Relay starts at Windows logon.
pause
