#!/usr/bin/env python3
"""OurSpace Relay Admin Panel helpers — dashboard, database browser, live logs."""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any

LOG = logging.getLogger("ourspace.relay.admin")

_LOG_BUFFER: deque[str] = deque(maxlen=2_000)
_LOG_LOCK = threading.Lock()

ADMIN_TABLES = (
    "relay_messages",
    "relay_archive",
    "relay_device_events",
    "relay_deliveries",
    "push_tokens",
    "household_backups",
)

_HTML_PATH = Path(__file__).resolve().parent / "admin.html"


class MemoryLogHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        try:
            line = self.format(record)
        except Exception:  # noqa: BLE001
            line = record.getMessage()
        with _LOG_LOCK:
            _LOG_BUFFER.append(line)


def install_memory_log_handler() -> None:
    root = logging.getLogger()
    for h in root.handlers:
        if isinstance(h, MemoryLogHandler):
            return
    handler = MemoryLogHandler()
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    root.addHandler(handler)


def recent_logs(limit: int = 200, level: str = "", log_file: str = "") -> list[str]:
    limit = max(1, min(int(limit), 1_000))
    level = (level or "").upper().strip()
    with _LOG_LOCK:
        lines = list(_LOG_BUFFER)
    if len(lines) < 20 and log_file:
        lines = tail_log_file(log_file, limit) or lines
    if level:
        lines = [ln for ln in lines if f" {level} " in ln]
    return lines[-limit:]


def tail_log_file(path: str, limit: int = 200) -> list[str]:
    try:
        if not path or not os.path.isfile(path):
            return []
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - 256_000))
            data = fh.read()
        lines = [ln for ln in data.splitlines() if ln.strip()]
        return lines[-max(1, min(limit, 1_000)) :]
    except OSError:
        return []


def admin_html_bytes() -> bytes:
    if _HTML_PATH.is_file():
        return _HTML_PATH.read_bytes()
    return b"<h1>admin.html missing</h1>"


def db_table_stats(store) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    with store.transaction() as database:
        for name in ADMIN_TABLES:
            try:
                count = database.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
            except sqlite3.Error:
                count = -1
            rows.append({"name": name, "count": int(count)})
        try:
            page_count = database.execute("PRAGMA page_count").fetchone()[0]
            page_size = database.execute("PRAGMA page_size").fetchone()[0]
            db_bytes = int(page_count) * int(page_size)
        except sqlite3.Error:
            db_bytes = 0
    path = getattr(store, "path", "")
    file_bytes = 0
    try:
        if path and os.path.isfile(path):
            file_bytes = os.path.getsize(path)
    except OSError:
        pass
    return {
        "tables": rows,
        "dbPath": path,
        "pageBytes": db_bytes,
        "fileBytes": file_bytes,
    }


def db_browse(
    store,
    table: str,
    limit: int = 50,
    offset: int = 0,
    mailbox: str = "",
    direction: str = "",
    q: str = "",
) -> dict[str, Any]:
    if table not in ADMIN_TABLES:
        raise ValueError("unknown_table")
    limit = max(1, min(int(limit), 200))
    offset = max(0, int(offset))
    mailbox = (mailbox or "").strip()
    direction = (direction or "").strip()
    q = (q or "").strip()

    where: list[str] = []
    args: list[Any] = []
    if table in ("relay_messages", "relay_archive", "relay_device_events", "relay_deliveries") and mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    if table in ("relay_messages", "relay_archive", "relay_device_events", "relay_deliveries") and direction in ("to-host", "to-companion"):
        where.append("direction = ?")
        args.append(direction)
    if table in ("relay_messages", "relay_archive") and q:
        where.append("(message_id LIKE ? OR envelope_json LIKE ?)")
        args.extend([f"%{q}%", f"%{q}%"])
    if table == "relay_device_events" and q:
        where.append("(device_id LIKE ? OR action LIKE ? OR message_id LIKE ? OR result LIKE ?)")
        args.extend([f"%{q}%"] * 4)
    if table == "relay_deliveries" and q:
        where.append("(device_id LIKE ? OR message_id LIKE ?)")
        args.extend([f"%{q}%"] * 2)
    if table == "push_tokens" and mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    if table == "household_backups" and mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")

    clause = (" WHERE " + " AND ".join(where)) if where else ""
    order = {
        "relay_messages": "created_at DESC",
        "relay_archive": "archive_id DESC",
        "relay_device_events": "event_at DESC, event_id DESC",
        "relay_deliveries": "last_delivered_at DESC",
        "push_tokens": "updated_at DESC",
        "household_backups": "updated_at DESC",
    }[table]

    with store.transaction() as database:
        total = database.execute(f"SELECT COUNT(*) FROM {table}{clause}", args).fetchone()[0]
        if table == "relay_messages":
            sql = f"""
                SELECT mailbox_id, direction, message_id, correlation_id, created_at, expires_at,
                       length(envelope_json) AS envelope_bytes,
                       substr(envelope_json, 1, 240) AS envelope_preview
                FROM relay_messages{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        elif table == "relay_archive":
            sql = f"""
                SELECT archive_id, mailbox_id, direction, message_id, correlation_id, created_at, expires_at,
                       length(envelope_json) AS envelope_bytes,
                       substr(envelope_json, 1, 240) AS envelope_preview
                FROM relay_archive{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        elif table == "relay_device_events":
            sql = f"""
                SELECT event_id, event_at, mailbox_id, device_id, role, action, direction,
                       message_id, message_type, result,
                       substr(details_json, 1, 240) AS details_preview
                FROM relay_device_events{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        elif table == "relay_deliveries":
            sql = f"""
                SELECT mailbox_id, direction, message_id, device_id, role,
                       first_delivered_at, last_delivered_at, delivery_count, last_event_at
                FROM relay_deliveries{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        elif table == "push_tokens":
            sql = f"""
                SELECT mailbox_id, substr(token, 1, 16) || '…' AS token_prefix, platform, updated_at
                FROM push_tokens{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        else:
            sql = f"""
                SELECT mailbox_id, updated_at, length(backup_json) AS backup_bytes
                FROM household_backups{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        cur = database.execute(sql, [*args, limit, offset])
        columns = [d[0] for d in cur.description]
        items = [dict(zip(columns, row)) for row in cur.fetchall()]

    for item in items:
        mid = item.get("mailbox_id")
        if isinstance(mid, str) and len(mid) > 16:
            item["mailbox_prefix"] = mid[:12]
    return {
        "table": table,
        "total": int(total),
        "limit": limit,
        "offset": offset,
        "columns": columns,
        "items": items,
    }


def db_message_detail(store, table: str, message_id: str, mailbox: str = "") -> dict[str, Any] | None:
    if table not in ("relay_messages", "relay_archive"):
        raise ValueError("unsupported_table")
    message_id = (message_id or "").strip()
    if not message_id:
        return None
    with store.transaction() as database:
        if table == "relay_messages":
            sql = """
                SELECT mailbox_id, direction, message_id, correlation_id, created_at, expires_at, envelope_json
                FROM relay_messages WHERE message_id=?
            """
            args: list[Any] = [message_id]
            if mailbox:
                sql += " AND mailbox_id LIKE ?"
                args.append(f"{mailbox}%")
            sql += " LIMIT 1"
            row = database.execute(sql, args).fetchone()
            if not row:
                return None
            envelope = json.loads(row[6])
            return {
                "table": table,
                "mailbox_id": row[0],
                "mailbox_prefix": row[0][:12],
                "direction": row[1],
                "message_id": row[2],
                "correlation_id": row[3],
                "created_at": row[4],
                "expires_at": row[5],
                "envelope_bytes": len(row[6].encode("utf-8")),
                "envelope": _safe_envelope_view(envelope),
            }
        sql = """
            SELECT archive_id, mailbox_id, direction, message_id, correlation_id, created_at, expires_at, envelope_json
            FROM relay_archive WHERE message_id=?
        """
        args = [message_id]
        if mailbox:
            sql += " AND mailbox_id LIKE ?"
            args.append(f"{mailbox}%")
        sql += " ORDER BY archive_id DESC LIMIT 1"
        row = database.execute(sql, args).fetchone()
        if not row:
            return None
        envelope = json.loads(row[7])
        return {
            "table": table,
            "archive_id": row[0],
            "mailbox_id": row[1],
            "mailbox_prefix": row[1][:12],
            "direction": row[2],
            "message_id": row[3],
            "correlation_id": row[4],
            "created_at": row[5],
            "expires_at": row[6],
            "envelope_bytes": len(row[7].encode("utf-8")),
            "envelope": _safe_envelope_view(envelope),
        }


def _safe_envelope_view(envelope: dict) -> dict:
    view: dict[str, Any] = {"type": envelope.get("type"), "keys": sorted(envelope.keys())}
    for key in ("requestId", "sentAt", "correlationId"):
        if key in envelope:
            view[key] = envelope[key]
    delta = envelope.get("delta")
    if isinstance(delta, dict):
        changes = delta.get("changes")
        acks = delta.get("acknowledgedChanges") or delta.get("acknowledgements")
        view["delta"] = {
            "protocol": delta.get("protocol"),
            "schema": delta.get("schema"),
            "changesCount": len(changes) if isinstance(changes, list) else 0,
            "ackCount": len(acks) if isinstance(acks, list) else 0,
            "changeEntityTypes": _entity_type_histogram(changes) if isinstance(changes, list) else {},
        }
    raw = json.dumps(envelope, ensure_ascii=False, separators=(",", ":"))
    view["rawPreview"] = raw[:8_000] + ("…" if len(raw) > 8_000 else "")
    view["rawBytes"] = len(raw.encode("utf-8"))
    return view


def _entity_type_histogram(changes: list) -> dict[str, int]:
    hist: dict[str, int] = {}
    for item in changes:
        if not isinstance(item, dict):
            continue
        et = str(item.get("entityType") or "?")
        hist[et] = hist.get(et, 0) + 1
    return hist


def db_direction_breakdown(store) -> list[dict[str, Any]]:
    now_ms = int(time.time() * 1000)
    with store.transaction() as database:
        rows = database.execute(
            """
            SELECT direction, COUNT(*) AS cnt, MIN(created_at) AS oldest, MAX(created_at) AS newest
            FROM relay_messages
            WHERE expires_at > ?
            GROUP BY direction
            """,
            (now_ms,),
        ).fetchall()
    return [
        {"direction": r[0], "count": int(r[1]), "oldestAt": r[2], "newestAt": r[3]}
        for r in rows
    ]



_MESSAGE_TYPE_SQL = "COALESCE(NULLIF(CAST(json_extract(envelope_json, '$.type') AS TEXT), ''), '(بدون نوع)')"
_ERROR_ENVELOPE_SQL = """(
    lower(COALESCE(CAST(json_extract(envelope_json, '$.type') AS TEXT), '')) LIKE '%error%'
    OR json_type(envelope_json, '$.error') IN ('true', 'object', 'array')
    OR json_extract(envelope_json, '$.error') = 1
    OR (json_type(envelope_json, '$.error') = 'text'
        AND length(trim(json_extract(envelope_json, '$.error'))) > 0)
    OR json_extract(envelope_json, '$.errorCode') IS NOT NULL
    OR json_extract(envelope_json, '$.errorMessage') IS NOT NULL
    OR json_extract(envelope_json, '$.locationRefreshError') IS NOT NULL
    OR json_extract(envelope_json, '$.success') = 0
)"""
_ERROR_REASON_SQL = """substr(COALESCE(
    NULLIF(CAST(json_extract(envelope_json, '$.errorMessage') AS TEXT), ''),
    NULLIF(CAST(json_extract(envelope_json, '$.locationRefreshError') AS TEXT), ''),
    NULLIF(CAST(json_extract(envelope_json, '$.errorCode') AS TEXT), ''),
    NULLIF(CAST(json_extract(envelope_json, '$.message') AS TEXT), ''),
    NULLIF(CAST(json_extract(envelope_json, '$.reason') AS TEXT), ''),
    CASE WHEN json_type(envelope_json, '$.error') IN ('text', 'object', 'array')
         THEN CAST(json_extract(envelope_json, '$.error') AS TEXT) END,
    'خطا در پیام'
), 1, 500)"""


def _message_filters(mailbox: str, direction: str, pending: bool) -> tuple[str, list[Any]]:
    where: list[str] = []
    args: list[Any] = []
    if pending:
        where.append("expires_at > ?")
        args.append(int(time.time() * 1000))
    if mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    if direction:
        where.append("direction = ?")
        args.append(direction)
    return (" WHERE " + " AND ".join(where)) if where else "", args


def message_type_report(
    store,
    mailbox: str = "",
    direction: str = "",
    recent_limit: int = 100,
    log_file: str = "",
) -> dict[str, Any]:
    """Aggregate all stored envelope types and surface error envelopes/logs for admin."""
    mailbox = (mailbox or "").strip()
    direction = (direction or "").strip()
    if direction not in ("", "to-host", "to-companion"):
        raise ValueError("invalid_direction")
    recent_limit = max(1, min(int(recent_limit), 200))
    by_type: dict[str, dict[str, Any]] = {}
    pending_total = 0
    archive_total = 0
    error_pending = 0
    error_archived = 0

    with store.transaction() as database:
        for table, source in (("relay_messages", "pending"), ("relay_archive", "archived")):
            clause, args = _message_filters(mailbox, direction, pending=(source == "pending"))
            rows = database.execute(
                f"""
                SELECT {_MESSAGE_TYPE_SQL} AS message_type,
                       COUNT(*) AS message_count,
                       COALESCE(SUM(length(envelope_json)), 0) AS envelope_bytes,
                       COALESCE(SUM(CASE WHEN {_ERROR_ENVELOPE_SQL} THEN 1 ELSE 0 END), 0) AS error_count,
                       MIN(created_at) AS oldest_at,
                       MAX(created_at) AS latest_at
                FROM {table}{clause}
                GROUP BY message_type
                """,
                args,
            ).fetchall()
            source_total = 0
            source_errors = 0
            for row in rows:
                message_type = str(row[0] or "(بدون نوع)")
                record = by_type.setdefault(message_type, {
                    "type": message_type,
                    "pending": 0,
                    "archived": 0,
                    "pendingBytes": 0,
                    "archivedBytes": 0,
                    "errorsPending": 0,
                    "errorsArchived": 0,
                    "oldestAt": None,
                    "latestAt": None,
                })
                count = int(row[1] or 0)
                size = int(row[2] or 0)
                errors = int(row[3] or 0)
                record[source] = count
                record[f"{source}Bytes"] = size
                record[f"errors{source.title()}"] = errors
                record["oldestAt"] = min(
                    (value for value in (record["oldestAt"], row[4]) if value is not None),
                    default=None,
                )
                record["latestAt"] = max(
                    (value for value in (record["latestAt"], row[5]) if value is not None),
                    default=None,
                )
                source_total += count
                source_errors += errors
            if source == "pending":
                pending_total = source_total
                error_pending = source_errors
            else:
                archive_total = source_total
                error_archived = source_errors

        pending_clause, pending_args = _message_filters(mailbox, direction, pending=True)
        archive_clause, archive_args = _message_filters(mailbox, direction, pending=False)
        error_rows = database.execute(
            f"""
            SELECT source, mailbox_id, direction, message_id, created_at, message_type, reason
            FROM (
                SELECT 'pending' AS source, mailbox_id, direction, message_id, created_at,
                       {_MESSAGE_TYPE_SQL} AS message_type, {_ERROR_REASON_SQL} AS reason,
                       CASE WHEN {_ERROR_ENVELOPE_SQL} THEN 1 ELSE 0 END AS is_error
                FROM relay_messages{pending_clause}
                UNION ALL
                SELECT 'archive' AS source, mailbox_id, direction, message_id, created_at,
                       {_MESSAGE_TYPE_SQL} AS message_type, {_ERROR_REASON_SQL} AS reason,
                       CASE WHEN {_ERROR_ENVELOPE_SQL} THEN 1 ELSE 0 END AS is_error
                FROM relay_archive{archive_clause}
            )
            WHERE is_error = 1
            ORDER BY created_at DESC
            LIMIT ?
            """,
            [*pending_args, *archive_args, recent_limit],
        ).fetchall()

    error_messages: list[dict[str, Any]] = []
    for row in error_rows:
        error_messages.append({
            "source": row[0],
            "mailboxPrefix": str(row[1] or "")[:12],
            "direction": row[2],
            "messageId": row[3],
            "createdAt": row[4],
            "type": row[5],
            "reason": str(row[6] or "خطا در پیام")[:500],
        })

    types = sorted(
        by_type.values(),
        key=lambda item: (
            -(item["errorsPending"] + item["errorsArchived"]),
            -(item["pending"] + item["archived"]),
            item["type"].lower(),
        ),
    )
    lines = recent_logs(limit=1_000, log_file=log_file)
    error_logs = []
    for line in lines:
        level = next((name for name in ("CRITICAL", "ERROR", "WARNING") if f" {name} " in line), "")
        if level:
            error_logs.append({"level": level, "line": line})
    return {
        "generatedAt": int(time.time() * 1000),
        "filters": {"mailbox": mailbox, "direction": direction},
        "pendingTotal": pending_total,
        "archiveTotal": archive_total,
        "errorEnvelopePending": error_pending,
        "errorEnvelopeArchived": error_archived,
        "types": types,
        "errorMessages": error_messages,
        "recentServerErrors": error_logs[-recent_limit:][::-1],
    }



def relay_flow_report(
    store,
    devices: list[dict[str, Any]] | None = None,
    mailbox: str = "",
    limit: int = 100,
    stuck_after_ms: int = 120_000,
    now_ms: int | None = None,
) -> dict[str, Any]:
    """Show current queue position, observed delivery/ACK state, and device activity."""
    now_ms = int(now_ms or time.time() * 1000)
    mailbox = (mailbox or "").strip()
    limit = max(1, min(int(limit), 250))
    stuck_after_ms = max(30_000, min(int(stuck_after_ms), 24 * 60 * 60 * 1000))
    where = ["m.expires_at > ?"]
    args: list[Any] = [now_ms]
    if mailbox:
        where.append("m.mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    clause = " WHERE " + " AND ".join(where)
    delivery_summary = """(
        SELECT mailbox_id, direction, message_id,
               SUM(delivery_count) AS delivery_count,
               MIN(first_delivered_at) AS first_delivered_at,
               MAX(last_delivered_at) AS last_delivered_at,
               COUNT(*) AS receiving_devices
        FROM relay_deliveries
        GROUP BY mailbox_id, direction, message_id
    )"""
    online_by_role: dict[tuple[str, str], bool] = {}
    for item in devices or []:
        key = (str(item.get("mailbox_id") or ""), str(item.get("role") or "unknown"))
        online_by_role[key] = online_by_role.get(key, False) or bool(item.get("online"))

    with store.transaction() as database:
        grouped = database.execute(
            f"""
            SELECT m.direction, COUNT(*) AS pending_count,
                   SUM(CASE WHEN COALESCE(d.delivery_count, 0) = 0 THEN 1 ELSE 0 END) AS queued_count,
                   SUM(CASE WHEN COALESCE(d.delivery_count, 0) > 0 THEN 1 ELSE 0 END) AS awaiting_ack_count,
                   SUM(CASE WHEN (? - COALESCE(d.first_delivered_at, m.created_at)) >= ? THEN 1 ELSE 0 END) AS stuck_count,
                   MIN(m.created_at) AS oldest_at
            FROM relay_messages AS m
            LEFT JOIN {delivery_summary} AS d
              ON d.mailbox_id=m.mailbox_id AND d.direction=m.direction AND d.message_id=m.message_id
            {clause}
            GROUP BY m.direction
            """,
            [now_ms, stuck_after_ms, *args],
        ).fetchall()
        grouped_by_direction = {row[0]: row for row in grouped}
        flows = []
        for direction in ("to-host", "to-companion"):
            row = grouped_by_direction.get(direction)
            target_role = "host" if direction == "to-host" else "companion"
            source_role = "companion" if target_role == "host" else "host"
            flows.append({
                "direction": direction,
                "sourceRole": source_role,
                "targetRole": target_role,
                "targetOnline": any(
                    online_by_role.get((str(item.get("mailbox_id") or ""), target_role), False)
                    for item in (devices or [])
                ),
                "pendingCount": int(row[1] or 0) if row else 0,
                "queuedCount": int(row[2] or 0) if row else 0,
                "awaitingAckCount": int(row[3] or 0) if row else 0,
                "stuckCount": int(row[4] or 0) if row else 0,
                "oldestAt": row[5] if row else None,
            })

        message_rows = database.execute(
            f"""
            SELECT m.mailbox_id, m.direction, m.message_id, m.created_at, m.expires_at,
                   {_MESSAGE_TYPE_SQL} AS message_type,
                   CASE WHEN {_ERROR_ENVELOPE_SQL} THEN 1 ELSE 0 END AS is_error,
                   COALESCE(d.delivery_count, 0) AS delivery_count,
                   d.first_delivered_at,
                   d.last_delivered_at,
                   COALESCE(d.receiving_devices, 0) AS receiving_devices
            FROM relay_messages AS m
            LEFT JOIN {delivery_summary} AS d
              ON d.mailbox_id=m.mailbox_id AND d.direction=m.direction AND d.message_id=m.message_id
            {clause}
            ORDER BY COALESCE(d.last_delivered_at, m.created_at) ASC, m.created_at ASC
            LIMIT ?
            """,
            [*args, limit],
        ).fetchall()
        event_where = " WHERE mailbox_id LIKE ?" if mailbox else ""
        event_args: list[Any] = [f"{mailbox}%"] if mailbox else []
        event_rows = database.execute(
            f"""
            SELECT event_id, event_at, mailbox_id, device_id, role, action, direction,
                   message_id, message_type, result, details_json
            FROM relay_device_events{event_where}
            ORDER BY event_at DESC, event_id DESC
            LIMIT ?
            """,
            [*event_args, min(200, max(20, limit))],
        ).fetchall()
        historical_device_rows = database.execute(
            f"""
            SELECT e.mailbox_id, e.device_id, e.role, e.action, e.event_at
            FROM relay_device_events AS e
            JOIN (
                SELECT mailbox_id, device_id, MAX(event_id) AS latest_event_id
                FROM relay_device_events{event_where}
                GROUP BY mailbox_id, device_id
            ) AS latest ON latest.latest_event_id=e.event_id
            ORDER BY e.event_at DESC
            LIMIT 500
            """,
            event_args,
        ).fetchall()

    pending_messages: list[dict[str, Any]] = []
    for row in message_rows:
        mailbox_id = str(row[0] or "")
        direction = str(row[1] or "")
        target_role = "host" if direction == "to-host" else "companion"
        source_role = "companion" if target_role == "host" else "host"
        delivery_count = int(row[7] or 0)
        first_delivered_at = int(row[8]) if row[8] is not None else None
        last_delivered_at = int(row[9]) if row[9] is not None else None
        stage_at = first_delivered_at or int(row[3] or 0)
        stage_age_ms = max(0, now_ms - stage_at)
        stuck = stage_age_ms >= stuck_after_ms
        target_online = online_by_role.get((mailbox_id, target_role), False)
        if delivery_count:
            stage = "awaiting_ack"
            blocked_at = "ack_from_recipient"
        else:
            stage = "queued"
            blocked_at = "relay_queue"
        if stuck and not target_online:
            stuck_reason = "recipient_offline"
        elif stuck and delivery_count:
            stuck_reason = "ack_missing"
        elif stuck:
            stuck_reason = "recipient_not_receiving"
        else:
            stuck_reason = ""
        pending_messages.append({
            "mailboxPrefix": mailbox_id[:12],
            "direction": direction,
            "messageId": row[2],
            "type": row[5],
            "isError": bool(row[6]),
            "createdAt": row[3],
            "expiresAt": row[4],
            "firstDeliveredAt": first_delivered_at,
            "lastDeliveredAt": last_delivered_at,
            "deliveryCount": delivery_count,
            "receivingDevices": int(row[10] or 0),
            "sourceRole": source_role,
            "targetRole": target_role,
            "targetOnline": target_online,
            "stage": stage,
            "blockedAt": blocked_at,
            "stageAgeMs": stage_age_ms,
            "stuck": stuck,
            "stuckReason": stuck_reason,
        })

    recent_events: list[dict[str, Any]] = []
    for row in event_rows:
        try:
            details = json.loads(row[10] or "{}")
        except (TypeError, json.JSONDecodeError):
            details = {}
        recent_events.append({
            "eventId": int(row[0]),
            "at": row[1],
            "mailboxPrefix": str(row[2] or "")[:12],
            "deviceId": row[3],
            "deviceIdPrefix": str(row[3] or "")[:12],
            "role": row[4],
            "action": row[5],
            "direction": row[6],
            "messageId": row[7],
            "type": row[8],
            "result": row[9],
            "details": details if isinstance(details, dict) else {},
        })

    safe_devices = []
    for item in devices or []:
        safe_devices.append({
            "deviceId": item.get("device_id"),
            "deviceIdPrefix": str(item.get("device_id") or "")[:12],
            "role": item.get("role") or "unknown",
            "identified": bool(item.get("identified")),
            "online": bool(item.get("online")),
            "lastSeenAt": item.get("last_seen_at"),
            "lastHttpSeenAt": item.get("last_http_seen_at"),
            "websocketConnections": int(item.get("websocket_connections") or 0),
            "connection": item.get("connection") or "unknown",
            "lastAction": item.get("last_action") or "",
            "mailboxPrefix": item.get("mailbox_prefix") or "",
        })
    known_device_keys = {
        (str(item.get("mailbox_id") or ""), str(item.get("device_id") or "unknown"))
        for item in (devices or [])
    }
    for row in historical_device_rows:
        mailbox_id = str(row[0] or "")
        device_id = str(row[1] or "unknown")
        if (mailbox_id, device_id) in known_device_keys:
            continue
        role = str(row[2] or "unknown")
        safe_devices.append({
            "deviceId": device_id,
            "deviceIdPrefix": device_id[:12],
            "role": role,
            "identified": len(device_id) == 24 and all(ch in "0123456789abcdef" for ch in device_id),
            "online": False,
            "lastSeenAt": row[4],
            "lastHttpSeenAt": row[4],
            "websocketConnections": 0,
            "connection": "offline",
            "lastAction": row[3] or "",
            "mailboxPrefix": mailbox_id[:12],
        })
    safe_devices.sort(key=lambda item: (not item["online"], item["role"], item["deviceId"] or ""))
    return {
        "serverTimeMs": now_ms,
        "stuckAfterMs": stuck_after_ms,
        "onlineWindowMs": 90_000,
        "filters": {"mailbox": mailbox},
        "devices": safe_devices,
        "flows": flows,
        "pendingTotal": sum(item["pendingCount"] for item in flows),
        "pendingMessages": pending_messages,
        "messagesTruncated": sum(item["pendingCount"] for item in flows) > len(pending_messages),
        "recentEvents": recent_events,
    }


def purge_expired(store) -> int:
    now_ms = int(time.time() * 1000)
    with store.transaction() as database:
        cur = database.execute("DELETE FROM relay_messages WHERE expires_at <= ?", (now_ms,))
        return int(cur.rowcount or 0)


def clear_pending(store, mailbox: str = "", direction: str = "") -> int:
    where = ["1=1"]
    args: list[Any] = []
    if mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    if direction in ("to-host", "to-companion"):
        where.append("direction = ?")
        args.append(direction)
    sql = f"DELETE FROM relay_messages WHERE {' AND '.join(where)}"
    with store.transaction() as database:
        cur = database.execute(sql, args)
        return int(cur.rowcount or 0)


# ─── App-like household catalog (entities from sync deltas on the relay) ───

_APP_ENTITY_SECTIONS = {
    "messages": "گفتگو",
    "tasks": "کارها",
    "events": "قرارها",
    "shopping": "خرید",
    "financialAccounts": "حساب‌های مالی",
    "financeTransactions": "تراکنش‌ها",
    "financeBudgets": "بودجه",
    "sharedDebts": "بدهی",
    "recurringTransactions": "تراکنش تکرارشونده",
    "memories": "خاطرات",
    "moodCheckIns": "حال روزانه",
    "specialDates": "مناسبت‌ها",
    "habits": "عادات",
    "watchlistItems": "فیلم و سریال",
    "bookItems": "کتاب‌ها",
    "foodItems": "غذاها",
    "sharedPlaces": "مکان‌ها",
    "coupleProfile": "پروفایل ما",
    "cycleLogs": "چرخه",
    "cycleSettings": "تنظیمات چرخه",
    "heartPulses": "قلب",
    "attachments": "پیوست‌ها",
    "telegramStickerPacks": "استیکر تلگرام",
    "locationShares": "موقعیت",
}


def _iter_recent_envelopes(store, mailbox: str = "", limit: int = 800) -> list[dict[str, Any]]:
    """Newest pending + archived envelopes for catalog extraction."""
    limit = max(50, min(int(limit), 2_500))
    mailbox = (mailbox or "").strip()
    rows: list[tuple] = []
    with store.transaction() as database:
        for table in ("relay_messages", "relay_archive"):
            if mailbox:
                cur = database.execute(
                    f"""
                    SELECT mailbox_id, direction, message_id, created_at, envelope_json
                    FROM {table}
                    WHERE mailbox_id LIKE ?
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (f"{mailbox}%", limit),
                )
            else:
                cur = database.execute(
                    f"""
                    SELECT mailbox_id, direction, message_id, created_at, envelope_json
                    FROM {table}
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (limit,),
                )
            rows.extend(cur.fetchall())
    out: list[dict[str, Any]] = []
    for row in rows:
        try:
            envelope = json.loads(row[4])
        except Exception:  # noqa: BLE001
            continue
        if not isinstance(envelope, dict):
            continue
        out.append(
            {
                "mailbox_id": row[0],
                "direction": row[1],
                "message_id": row[2],
                "created_at": row[3],
                "envelope": envelope,
            }
        )
    return out


def _payload_summary(entity_type: str, payload: dict) -> dict[str, Any]:
    """Human-readable fields for list UI (no giant blobs)."""
    summary: dict[str, Any] = {
        "id": str(payload.get("id") or payload.get("entityId") or "")[:80],
        "entityType": entity_type,
        "deleted": bool(payload.get("deleted") or payload.get("isDeleted")),
        "updatedAt": payload.get("updatedAt") or payload.get("occurredAt") or payload.get("createdAt"),
    }
    title_keys = (
        "title", "name", "text", "note", "category", "kind", "status",
        "mediaType", "assignee", "quantity",
    )
    for key in title_keys:
        val = payload.get(key)
        if val is None or val == "":
            continue
        if key == "text" and isinstance(val, str):
            summary["text"] = val[:500]
        elif key == "title" and isinstance(val, str):
            summary["title"] = val[:200]
        elif key == "name" and isinstance(val, str):
            summary["name"] = val[:200]
        else:
            summary[key] = val if not isinstance(val, str) else val[:120]
    if "amount" in payload:
        summary["amount"] = payload.get("amount")
    if "openingBalance" in payload:
        summary["openingBalance"] = payload.get("openingBalance")
    # Drop binary attachment content
    if entity_type == "attachments":
        summary["mimeType"] = payload.get("mimeType")
        summary["sizeBytes"] = payload.get("sizeBytes") or payload.get("size")
        summary.pop("text", None)
    return summary


def household_catalog(
    store,
    mailbox: str = "",
    entity_type: str = "",
    limit: int = 150,
    scan_limit: int = 1_000,
) -> dict[str, Any]:
    """
    Build an app-like catalog from sync deltas stored on the relay.
    Keeps the latest version of each entityId (by updatedAt / envelope time).
    """
    entity_type = (entity_type or "").strip()
    limit = max(1, min(int(limit), 500))
    scan_limit = max(100, min(int(scan_limit), 3_000))
    envelopes = _iter_recent_envelopes(store, mailbox=mailbox, limit=scan_limit)
    # entityType -> entityId -> record
    latest: dict[str, dict[str, dict[str, Any]]] = {}
    type_counts: dict[str, int] = {}
    scanned_changes = 0

    # Seed from durable admin store (authoritative server-side edits)
    try:
        ensure_admin_entity_table(store)
        with store.transaction() as database:
            rows = database.execute(
                "SELECT entity_type, entity_id, payload_json, actor, updated_at FROM admin_entity_records"
            ).fetchall()
        for row in rows:
            et, eid, payload_json, actor, u_at = row
            try:
                payload = json.loads(payload_json)
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            summary = _payload_summary(str(et), payload)
            summary["id"] = str(eid)
            summary["_sort"] = int(u_at or 0)
            summary["_seenAt"] = int(u_at or 0)
            summary["_direction"] = "admin"
            summary["_mailbox"] = "server"
            summary["_adminActor"] = str(actor or "")
            latest.setdefault(str(et), {})[str(eid)] = summary
            type_counts[str(et)] = type_counts.get(str(et), 0) + 1
            scanned_changes += 1
    except Exception as exc:  # noqa: BLE001
        LOG.warning("admin_entity_seed_failed: %s", exc)

    for item in envelopes:
        envelope = item["envelope"]
        delta = envelope.get("delta")
        changes = delta.get("changes") if isinstance(delta, dict) else None
        if not isinstance(changes, list):
            # Full snapshot style
            for key, label in _APP_ENTITY_SECTIONS.items():
                arr = envelope.get(key)
                if not isinstance(arr, list):
                    continue
                for payload in arr:
                    if not isinstance(payload, dict):
                        continue
                    scanned_changes += 1
                    eid = str(payload.get("id") or "")
                    if not eid:
                        continue
                    type_counts[key] = type_counts.get(key, 0) + 1
                    bucket = latest.setdefault(key, {})
                    prev = bucket.get(eid)
                    u_at = int(payload.get("updatedAt") or item["created_at"] or 0)
                    if prev and int(prev.get("_sort") or 0) >= u_at:
                        continue
                    summary = _payload_summary(key, payload)
                    summary["_sort"] = u_at
                    summary["_seenAt"] = item["created_at"]
                    summary["_direction"] = item["direction"]
                    summary["_mailbox"] = str(item["mailbox_id"])[:12]
                    bucket[eid] = summary
            continue

        for change in changes:
            if not isinstance(change, dict):
                continue
            et = str(change.get("entityType") or "")
            if not et:
                continue
            payload = change.get("payload")
            if not isinstance(payload, dict):
                payload = {"id": change.get("entityId"), "deleted": change.get("deleted")}
            scanned_changes += 1
            type_counts[et] = type_counts.get(et, 0) + 1
            if entity_type and et != entity_type:
                continue
            eid = str(change.get("entityId") or payload.get("id") or "")
            if not eid:
                continue
            bucket = latest.setdefault(et, {})
            u_at = int(
                change.get("updatedAt")
                or payload.get("updatedAt")
                or item["created_at"]
                or 0
            )
            prev = bucket.get(eid)
            if prev and int(prev.get("_sort") or 0) >= u_at:
                continue
            summary = _payload_summary(et, payload)
            summary["id"] = eid
            summary["_sort"] = u_at
            summary["_seenAt"] = item["created_at"]
            summary["_direction"] = item["direction"]
            summary["_mailbox"] = str(item["mailbox_id"])[:12]
            bucket[eid] = summary

    # Unique counts after merge
    unique_counts = {et: len(bucket) for et, bucket in latest.items()}
    sections = []
    for et, label in _APP_ENTITY_SECTIONS.items():
        sections.append(
            {
                "entityType": et,
                "label": label,
                "uniqueCount": unique_counts.get(et, 0),
                "rawSightings": type_counts.get(et, 0),
            }
        )
    for et, cnt in unique_counts.items():
        if et not in _APP_ENTITY_SECTIONS:
            sections.append(
                {
                    "entityType": et,
                    "label": et,
                    "uniqueCount": cnt,
                    "rawSightings": type_counts.get(et, 0),
                }
            )
    sections.sort(key=lambda s: (-s["uniqueCount"], s["label"]))

    items: list[dict[str, Any]] = []
    if entity_type:
        bucket = latest.get(entity_type, {})
        items = sorted(bucket.values(), key=lambda r: -int(r.get("_sort") or 0))[:limit]
        for row in items:
            row.pop("_sort", None)

    return {
        "generatedAt": int(time.time() * 1000),
        "mailbox": mailbox,
        "entityType": entity_type or None,
        "scannedEnvelopes": len(envelopes),
        "scannedChanges": scanned_changes,
        "sections": sections,
        "items": items,
        "note": "داده از بسته‌های همگام‌سازی روی رله استخراج شده؛ آخرین نسخه هر شناسه نمایش داده می‌شود.",
    }


# ─── Admin entity edit → inject sync delta onto relay ───

_DELTA_PROTOCOL = 3
_DELTA_SCHEMA = 1
_EDITABLE_ENTITY_TYPES = frozenset({
    "tasks", "events", "shopping", "messages", "financialAccounts", "financeTransactions",
    "financeBudgets", "sharedDebts", "recurringTransactions", "memories", "moodCheckIns",
    "specialDates", "coupleProfile", "cycleLogs", "cycleSettings", "locationShares",
    "heartPulses", "sharedPlaces", "habits", "watchlistItems", "bookItems",
    "telegramStickerPacks", "telegramStickers",
    # foodItems may be app-only; still allow if present in payloads
    "attachments",
})


def _resolve_mailbox_id(store, mailbox_hint: str = "") -> str:
    hint = (mailbox_hint or "").strip()
    if len(hint) >= 20:
        return hint
    with store.transaction() as database:
        if hint:
            row = database.execute(
                """
                SELECT mailbox_id FROM relay_messages
                WHERE mailbox_id LIKE ?
                ORDER BY created_at DESC LIMIT 1
                """,
                (f"{hint}%",),
            ).fetchone()
            if row:
                return str(row[0])
            row = database.execute(
                """
                SELECT mailbox_id FROM relay_archive
                WHERE mailbox_id LIKE ?
                ORDER BY created_at DESC LIMIT 1
                """,
                (f"{hint}%",),
            ).fetchone()
            if row:
                return str(row[0])
        row = database.execute(
            """
            SELECT mailbox_id, COUNT(*) AS c FROM relay_archive
            GROUP BY mailbox_id ORDER BY c DESC LIMIT 1
            """
        ).fetchone()
        if row:
            return str(row[0])
        row = database.execute(
            "SELECT mailbox_id FROM relay_messages ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        if row:
            return str(row[0])
    raise ValueError("mailbox_not_found")



def ensure_admin_entity_table(store) -> None:
    with store.transaction() as database:
        database.execute(
            """
            CREATE TABLE IF NOT EXISTS admin_entity_records (
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                actor TEXT NOT NULL,
                origin_device_id TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                PRIMARY KEY (entity_type, entity_id)
            )
            """
        )
        database.execute(
            "CREATE INDEX IF NOT EXISTS idx_admin_entity_updated ON admin_entity_records(updated_at)"
        )


def upsert_admin_entity(
    store,
    *,
    entity_type: str,
    entity_id: str,
    payload: dict,
    actor: str,
    origin_device_id: str,
    updated_at: int,
) -> None:
    ensure_admin_entity_table(store)
    now = int(time.time() * 1000)
    with store.transaction() as database:
        row = database.execute(
            "SELECT created_at FROM admin_entity_records WHERE entity_type=? AND entity_id=?",
            (entity_type, entity_id),
        ).fetchone()
        created = int(row[0]) if row else now
        database.execute(
            """
            INSERT OR REPLACE INTO admin_entity_records(
                entity_type, entity_id, payload_json, actor, origin_device_id, updated_at, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                entity_type,
                entity_id,
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                actor,
                origin_device_id,
                updated_at,
                created,
            ),
        )


def inject_entity_edit(
    store,
    *,
    entity_type: str,
    payload: dict,
    actor: str = "host",
    deliver_to: str = "both",
    mailbox_hint: str = "",
    origin_device_id: str = "",
) -> dict[str, Any]:
    """
    Publish an incremental_exchange so both phones apply the entity via normal sync.

    actor: host | companion  → originDeviceId label for conflict resolution
    deliver_to: both | host | companion  → which mailbox direction(s) receive the delta
    """
    entity_type = (entity_type or "").strip()
    if entity_type not in _EDITABLE_ENTITY_TYPES:
        raise ValueError(f"unsupported_entity_type:{entity_type}")
    if not isinstance(payload, dict):
        raise ValueError("payload_must_be_object")
    entity_id = str(payload.get("id") or "").strip()
    if not entity_id:
        raise ValueError("payload_id_required")

    now_ms = int(time.time() * 1000)
    # Ensure LWW wins on phones
    payload = dict(payload)
    payload["id"] = entity_id
    payload["updatedAt"] = max(int(payload.get("updatedAt") or 0), now_ms)
    if "createdAt" not in payload:
        payload["createdAt"] = payload["updatedAt"]

    actor = (actor or "host").strip().lower()
    if actor not in ("host", "companion"):
        actor = "host"
    origin = (origin_device_id or "").strip() or f"admin-{actor}"

    # Always deliver to BOTH phones so the household stays consistent.
    deliver_to = "both"
    directions = ["to-companion", "to-host"]

    mailbox = _resolve_mailbox_id(store, mailbox_hint)
    upsert_admin_entity(
        store,
        entity_type=entity_type,
        entity_id=entity_id,
        payload=payload,
        actor=actor,
        origin_device_id=origin,
        updated_at=int(payload["updatedAt"]),
    )
    change_id = f"admin-{now_ms}-{entity_id}"[:200]
    request_id = f"admin-req-{now_ms}"

    change = {
        "changeId": change_id,
        "entityType": entity_type,
        "entityId": entity_id,
        "changedAt": payload["updatedAt"],
        "originDeviceId": origin,
        "payload": payload,
    }
    delta = {
        "protocol": _DELTA_PROTOCOL,
        "schema": _DELTA_SCHEMA,
        "changes": [change],
        "acknowledgements": [],
    }
    envelope = {
        "type": "incremental_exchange",
        "requestId": request_id,
        "sentAt": now_ms,
        "delta": delta,
        "adminEdit": True,
        "adminActor": actor,
    }

    expires_at = now_ms + 7 * 24 * 60 * 60 * 1000  # 7 days
    published: list[dict[str, Any]] = []
    for direction in directions:
        message_id = f"admin-{actor}-{direction}-{now_ms}-{entity_id}"[:200]
        message = {
            "messageId": message_id,
            "createdAt": now_ms,
            "expiresAt": expires_at,
            "envelope": envelope,
            "correlationId": None,
        }
        created = store.publish(mailbox, direction, message)
        published.append(
            {
                "direction": direction,
                "messageId": message_id,
                "stored": bool(created),
            }
        )
        try:
            notify_waiters = None  # server module wakes via store.publish → notify_waiters
        except Exception:  # noqa: BLE001
            pass

    LOG.info(
        "admin_inject entity=%s id=%s actor=%s dirs=%s mailbox=%s",
        entity_type,
        entity_id[:16],
        actor,
        [p["direction"] for p in published],
        mailbox[:12],
    )
    return {
        "ok": True,
        "entityType": entity_type,
        "entityId": entity_id,
        "changeId": change_id,
        "actor": actor,
        "originDeviceId": origin,
        "mailboxPrefix": mailbox[:12],
        "published": published,
        "payloadUpdatedAt": payload["updatedAt"],
        "hint": "به هر دو گوشی (میزبان و همراه) ارسال شد و روی سرور ذخیره شد. گوشی‌های آنلاین فوری اعمال می‌کنند.",
    }
