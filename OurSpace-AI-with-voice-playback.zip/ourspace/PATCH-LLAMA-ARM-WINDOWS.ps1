$f = "C:\Android\llama.cpp\ggml\src\ggml-cpu\CMakeLists.txt"
if (-not (Test-Path $f)) { Write-Host "Missing $f"; exit 1 }
$c = Get-Content -Raw $f
$c2 = $c.Replace('message(FATAL_ERROR "Failed to get ARM features")', 'message(WARNING "Failed to get ARM features (ignored for Android cross-compile)")')
$c2 = $c2.Replace('INPUT_FILE "/dev/null"', 'INPUT_FILE "NUL"')
if ($c -eq $c2) { Write-Host "No changes needed (already patched or text differs)" }
else {
  [System.IO.File]::WriteAllText($f, $c2)
  Write-Host "Patched: $f"
}
